// uGUI core: RectTransform, Canvas, CanvasRenderer, CanvasGroup, Sprite, RectTransformUtility.
using System;
using System.Collections.Generic;
using Anvil;

namespace UnityEngine
{
    // Like Unity, m_AnchoredPosition / sizeDelta / anchors / pivot are the stored values; localPosition follows them
    // (and moving the transform directly updates anchoredPosition on the next sync).
    public sealed class RectTransform : Transform
    {
        public enum Edge { Left = 0, Right = 1, Top = 2, Bottom = 3 }
        public enum Axis { Horizontal = 0, Vertical = 1 }
        public delegate void ReapplyDrivenProperties(RectTransform driven);
#pragma warning disable 67
        public static event ReapplyDrivenProperties reapplyDrivenProperties;
#pragma warning restore 67

        internal Vector2 m_AnchorMin = new Vector2(0.5f, 0.5f), m_AnchorMax = new Vector2(0.5f, 0.5f);
        internal Vector2 m_AnchoredPosition, m_SizeDelta = new Vector2(100, 100), m_Pivot = new Vector2(0.5f, 0.5f);
        internal Vector2 m_SyncedLP;
        internal RectTransform() { }

        RectTransform ParentRT => m_Parent as RectTransform;
        internal Vector2 SizeInternal()
        {
            var p = ParentRT;
            Vector2 ps = p != null ? p.SizeInternal() : Vector2.zero;
            return new Vector2(ps.x * (m_AnchorMax.x - m_AnchorMin.x) + m_SizeDelta.x, ps.y * (m_AnchorMax.y - m_AnchorMin.y) + m_SizeDelta.y);
        }
        // the anchor reference point, relative to the parent's pivot
        internal Vector2 AnchorRef()
        {
            var p = ParentRT;
            if (p == null) return Vector2.zero;
            var ps = p.SizeInternal();
            float ax = m_AnchorMin.x + (m_AnchorMax.x - m_AnchorMin.x) * m_Pivot.x, ay = m_AnchorMin.y + (m_AnchorMax.y - m_AnchorMin.y) * m_Pivot.y;
            return new Vector2(-ps.x * p.m_Pivot.x + ax * ps.x, -ps.y * p.m_Pivot.y + ay * ps.y);
        }
        internal void InitFromLocalPosition()
        {
            var lp = new Vector2(m_LocalPosition.x, m_LocalPosition.y);
            m_AnchoredPosition = lp - AnchorRef();
            m_SyncedLP = lp;
        }
        // brings localPosition and anchoredPosition into agreement
        internal void Sync()
        {
            var cur = new Vector2(m_LocalPosition.x, m_LocalPosition.y);
            var r = AnchorRef();
            if (cur.x != m_SyncedLP.x || cur.y != m_SyncedLP.y) m_AnchoredPosition = cur - r; // moved through the Transform API
            var want = m_AnchoredPosition + r;
            if (want.x != cur.x || want.y != cur.y) { m_LocalPosition = new Vector3(want.x, want.y, m_LocalPosition.z); MarkDirty(); }
            m_SyncedLP = want;
        }
        internal void SyncTree() { Sync(); foreach (var c in m_Children) if (c is RectTransform r) r.SyncTree(); else c.SyncChildrenRects(); }

        public Vector2 anchorMin { get { Sync(); return m_AnchorMin; } set { Sync(); m_AnchorMin = value; Sync(); Changed(); } }
        public Vector2 anchorMax { get { Sync(); return m_AnchorMax; } set { Sync(); m_AnchorMax = value; Sync(); Changed(); } }
        public Vector2 anchoredPosition { get { Sync(); return m_AnchoredPosition; } set { Sync(); m_AnchoredPosition = value; Sync(); } }
        public Vector2 sizeDelta { get { Sync(); return m_SizeDelta; } set { Sync(); m_SizeDelta = value; Sync(); Changed(); } }
        public Vector2 pivot { get { Sync(); return m_Pivot; } set { Sync(); m_Pivot = value; Sync(); Changed(); } }
        public Vector3 anchoredPosition3D
        {
            get { Sync(); return new Vector3(m_AnchoredPosition.x, m_AnchoredPosition.y, m_LocalPosition.z); }
            set { Sync(); m_AnchoredPosition = new Vector2(value.x, value.y); m_LocalPosition.z = value.z; MarkDirty(); Sync(); }
        }
        public Vector2 offsetMin
        {
            get { Sync(); return m_AnchoredPosition - Vector2.Scale(m_SizeDelta, m_Pivot); }
            set { Sync(); var off = value - (m_AnchoredPosition - Vector2.Scale(m_SizeDelta, m_Pivot)); m_SizeDelta -= off; m_AnchoredPosition += Vector2.Scale(off, Vector2.one - m_Pivot); Sync(); Changed(); }
        }
        public Vector2 offsetMax
        {
            get { Sync(); return m_AnchoredPosition + Vector2.Scale(m_SizeDelta, Vector2.one - m_Pivot); }
            set { Sync(); var off = value - (m_AnchoredPosition + Vector2.Scale(m_SizeDelta, Vector2.one - m_Pivot)); m_SizeDelta += off; m_AnchoredPosition += Vector2.Scale(off, m_Pivot); Sync(); Changed(); }
        }
        public Rect rect { get { var s = SizeInternal(); return new Rect(-s.x * m_Pivot.x, -s.y * m_Pivot.y, s.x, s.y); } }
        public Object drivenByObject => null;
        internal void Changed() { foreach (var c in m_Children) if (c is RectTransform r) r.Sync(); UI.UIRuntime.MarkLayoutDirty(); }

        public void GetLocalCorners(Vector3[] fourCornersArray)
        {
            if (fourCornersArray == null || fourCornersArray.Length < 4) { Debug.LogError("Calling GetLocalCorners with an array that is null or has less than 4 elements."); return; }
            var r = rect;
            fourCornersArray[0] = new Vector3(r.xMin, r.yMin, 0); fourCornersArray[1] = new Vector3(r.xMin, r.yMax, 0);
            fourCornersArray[2] = new Vector3(r.xMax, r.yMax, 0); fourCornersArray[3] = new Vector3(r.xMax, r.yMin, 0);
        }
        public void GetWorldCorners(Vector3[] fourCornersArray)
        {
            if (fourCornersArray == null || fourCornersArray.Length < 4) { Debug.LogError("Calling GetWorldCorners with an array that is null or has less than 4 elements."); return; }
            SyncUp();
            GetLocalCorners(fourCornersArray);
            var m = localToWorldMatrix;
            for (int i = 0; i < 4; i++) fourCornersArray[i] = m.MultiplyPoint(fourCornersArray[i]);
        }
        internal void SyncUp() { var p = ParentRT; if (p != null) p.SyncUp(); Sync(); }
        public void SetSizeWithCurrentAnchors(Axis axis, float size)
        {
            Sync();
            int i = (int)axis;
            var p = ParentRT; Vector2 ps = p != null ? p.SizeInternal() : Vector2.zero;
            var sd = m_SizeDelta; sd[i] = size - ps[i] * (m_AnchorMax[i] - m_AnchorMin[i]); m_SizeDelta = sd;
            Sync(); Changed();
        }
        public void SetInsetAndSizeFromParentEdge(Edge edge, float inset, float size)
        {
            Sync();
            int axis = edge == Edge.Top || edge == Edge.Bottom ? 1 : 0;
            bool end = edge == Edge.Top || edge == Edge.Right;
            float a = end ? 1 : 0;
            var amin = m_AnchorMin; amin[axis] = a; m_AnchorMin = amin;
            var amax = m_AnchorMax; amax[axis] = a; m_AnchorMax = amax;
            var sd = m_SizeDelta; sd[axis] = size; m_SizeDelta = sd;
            var ap = m_AnchoredPosition; ap[axis] = end ? -inset - size * (1 - m_Pivot[axis]) : inset + size * m_Pivot[axis]; m_AnchoredPosition = ap;
            Sync(); Changed();
        }
        public void ForceUpdateRectTransforms() => SyncTree();

        internal override void CopyFromInternal(Component src)
        {
            if (src is RectTransform s) { m_AnchorMin = s.m_AnchorMin; m_AnchorMax = s.m_AnchorMax; m_AnchoredPosition = s.m_AnchoredPosition; m_SizeDelta = s.m_SizeDelta; m_Pivot = s.m_Pivot; m_SyncedLP = new Vector2(m_LocalPosition.x, m_LocalPosition.y); }
        }
    }

    public sealed class Sprite : Object
    {
        internal Texture2D m_Texture; internal Rect m_Rect; internal Vector2 m_Pivot; internal float m_PPU = 100; internal Vector4 m_Border;
        Sprite() { }
        public static Sprite Create(Texture2D texture, Rect rect, Vector2 pivot) => Create(texture, rect, pivot, 100f, 0, SpriteMeshType.Tight, Vector4.zero, false);
        public static Sprite Create(Texture2D texture, Rect rect, Vector2 pivot, float pixelsPerUnit) => Create(texture, rect, pivot, pixelsPerUnit, 0, SpriteMeshType.Tight, Vector4.zero, false);
        public static Sprite Create(Texture2D texture, Rect rect, Vector2 pivot, float pixelsPerUnit, uint extrude) => Create(texture, rect, pivot, pixelsPerUnit, extrude, SpriteMeshType.Tight, Vector4.zero, false);
        public static Sprite Create(Texture2D texture, Rect rect, Vector2 pivot, float pixelsPerUnit, uint extrude, SpriteMeshType meshType) => Create(texture, rect, pivot, pixelsPerUnit, extrude, meshType, Vector4.zero, false);
        public static Sprite Create(Texture2D texture, Rect rect, Vector2 pivot, float pixelsPerUnit, uint extrude, SpriteMeshType meshType, Vector4 border) => Create(texture, rect, pivot, pixelsPerUnit, extrude, meshType, border, false);
        public static Sprite Create(Texture2D texture, Rect rect, Vector2 pivot, float pixelsPerUnit, uint extrude, SpriteMeshType meshType, Vector4 border, bool generateFallbackPhysicsShape)
        {
            if (texture == null) { Debug.LogError("Sprite.Create: texture is null"); return null; }
            return new Sprite { m_Texture = texture, m_Rect = rect, m_Pivot = new Vector2(pivot.x * rect.width, pivot.y * rect.height), m_PPU = pixelsPerUnit, m_Border = border, m_Name = texture.name };
        }
        public Texture2D texture => m_Texture;
        public Rect rect => m_Rect;
        public Rect textureRect => m_Rect;
        public Vector2 textureRectOffset => Vector2.zero;
        public Vector2 pivot => m_Pivot;
        public float pixelsPerUnit => m_PPU;
        public Vector4 border => m_Border;
        public bool packed => false;
        public Bounds bounds => new Bounds(new Vector3((m_Rect.width * 0.5f - m_Pivot.x) / m_PPU, (m_Rect.height * 0.5f - m_Pivot.y) / m_PPU, 0), new Vector3(m_Rect.width / m_PPU, m_Rect.height / m_PPU, 0));
        public Texture2D associatedAlphaSplitTexture => null;
        public Vector2[] uv { get { float w = Mathf.Max(1, m_Texture.width), h = Mathf.Max(1, m_Texture.height); return new[] { new Vector2(m_Rect.xMin / w, m_Rect.yMax / h), new Vector2(m_Rect.xMax / w, m_Rect.yMax / h), new Vector2(m_Rect.xMin / w, m_Rect.yMin / h), new Vector2(m_Rect.xMax / w, m_Rect.yMin / h) }; } }
        public Vector2[] vertices { get { var b = bounds; return new[] { new Vector2(b.min.x, b.max.y), new Vector2(b.max.x, b.max.y), new Vector2(b.min.x, b.min.y), new Vector2(b.max.x, b.min.y) }; } }
        public ushort[] triangles => new ushort[] { 0, 1, 3, 0, 3, 2 };
    }
    public enum SpriteMeshType { FullRect = 0, Tight = 1 }
    public enum SpriteAlignment { Center = 0, TopLeft = 1, TopCenter = 2, TopRight = 3, LeftCenter = 4, RightCenter = 5, BottomLeft = 6, BottomCenter = 7, BottomRight = 8, Custom = 9 }

    public interface ICanvasRaycastFilter { bool IsRaycastLocationValid(Vector2 sp, Camera eventCamera); }

    [DisallowMultipleComponent]
    public sealed class Canvas : Behaviour
    {
        public delegate void WillRenderCanvases();
        public static event WillRenderCanvases willRenderCanvases;
        public static event WillRenderCanvases preWillRenderCanvases;
        internal static void FireWillRender() { preWillRenderCanvases?.Invoke(); willRenderCanvases?.Invoke(); }

        public RenderMode renderMode { get; set; } = RenderMode.ScreenSpaceOverlay;
        public Camera worldCamera { get; set; }
        public float planeDistance { get; set; } = 100f;
        public bool pixelPerfect { get; set; }
        public bool overrideSorting { get; set; }
        public bool overridePixelPerfect { get; set; }
        public int sortingOrder { get; set; }
        public int sortingLayerID { get; set; }
        public string sortingLayerName { get; set; } = "Default";
        public int targetDisplay { get; set; }
        public float referencePixelsPerUnit { get; set; } = 100f;
        public float normalizedSortingGridSize { get; set; } = 0.1f;
        public AdditionalCanvasShaderChannels additionalShaderChannels { get; set; }
        public bool vertexColorAlwaysGammaSpace { get; set; }
        internal float m_ScaleFactor = 1f;
        public float scaleFactor { get => m_ScaleFactor; set => m_ScaleFactor = Mathf.Max(0.0001f, value); }
        public bool isRootCanvas { get { var p = transform.parent; return p == null || p.GetComponentInParent<Canvas>() == null; } }
        public Canvas rootCanvas { get { Canvas r = this; for (var t = transform.parent; t != null; t = t.parent) { var c = t.GetComponent<Canvas>(); if (c != null && c.enabled) r = c; } return r; } }
        public int renderOrder => 0;
        public int cachedSortingLayerValue => 0;
        public Rect pixelRect => new Rect(0, 0, Screen.width, Screen.height);
        public float renderingDisplaySize => Screen.height;
        public Vector2 renderingDisplaySizeVector => new Vector2(Screen.width, Screen.height);
        public static void ForceUpdateCanvases() => UI.UIRuntime.LayoutAll();
        public static Material GetDefaultCanvasMaterial() => Material.DefaultMaterial;
        public static Material GetETC1SupportedCanvasMaterial() => Material.DefaultMaterial;
        internal override void OnAddedInternal() { m_GameObject.ConvertToRect(); UI.UIRuntime.MarkLayoutDirty(); }
    }

    public sealed class CanvasRenderer : Component
    {
        internal Color m_Color = Color.white; internal float m_Alpha = 1f;
        public bool hasPopInstruction { get; set; }
        public int materialCount { get; set; }
        public int popMaterialCount { get; set; }
        public int absoluteDepth => 0;
        public bool hasMoved => false;
        public bool cullTransparentMesh { get; set; }
        public bool hasRectClipping => false;
        public int relativeDepth => 0;
        public bool cull { get; set; }
        public Vector2 clippingSoftness { get; set; }
        public void SetColor(Color color) { m_Color = color; }
        public Color GetColor() => m_Color;
        public void SetAlpha(float alpha) { m_Alpha = alpha; }
        public float GetAlpha() => m_Alpha;
        public float GetInheritedAlpha() { float a = m_Alpha; for (var t = transform; t != null; t = t.parent) { var g = t.GetComponent<CanvasGroup>(); if (g != null && g.enabled) { a *= g.alpha; if (g.ignoreParentGroups) break; } } return a; }
        public void EnableRectClipping(Rect rect) { }
        public void DisableRectClipping() { }
        public void SetMaterial(Material material, int index) { }
        public void SetMaterial(Material material, Texture texture) { }
        public Material GetMaterial() => null;
        public Material GetMaterial(int index) => null;
        public void SetTexture(Texture texture) { }
        public void SetMesh(Mesh mesh) { }
        public Mesh GetMesh() => null;
        public void Clear() { }
    }

    [DisallowMultipleComponent]
    public sealed class CanvasGroup : Behaviour, ICanvasRaycastFilter
    {
        public float alpha { get; set; } = 1f;
        public bool interactable { get; set; } = true;
        public bool blocksRaycasts { get; set; } = true;
        public bool ignoreParentGroups { get; set; }
        public bool IsRaycastLocationValid(Vector2 sp, Camera eventCamera) => blocksRaycasts;
    }

    public sealed class RectTransformUtility
    {
        RectTransformUtility() { }
        static Vector3 ToWorldPoint(Vector2 screenPoint, Camera cam, RectTransform rect)
        {
            // overlay canvases live in screen space; others need a camera ray onto the rect's plane
            if (cam == null) return new Vector3(screenPoint.x, screenPoint.y, rect.position.z);
            var ray = cam.ScreenPointToRay(new Vector3(screenPoint.x, screenPoint.y, 0));
            var plane = new Plane(rect.rotation * Vector3.back, rect.position);
            if (plane.Raycast(ray, out float d)) return ray.GetPoint(d);
            return rect.position;
        }
        public static bool ScreenPointToWorldPointInRectangle(RectTransform rect, Vector2 screenPoint, Camera cam, out Vector3 worldPoint)
        {
            worldPoint = Vector3.zero;
            if (rect == null) return false;
            if (cam != null)
            {
                var ray = cam.ScreenPointToRay(new Vector3(screenPoint.x, screenPoint.y, 0));
                var plane = new Plane(rect.rotation * Vector3.back, rect.position);
                if (!plane.Raycast(ray, out float d)) return false;
                worldPoint = ray.GetPoint(d); return true;
            }
            worldPoint = new Vector3(screenPoint.x, screenPoint.y, rect.position.z);
            return true;
        }
        public static bool ScreenPointToLocalPointInRectangle(RectTransform rect, Vector2 screenPoint, Camera cam, out Vector2 localPoint)
        {
            localPoint = Vector2.zero;
            if (!ScreenPointToWorldPointInRectangle(rect, screenPoint, cam, out var wp)) return false;
            rect.SyncUp();
            var lp = rect.InverseTransformPoint(wp);
            localPoint = new Vector2(lp.x, lp.y);
            return true;
        }
        public static bool RectangleContainsScreenPoint(RectTransform rect, Vector2 screenPoint) => RectangleContainsScreenPoint(rect, screenPoint, null);
        public static bool RectangleContainsScreenPoint(RectTransform rect, Vector2 screenPoint, Camera cam) => RectangleContainsScreenPoint(rect, screenPoint, cam, Vector4.zero);
        public static bool RectangleContainsScreenPoint(RectTransform rect, Vector2 screenPoint, Camera cam, Vector4 offset)
        {
            if (rect == null) return false;
            if (cam == null) cam = UI.UIRuntime.CameraFor(rect);
            if (!ScreenPointToLocalPointInRectangle(rect, screenPoint, cam, out var lp)) return false;
            var r = rect.rect;
            return lp.x >= r.xMin - offset.x && lp.x <= r.xMax + offset.z && lp.y >= r.yMin - offset.y && lp.y <= r.yMax + offset.w;
        }
        public static Vector2 WorldToScreenPoint(Camera cam, Vector3 worldPoint)
        {
            if (cam == null) return new Vector2(worldPoint.x, worldPoint.y);
            var s = cam.WorldToScreenPoint(worldPoint); return new Vector2(s.x, s.y);
        }
        public static Vector2 PixelAdjustPoint(Vector2 point, Transform elementTransform, Canvas canvas) => new Vector2(Mathf.Round(point.x), Mathf.Round(point.y));
        public static Rect PixelAdjustRect(RectTransform rectTransform, Canvas canvas) => rectTransform.rect;
        public static Bounds CalculateRelativeRectTransformBounds(Transform root, Transform child)
        {
            var rts = child.GetComponentsInChildren<RectTransform>();
            if (rts.Length == 0) return new Bounds(Vector3.zero, Vector3.zero);
            var corners = new Vector3[4]; var toLocal = root.worldToLocalMatrix;
            var min = new Vector3(float.MaxValue, float.MaxValue, float.MaxValue); var max = -min;
            foreach (var r in rts) { r.GetWorldCorners(corners); foreach (var c in corners) { var l = toLocal.MultiplyPoint3x4(c); min = Vector3.Min(min, l); max = Vector3.Max(max, l); } }
            var b = new Bounds(min, Vector3.zero); b.Encapsulate(max); return b;
        }
        public static Bounds CalculateRelativeRectTransformBounds(Transform trans) => CalculateRelativeRectTransformBounds(trans, trans);
        public static void FlipLayoutOnAxis(RectTransform rect, int axis, bool keepPositioning, bool recursive)
        {
            if (rect == null) return;
            if (recursive) foreach (Transform c in rect) if (c is RectTransform cr) FlipLayoutOnAxis(cr, axis, false, true);
            var p = rect.pivot; p[axis] = 1 - p[axis]; rect.pivot = p;
            if (keepPositioning) return;
            var ap = rect.anchoredPosition; ap[axis] = -ap[axis]; rect.anchoredPosition = ap;
            var amin = rect.anchorMin; var amax = rect.anchorMax; float t = amin[axis]; amin[axis] = 1 - amax[axis]; amax[axis] = 1 - t; rect.anchorMin = amin; rect.anchorMax = amax;
        }
        public static void FlipLayoutAxes(RectTransform rect, bool keepPositioning, bool recursive)
        {
            if (rect == null) return;
            if (recursive) foreach (Transform c in rect) if (c is RectTransform cr) FlipLayoutAxes(cr, false, true);
            Vector2 S(Vector2 v) => new Vector2(v.y, v.x);
            rect.pivot = S(rect.pivot); rect.sizeDelta = S(rect.sizeDelta);
            if (keepPositioning) return;
            rect.anchoredPosition = S(rect.anchoredPosition); rect.anchorMin = S(rect.anchorMin); rect.anchorMax = S(rect.anchorMax);
        }
        public static Ray ScreenPointToRay(Camera cam, Vector2 screenPos) => cam != null ? cam.ScreenPointToRay(new Vector3(screenPos.x, screenPos.y, 0)) : new Ray(new Vector3(screenPos.x, screenPos.y, -100), Vector3.forward);
    }
}
