// Anvil — body tracking from the webcam (MediaPipe Pose, running in the browser; the video never leaves the computer).
// Unity has no built-in body tracking: in Unity the same script would read a MediaPipe-for-Unity plugin instead.
using System;
using UnityEngine;

namespace Anvil
{
    /// MediaPipe Pose's body points (the ones a robot needs; any index 0–32 works too)
    public enum PoseLandmark
    {
        Nose = 0, LeftShoulder = 11, RightShoulder = 12, LeftElbow = 13, RightElbow = 14,
        LeftWrist = 15, RightWrist = 16, LeftHip = 23, RightHip = 24, LeftKnee = 25, RightKnee = 26, LeftAnkle = 27, RightAnkle = 28,
    }

    /// <summary>
    /// The webcam body tracker. Call <see cref="Start"/> once (the browser asks for the camera), then read
    /// points with <see cref="TryGetLandmark"/> every frame.
    /// Positions are in metres, centred between the hips, seen like a mirror:
    /// x = towards your right, y = up, z = towards the camera.
    /// </summary>
    public static class BodyTracking
    {
        internal static Action<bool> s_Start;
        internal static Action s_Stop;
        internal static Func<double[]> s_Get;
        static double[] s_Data = Array.Empty<double>();
        static int s_Frame = -1;
        static bool s_Started;

        /// Turns the camera and tracker on (does nothing if already on). accurate: the bigger model (steadier, slower).
        public static void Start(bool accurate = false) { s_Started = true; s_Start?.Invoke(accurate); }
        public static void Stop() { s_Started = false; s_Stop?.Invoke(); }
        internal static void ResetForPlay() { if (s_Started) Stop(); s_Data = Array.Empty<double>(); s_Frame = -1; }

        static void Refresh()
        {
            if (s_Frame == Time.frameCount) return;
            s_Frame = Time.frameCount;
            try { s_Data = s_Get?.Invoke() ?? Array.Empty<double>(); } catch { s_Data = Array.Empty<double>(); }
        }

        /// true while it can see a person (and the last result is less than half a second old)
        public static bool IsTracking { get { Refresh(); return s_Data.Length > 2 && s_Data[0] == 3 && s_Data[1] < 500; } }
        public static bool IsRunning { get { Refresh(); return s_Data.Length > 0 && s_Data[0] >= 1; } }
        /// a short description for on-screen labels
        public static string Status
        {
            get
            {
                Refresh();
                if (s_Data.Length == 0) return "off";
                switch ((int)s_Data[0])
                {
                    case -1: return "error (see the Console)";
                    case 1: return "starting camera…";
                    case 2: return "camera on, looking for you";
                    case 3: return s_Data[1] < 500 ? "tracking" : "lost you";
                    default: return "off";
                }
            }
        }

        /// A body point: position (metres, mirror space: x your right, y up, z towards the camera) and how sure the
        /// tracker is that it can see it (0–1). Returns false when nobody is tracked.
        public static bool TryGetLandmark(PoseLandmark which, out Vector3 position, out float visibility) => TryGetLandmark((int)which, out position, out visibility);
        public static bool TryGetLandmark(int index, out Vector3 position, out float visibility)
        {
            position = Vector3.zero; visibility = 0;
            if (!IsTracking || index < 0 || index > 32) return false;
            int o = 2 + index * 6;
            if (o + 5 >= s_Data.Length) return false;
            // MediaPipe: x to the image's right, y down, z away from the camera. As a mirror: flip all three.
            position = new Vector3(-(float)s_Data[o], -(float)s_Data[o + 1], -(float)s_Data[o + 2]);
            visibility = (float)s_Data[o + 3];
            return true;
        }
        /// where the point is in the camera picture (0–1, mirrored like the preview: 0,0 bottom-left)
        public static bool TryGetScreenPoint(PoseLandmark which, out Vector2 point)
        {
            point = Vector2.zero;
            if (!IsTracking) return false;
            int o = 2 + (int)which * 6;
            if (o + 5 >= s_Data.Length) return false;
            point = new Vector2(1f - (float)s_Data[o + 4], 1f - (float)s_Data[o + 5]);
            return true;
        }
    }
}
