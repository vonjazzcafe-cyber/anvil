// Anvil — ParticleSystem: Unity's module API (structs that write through to the system) with a CPU simulation of
// emission, bursts, shapes, gravity, forces, velocity/colour/size/rotation over lifetime, noise and collisions.
using System;
using System.Collections.Generic;
using Anvil;

namespace UnityEngine
{
    public enum ParticleSystemSimulationSpace { Local = 0, World = 1, Custom = 2 }
    public enum ParticleSystemScalingMode { Hierarchy = 0, Local = 1, Shape = 2 }
    public enum ParticleSystemStopBehavior { StopEmittingAndClear = 0, StopEmitting = 1 }
    public enum ParticleSystemStopAction { None = 0, Disable = 1, Destroy = 2, Callback = 3 }
    public enum ParticleSystemCullingMode { Automatic = 0, PauseAndCatchup = 1, Pause = 2, AlwaysSimulate = 3 }
    public enum ParticleSystemRingBufferMode { Disabled = 0, PauseUntilReplaced = 1, LoopUntilReplaced = 2 }
    public enum ParticleSystemEmitterVelocityMode { Transform = 0, Rigidbody = 1, Custom = 2 }
    public enum ParticleSystemShapeType { Sphere = 0, SphereShell = 1, Hemisphere = 2, HemisphereShell = 3, Cone = 4, Box = 5, Mesh = 6, ConeShell = 7, ConeVolume = 8, ConeVolumeShell = 9, Circle = 10, CircleEdge = 11, SingleSidedEdge = 12, MeshRenderer = 13, SkinnedMeshRenderer = 14, BoxShell = 15, BoxEdge = 16, Donut = 17, Rectangle = 18, Sprite = 19, SpriteRenderer = 20 }
    public enum ParticleSystemShapeMultiModeValue { Random = 0, Loop = 1, PingPong = 2, BurstSpread = 3 }
    public enum ParticleSystemCurveMode { Constant = 0, Curve = 1, TwoCurves = 2, TwoConstants = 3 }
    public enum ParticleSystemGradientMode { Color = 0, Gradient = 1, TwoColors = 2, TwoGradients = 3, RandomColor = 4 }
    public enum ParticleSystemRenderMode { Billboard = 0, Stretch = 1, HorizontalBillboard = 2, VerticalBillboard = 3, Mesh = 4, None = 5 }
    public enum ParticleSystemRenderSpace { View = 0, World = 1, Local = 2, Facing = 3, Velocity = 4 }
    public enum ParticleSystemSortMode { None = 0, Distance = 1, OldestInFront = 2, YoungestInFront = 3, Depth = 4 }
    public enum ParticleSystemCollisionType { Planes = 0, World = 1 }
    public enum ParticleSystemCollisionMode { Collision3D = 0, Collision2D = 1 }
    public enum ParticleSystemCollisionQuality { High = 0, Medium = 1, Low = 2 }
    public enum ParticleSystemOverlapAction { Ignore = 0, Kill = 1, Callback = 2 }
    public enum ParticleSystemInheritVelocityMode { Initial = 0, Current = 1 }
    public enum ParticleSystemNoiseQuality { Low = 0, Medium = 1, High = 2 }
    public enum ParticleSystemAnimationMode { Grid = 0, Sprites = 1 }
    public enum ParticleSystemAnimationType { WholeSheet = 0, SingleRow = 1 }
    public enum ParticleSystemSubEmitterType { Birth = 0, Collision = 1, Death = 2, Trigger = 3, Manual = 4 }
    [Flags] public enum ParticleSystemSubEmitterProperties { InheritNothing = 0, InheritEverything = 31, InheritColor = 1, InheritSize = 2, InheritRotation = 4, InheritLifetime = 8, InheritDuration = 16 }
    public enum ParticleSystemTrailMode { PerParticle = 0, Ribbon = 1 }
    public enum ParticleSystemTrailTextureMode { Stretch = 0, Tile = 1, DistributePerSegment = 2, RepeatPerSegment = 3 }
    public enum ParticleSystemCustomData { Custom1 = 0, Custom2 = 1 }
    public enum ParticleSystemMeshShapeType { Vertex = 0, Edge = 1, Triangle = 2 }
    public enum ParticleSystemShapeTextureChannel { Red = 0, Green = 1, Blue = 2, Alpha = 3 }
    public enum ParticleSystemVertexStream { Position = 0, Normal = 1, Tangent = 2, Color = 3, UV = 4 }
    public enum ParticleSystemGameObjectFilter { LayerMask = 0, List = 1, LayerMaskAndList = 2 }
    public enum ParticleSystemForceFieldShape { Sphere = 0, Hemisphere = 1, Cylinder = 2, Box = 3 }
    public enum ParticleSystemTriggerEventType { Inside = 0, Outside = 1, Enter = 2, Exit = 3 }

    public sealed class ParticleSystemRenderer : Renderer
    {
        internal override bool UsesDefaultMaterial => false;
        public ParticleSystemRenderMode renderMode { get; set; } = ParticleSystemRenderMode.Billboard;
        public float cameraVelocityScale { get; set; }
        public float velocityScale { get; set; }
        public float lengthScale { get; set; } = 2f;
        public float normalDirection { get; set; } = 1f;
        public float sortingFudge { get; set; }
        public float minParticleSize { get; set; }
        public float maxParticleSize { get; set; } = 0.5f;
        public ParticleSystemSortMode sortMode { get; set; }
        public ParticleSystemRenderSpace alignment { get; set; } = ParticleSystemRenderSpace.View;
        public Vector3 pivot { get; set; }
        public Vector3 flip { get; set; }
        public bool allowRoll { get; set; } = true;
        public bool enableGPUInstancing { get; set; } = true;
        public bool applyActiveColorSpace { get; set; } = true;
        public Mesh mesh { get; set; }
        public int meshCount => mesh != null ? 1 : 0;
        public Material trailMaterial { get; set; }
        public SpriteMaskInteraction maskInteraction { get; set; }
        public float shadowBias { get; set; }
        public int activeVertexStreamsCount => 3;
        public void SetActiveVertexStreams(List<ParticleSystemVertexStream> streams) { }
        public void GetActiveVertexStreams(List<ParticleSystemVertexStream> streams) { streams.Clear(); streams.Add(ParticleSystemVertexStream.Position); streams.Add(ParticleSystemVertexStream.Color); streams.Add(ParticleSystemVertexStream.UV); }
        public int GetMeshes(Mesh[] meshes) { if (meshes.Length > 0 && mesh != null) { meshes[0] = mesh; return 1; } return 0; }
        public void SetMeshes(Mesh[] meshes) { mesh = meshes != null && meshes.Length > 0 ? meshes[0] : null; }
        public void BakeMesh(Mesh mesh, bool useTransform = false) { }
        public void BakeTrailsMesh(Mesh mesh, bool useTransform = false) { }
        internal override void OnAddedInternal() { if (m_Materials.Length == 0) m_SharedMaterial = ParticleSystem.DefaultMaterial; }
    }

    [RequireComponent(typeof(Transform))]
    public sealed partial class ParticleSystem : Component
    {
        // ---------------- value types ----------------
        [Serializable]
        public struct MinMaxCurve
        {
            ParticleSystemCurveMode m_Mode; float m_CurveMultiplier; AnimationCurve m_CurveMin, m_CurveMax; float m_ConstantMin, m_ConstantMax;
            public MinMaxCurve(float constant) { m_Mode = ParticleSystemCurveMode.Constant; m_CurveMultiplier = 0; m_CurveMin = null; m_CurveMax = null; m_ConstantMin = 0; m_ConstantMax = constant; }
            public MinMaxCurve(float multiplier, AnimationCurve curve) { m_Mode = ParticleSystemCurveMode.Curve; m_CurveMultiplier = multiplier; m_CurveMin = null; m_CurveMax = curve; m_ConstantMin = 0; m_ConstantMax = 0; }
            public MinMaxCurve(float multiplier, AnimationCurve min, AnimationCurve max) { m_Mode = ParticleSystemCurveMode.TwoCurves; m_CurveMultiplier = multiplier; m_CurveMin = min; m_CurveMax = max; m_ConstantMin = 0; m_ConstantMax = 0; }
            public MinMaxCurve(float min, float max) { m_Mode = ParticleSystemCurveMode.TwoConstants; m_CurveMultiplier = 0; m_CurveMin = null; m_CurveMax = null; m_ConstantMin = min; m_ConstantMax = max; }
            public ParticleSystemCurveMode mode { get => m_Mode; set => m_Mode = value; }
            public float curveMultiplier { get => m_CurveMultiplier; set => m_CurveMultiplier = value; }
            public AnimationCurve curveMax { get => m_CurveMax; set => m_CurveMax = value; }
            public AnimationCurve curveMin { get => m_CurveMin; set => m_CurveMin = value; }
            public float constantMax { get => m_ConstantMax; set => m_ConstantMax = value; }
            public float constantMin { get => m_ConstantMin; set => m_ConstantMin = value; }
            public float constant { get => m_ConstantMax; set => m_ConstantMax = value; }
            public AnimationCurve curve { get => m_CurveMax; set => m_CurveMax = value; }
            public float Evaluate(float time) => Evaluate(time, 1f);
            public float Evaluate(float time, float lerpFactor)
            {
                switch (m_Mode)
                {
                    case ParticleSystemCurveMode.Constant: return m_ConstantMax;
                    case ParticleSystemCurveMode.TwoConstants: return Mathf.Lerp(m_ConstantMin, m_ConstantMax, lerpFactor);
                    case ParticleSystemCurveMode.Curve: return (m_CurveMax?.Evaluate(time) ?? 0) * m_CurveMultiplier;
                    default: return Mathf.Lerp(m_CurveMin?.Evaluate(time) ?? 0, m_CurveMax?.Evaluate(time) ?? 0, lerpFactor) * m_CurveMultiplier;
                }
            }
            public static implicit operator MinMaxCurve(float constant) => new MinMaxCurve(constant);
            internal float Max => m_Mode switch { ParticleSystemCurveMode.Constant => m_ConstantMax, ParticleSystemCurveMode.TwoConstants => Math.Max(m_ConstantMin, m_ConstantMax), _ => m_CurveMultiplier };
        }

        [Serializable]
        public struct MinMaxGradient
        {
            ParticleSystemGradientMode m_Mode; Gradient m_GradientMin, m_GradientMax; Color m_ColorMin, m_ColorMax;
            public MinMaxGradient(Color color) { m_Mode = ParticleSystemGradientMode.Color; m_GradientMin = null; m_GradientMax = null; m_ColorMin = Color.black; m_ColorMax = color; }
            public MinMaxGradient(Gradient gradient) { m_Mode = ParticleSystemGradientMode.Gradient; m_GradientMin = null; m_GradientMax = gradient; m_ColorMin = Color.black; m_ColorMax = Color.white; }
            public MinMaxGradient(Color min, Color max) { m_Mode = ParticleSystemGradientMode.TwoColors; m_GradientMin = null; m_GradientMax = null; m_ColorMin = min; m_ColorMax = max; }
            public MinMaxGradient(Gradient min, Gradient max) { m_Mode = ParticleSystemGradientMode.TwoGradients; m_GradientMin = min; m_GradientMax = max; m_ColorMin = Color.black; m_ColorMax = Color.white; }
            public ParticleSystemGradientMode mode { get => m_Mode; set => m_Mode = value; }
            public Gradient gradientMax { get => m_GradientMax; set => m_GradientMax = value; }
            public Gradient gradientMin { get => m_GradientMin; set => m_GradientMin = value; }
            public Color colorMax { get => m_ColorMax; set => m_ColorMax = value; }
            public Color colorMin { get => m_ColorMin; set => m_ColorMin = value; }
            public Color color { get => m_ColorMax; set => m_ColorMax = value; }
            public Gradient gradient { get => m_GradientMax; set => m_GradientMax = value; }
            public Color Evaluate(float time) => Evaluate(time, 1f);
            public Color Evaluate(float time, float lerpFactor)
            {
                switch (m_Mode)
                {
                    case ParticleSystemGradientMode.Color: return m_ColorMax;
                    case ParticleSystemGradientMode.TwoColors: return Color.Lerp(m_ColorMin, m_ColorMax, lerpFactor);
                    case ParticleSystemGradientMode.Gradient: return m_GradientMax?.Evaluate(time) ?? Color.white;
                    case ParticleSystemGradientMode.RandomColor: return m_GradientMax?.Evaluate(lerpFactor) ?? Color.white;
                    default: return Color.Lerp(m_GradientMin?.Evaluate(time) ?? Color.white, m_GradientMax?.Evaluate(time) ?? Color.white, lerpFactor);
                }
            }
            public static implicit operator MinMaxGradient(Color color) => new MinMaxGradient(color);
            public static implicit operator MinMaxGradient(Gradient gradient) => new MinMaxGradient(gradient);
        }

        [Serializable]
        public struct Burst
        {
            float m_Time; MinMaxCurve m_Count; int m_RepeatCount; float m_RepeatInterval; float m_Probability;
            public Burst(float _time, short _count) : this(_time, (MinMaxCurve)_count, 1, 0.01f) { }
            public Burst(float _time, short _minCount, short _maxCount) : this(_time, new MinMaxCurve(_minCount, _maxCount), 1, 0.01f) { }
            public Burst(float _time, short _minCount, short _maxCount, int _cycleCount, float _repeatInterval) : this(_time, new MinMaxCurve(_minCount, _maxCount), _cycleCount, _repeatInterval) { }
            public Burst(float _time, MinMaxCurve _count) : this(_time, _count, 1, 0.01f) { }
            public Burst(float _time, MinMaxCurve _count, int _cycleCount, float _repeatInterval) { m_Time = _time; m_Count = _count; m_RepeatCount = _cycleCount - 1; m_RepeatInterval = _repeatInterval; m_Probability = 1f; }
            public float time { get => m_Time; set => m_Time = value; }
            public MinMaxCurve count { get => m_Count; set => m_Count = value; }
            public short minCount { get => (short)m_Count.constantMin; set => m_Count.constantMin = value; }
            public short maxCount { get => (short)m_Count.constantMax; set => m_Count.constantMax = value; }
            public int cycleCount { get => m_RepeatCount + 1; set => m_RepeatCount = value - 1; }
            public float repeatInterval { get => m_RepeatInterval; set => m_RepeatInterval = value; }
            public float probability { get => m_Probability; set => m_Probability = value; }
        }

        public struct Particle
        {
            internal Vector3 m_Position, m_Velocity, m_AnimatedVelocity, m_Rotation, m_AngularVelocity, m_StartSize;
            internal Color32 m_StartColor; internal uint m_RandomSeed; internal float m_Lifetime, m_StartLifetime; internal float m_EmitAccumulator;
            internal Vector3 m_TotalVelocityCache;
            public Vector3 position { get => m_Position; set => m_Position = value; }
            public Vector3 velocity { get => m_Velocity; set => m_Velocity = value; }
            public Vector3 animatedVelocity => m_AnimatedVelocity;
            public Vector3 totalVelocity => m_Velocity + m_AnimatedVelocity;
            public float remainingLifetime { get => m_Lifetime; set => m_Lifetime = value; }
            public float startLifetime { get => m_StartLifetime; set => m_StartLifetime = value; }
            public Color32 startColor { get => m_StartColor; set => m_StartColor = value; }
            public uint randomSeed { get => m_RandomSeed; set => m_RandomSeed = value; }
            public Vector3 axisOfRotation { get; set; }
            public float startSize { get => m_StartSize.x; set => m_StartSize = new Vector3(value, value, value); }
            public Vector3 startSize3D { get => m_StartSize; set => m_StartSize = value; }
            public float rotation { get => m_Rotation.z * Mathf.Rad2Deg; set => m_Rotation = new Vector3(0, 0, value * Mathf.Deg2Rad); }
            public Vector3 rotation3D { get => m_Rotation * Mathf.Rad2Deg; set => m_Rotation = value * Mathf.Deg2Rad; }
            public float angularVelocity { get => m_AngularVelocity.z * Mathf.Rad2Deg; set => m_AngularVelocity = new Vector3(0, 0, value * Mathf.Deg2Rad); }
            public Vector3 angularVelocity3D { get => m_AngularVelocity * Mathf.Rad2Deg; set => m_AngularVelocity = value * Mathf.Deg2Rad; }
            public float GetCurrentSize(ParticleSystem system) => system.CurrentSize(ref this).x;
            public Vector3 GetCurrentSize3D(ParticleSystem system) => system.CurrentSize(ref this);
            public Color32 GetCurrentColor(ParticleSystem system) => system.CurrentColor(ref this);
            public void SetMeshIndex(int index) { }
            public int GetMeshIndex(ParticleSystem system) => 0;
        }

        public struct EmitParams
        {
            internal Particle m_Particle;
            internal bool m_PositionSet, m_VelocitySet, m_AxisOfRotationSet, m_RotationSet, m_AngularVelocitySet, m_StartSizeSet, m_StartColorSet, m_RandomSeedSet, m_StartLifetimeSet, m_MeshIndexSet, m_ApplyShapeToPosition;
            public Particle particle { get => m_Particle; set { m_Particle = value; m_PositionSet = m_VelocitySet = m_RotationSet = m_AngularVelocitySet = m_StartSizeSet = m_StartColorSet = m_RandomSeedSet = m_StartLifetimeSet = true; } }
            public Vector3 position { get => m_Particle.position; set { m_Particle.position = value; m_PositionSet = true; } }
            public bool applyShapeToPosition { get => m_ApplyShapeToPosition; set => m_ApplyShapeToPosition = value; }
            public Vector3 velocity { get => m_Particle.velocity; set { m_Particle.velocity = value; m_VelocitySet = true; } }
            public float startLifetime { get => m_Particle.startLifetime; set { m_Particle.startLifetime = value; m_StartLifetimeSet = true; } }
            public float startSize { get => m_Particle.startSize; set { m_Particle.startSize = value; m_StartSizeSet = true; } }
            public Vector3 startSize3D { get => m_Particle.startSize3D; set { m_Particle.startSize3D = value; m_StartSizeSet = true; } }
            public Vector3 axisOfRotation { get => m_Particle.axisOfRotation; set { m_Particle.axisOfRotation = value; m_AxisOfRotationSet = true; } }
            public float rotation { get => m_Particle.rotation; set { m_Particle.rotation = value; m_RotationSet = true; } }
            public Vector3 rotation3D { get => m_Particle.rotation3D; set { m_Particle.rotation3D = value; m_RotationSet = true; } }
            public float angularVelocity { get => m_Particle.angularVelocity; set { m_Particle.angularVelocity = value; m_AngularVelocitySet = true; } }
            public Vector3 angularVelocity3D { get => m_Particle.angularVelocity3D; set { m_Particle.angularVelocity3D = value; m_AngularVelocitySet = true; } }
            public Color32 startColor { get => m_Particle.startColor; set { m_Particle.startColor = value; m_StartColorSet = true; } }
            public uint randomSeed { get => m_Particle.randomSeed; set { m_Particle.randomSeed = value; m_RandomSeedSet = true; } }
            public int meshIndex { set => m_MeshIndexSet = true; }
            public void ResetPosition() => m_PositionSet = false;
            public void ResetVelocity() => m_VelocitySet = false;
            public void ResetAxisOfRotation() => m_AxisOfRotationSet = false;
            public void ResetRotation() => m_RotationSet = false;
            public void ResetAngularVelocity() => m_AngularVelocitySet = false;
            public void ResetStartSize() => m_StartSizeSet = false;
            public void ResetStartColor() => m_StartColorSet = false;
            public void ResetRandomSeed() => m_RandomSeedSet = false;
            public void ResetStartLifetime() => m_StartLifetimeSet = false;
            public void ResetMeshIndex() => m_MeshIndexSet = false;
        }

        // ---------------- module state ----------------
        internal sealed class MainData
        {
            public float duration = 5f; public bool loop = true; public bool prewarm; public MinMaxCurve startDelay = 0f; public float startDelayMultiplier = 1;
            public MinMaxCurve startLifetime = 5f; public MinMaxCurve startSpeed = 5f; public bool startSize3D; public MinMaxCurve startSize = 1f, startSizeY = 1f, startSizeZ = 1f;
            public bool startRotation3D; public MinMaxCurve startRotationX = 0f, startRotationY = 0f, startRotation = 0f; public float flipRotation;
            public MinMaxGradient startColor = Color.white; public MinMaxCurve gravityModifier = 0f; public ParticleSystemSimulationSpace simulationSpace = ParticleSystemSimulationSpace.Local;
            public Transform customSimulationSpace; public float simulationSpeed = 1f; public bool useUnscaledTime; public ParticleSystemScalingMode scalingMode = ParticleSystemScalingMode.Local;
            public bool playOnAwake = true; public int maxParticles = 1000; public ParticleSystemEmitterVelocityMode emitterVelocityMode = ParticleSystemEmitterVelocityMode.Transform; public Vector3 emitterVelocity;
            public ParticleSystemStopAction stopAction; public ParticleSystemRingBufferMode ringBufferMode; public Vector2 ringBufferLoopRange = new Vector2(0, 1); public ParticleSystemCullingMode cullingMode;
        }
        internal sealed class EmissionData { public bool enabled = true; public MinMaxCurve rateOverTime = 10f; public MinMaxCurve rateOverDistance = 0f; public List<Burst> bursts = new List<Burst>(); }
        internal sealed class ShapeData
        {
            public bool enabled = true; public ParticleSystemShapeType shapeType = ParticleSystemShapeType.Cone; public float radius = 1f, radiusThickness = 1f, angle = 25f, length = 5f, arc = 360f, donutRadius = 0.2f, randomDirectionAmount, sphericalDirectionAmount, randomPositionAmount, normalOffset;
            public Vector3 boxThickness, position, rotation, scale = Vector3.one; public bool alignToDirection; public Mesh mesh; public MeshRenderer meshRenderer; public Texture2D texture;
            public ParticleSystemShapeMultiModeValue arcMode, radiusMode; public float arcSpread, radiusSpread; public MinMaxCurve arcSpeed = 1f, radiusSpeed = 1f;
        }
        internal sealed class XYZ { public bool enabled; public MinMaxCurve x = 0f, y = 0f, z = 0f; public ParticleSystemSimulationSpace space = ParticleSystemSimulationSpace.Local; public MinMaxCurve orbitalX = 0f, orbitalY = 0f, orbitalZ = 0f, radial = 0f, speedModifier = 1f; public bool randomized; }
        internal sealed class LimitData { public bool enabled; public bool separateAxes; public MinMaxCurve limit = 1f, limitX = 1f, limitY = 1f, limitZ = 1f; public float dampen = 1f; public MinMaxCurve drag = 0f; public bool multiplyDragByParticleSize = true, multiplyDragByParticleVelocity = true; public ParticleSystemSimulationSpace space; }
        internal sealed class GradData { public bool enabled; public MinMaxGradient color = Color.white; public Vector2 range = new Vector2(0, 1); }
        internal sealed class SizeData { public bool enabled; public bool separateAxes; public MinMaxCurve size = new MinMaxCurve(1f, new AnimationCurve(new Keyframe(0, 0), new Keyframe(1, 1))), y = 1f, z = 1f; public Vector2 range = new Vector2(0, 1); }
        internal sealed class RotData { public bool enabled; public bool separateAxes; public MinMaxCurve x = 0f, y = 0f, z = 45f * Mathf.Deg2Rad; public Vector2 range = new Vector2(0, 1); }
        internal sealed class NoiseData { public bool enabled; public MinMaxCurve strength = 1f, strengthY = 1f, strengthZ = 1f; public bool separateAxes; public float frequency = 0.5f; public MinMaxCurve scrollSpeed = 0f; public bool damping = true; public int octaveCount = 1; public float octaveMultiplier = 0.5f, octaveScale = 2f; public ParticleSystemNoiseQuality quality = ParticleSystemNoiseQuality.High; public MinMaxCurve positionAmount = 1f, rotationAmount = 0f, sizeAmount = 0f; }
        internal sealed class CollisionData
        {
            public bool enabled; public ParticleSystemCollisionType type = ParticleSystemCollisionType.Planes; public ParticleSystemCollisionMode mode; public MinMaxCurve dampen = 0f, bounce = 1f, lifetimeLoss = 0f;
            public float minKillSpeed, maxKillSpeed = 10000f, radiusScale = 1f, voxelSize = 0.5f, colliderForce; public LayerMask collidesWith = -1; public bool enableDynamicColliders = true, sendCollisionMessages, multiplyColliderForceByCollisionAngle = true, multiplyColliderForceByParticleSpeed, multiplyColliderForceByParticleSize;
            public ParticleSystemCollisionQuality quality; public int maxCollisionShapes = 256; public List<Transform> planes = new List<Transform>();
        }
        internal readonly MainData m_Main = new MainData();
        internal readonly EmissionData m_Emission = new EmissionData();
        internal readonly ShapeData m_Shape = new ShapeData();
        internal readonly XYZ m_VelOL = new XYZ(), m_ForceOL = new XYZ();
        internal readonly LimitData m_Limit = new LimitData();
        internal readonly GradData m_ColorOL = new GradData(), m_ColorBS = new GradData { range = new Vector2(0, 1) };
        internal readonly SizeData m_SizeOL = new SizeData(), m_SizeBS = new SizeData();
        internal readonly RotData m_RotOL = new RotData(), m_RotBS = new RotData();
        internal readonly NoiseData m_Noise = new NoiseData();
        internal readonly CollisionData m_Collision = new CollisionData();
        internal bool m_InheritEnabled; internal MinMaxCurve m_InheritCurve = 0f; internal ParticleSystemInheritVelocityMode m_InheritMode;
        internal bool m_TrailsEnabled, m_TriggerEnabled, m_LightsEnabled, m_TexSheetEnabled, m_SubEmittersEnabled, m_ExternalForcesEnabled, m_CustomDataEnabled;
        internal MinMaxCurve m_ExternalMultiplier = 1f; internal int m_TexTilesX = 1, m_TexTilesY = 1;

        // ---------------- module accessors ----------------
        public MainModule main => new MainModule(this);
        public EmissionModule emission => new EmissionModule(this);
        public ShapeModule shape => new ShapeModule(this);
        public VelocityOverLifetimeModule velocityOverLifetime => new VelocityOverLifetimeModule(this);
        public LimitVelocityOverLifetimeModule limitVelocityOverLifetime => new LimitVelocityOverLifetimeModule(this);
        public InheritVelocityModule inheritVelocity => new InheritVelocityModule(this);
        public ForceOverLifetimeModule forceOverLifetime => new ForceOverLifetimeModule(this);
        public ColorOverLifetimeModule colorOverLifetime => new ColorOverLifetimeModule(this);
        public ColorBySpeedModule colorBySpeed => new ColorBySpeedModule(this);
        public SizeOverLifetimeModule sizeOverLifetime => new SizeOverLifetimeModule(this);
        public SizeBySpeedModule sizeBySpeed => new SizeBySpeedModule(this);
        public RotationOverLifetimeModule rotationOverLifetime => new RotationOverLifetimeModule(this);
        public RotationBySpeedModule rotationBySpeed => new RotationBySpeedModule(this);
        public ExternalForcesModule externalForces => new ExternalForcesModule(this);
        public NoiseModule noise => new NoiseModule(this);
        public CollisionModule collision => new CollisionModule(this);
        public TriggerModule trigger => new TriggerModule(this);
        public SubEmittersModule subEmitters => new SubEmittersModule(this);
        public TextureSheetAnimationModule textureSheetAnimation => new TextureSheetAnimationModule(this);
        public LightsModule lights => new LightsModule(this);
        public TrailModule trails => new TrailModule(this);
        public CustomDataModule customData => new CustomDataModule(this);

        public struct MainModule
        {
            readonly ParticleSystem s; internal MainModule(ParticleSystem s) { this.s = s; } MainData d => s.m_Main;
            public float duration { get => d.duration; set { if (s.isPlaying) { Debug.LogWarning("Setting the duration while system is still playing is not supported. Please wait until the system has stopped and all particles have expired or call Stop with ParticleSystemStopBehavior.StopEmittingAndClear to stop the system and clear all particles."); return; } d.duration = Math.Max(0.05f, value); } }
            public bool loop { get => d.loop; set => d.loop = value; }
            public bool prewarm { get => d.prewarm; set => d.prewarm = value; }
            public MinMaxCurve startDelay { get => d.startDelay; set => d.startDelay = value; }
            public float startDelayMultiplier { get => d.startDelayMultiplier; set => d.startDelayMultiplier = value; }
            public MinMaxCurve startLifetime { get => d.startLifetime; set => d.startLifetime = value; }
            public float startLifetimeMultiplier { get => d.startLifetime.Max; set { var c = d.startLifetime; if (c.mode == ParticleSystemCurveMode.Constant) c.constant = value; else c.curveMultiplier = value; d.startLifetime = c; } }
            public MinMaxCurve startSpeed { get => d.startSpeed; set => d.startSpeed = value; }
            public float startSpeedMultiplier { get => d.startSpeed.Max; set { var c = d.startSpeed; if (c.mode == ParticleSystemCurveMode.Constant) c.constant = value; else c.curveMultiplier = value; d.startSpeed = c; } }
            public bool startSize3D { get => d.startSize3D; set => d.startSize3D = value; }
            public MinMaxCurve startSize { get => d.startSize; set => d.startSize = value; }
            public float startSizeMultiplier { get => d.startSize.Max; set { var c = d.startSize; if (c.mode == ParticleSystemCurveMode.Constant) c.constant = value; else c.curveMultiplier = value; d.startSize = c; } }
            public MinMaxCurve startSizeX { get => d.startSize; set => d.startSize = value; }
            public float startSizeXMultiplier { get => startSizeMultiplier; set => startSizeMultiplier = value; }
            public MinMaxCurve startSizeY { get => d.startSizeY; set => d.startSizeY = value; }
            public float startSizeYMultiplier { get => d.startSizeY.Max; set => d.startSizeY = value; }
            public MinMaxCurve startSizeZ { get => d.startSizeZ; set => d.startSizeZ = value; }
            public float startSizeZMultiplier { get => d.startSizeZ.Max; set => d.startSizeZ = value; }
            public bool startRotation3D { get => d.startRotation3D; set => d.startRotation3D = value; }
            public MinMaxCurve startRotation { get => d.startRotation; set => d.startRotation = value; }
            public float startRotationMultiplier { get => d.startRotation.Max; set => d.startRotation = value; }
            public MinMaxCurve startRotationX { get => d.startRotationX; set => d.startRotationX = value; }
            public MinMaxCurve startRotationY { get => d.startRotationY; set => d.startRotationY = value; }
            public MinMaxCurve startRotationZ { get => d.startRotation; set => d.startRotation = value; }
            public float startRotationXMultiplier { get => d.startRotationX.Max; set => d.startRotationX = value; }
            public float startRotationYMultiplier { get => d.startRotationY.Max; set => d.startRotationY = value; }
            public float startRotationZMultiplier { get => d.startRotation.Max; set => d.startRotation = value; }
            public float flipRotation { get => d.flipRotation; set => d.flipRotation = value; }
            public MinMaxGradient startColor { get => d.startColor; set => d.startColor = value; }
            public MinMaxCurve gravityModifier { get => d.gravityModifier; set => d.gravityModifier = value; }
            public float gravityModifierMultiplier { get => d.gravityModifier.Max; set => d.gravityModifier = value; }
            public ParticleSystemSimulationSpace simulationSpace { get => d.simulationSpace; set => d.simulationSpace = value; }
            public Transform customSimulationSpace { get => d.customSimulationSpace; set => d.customSimulationSpace = value; }
            public float simulationSpeed { get => d.simulationSpeed; set => d.simulationSpeed = value; }
            public bool useUnscaledTime { get => d.useUnscaledTime; set => d.useUnscaledTime = value; }
            public ParticleSystemScalingMode scalingMode { get => d.scalingMode; set => d.scalingMode = value; }
            public bool playOnAwake { get => d.playOnAwake; set => d.playOnAwake = value; }
            public int maxParticles { get => d.maxParticles; set => d.maxParticles = Math.Max(0, value); }
            public ParticleSystemEmitterVelocityMode emitterVelocityMode { get => d.emitterVelocityMode; set => d.emitterVelocityMode = value; }
            public Vector3 emitterVelocity { get => d.emitterVelocity; set => d.emitterVelocity = value; }
            public ParticleSystemStopAction stopAction { get => d.stopAction; set => d.stopAction = value; }
            public ParticleSystemRingBufferMode ringBufferMode { get => d.ringBufferMode; set => d.ringBufferMode = value; }
            public Vector2 ringBufferLoopRange { get => d.ringBufferLoopRange; set => d.ringBufferLoopRange = value; }
            public ParticleSystemCullingMode cullingMode { get => d.cullingMode; set => d.cullingMode = value; }
        }
        public struct EmissionModule
        {
            readonly ParticleSystem s; internal EmissionModule(ParticleSystem s) { this.s = s; } EmissionData d => s.m_Emission;
            public bool enabled { get => d.enabled; set => d.enabled = value; }
            public MinMaxCurve rateOverTime { get => d.rateOverTime; set => d.rateOverTime = value; }
            public float rateOverTimeMultiplier { get => d.rateOverTime.Max; set { var c = d.rateOverTime; if (c.mode == ParticleSystemCurveMode.Constant) c.constant = value; else c.curveMultiplier = value; d.rateOverTime = c; } }
            public MinMaxCurve rateOverDistance { get => d.rateOverDistance; set => d.rateOverDistance = value; }
            public float rateOverDistanceMultiplier { get => d.rateOverDistance.Max; set => d.rateOverDistance = value; }
            public int burstCount { get => d.bursts.Count; set { while (d.bursts.Count < value) d.bursts.Add(new Burst(0, (MinMaxCurve)30f)); if (d.bursts.Count > value) d.bursts.RemoveRange(value, d.bursts.Count - value); } }
            public void SetBursts(Burst[] bursts) => SetBursts(bursts, bursts?.Length ?? 0);
            public void SetBursts(Burst[] bursts, int size) { d.bursts.Clear(); for (int i = 0; i < size && i < bursts.Length; i++) d.bursts.Add(bursts[i]); }
            public int GetBursts(Burst[] bursts) { int n = Math.Min(bursts.Length, d.bursts.Count); for (int i = 0; i < n; i++) bursts[i] = d.bursts[i]; return n; }
            public void SetBurst(int index, Burst burst) { if (index >= 0 && index < d.bursts.Count) d.bursts[index] = burst; }
            public Burst GetBurst(int index) => d.bursts[index];
        }
        public struct ShapeModule
        {
            readonly ParticleSystem s; internal ShapeModule(ParticleSystem s) { this.s = s; } ShapeData d => s.m_Shape;
            public bool enabled { get => d.enabled; set => d.enabled = value; }
            public ParticleSystemShapeType shapeType { get => d.shapeType; set => d.shapeType = value; }
            public float randomDirectionAmount { get => d.randomDirectionAmount; set => d.randomDirectionAmount = value; }
            public float sphericalDirectionAmount { get => d.sphericalDirectionAmount; set => d.sphericalDirectionAmount = value; }
            public float randomPositionAmount { get => d.randomPositionAmount; set => d.randomPositionAmount = value; }
            public bool alignToDirection { get => d.alignToDirection; set => d.alignToDirection = value; }
            public float radius { get => d.radius; set => d.radius = Math.Max(0, value); }
            public ParticleSystemShapeMultiModeValue radiusMode { get => d.radiusMode; set => d.radiusMode = value; }
            public float radiusSpread { get => d.radiusSpread; set => d.radiusSpread = value; }
            public MinMaxCurve radiusSpeed { get => d.radiusSpeed; set => d.radiusSpeed = value; }
            public float radiusSpeedMultiplier { get => d.radiusSpeed.Max; set => d.radiusSpeed = value; }
            public float radiusThickness { get => d.radiusThickness; set => d.radiusThickness = Mathf.Clamp01(value); }
            public float angle { get => d.angle; set => d.angle = Mathf.Clamp(value, 0, 90); }
            public float length { get => d.length; set => d.length = value; }
            public Vector3 boxThickness { get => d.boxThickness; set => d.boxThickness = value; }
            public ParticleSystemMeshShapeType meshShapeType { get; set; }
            public Mesh mesh { get => d.mesh; set => d.mesh = value; }
            public MeshRenderer meshRenderer { get => d.meshRenderer; set => d.meshRenderer = value; }
            public SkinnedMeshRenderer skinnedMeshRenderer { get; set; }
            public Sprite sprite { get; set; }
            public bool useMeshMaterialIndex { get; set; }
            public int meshMaterialIndex { get; set; }
            public bool useMeshColors { get; set; }
            public float normalOffset { get => d.normalOffset; set => d.normalOffset = value; }
            public float donutRadius { get => d.donutRadius; set => d.donutRadius = value; }
            public Vector3 position { get => d.position; set => d.position = value; }
            public Vector3 rotation { get => d.rotation; set => d.rotation = value; }
            public Vector3 scale { get => d.scale; set => d.scale = value; }
            public Texture2D texture { get => d.texture; set => d.texture = value; }
            public float arc { get => d.arc; set => d.arc = Mathf.Clamp(value, 0, 360); }
            public ParticleSystemShapeMultiModeValue arcMode { get => d.arcMode; set => d.arcMode = value; }
            public float arcSpread { get => d.arcSpread; set => d.arcSpread = value; }
            public MinMaxCurve arcSpeed { get => d.arcSpeed; set => d.arcSpeed = value; }
            public float arcSpeedMultiplier { get => d.arcSpeed.Max; set => d.arcSpeed = value; }
        }
        public struct VelocityOverLifetimeModule
        {
            readonly ParticleSystem s; internal VelocityOverLifetimeModule(ParticleSystem s) { this.s = s; } XYZ d => s.m_VelOL;
            public bool enabled { get => d.enabled; set => d.enabled = value; }
            public MinMaxCurve x { get => d.x; set => d.x = value; }
            public MinMaxCurve y { get => d.y; set => d.y = value; }
            public MinMaxCurve z { get => d.z; set => d.z = value; }
            public float xMultiplier { get => d.x.Max; set => d.x = value; }
            public float yMultiplier { get => d.y.Max; set => d.y = value; }
            public float zMultiplier { get => d.z.Max; set => d.z = value; }
            public MinMaxCurve orbitalX { get => d.orbitalX; set => d.orbitalX = value; }
            public MinMaxCurve orbitalY { get => d.orbitalY; set => d.orbitalY = value; }
            public MinMaxCurve orbitalZ { get => d.orbitalZ; set => d.orbitalZ = value; }
            public MinMaxCurve orbitalOffsetX { get; set; }
            public MinMaxCurve orbitalOffsetY { get; set; }
            public MinMaxCurve orbitalOffsetZ { get; set; }
            public MinMaxCurve radial { get => d.radial; set => d.radial = value; }
            public float radialMultiplier { get => d.radial.Max; set => d.radial = value; }
            public MinMaxCurve speedModifier { get => d.speedModifier; set => d.speedModifier = value; }
            public float speedModifierMultiplier { get => d.speedModifier.Max; set => d.speedModifier = value; }
            public ParticleSystemSimulationSpace space { get => d.space; set => d.space = value; }
        }
        public struct ForceOverLifetimeModule
        {
            readonly ParticleSystem s; internal ForceOverLifetimeModule(ParticleSystem s) { this.s = s; } XYZ d => s.m_ForceOL;
            public bool enabled { get => d.enabled; set => d.enabled = value; }
            public MinMaxCurve x { get => d.x; set => d.x = value; }
            public MinMaxCurve y { get => d.y; set => d.y = value; }
            public MinMaxCurve z { get => d.z; set => d.z = value; }
            public float xMultiplier { get => d.x.Max; set => d.x = value; }
            public float yMultiplier { get => d.y.Max; set => d.y = value; }
            public float zMultiplier { get => d.z.Max; set => d.z = value; }
            public ParticleSystemSimulationSpace space { get => d.space; set => d.space = value; }
            public bool randomized { get => d.randomized; set => d.randomized = value; }
        }
        public struct LimitVelocityOverLifetimeModule
        {
            readonly ParticleSystem s; internal LimitVelocityOverLifetimeModule(ParticleSystem s) { this.s = s; } LimitData d => s.m_Limit;
            public bool enabled { get => d.enabled; set => d.enabled = value; }
            public MinMaxCurve limit { get => d.limit; set => d.limit = value; }
            public float limitMultiplier { get => d.limit.Max; set => d.limit = value; }
            public MinMaxCurve limitX { get => d.limitX; set => d.limitX = value; }
            public MinMaxCurve limitY { get => d.limitY; set => d.limitY = value; }
            public MinMaxCurve limitZ { get => d.limitZ; set => d.limitZ = value; }
            public float limitXMultiplier { get => d.limitX.Max; set => d.limitX = value; }
            public float limitYMultiplier { get => d.limitY.Max; set => d.limitY = value; }
            public float limitZMultiplier { get => d.limitZ.Max; set => d.limitZ = value; }
            public bool separateAxes { get => d.separateAxes; set => d.separateAxes = value; }
            public float dampen { get => d.dampen; set => d.dampen = value; }
            public MinMaxCurve drag { get => d.drag; set => d.drag = value; }
            public float dragMultiplier { get => d.drag.Max; set => d.drag = value; }
            public bool multiplyDragByParticleSize { get => d.multiplyDragByParticleSize; set => d.multiplyDragByParticleSize = value; }
            public bool multiplyDragByParticleVelocity { get => d.multiplyDragByParticleVelocity; set => d.multiplyDragByParticleVelocity = value; }
            public ParticleSystemSimulationSpace space { get => d.space; set => d.space = value; }
        }
        public struct InheritVelocityModule
        {
            readonly ParticleSystem s; internal InheritVelocityModule(ParticleSystem s) { this.s = s; }
            public bool enabled { get => s.m_InheritEnabled; set => s.m_InheritEnabled = value; }
            public ParticleSystemInheritVelocityMode mode { get => s.m_InheritMode; set => s.m_InheritMode = value; }
            public MinMaxCurve curve { get => s.m_InheritCurve; set => s.m_InheritCurve = value; }
            public float curveMultiplier { get => s.m_InheritCurve.Max; set => s.m_InheritCurve = value; }
        }
        public struct ColorOverLifetimeModule
        {
            readonly ParticleSystem s; internal ColorOverLifetimeModule(ParticleSystem s) { this.s = s; }
            public bool enabled { get => s.m_ColorOL.enabled; set => s.m_ColorOL.enabled = value; }
            public MinMaxGradient color { get => s.m_ColorOL.color; set => s.m_ColorOL.color = value; }
        }
        public struct ColorBySpeedModule
        {
            readonly ParticleSystem s; internal ColorBySpeedModule(ParticleSystem s) { this.s = s; }
            public bool enabled { get => s.m_ColorBS.enabled; set => s.m_ColorBS.enabled = value; }
            public MinMaxGradient color { get => s.m_ColorBS.color; set => s.m_ColorBS.color = value; }
            public Vector2 range { get => s.m_ColorBS.range; set => s.m_ColorBS.range = value; }
        }
        public struct SizeOverLifetimeModule
        {
            readonly ParticleSystem s; internal SizeOverLifetimeModule(ParticleSystem s) { this.s = s; } SizeData d => s.m_SizeOL;
            public bool enabled { get => d.enabled; set => d.enabled = value; }
            public MinMaxCurve size { get => d.size; set => d.size = value; }
            public float sizeMultiplier { get => d.size.Max; set { var c = d.size; c.curveMultiplier = value; if (c.mode == ParticleSystemCurveMode.Constant) c.constant = value; d.size = c; } }
            public MinMaxCurve x { get => d.size; set => d.size = value; }
            public MinMaxCurve y { get => d.y; set => d.y = value; }
            public MinMaxCurve z { get => d.z; set => d.z = value; }
            public float xMultiplier { get => sizeMultiplier; set => sizeMultiplier = value; }
            public float yMultiplier { get => d.y.Max; set => d.y = value; }
            public float zMultiplier { get => d.z.Max; set => d.z = value; }
            public bool separateAxes { get => d.separateAxes; set => d.separateAxes = value; }
        }
        public struct SizeBySpeedModule
        {
            readonly ParticleSystem s; internal SizeBySpeedModule(ParticleSystem s) { this.s = s; } SizeData d => s.m_SizeBS;
            public bool enabled { get => d.enabled; set => d.enabled = value; }
            public MinMaxCurve size { get => d.size; set => d.size = value; }
            public float sizeMultiplier { get => d.size.Max; set => d.size = value; }
            public MinMaxCurve x { get => d.size; set => d.size = value; }
            public MinMaxCurve y { get => d.y; set => d.y = value; }
            public MinMaxCurve z { get => d.z; set => d.z = value; }
            public bool separateAxes { get => d.separateAxes; set => d.separateAxes = value; }
            public Vector2 range { get => d.range; set => d.range = value; }
        }
        public struct RotationOverLifetimeModule
        {
            readonly ParticleSystem s; internal RotationOverLifetimeModule(ParticleSystem s) { this.s = s; } RotData d => s.m_RotOL;
            public bool enabled { get => d.enabled; set => d.enabled = value; }
            public MinMaxCurve x { get => d.x; set => d.x = value; }
            public MinMaxCurve y { get => d.y; set => d.y = value; }
            public MinMaxCurve z { get => d.z; set => d.z = value; }
            public float xMultiplier { get => d.x.Max; set => d.x = value; }
            public float yMultiplier { get => d.y.Max; set => d.y = value; }
            public float zMultiplier { get => d.z.Max; set => d.z = value; }
            public bool separateAxes { get => d.separateAxes; set => d.separateAxes = value; }
        }
        public struct RotationBySpeedModule
        {
            readonly ParticleSystem s; internal RotationBySpeedModule(ParticleSystem s) { this.s = s; } RotData d => s.m_RotBS;
            public bool enabled { get => d.enabled; set => d.enabled = value; }
            public MinMaxCurve x { get => d.x; set => d.x = value; }
            public MinMaxCurve y { get => d.y; set => d.y = value; }
            public MinMaxCurve z { get => d.z; set => d.z = value; }
            public bool separateAxes { get => d.separateAxes; set => d.separateAxes = value; }
            public Vector2 range { get => d.range; set => d.range = value; }
        }
        public struct ExternalForcesModule
        {
            readonly ParticleSystem s; internal ExternalForcesModule(ParticleSystem s) { this.s = s; }
            public bool enabled { get => s.m_ExternalForcesEnabled; set => s.m_ExternalForcesEnabled = value; }
            public float multiplier { get => s.m_ExternalMultiplier.Max; set => s.m_ExternalMultiplier = value; }
            public MinMaxCurve multiplierCurve { get => s.m_ExternalMultiplier; set => s.m_ExternalMultiplier = value; }
            public ParticleSystemGameObjectFilter influenceFilter { get; set; }
            public LayerMask influenceMask { get; set; }
        }
        public struct NoiseModule
        {
            readonly ParticleSystem s; internal NoiseModule(ParticleSystem s) { this.s = s; } NoiseData d => s.m_Noise;
            public bool enabled { get => d.enabled; set => d.enabled = value; }
            public bool separateAxes { get => d.separateAxes; set => d.separateAxes = value; }
            public MinMaxCurve strength { get => d.strength; set => d.strength = value; }
            public float strengthMultiplier { get => d.strength.Max; set => d.strength = value; }
            public MinMaxCurve strengthX { get => d.strength; set => d.strength = value; }
            public MinMaxCurve strengthY { get => d.strengthY; set => d.strengthY = value; }
            public MinMaxCurve strengthZ { get => d.strengthZ; set => d.strengthZ = value; }
            public float frequency { get => d.frequency; set => d.frequency = value; }
            public bool damping { get => d.damping; set => d.damping = value; }
            public int octaveCount { get => d.octaveCount; set => d.octaveCount = Math.Clamp(value, 1, 4); }
            public float octaveMultiplier { get => d.octaveMultiplier; set => d.octaveMultiplier = value; }
            public float octaveScale { get => d.octaveScale; set => d.octaveScale = value; }
            public ParticleSystemNoiseQuality quality { get => d.quality; set => d.quality = value; }
            public MinMaxCurve scrollSpeed { get => d.scrollSpeed; set => d.scrollSpeed = value; }
            public float scrollSpeedMultiplier { get => d.scrollSpeed.Max; set => d.scrollSpeed = value; }
            public bool remapEnabled { get; set; }
            public MinMaxCurve positionAmount { get => d.positionAmount; set => d.positionAmount = value; }
            public MinMaxCurve rotationAmount { get => d.rotationAmount; set => d.rotationAmount = value; }
            public MinMaxCurve sizeAmount { get => d.sizeAmount; set => d.sizeAmount = value; }
        }
        public struct CollisionModule
        {
            readonly ParticleSystem s; internal CollisionModule(ParticleSystem s) { this.s = s; } CollisionData d => s.m_Collision;
            public bool enabled { get => d.enabled; set => d.enabled = value; }
            public ParticleSystemCollisionType type { get => d.type; set => d.type = value; }
            public ParticleSystemCollisionMode mode { get => d.mode; set => d.mode = value; }
            public MinMaxCurve dampen { get => d.dampen; set => d.dampen = value; }
            public float dampenMultiplier { get => d.dampen.Max; set => d.dampen = value; }
            public MinMaxCurve bounce { get => d.bounce; set => d.bounce = value; }
            public float bounceMultiplier { get => d.bounce.Max; set => d.bounce = value; }
            public MinMaxCurve lifetimeLoss { get => d.lifetimeLoss; set => d.lifetimeLoss = value; }
            public float lifetimeLossMultiplier { get => d.lifetimeLoss.Max; set => d.lifetimeLoss = value; }
            public float minKillSpeed { get => d.minKillSpeed; set => d.minKillSpeed = value; }
            public float maxKillSpeed { get => d.maxKillSpeed; set => d.maxKillSpeed = value; }
            public LayerMask collidesWith { get => d.collidesWith; set => d.collidesWith = value; }
            public bool enableDynamicColliders { get => d.enableDynamicColliders; set => d.enableDynamicColliders = value; }
            public int maxCollisionShapes { get => d.maxCollisionShapes; set => d.maxCollisionShapes = value; }
            public ParticleSystemCollisionQuality quality { get => d.quality; set => d.quality = value; }
            public float voxelSize { get => d.voxelSize; set => d.voxelSize = value; }
            public float radiusScale { get => d.radiusScale; set => d.radiusScale = value; }
            public bool sendCollisionMessages { get => d.sendCollisionMessages; set => d.sendCollisionMessages = value; }
            public float colliderForce { get => d.colliderForce; set => d.colliderForce = value; }
            public bool multiplyColliderForceByCollisionAngle { get => d.multiplyColliderForceByCollisionAngle; set => d.multiplyColliderForceByCollisionAngle = value; }
            public bool multiplyColliderForceByParticleSpeed { get => d.multiplyColliderForceByParticleSpeed; set => d.multiplyColliderForceByParticleSpeed = value; }
            public bool multiplyColliderForceByParticleSize { get => d.multiplyColliderForceByParticleSize; set => d.multiplyColliderForceByParticleSize = value; }
            public int planeCount => d.planes.Count;
            public void AddPlane(Transform transform) { if (transform != null) d.planes.Add(transform); }
            public void RemovePlane(int index) { if (index >= 0 && index < d.planes.Count) d.planes.RemoveAt(index); }
            public void RemovePlane(Transform transform) => d.planes.Remove(transform);
            public void SetPlane(int index, Transform transform) { while (d.planes.Count <= index) d.planes.Add(null); d.planes[index] = transform; }
            public Transform GetPlane(int index) => index >= 0 && index < d.planes.Count ? d.planes[index] : null;
        }
        public struct TriggerModule
        {
            readonly ParticleSystem s; internal TriggerModule(ParticleSystem s) { this.s = s; }
            public bool enabled { get => s.m_TriggerEnabled; set => s.m_TriggerEnabled = value; }
            public ParticleSystemOverlapAction inside { get; set; }
            public ParticleSystemOverlapAction outside { get; set; }
            public ParticleSystemOverlapAction enter { get; set; }
            public ParticleSystemOverlapAction exit { get; set; }
            public float radiusScale { get; set; }
            public int colliderCount => 0;
            public void AddCollider(Component collider) { }
            public void RemoveCollider(int index) { }
            public void SetCollider(int index, Component collider) { }
            public Component GetCollider(int index) => null;
        }
        public struct SubEmittersModule
        {
            readonly ParticleSystem s; internal SubEmittersModule(ParticleSystem s) { this.s = s; }
            public bool enabled { get => s.m_SubEmittersEnabled; set => s.m_SubEmittersEnabled = value; }
            public int subEmittersCount => 0;
            public void AddSubEmitter(ParticleSystem subEmitter, ParticleSystemSubEmitterType type, ParticleSystemSubEmitterProperties properties) { }
            public void AddSubEmitter(ParticleSystem subEmitter, ParticleSystemSubEmitterType type, ParticleSystemSubEmitterProperties properties, float emitProbability) { }
            public void RemoveSubEmitter(int index) { }
            public ParticleSystem GetSubEmitterSystem(int index) => null;
        }
        public struct TextureSheetAnimationModule
        {
            readonly ParticleSystem s; internal TextureSheetAnimationModule(ParticleSystem s) { this.s = s; }
            public bool enabled { get => s.m_TexSheetEnabled; set => s.m_TexSheetEnabled = value; }
            public ParticleSystemAnimationMode mode { get; set; }
            public int numTilesX { get => s.m_TexTilesX; set => s.m_TexTilesX = Math.Max(1, value); }
            public int numTilesY { get => s.m_TexTilesY; set => s.m_TexTilesY = Math.Max(1, value); }
            public ParticleSystemAnimationType animation { get; set; }
            public MinMaxCurve frameOverTime { get; set; }
            public float frameOverTimeMultiplier { get; set; }
            public MinMaxCurve startFrame { get; set; }
            public float startFrameMultiplier { get; set; }
            public int cycleCount { get; set; }
            public int rowIndex { get; set; }
            public float fps { get; set; }
            public void AddSprite(Sprite sprite) { }
        }
        public struct LightsModule
        {
            readonly ParticleSystem s; internal LightsModule(ParticleSystem s) { this.s = s; }
            public bool enabled { get => s.m_LightsEnabled; set => s.m_LightsEnabled = value; }
            public float ratio { get; set; }
            public bool useRandomDistribution { get; set; }
            public Light light { get; set; }
            public bool useParticleColor { get; set; }
            public bool sizeAffectsRange { get; set; }
            public bool alphaAffectsIntensity { get; set; }
            public MinMaxCurve range { get; set; }
            public float rangeMultiplier { get; set; }
            public MinMaxCurve intensity { get; set; }
            public float intensityMultiplier { get; set; }
            public int maxLights { get; set; }
        }
        public struct TrailModule
        {
            readonly ParticleSystem s; internal TrailModule(ParticleSystem s) { this.s = s; }
            public bool enabled { get => s.m_TrailsEnabled; set => s.m_TrailsEnabled = value; }
            public ParticleSystemTrailMode mode { get; set; }
            public float ratio { get; set; }
            public MinMaxCurve lifetime { get; set; }
            public float lifetimeMultiplier { get; set; }
            public float minVertexDistance { get; set; }
            public ParticleSystemTrailTextureMode textureMode { get; set; }
            public bool worldSpace { get; set; }
            public bool dieWithParticles { get; set; }
            public bool sizeAffectsWidth { get; set; }
            public bool sizeAffectsLifetime { get; set; }
            public bool inheritParticleColor { get; set; }
            public MinMaxGradient colorOverLifetime { get; set; }
            public MinMaxCurve widthOverTrail { get; set; }
            public float widthOverTrailMultiplier { get; set; }
            public MinMaxGradient colorOverTrail { get; set; }
            public bool generateLightingData { get; set; }
            public int ribbonCount { get; set; }
            public float shadowBias { get; set; }
            public bool splitSubEmitterRibbons { get; set; }
            public bool attachRibbonsToTransform { get; set; }
        }
        public struct CustomDataModule
        {
            readonly ParticleSystem s; internal CustomDataModule(ParticleSystem s) { this.s = s; }
            public bool enabled { get => s.m_CustomDataEnabled; set => s.m_CustomDataEnabled = value; }
        }
    }
}
