// uGUI graphics: Graphic, Image, RawImage, Text, masks, mesh effects, CanvasScaler, GraphicRaycaster.
using System;
using System.Collections.Generic;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace UnityEngine.UI
{
    public enum CanvasUpdate { Prelayout = 0, Layout = 1, PostLayout = 2, PreRender = 3, LatePreRender = 4, MaxUpdateValue = 5 }
    public interface ICanvasElement { void Rebuild(CanvasUpdate executing); Transform transform { get; } void LayoutComplete(); void GraphicUpdateComplete(); bool IsDestroyed(); }
    public interface IClippable { GameObject gameObject { get; } void RecalculateClipping(); RectTransform rectTransform { get; } void Cull(Rect clipRect, bool validRect); void SetClipRect(Rect value, bool validRect); void SetClipSoftness(Vector2 clipSoftness); }
    public interface IMaskable { void RecalculateMasking(); }
    public interface IMaterialModifier { Material GetModifiedMaterial(Material baseMaterial); }
    public interface IMeshModifier { void ModifyMesh(Mesh mesh); void ModifyMesh(VertexHelper verts); }
    // internal: refreshes visuals that Unity keeps up to date in the editor (slider fill, toggle mark...)
    internal interface IUIRefresh { void UIRefresh(); }

    public static class CanvasUpdateRegistry
    {
        public static bool IsRebuildingLayout() => false;
        public static bool IsRebuildingGraphics() => false;
        public static void RegisterCanvasElementForLayoutRebuild(ICanvasElement element) => UIRuntime.MarkLayoutDirty();
        public static bool TryRegisterCanvasElementForLayoutRebuild(ICanvasElement element) { UIRuntime.MarkLayoutDirty(); return true; }
        public static void RegisterCanvasElementForGraphicRebuild(ICanvasElement element) { }
        public static bool TryRegisterCanvasElementForGraphicRebuild(ICanvasElement element) => true;
        public static void UnRegisterCanvasElementForRebuild(ICanvasElement element) { }
        public static void DisableCanvasElementForRebuild(ICanvasElement element) { }
    }

    public struct UIVertex
    {
        public Vector3 position, normal; public Vector4 tangent; public Color32 color; public Vector4 uv0, uv1, uv2, uv3;
        public static UIVertex simpleVert = new UIVertex { position = Vector3.zero, normal = Vector3.back, tangent = new Vector4(1, 0, 0, -1), color = new Color32(255, 255, 255, 255) };
    }
    public class VertexHelper : IDisposable
    {
        internal readonly List<UIVertex> m_Verts = new List<UIVertex>();
        internal readonly List<int> m_Indices = new List<int>();
        public VertexHelper() { }
        public VertexHelper(Mesh m) { }
        public void Clear() { m_Verts.Clear(); m_Indices.Clear(); }
        public int currentVertCount => m_Verts.Count;
        public int currentIndexCount => m_Indices.Count;
        public void PopulateUIVertex(ref UIVertex vertex, int i) => vertex = m_Verts[i];
        public void SetUIVertex(UIVertex vertex, int i) => m_Verts[i] = vertex;
        public void FillMesh(Mesh mesh) { }
        public void Dispose() { Clear(); }
        public void AddVert(Vector3 position, Color32 color, Vector4 uv0, Vector4 uv1, Vector4 uv2, Vector4 uv3, Vector3 normal, Vector4 tangent) => m_Verts.Add(new UIVertex { position = position, color = color, uv0 = uv0, uv1 = uv1, uv2 = uv2, uv3 = uv3, normal = normal, tangent = tangent });
        public void AddVert(Vector3 position, Color32 color, Vector4 uv0, Vector4 uv1, Vector3 normal, Vector4 tangent) => AddVert(position, color, uv0, uv1, Vector4.zero, Vector4.zero, normal, tangent);
        public void AddVert(Vector3 position, Color32 color, Vector4 uv0) => AddVert(position, color, uv0, Vector4.zero, Vector3.back, new Vector4(1, 0, 0, -1));
        public void AddVert(UIVertex v) => m_Verts.Add(v);
        public void AddTriangle(int idx0, int idx1, int idx2) { m_Indices.Add(idx0); m_Indices.Add(idx1); m_Indices.Add(idx2); }
        public void AddUIVertexQuad(UIVertex[] verts) { int s = currentVertCount; for (int i = 0; i < 4; i++) AddVert(verts[i]); AddTriangle(s, s + 1, s + 2); AddTriangle(s + 2, s + 3, s); }
        public void AddUIVertexStream(List<UIVertex> verts, List<int> indices) { int s = currentVertCount; m_Verts.AddRange(verts); if (indices != null) foreach (var i in indices) m_Indices.Add(i + s); }
        public void AddUIVertexTriangleStream(List<UIVertex> verts) { int s = currentVertCount; m_Verts.AddRange(verts); for (int i = 0; i < verts.Count; i++) m_Indices.Add(s + i); }
        public void GetUIVertexStream(List<UIVertex> stream) { stream.Clear(); foreach (var i in m_Indices) stream.Add(m_Verts[i]); }
    }

    [DisallowMultipleComponent]
    [RequireComponent(typeof(RectTransform))]
    [RequireComponent(typeof(CanvasRenderer))]
    public abstract class Graphic : UIBehaviour, ICanvasElement
    {
        static Material s_DefaultUI; static Texture2D s_WhiteTexture;
        public static Material defaultGraphicMaterial => s_DefaultUI ??= new Material(Shader.Find("UI/Default")) { m_Name = "Default UI Material" };
        protected static Texture2D s_WhiteTexture2 => s_WhiteTexture ??= Texture2D.whiteTexture;
        [SerializeField] protected Material m_Material;
        [SerializeField] Color m_Color = Color.white;
        [SerializeField] bool m_RaycastTarget = true;
        [SerializeField] Vector4 m_RaycastPadding;
        [NonSerialized] protected bool useLegacyMeshGeneration = true;
        // cross fades (Selectable colour tint, Toggle fade)
        [NonSerialized] internal Color m_FadeFrom = Color.white, m_FadeTo = Color.white; [NonSerialized] internal float m_FadeStart, m_FadeDur; [NonSerialized] internal bool m_FadeUnscaled, m_FadeRGB = true, m_FadeA = true;
        [NonSerialized] internal float m_AlphaFrom = 1, m_AlphaTo = 1, m_AlphaStart, m_AlphaDur;

        public virtual Color color { get => m_Color; set { m_Color = value; SetVerticesDirty(); } }
        public virtual bool raycastTarget { get => m_RaycastTarget; set => m_RaycastTarget = value; }
        public Vector4 raycastPadding { get => m_RaycastPadding; set => m_RaycastPadding = value; }
        public int depth => -1;
        public RectTransform rectTransform => (RectTransform)transform;
        public Canvas canvas => GetComponentInParent<Canvas>();
        public CanvasRenderer canvasRenderer { get { var c = GetComponent<CanvasRenderer>(); return c != null ? c : gameObject.AddComponent<CanvasRenderer>(); } }
        public virtual Material defaultMaterial => defaultGraphicMaterial;
        public virtual Material material { get => m_Material != null ? m_Material : defaultMaterial; set => m_Material = value; }
        public virtual Material materialForRendering => material;
        public virtual Texture mainTexture => s_WhiteTexture2;
        public virtual void SetAllDirty() { SetLayoutDirty(); SetVerticesDirty(); SetMaterialDirty(); }
        public virtual void SetLayoutDirty() => UIRuntime.MarkLayoutDirty();
        public virtual void SetVerticesDirty() { }
        public virtual void SetMaterialDirty() { }
        public void SetRaycastDirty() { }
        public virtual void Rebuild(CanvasUpdate update) { }
        public virtual void LayoutComplete() { }
        public virtual void GraphicUpdateComplete() { }
        public virtual void OnCullingChanged() { }
        public virtual void SetNativeSize() { }
        protected virtual void UpdateGeometry() { }
        protected virtual void UpdateMaterial() { }
        protected virtual void OnPopulateMesh(VertexHelper vh)
        {
            var r = GetPixelAdjustedRect(); var c = (Color32)color;
            vh.Clear();
            vh.AddVert(new Vector3(r.xMin, r.yMin), c, new Vector4(0, 0)); vh.AddVert(new Vector3(r.xMin, r.yMax), c, new Vector4(0, 1));
            vh.AddVert(new Vector3(r.xMax, r.yMax), c, new Vector4(1, 1)); vh.AddVert(new Vector3(r.xMax, r.yMin), c, new Vector4(1, 0));
            vh.AddTriangle(0, 1, 2); vh.AddTriangle(2, 3, 0);
        }
        [Obsolete("Use OnPopulateMesh(VertexHelper vh) instead.", false)] protected virtual void OnPopulateMesh(Mesh m) { }
        protected override void OnRectTransformDimensionsChange() { }
        protected override void OnEnable() { UIRuntime.MarkLayoutDirty(); }
        protected override void OnDisable() { UIRuntime.MarkLayoutDirty(); }
        public virtual bool Raycast(Vector2 sp, Camera eventCamera)
        {
            if (!isActiveAndEnabled) return false;
            for (var t = transform; t != null; t = t.parent)
            {
                foreach (var c in t.gameObject.m_Components)
                {
                    if (c is ICanvasRaycastFilter f && (!(c is Behaviour b) || b.isActiveAndEnabled))
                    {
                        if (c is CanvasGroup cg) { if (!cg.blocksRaycasts) return false; if (cg.ignoreParentGroups) goto next; continue; }
                        if (!f.IsRaycastLocationValid(sp, eventCamera)) return false;
                    }
                }
                if (t.GetComponent<Canvas>() is Canvas cv && cv.overrideSorting) break;
                next:;
            }
            return true;
        }
        public Vector2 PixelAdjustPoint(Vector2 point) => point;
        public Rect GetPixelAdjustedRect() => rectTransform.rect;
        public virtual void CrossFadeColor(Color targetColor, float duration, bool ignoreTimeScale, bool useAlpha) => CrossFadeColor(targetColor, duration, ignoreTimeScale, useAlpha, true);
        public virtual void CrossFadeColor(Color targetColor, float duration, bool ignoreTimeScale, bool useAlpha, bool useRGB)
        {
            var cr = canvasRenderer;
            if (!useRGB && !useAlpha) return;
            var cur = cr.GetColor();
            if (duration <= 0) { cr.SetColor(new Color(useRGB ? targetColor.r : cur.r, useRGB ? targetColor.g : cur.g, useRGB ? targetColor.b : cur.b, useAlpha ? targetColor.a : cur.a)); m_FadeDur = 0; return; }
            m_FadeFrom = cur; m_FadeTo = targetColor; m_FadeDur = duration; m_FadeUnscaled = ignoreTimeScale; m_FadeRGB = useRGB; m_FadeA = useAlpha;
            m_FadeStart = ignoreTimeScale ? Time.unscaledTime : Time.time;
        }
        public virtual void CrossFadeAlpha(float alpha, float duration, bool ignoreTimeScale)
        {
            var cr = canvasRenderer;
            if (duration <= 0) { cr.SetAlpha(alpha); m_AlphaDur = 0; return; }
            m_AlphaFrom = cr.GetAlpha(); m_AlphaTo = alpha; m_AlphaDur = duration; m_AlphaStart = ignoreTimeScale ? Time.unscaledTime : Time.time; m_FadeUnscaled = ignoreTimeScale;
        }
        internal void StepFades()
        {
            if (m_FadeDur > 0)
            {
                float t = Mathf.Clamp01(((m_FadeUnscaled ? Time.unscaledTime : Time.time) - m_FadeStart) / m_FadeDur);
                var c = Color.Lerp(m_FadeFrom, m_FadeTo, t); var cur = canvasRenderer.m_Color;
                canvasRenderer.m_Color = new Color(m_FadeRGB ? c.r : cur.r, m_FadeRGB ? c.g : cur.g, m_FadeRGB ? c.b : cur.b, m_FadeA ? c.a : cur.a);
                if (t >= 1) m_FadeDur = 0;
            }
            if (m_AlphaDur > 0)
            {
                float t = Mathf.Clamp01(((m_FadeUnscaled ? Time.unscaledTime : Time.time) - m_AlphaStart) / m_AlphaDur);
                canvasRenderer.m_Alpha = Mathf.Lerp(m_AlphaFrom, m_AlphaTo, t);
                if (t >= 1) m_AlphaDur = 0;
            }
        }
        public void RegisterDirtyLayoutCallback(UnityAction action) { }
        public void UnregisterDirtyLayoutCallback(UnityAction action) { }
        public void RegisterDirtyVerticesCallback(UnityAction action) { }
        public void UnregisterDirtyVerticesCallback(UnityAction action) { }
        public void RegisterDirtyMaterialCallback(UnityAction action) { }
        public void UnregisterDirtyMaterialCallback(UnityAction action) { }
        // draws this graphic (called by UIRuntime with screen-space geometry)
        internal virtual void Draw(UIDraw d) { if (UIRuntime.OverridesPopulate(GetType())) d.CustomMesh(this); else d.Quad(this, null, 0, null); }
        internal Color RenderColor(float groupAlpha)
        {
            var cr = GetComponent<CanvasRenderer>();
            var c = color;
            if (cr != null) { c *= cr.m_Color; c.a *= cr.m_Alpha; }
            c.a *= groupAlpha;
            return c;
        }
        internal void PopulateForDraw(VertexHelper vh) => OnPopulateMesh(vh);
    }

    public abstract class MaskableGraphic : Graphic, IClippable, IMaskable, IMaterialModifier
    {
        [Serializable] public class CullStateChangedEvent : UnityEvent<bool> { }
        [SerializeField] bool m_Maskable = true;
        [SerializeField] CullStateChangedEvent m_OnCullStateChanged = new CullStateChangedEvent();
        public CullStateChangedEvent onCullStateChanged { get => m_OnCullStateChanged; set => m_OnCullStateChanged = value; }
        public bool maskable { get => m_Maskable; set => m_Maskable = value; }
        public bool isMaskingGraphic { get; set; }
        public virtual Material GetModifiedMaterial(Material baseMaterial) => baseMaterial;
        public virtual void Cull(Rect clipRect, bool validRect) { }
        public virtual void SetClipRect(Rect clipRect, bool validRect) { }
        public virtual void SetClipSoftness(Vector2 clipSoftness) { }
        public virtual void RecalculateClipping() { }
        public virtual void RecalculateMasking() { }
        [Obsolete("Not used anymore.", true)] public virtual void ParentMaskStateChanged() { }
    }

    public class Image : MaskableGraphic, ISerializationCallbackReceiver, ILayoutElement, ICanvasRaycastFilter
    {
        public enum Type { Simple = 0, Sliced = 1, Tiled = 2, Filled = 3 }
        public enum FillMethod { Horizontal = 0, Vertical = 1, Radial90 = 2, Radial180 = 3, Radial360 = 4 }
        public enum OriginHorizontal { Left = 0, Right = 1 }
        public enum OriginVertical { Bottom = 0, Top = 1 }
        public enum Origin90 { BottomLeft = 0, TopLeft = 1, TopRight = 2, BottomRight = 3 }
        public enum Origin180 { Bottom = 0, Left = 1, Top = 2, Right = 3 }
        public enum Origin360 { Bottom = 0, Right = 1, Top = 2, Left = 3 }
        protected static Material s_ETC1DefaultUI = null;
        [SerializeField] Sprite m_Sprite; [NonSerialized] Sprite m_OverrideSprite;
        [SerializeField] Type m_Type = Type.Simple;
        [SerializeField] bool m_PreserveAspect, m_FillCenter = true;
        [SerializeField] FillMethod m_FillMethod = FillMethod.Radial360;
        [SerializeField] float m_FillAmount = 1f;
        [SerializeField] bool m_FillClockwise = true;
        [SerializeField] int m_FillOrigin;
        [SerializeField] bool m_UseSpriteMesh;
        [SerializeField] float m_PixelsPerUnitMultiplier = 1f;
        float m_AlphaHitTestMinimumThreshold;
        public Sprite sprite { get => m_Sprite; set { m_Sprite = value; SetAllDirty(); } }
        public Sprite overrideSprite { get => activeSprite; set => m_OverrideSprite = value; }
        Sprite activeSprite => m_OverrideSprite != null ? m_OverrideSprite : m_Sprite;
        public Type type { get => m_Type; set => m_Type = value; }
        public bool preserveAspect { get => m_PreserveAspect; set => m_PreserveAspect = value; }
        public bool fillCenter { get => m_FillCenter; set => m_FillCenter = value; }
        public FillMethod fillMethod { get => m_FillMethod; set { m_FillMethod = value; m_FillOrigin = 0; } }
        public float fillAmount { get => m_FillAmount; set => m_FillAmount = Mathf.Clamp01(value); }
        public bool fillClockwise { get => m_FillClockwise; set => m_FillClockwise = value; }
        public int fillOrigin { get => m_FillOrigin; set => m_FillOrigin = value; }
        public bool useSpriteMesh { get => m_UseSpriteMesh; set => m_UseSpriteMesh = value; }
        public float pixelsPerUnitMultiplier { get => m_PixelsPerUnitMultiplier; set => m_PixelsPerUnitMultiplier = Mathf.Max(0.01f, value); }
        public float alphaHitTestMinimumThreshold { get => m_AlphaHitTestMinimumThreshold; set => m_AlphaHitTestMinimumThreshold = value; }
        [Obsolete("eventAlphaThreshold has been deprecated. Use eventMinimumAlphaThreshold instead (UnityUpgradable) -> alphaHitTestMinimumThreshold")] public float eventAlphaThreshold { get => 1 - alphaHitTestMinimumThreshold; set => alphaHitTestMinimumThreshold = 1 - value; }
        public static Material defaultETC1GraphicMaterial => defaultGraphicMaterial;
        public override Texture mainTexture => activeSprite != null ? activeSprite.texture : s_WhiteTexture2;
        public bool hasBorder => activeSprite != null && activeSprite.border.sqrMagnitude > 0f;
        public float pixelsPerUnit { get { float sp = activeSprite != null ? activeSprite.pixelsPerUnit : 100; var c = canvas; float r = c != null ? c.referencePixelsPerUnit : 100; return sp / r; } }
        public override Material material { get => m_Material != null ? m_Material : defaultMaterial; set => base.material = value; }
        public virtual void CalculateLayoutInputHorizontal() { }
        public virtual void CalculateLayoutInputVertical() { }
        public virtual float minWidth => 0;
        public virtual float preferredWidth => activeSprite == null ? 0 : (type == Type.Sliced || type == Type.Tiled ? (activeSprite.border.x + activeSprite.border.z) : activeSprite.rect.width) / pixelsPerUnit;
        public virtual float flexibleWidth => -1;
        public virtual float minHeight => 0;
        public virtual float preferredHeight => activeSprite == null ? 0 : (type == Type.Sliced || type == Type.Tiled ? (activeSprite.border.y + activeSprite.border.w) : activeSprite.rect.height) / pixelsPerUnit;
        public virtual float flexibleHeight => -1;
        public virtual int layoutPriority => 0;
        public override void SetNativeSize()
        {
            if (activeSprite == null) return;
            float w = activeSprite.rect.width / pixelsPerUnit, h = activeSprite.rect.height / pixelsPerUnit;
            rectTransform.anchorMax = rectTransform.anchorMin;
            rectTransform.sizeDelta = new Vector2(w, h);
        }
        public virtual bool IsRaycastLocationValid(Vector2 screenPoint, Camera eventCamera) => true;
        public virtual void OnBeforeSerialize() { }
        public virtual void OnAfterDeserialize() { }
        public void DisableSpriteOptimizations() { }
        internal override void Draw(UIDraw d)
        {
            if (UIRuntime.OverridesPopulate(GetType())) { d.CustomMesh(this); return; }
            string extra = null;
            var sp = activeSprite;
            if (m_Type == Type.Filled && m_FillAmount < 1f) extra = "fl=" + (int)m_FillMethod + "," + UIDraw.F(m_FillAmount) + "," + m_FillOrigin + "," + (m_FillClockwise ? 1 : 0);
            if (sp != null && sp.texture != null && (sp.rect.x != 0 || sp.rect.y != 0 || sp.rect.width != sp.texture.width || sp.rect.height != sp.texture.height))
            {
                float tw = sp.texture.width, th = sp.texture.height;
                extra = (extra != null ? extra + ";" : "") + "uv=" + UIDraw.F(sp.rect.x / tw) + "," + UIDraw.F(sp.rect.y / th) + "," + UIDraw.F(sp.rect.width / tw) + "," + UIDraw.F(sp.rect.height / th);
            }
            if (sp != null && (m_Type == Type.Sliced || m_Type == Type.Tiled) && hasBorder)
                extra = (extra != null ? extra + ";" : "") + "sl=" + UIDraw.F(sp.border.x) + "," + UIDraw.F(sp.border.y) + "," + UIDraw.F(sp.border.z) + "," + UIDraw.F(sp.border.w) + "," + UIDraw.F(pixelsPerUnit) + (m_FillCenter ? "" : ",h");
            d.Quad(this, sp?.texture, m_PreserveAspect && m_Type == Type.Simple ? 2 : 0, extra);
        }
    }

    public class RawImage : MaskableGraphic
    {
        [SerializeField] Texture m_Texture;
        [SerializeField] Rect m_UVRect = new Rect(0f, 0f, 1f, 1f);
        public override Texture mainTexture => m_Texture != null ? m_Texture : s_WhiteTexture2;
        public Texture texture { get => m_Texture; set => m_Texture = value; }
        public Rect uvRect { get => m_UVRect; set => m_UVRect = value; }
        public override void SetNativeSize()
        {
            var t = mainTexture; if (t == null) return;
            rectTransform.anchorMax = rectTransform.anchorMin;
            rectTransform.sizeDelta = new Vector2(t.width * m_UVRect.width, t.height * m_UVRect.height);
        }
        internal override void Draw(UIDraw d)
        {
            string extra = m_UVRect != new Rect(0, 0, 1, 1) ? "uv=" + UIDraw.F(m_UVRect.x) + "," + UIDraw.F(m_UVRect.y) + "," + UIDraw.F(m_UVRect.width) + "," + UIDraw.F(m_UVRect.height) : null;
            d.Quad(this, m_Texture, 0, extra);
        }
    }

    [Serializable]
    public class FontData : ISerializationCallbackReceiver
    {
        public static FontData defaultFontData => new FontData { font = Font.Default, fontSize = 14, lineSpacing = 1f, fontStyle = FontStyle.Normal, bestFit = false, minSize = 10, maxSize = 40, alignment = TextAnchor.UpperLeft, horizontalOverflow = HorizontalWrapMode.Wrap, verticalOverflow = VerticalWrapMode.Truncate, richText = true, alignByGeometry = false };
        public Font font { get; set; }
        public int fontSize { get; set; }
        public FontStyle fontStyle { get; set; }
        public bool bestFit { get; set; }
        public int minSize { get; set; }
        public int maxSize { get; set; }
        public TextAnchor alignment { get; set; }
        public bool alignByGeometry { get; set; }
        public bool richText { get; set; }
        public HorizontalWrapMode horizontalOverflow { get; set; }
        public VerticalWrapMode verticalOverflow { get; set; }
        public float lineSpacing { get; set; }
        void ISerializationCallbackReceiver.OnBeforeSerialize() { }
        void ISerializationCallbackReceiver.OnAfterDeserialize() { }
    }

    public class Text : MaskableGraphic, ILayoutElement
    {
        [SerializeField] protected string m_Text = "";
        [SerializeField] Font m_Font;
        [SerializeField] int m_FontSize = 14;
        [SerializeField] FontStyle m_FontStyle = FontStyle.Normal;
        [SerializeField] bool m_BestFit; [SerializeField] int m_MinSize = 10, m_MaxSize = 40;
        [SerializeField] TextAnchor m_Alignment = TextAnchor.UpperLeft;
        [SerializeField] bool m_AlignByGeometry, m_RichText = true;
        [SerializeField] HorizontalWrapMode m_HorizontalOverflow = HorizontalWrapMode.Wrap;
        [SerializeField] VerticalWrapMode m_VerticalOverflow = VerticalWrapMode.Truncate;
        [SerializeField] float m_LineSpacing = 1f;
        public virtual string text { get => m_Text; set { m_Text = value ?? ""; SetLayoutDirty(); } }
        public Font font { get => m_Font != null ? m_Font : Font.Default; set => m_Font = value; }
        public int fontSize { get => m_FontSize; set { m_FontSize = value; SetLayoutDirty(); } }
        public FontStyle fontStyle { get => m_FontStyle; set => m_FontStyle = value; }
        public bool resizeTextForBestFit { get => m_BestFit; set => m_BestFit = value; }
        public int resizeTextMinSize { get => m_MinSize; set => m_MinSize = value; }
        public int resizeTextMaxSize { get => m_MaxSize; set => m_MaxSize = value; }
        public TextAnchor alignment { get => m_Alignment; set => m_Alignment = value; }
        public bool alignByGeometry { get => m_AlignByGeometry; set => m_AlignByGeometry = value; }
        public bool supportRichText { get => m_RichText; set => m_RichText = value; }
        public HorizontalWrapMode horizontalOverflow { get => m_HorizontalOverflow; set => m_HorizontalOverflow = value; }
        public VerticalWrapMode verticalOverflow { get => m_VerticalOverflow; set => m_VerticalOverflow = value; }
        public float lineSpacing { get => m_LineSpacing; set => m_LineSpacing = value; }
        public override Texture mainTexture => s_WhiteTexture2;
        public float pixelsPerUnit => 1f;
        public TextGenerator cachedTextGenerator => new TextGenerator();
        public TextGenerator cachedTextGeneratorForLayout => new TextGenerator();
        public void FontTextureChanged() { }
        public TextGenerationSettings GetGenerationSettings(Vector2 extents) => new TextGenerationSettings { font = font, fontSize = fontSize, fontStyle = fontStyle, richText = supportRichText, lineSpacing = lineSpacing, textAnchor = alignment, horizontalOverflow = horizontalOverflow, verticalOverflow = verticalOverflow, generationExtents = extents, color = color, scaleFactor = 1 };
        public static Vector2 GetTextAnchorPivot(TextAnchor anchor) => new Vector2((int)anchor % 3 * 0.5f, 1 - (int)anchor / 3 * 0.5f);
        public virtual void CalculateLayoutInputHorizontal() { }
        public virtual void CalculateLayoutInputVertical() { }
        public virtual float minWidth => 0;
        public virtual float preferredWidth => UIText.Measure(m_Text, m_FontSize, m_FontStyle == FontStyle.Bold || m_FontStyle == FontStyle.BoldAndItalic, -1, m_LineSpacing, 0, m_RichText).x;
        public virtual float flexibleWidth => -1;
        public virtual float minHeight => 0;
        public virtual float preferredHeight => UIText.Measure(m_Text, m_FontSize, m_FontStyle == FontStyle.Bold || m_FontStyle == FontStyle.BoldAndItalic, m_HorizontalOverflow == HorizontalWrapMode.Wrap ? rectTransform.rect.width : -1, m_LineSpacing, 0, m_RichText).y;
        public virtual float flexibleHeight => -1;
        public virtual int layoutPriority => 0;
        public override void SetNativeSize() { }
        internal override void Draw(UIDraw d)
        {
            float size = m_FontSize;
            if (m_BestFit) size = UIText.BestFit(m_Text, m_MinSize, m_MaxSize, rectTransform.rect.size, m_LineSpacing, 0, m_RichText, m_HorizontalOverflow == HorizontalWrapMode.Wrap);
            var extra = new System.Text.StringBuilder();
            if (m_LineSpacing != 1f) extra.Append("ls=").Append(UIDraw.F(m_LineSpacing)).Append(';');
            if (m_VerticalOverflow == VerticalWrapMode.Truncate) extra.Append("clip=1;");
            UIEffects.Append(this, extra);
            d.Text(this, m_Text, size, (int)m_FontStyle, (int)m_Alignment, m_HorizontalOverflow == HorizontalWrapMode.Wrap, m_RichText, FontFamily(), extra.ToString());
        }
        string FontFamily() { var f = m_Font; if (f == null || f.name == "LegacyRuntime" || f.name == "Arial") return null; return f.fontNames != null && f.fontNames.Length > 0 ? string.Join(",", f.fontNames) : f.name; }
        public override string ToString() => m_Text;
    }

    // simple text metrics (Arial-like advance widths) for layout and best fit
    internal static class UIText
    {
        static float Adv(char c)
        {
            if (c == ' ') return 0.278f;
            if ("il.,:;'|!".IndexOf(c) >= 0) return 0.24f;
            if ("fjrt()[]{}-\"".IndexOf(c) >= 0) return 0.33f;
            if ("mwMW@".IndexOf(c) >= 0) return 0.86f;
            if (char.IsDigit(c)) return 0.556f;
            if (char.IsUpper(c)) return 0.68f;
            return 0.53f;
        }
        internal static string StripTags(string s, bool rich)
        {
            if (!rich || s == null || s.IndexOf('<') < 0) return s ?? "";
            return System.Text.RegularExpressions.Regex.Replace(s, "<[^<>]{1,40}>", "");
        }
        internal static Vector2 Measure(string text, float fontSize, bool bold, float wrapWidth, float lineSpacing, float charSpacingEm, bool rich)
        {
            text = StripTags(text, rich);
            if (string.IsNullOrEmpty(text)) return new Vector2(0, fontSize * 1.15f * lineSpacing);
            float maxW = 0; int lines = 0;
            foreach (var raw in text.Replace("\r", "").Split('\n'))
            {
                float w = 0; lines++;
                float lastBreakW = 0;
                foreach (char ch in raw)
                {
                    float a = (Adv(ch) * (bold ? 1.06f : 1f) + charSpacingEm) * fontSize;
                    if (wrapWidth > 0 && w + a > wrapWidth && w > 0)
                    {
                        maxW = Mathf.Max(maxW, ch == ' ' ? w : (lastBreakW > 0 ? lastBreakW : w));
                        lines++;
                        w = ch == ' ' ? 0 : (lastBreakW > 0 ? w - lastBreakW : 0);
                        lastBreakW = 0;
                        if (ch == ' ') continue;
                    }
                    if (ch == ' ') lastBreakW = w;
                    w += a;
                }
                maxW = Mathf.Max(maxW, w);
            }
            return new Vector2(maxW, lines * fontSize * 1.15f * lineSpacing);
        }
        internal static float BestFit(string text, float min, float max, Vector2 box, float lineSpacing, float cs, bool rich, bool wrap)
        {
            for (float s = max; s > min; s -= 1f)
            {
                var m = Measure(text, s, false, wrap ? box.x : -1, lineSpacing, cs, rich);
                if (m.x <= box.x + 0.5f && m.y <= box.y + 0.5f) return s;
            }
            return min;
        }
    }

    // ---------- masks ----------
    [AddComponentMenu("UI/Mask", 13)]
    [RequireComponent(typeof(RectTransform))]
    [DisallowMultipleComponent]
    public class Mask : UIBehaviour, ICanvasRaycastFilter, IMaterialModifier
    {
        [SerializeField] bool m_ShowMaskGraphic = true;
        public RectTransform rectTransform => (RectTransform)transform;
        public bool showMaskGraphic { get => m_ShowMaskGraphic; set => m_ShowMaskGraphic = value; }
        public Graphic graphic => GetComponent<Graphic>();
        public virtual bool MaskEnabled() => IsActive() && graphic != null;
        [Obsolete("Not used anymore.")] public virtual void OnSiblingGraphicEnabledDisabled() { }
        public virtual bool IsRaycastLocationValid(Vector2 sp, Camera eventCamera) => !isActiveAndEnabled || RectTransformUtility.RectangleContainsScreenPoint(rectTransform, sp, eventCamera);
        public virtual Material GetModifiedMaterial(Material baseMaterial) => baseMaterial;
    }
    [AddComponentMenu("UI/Rect Mask 2D", 14)]
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [RequireComponent(typeof(RectTransform))]
    public class RectMask2D : UIBehaviour, IClipper, ICanvasRaycastFilter
    {
        [SerializeField] Vector4 m_Padding;
        [SerializeField] Vector2Int m_Softness;
        public Vector4 padding { get => m_Padding; set => m_Padding = value; }
        public Vector2Int softness { get => m_Softness; set => m_Softness = value; }
        public Rect canvasRect => rectTransform.rect;
        public RectTransform rectTransform => (RectTransform)transform;
        public virtual bool IsRaycastLocationValid(Vector2 sp, Camera eventCamera) => !isActiveAndEnabled || RectTransformUtility.RectangleContainsScreenPoint(rectTransform, sp, eventCamera, m_Padding);
        public virtual void PerformClipping() { }
        public void AddClippable(IClippable clippable) { }
        public void RemoveClippable(IClippable clippable) { }
    }
    public interface IClipper { void PerformClipping(); }

    // ---------- mesh effects ----------
    [ExecuteAlways]
    public abstract class BaseMeshEffect : UIBehaviour, IMeshModifier
    {
        protected Graphic graphic => GetComponent<Graphic>();
        public virtual void ModifyMesh(Mesh mesh) { }
        public abstract void ModifyMesh(VertexHelper vh);
    }
    [AddComponentMenu("UI/Effects/Shadow", 80)]
    public class Shadow : BaseMeshEffect
    {
        [SerializeField] Color m_EffectColor = new Color(0f, 0f, 0f, 0.5f);
        [SerializeField] Vector2 m_EffectDistance = new Vector2(1f, -1f);
        [SerializeField] bool m_UseGraphicAlpha = true;
        public Color effectColor { get => m_EffectColor; set => m_EffectColor = value; }
        public Vector2 effectDistance { get => m_EffectDistance; set => m_EffectDistance = new Vector2(Mathf.Clamp(value.x, -600, 600), Mathf.Clamp(value.y, -600, 600)); }
        public bool useGraphicAlpha { get => m_UseGraphicAlpha; set => m_UseGraphicAlpha = value; }
        public override void ModifyMesh(VertexHelper vh) { }
        protected void ApplyShadow(List<UIVertex> verts, Color32 color, int start, int end, float x, float y) { }
    }
    [AddComponentMenu("UI/Effects/Outline", 81)]
    public class Outline : Shadow { }
    [AddComponentMenu("UI/Effects/Position As UV1", 82)]
    public class PositionAsUV1 : BaseMeshEffect { public override void ModifyMesh(VertexHelper vh) { } }
    internal static class UIEffects
    {
        internal static void Append(Component g, System.Text.StringBuilder sb)
        {
            foreach (var c in g.gameObject.m_Components)
            {
                if (!(c is Shadow s) || !s.isActiveAndEnabled) continue;
                var col = s.effectColor;
                sb.Append(c is Outline ? "ol=" : "sh=").Append(UIDraw.Hex(col)).Append(',').Append(UIDraw.F(s.effectDistance.x)).Append(',').Append(UIDraw.F(s.effectDistance.y)).Append(';');
            }
        }
    }

    // ---------- canvas helpers ----------
    [RequireComponent(typeof(Canvas))]
    [ExecuteAlways]
    [DisallowMultipleComponent]
    public class CanvasScaler : UIBehaviour
    {
        public enum ScaleMode { ConstantPixelSize = 0, ScaleWithScreenSize = 1, ConstantPhysicalSize = 2 }
        public enum ScreenMatchMode { MatchWidthOrHeight = 0, Expand = 1, Shrink = 2 }
        public enum Unit { Centimeters = 0, Millimeters = 1, Inches = 2, Points = 3, Picas = 4 }
        [SerializeField] ScaleMode m_UiScaleMode = ScaleMode.ConstantPixelSize;
        [SerializeField] protected float m_ReferencePixelsPerUnit = 100;
        [SerializeField] protected float m_ScaleFactor = 1;
        [SerializeField] protected Vector2 m_ReferenceResolution = new Vector2(800, 600);
        [SerializeField] protected ScreenMatchMode m_ScreenMatchMode = ScreenMatchMode.MatchWidthOrHeight;
        [Range(0, 1)] [SerializeField] protected float m_MatchWidthOrHeight = 0;
        [SerializeField] protected Unit m_PhysicalUnit = Unit.Points;
        [SerializeField] protected float m_FallbackScreenDPI = 96, m_DefaultSpriteDPI = 96, m_DynamicPixelsPerUnit = 1;
        [SerializeField] bool m_PresetInfoIsWorld;
        public ScaleMode uiScaleMode { get => m_UiScaleMode; set => m_UiScaleMode = value; }
        public float referencePixelsPerUnit { get => m_ReferencePixelsPerUnit; set => m_ReferencePixelsPerUnit = value; }
        public float scaleFactor { get => m_ScaleFactor; set => m_ScaleFactor = Mathf.Max(0.01f, value); }
        public Vector2 referenceResolution { get => m_ReferenceResolution; set { m_ReferenceResolution = value; if (m_ReferenceResolution.x > -1e-5f && m_ReferenceResolution.x < 1e-5f) m_ReferenceResolution.x = 1e-5f * Mathf.Sign(m_ReferenceResolution.x); if (m_ReferenceResolution.y > -1e-5f && m_ReferenceResolution.y < 1e-5f) m_ReferenceResolution.y = 1e-5f * Mathf.Sign(m_ReferenceResolution.y); } }
        public ScreenMatchMode screenMatchMode { get => m_ScreenMatchMode; set => m_ScreenMatchMode = value; }
        public float matchWidthOrHeight { get => m_MatchWidthOrHeight; set => m_MatchWidthOrHeight = value; }
        public Unit physicalUnit { get => m_PhysicalUnit; set => m_PhysicalUnit = value; }
        public float fallbackScreenDPI { get => m_FallbackScreenDPI; set => m_FallbackScreenDPI = value; }
        public float defaultSpriteDPI { get => m_DefaultSpriteDPI; set => m_DefaultSpriteDPI = Mathf.Max(1, value); }
        public float dynamicPixelsPerUnit { get => m_DynamicPixelsPerUnit; set => m_DynamicPixelsPerUnit = value; }
        protected virtual void Handle() { var c = GetComponent<Canvas>(); if (c != null) c.scaleFactor = ComputeScale(); }
        protected virtual void HandleWorldCanvas() { }
        protected virtual void HandleConstantPixelSize() { }
        protected virtual void HandleScaleWithScreenSize() { }
        protected virtual void HandleConstantPhysicalSize() { }
        protected void SetScaleFactor(float scaleFactor) { var c = GetComponent<Canvas>(); if (c != null) c.scaleFactor = scaleFactor; }
        protected void SetReferencePixelsPerUnit(float referencePixelsPerUnit) { var c = GetComponent<Canvas>(); if (c != null) c.referencePixelsPerUnit = referencePixelsPerUnit; }
        protected virtual void Update() => Handle();
        internal float ComputeScale()
        {
            switch (m_UiScaleMode)
            {
                case ScaleMode.ScaleWithScreenSize:
                    {
                        float w = Screen.width, h = Screen.height;
                        switch (m_ScreenMatchMode)
                        {
                            case ScreenMatchMode.Expand: return Mathf.Min(w / m_ReferenceResolution.x, h / m_ReferenceResolution.y);
                            case ScreenMatchMode.Shrink: return Mathf.Max(w / m_ReferenceResolution.x, h / m_ReferenceResolution.y);
                            default:
                                float lw = Mathf.Log(w / m_ReferenceResolution.x, 2), lh = Mathf.Log(h / m_ReferenceResolution.y, 2);
                                return Mathf.Pow(2, Mathf.Lerp(lw, lh, m_MatchWidthOrHeight));
                        }
                    }
                case ScaleMode.ConstantPhysicalSize:
                    {
                        float dpi = Screen.dpi > 0 ? Screen.dpi : m_FallbackScreenDPI;
                        float target = m_PhysicalUnit switch { Unit.Centimeters => 2.54f, Unit.Millimeters => 25.4f, Unit.Inches => 1, Unit.Points => 72, _ => 6 };
                        return dpi / target;
                    }
                default: return m_ScaleFactor;
            }
        }
    }

    [AddComponentMenu("Event/Graphic Raycaster")]
    [RequireComponent(typeof(Canvas))]
    public class GraphicRaycaster : BaseRaycaster
    {
        public enum BlockingObjects { None = 0, TwoD = 1, ThreeD = 2, All = 3 }
        [SerializeField] bool m_IgnoreReversedGraphics = true;
        [SerializeField] BlockingObjects m_BlockingObjects = BlockingObjects.None;
        [SerializeField] protected LayerMask m_BlockingMask = -1;
        public bool ignoreReversedGraphics { get => m_IgnoreReversedGraphics; set => m_IgnoreReversedGraphics = value; }
        public BlockingObjects blockingObjects { get => m_BlockingObjects; set => m_BlockingObjects = value; }
        public LayerMask blockingMask { get => m_BlockingMask; set => m_BlockingMask = value; }
        public override int sortOrderPriority { get { var c = GetComponent<Canvas>(); return c != null && c.renderMode == RenderMode.ScreenSpaceOverlay ? c.sortingOrder : base.sortOrderPriority; } }
        public override int renderOrderPriority { get { var c = GetComponent<Canvas>(); return c != null && c.renderMode == RenderMode.ScreenSpaceOverlay ? c.rootCanvas.renderOrder : base.renderOrderPriority; } }
        public override Camera eventCamera { get { var c = GetComponent<Canvas>(); if (c == null || c.renderMode == RenderMode.ScreenSpaceOverlay || (c.renderMode == RenderMode.ScreenSpaceCamera && c.worldCamera == null)) return null; return c.worldCamera != null ? c.worldCamera : Camera.main; } }
        public override void Raycast(PointerEventData eventData, List<RaycastResult> resultAppendList) => UIRuntime.RaycastCanvas(this, eventData, resultAppendList);
    }

    // Unity's TextGenerator: only the parts scripts read (line count, preferred size)
    public sealed class TextGenerator
    {
        public TextGenerator() { }
        public TextGenerator(int initialCapacity) { }
        public int lineCount { get; private set; }
        public int characterCount { get; private set; }
        public int characterCountVisible => characterCount;
        public int fontSizeUsedForBestFit { get; private set; }
        public Rect rectExtents { get; private set; }
        public bool Populate(string str, TextGenerationSettings settings)
        {
            var m = UIText.Measure(str, settings.fontSize, settings.fontStyle == FontStyle.Bold, settings.horizontalOverflow == HorizontalWrapMode.Wrap ? settings.generationExtents.x : -1, settings.lineSpacing, 0, settings.richText);
            lineCount = Mathf.Max(1, Mathf.RoundToInt(m.y / (settings.fontSize * 1.15f * Mathf.Max(0.01f, settings.lineSpacing))));
            characterCount = UIText.StripTags(str, settings.richText).Length;
            fontSizeUsedForBestFit = settings.fontSize;
            rectExtents = new Rect(0, 0, m.x, m.y);
            return true;
        }
        public bool PopulateWithErrors(string str, TextGenerationSettings settings, GameObject context) => Populate(str, settings);
        public float GetPreferredWidth(string str, TextGenerationSettings settings) => UIText.Measure(str, settings.fontSize, settings.fontStyle == FontStyle.Bold, -1, settings.lineSpacing, 0, settings.richText).x / Mathf.Max(0.0001f, settings.scaleFactor);
        public float GetPreferredHeight(string str, TextGenerationSettings settings) => UIText.Measure(str, settings.fontSize, settings.fontStyle == FontStyle.Bold, settings.horizontalOverflow == HorizontalWrapMode.Wrap ? settings.generationExtents.x : -1, settings.lineSpacing, 0, settings.richText).y / Mathf.Max(0.0001f, settings.scaleFactor);
        public void Invalidate() { }
    }
}

namespace UnityEngine
{
    public struct TextGenerationSettings
    {
        public Font font; public Color color; public int fontSize; public float lineSpacing; public bool richText; public float scaleFactor; public FontStyle fontStyle;
        public TextAnchor textAnchor; public bool alignByGeometry, resizeTextForBestFit; public int resizeTextMinSize, resizeTextMaxSize; public bool updateBounds;
        public VerticalWrapMode verticalOverflow; public HorizontalWrapMode horizontalOverflow; public Vector2 generationExtents, pivot; public bool generateOutOfBounds;
        public bool Equals(TextGenerationSettings other) => this.font == other.font && fontSize == other.fontSize && generationExtents == other.generationExtents;
    }
}
