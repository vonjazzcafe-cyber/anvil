// Anvil — IMGUI (OnGUI) subset. Draw commands are rendered by the editor as an HTML overlay on the Game view.
using System;
using System.Collections.Generic;
using Anvil;

namespace UnityEngine
{
    public enum TextAnchor { UpperLeft = 0, UpperCenter = 1, UpperRight = 2, MiddleLeft = 3, MiddleCenter = 4, MiddleRight = 5, LowerLeft = 6, LowerCenter = 7, LowerRight = 8 }
    public enum FontStyle { Normal = 0, Bold = 1, Italic = 2, BoldAndItalic = 3 }
    public enum TextClipping { Overflow = 0, Clip = 1, Ellipsis = 2 }
    public enum ScaleMode { StretchToFill = 0, ScaleAndCrop = 1, ScaleToFit = 2 }
    public enum EventType { MouseDown = 0, MouseUp = 1, MouseMove = 2, MouseDrag = 3, KeyDown = 4, KeyUp = 5, ScrollWheel = 6, Repaint = 7, Layout = 8, DragUpdated = 9, DragPerform = 10, DragExited = 15, Ignore = 11, Used = 12, ValidateCommand = 13, ExecuteCommand = 14, ContextClick = 16, MouseEnterWindow = 20, MouseLeaveWindow = 21, TouchDown = 30, TouchUp = 31, TouchMove = 32, TouchEnter = 33, TouchLeave = 34, TouchStationary = 35, mouseDown = 0, mouseUp = 1, mouseMove = 2, mouseDrag = 3, keyDown = 4, keyUp = 5, scrollWheel = 6, repaint = 7, layout = 8, dragUpdated = 9, dragPerform = 10, ignore = 11, used = 12 }

    public sealed class Event
    {
        public static Event current { get; internal set; } = new Event();
        public EventType type { get; set; } = EventType.Repaint;
        public EventType rawType => type;
        public Vector2 mousePosition { get; set; }
        public Vector2 delta { get; set; }
        public int button { get; set; }
        public KeyCode keyCode { get; set; }
        public char character { get; set; }
        public bool shift { get; set; }
        public bool control { get; set; }
        public bool alt { get; set; }
        public bool command { get; set; }
        public int clickCount { get; set; }
        public bool isKey => type == EventType.KeyDown || type == EventType.KeyUp;
        public bool isMouse => type == EventType.MouseDown || type == EventType.MouseUp || type == EventType.MouseDrag || type == EventType.MouseMove;
        public void Use() { type = EventType.Used; }
    }

    public class RectOffset
    {
        public int left, right, top, bottom;
        public RectOffset() { }
        public RectOffset(int left, int right, int top, int bottom) { this.left = left; this.right = right; this.top = top; this.bottom = bottom; }
        public int horizontal => left + right;
        public int vertical => top + bottom;
        public Rect Add(Rect rect) => new Rect(rect.x - left, rect.y - top, rect.width + horizontal, rect.height + vertical);
        public Rect Remove(Rect rect) => new Rect(rect.x + left, rect.y + top, rect.width - horizontal, rect.height - vertical);
    }


    public sealed class GUIStyleState
    {
        public Color textColor { get; set; } = new Color(0.9f, 0.9f, 0.9f, 1f);
        public Texture2D background { get; set; }
        public Texture2D[] scaledBackgrounds { get; set; }
        internal GUIStyleState Copy() => new GUIStyleState { textColor = textColor, background = background, scaledBackgrounds = scaledBackgrounds };
    }

    public sealed class GUIStyle
    {
        public string name { get; set; } = "";
        public GUIStyleState normal { get; set; } = new GUIStyleState();
        public GUIStyleState hover { get; set; } = new GUIStyleState();
        public GUIStyleState active { get; set; } = new GUIStyleState();
        public GUIStyleState focused { get; set; } = new GUIStyleState();
        public GUIStyleState onNormal { get; set; } = new GUIStyleState();
        public GUIStyleState onHover { get; set; } = new GUIStyleState();
        public GUIStyleState onActive { get; set; } = new GUIStyleState();
        public int fontSize { get; set; }
        public FontStyle fontStyle { get; set; }
        public Font font { get; set; }
        public TextAnchor alignment { get; set; } = TextAnchor.UpperLeft;
        public bool wordWrap { get; set; }
        public bool richText { get; set; } = true;
        public TextClipping clipping { get; set; }
        public RectOffset padding { get; set; } = new RectOffset(2, 2, 1, 2);
        public RectOffset margin { get; set; } = new RectOffset(4, 4, 2, 2);
        public RectOffset border { get; set; } = new RectOffset();
        public RectOffset overflow { get; set; } = new RectOffset();
        public float fixedWidth { get; set; }
        public float fixedHeight { get; set; }
        public bool stretchWidth { get; set; } = true;
        public bool stretchHeight { get; set; }
        public Vector2 contentOffset { get; set; }
        public float lineHeight => (fontSize > 0 ? fontSize : 12) * 1.25f;
        internal bool drawBackground;
        internal Color bgTint = new Color(0.2f, 0.2f, 0.2f, 0.75f);
        public GUIStyle() { }
        public GUIStyle(GUIStyle other)
        {
            if (other == null) return;
            name = other.name; fontSize = other.fontSize; fontStyle = other.fontStyle; font = other.font; alignment = other.alignment; wordWrap = other.wordWrap; richText = other.richText;
            normal = other.normal.Copy(); hover = other.hover.Copy(); active = other.active.Copy(); focused = other.focused.Copy();
            onNormal = other.onNormal.Copy(); onHover = other.onHover.Copy(); onActive = other.onActive.Copy(); onFocused = other.onFocused.Copy();
            padding = Copy(other.padding); margin = Copy(other.margin); border = Copy(other.border); overflow = Copy(other.overflow);
            fixedWidth = other.fixedWidth; fixedHeight = other.fixedHeight; stretchWidth = other.stretchWidth; stretchHeight = other.stretchHeight;
            drawBackground = other.drawBackground; bgTint = other.bgTint; clipping = other.clipping; contentOffset = other.contentOffset; imagePosition = other.imagePosition;
        }
        static RectOffset Copy(RectOffset o) => o == null ? new RectOffset() : new RectOffset(o.left, o.right, o.top, o.bottom);
        public GUIStyleState onFocused { get; set; } = new GUIStyleState();
        public ImagePosition imagePosition { get; set; }
        public bool isHeightDependantOnWidth => wordWrap;
        public void Draw(Rect position, bool isHover, bool isActive, bool on, bool hasKeyboardFocus) => GUI.Box(position, GUIContent.none, this);
        public void Draw(Rect position, GUIContent content, bool isHover, bool isActive, bool on, bool hasKeyboardFocus) => GUI.Box(position, content, this);
        public void Draw(Rect position, string text, bool isHover, bool isActive, bool on, bool hasKeyboardFocus) => GUI.Box(position, GUIContent.Temp(text), this);
        public void Draw(Rect position, GUIContent content, int controlID) => GUI.Box(position, content, this);
        public void Draw(Rect position, GUIContent content, int controlID, bool on) => GUI.Box(position, content, this);
        public float CalcScreenSize(Vector2 contentSize) => contentSize.y + padding.vertical;
        public override string ToString() => "GUIStyle '" + name + "'";
        public static GUIStyle none => new GUIStyle();
        public static implicit operator GUIStyle(string str) => GUI.skin.FindStyle(str) ?? GUI.skin.label;
        internal int EffFont => fontSize > 0 ? fontSize : 12;
        public Vector2 CalcSize(GUIContent content)
        {
            string t = content?.text ?? "";
            float w = StripTags(t).Length * EffFont * 0.56f + padding.horizontal;
            float h = Mathf.Max(1, CountLines(t)) * EffFont * 1.3f + padding.vertical;
            if (fixedWidth > 0) w = fixedWidth;
            if (fixedHeight > 0) h = fixedHeight;
            return new Vector2(Mathf.Ceil(w), Mathf.Ceil(h));
        }
        public float CalcHeight(GUIContent content, float width)
        {
            var s = CalcSize(content);
            if (!wordWrap || width <= 0) return s.y;
            int lines = Mathf.CeilToInt(s.x / Mathf.Max(1, width));
            return Mathf.Max(1, lines) * EffFont * 1.3f + padding.vertical;
        }
        public void CalcMinMaxWidth(GUIContent content, out float minWidth, out float maxWidth) { var s = CalcSize(content); minWidth = s.x; maxWidth = s.x; }
        static int CountLines(string s) { int n = 1; foreach (char c in s) if (c == '\n') n++; return n; }
        internal static string StripTags(string s)
        {
            if (s.IndexOf('<') < 0) return s;
            var sb = new System.Text.StringBuilder();
            bool inTag = false;
            foreach (char c in s) { if (c == '<') inTag = true; else if (c == '>') inTag = false; else if (!inTag) sb.Append(c); }
            return sb.ToString();
        }
    }

    public sealed class GUISkin : ScriptableObject
    {
        public Font font { get; set; }
        public GUIStyle box { get; set; }
        public GUIStyle label { get; set; }
        public GUIStyle textField { get; set; }
        public GUIStyle textArea { get; set; }
        public GUIStyle button { get; set; }
        public GUIStyle toggle { get; set; }
        public GUIStyle window { get; set; }
        public GUIStyle horizontalSlider { get; set; }
        public GUIStyle horizontalSliderThumb { get; set; }
        public GUIStyle verticalSlider { get; set; }
        public GUIStyle verticalSliderThumb { get; set; }
        public GUIStyle[] customStyles { get; set; } = Array.Empty<GUIStyle>();
        public GUIStyle FindStyle(string styleName)
        {
            switch (styleName)
            {
                case "box": case "Box": return box;
                case "label": case "Label": return label;
                case "button": case "Button": return button;
                case "textfield": case "TextField": return textField;
                case "textarea": case "TextArea": return textArea;
                case "toggle": case "Toggle": return toggle;
                case "window": case "Window": return window;
            }
            foreach (var s in customStyles) if (s.name == styleName) return s;
            return null;
        }
        public GUIStyle GetStyle(string styleName) => FindStyle(styleName) ?? label;
        internal static GUISkin CreateDefault()
        {
            World.allowLooseComponent = true;
            var s = new GUISkin();
            World.allowLooseComponent = false;
            s.label = new GUIStyle { name = "label", padding = new RectOffset(2, 2, 1, 2), wordWrap = true };
            s.box = new GUIStyle { name = "box", alignment = TextAnchor.UpperCenter, padding = new RectOffset(4, 4, 4, 4), drawBackground = true, bgTint = new Color(0.1f, 0.1f, 0.1f, 0.6f) };
            s.button = new GUIStyle { name = "button", alignment = TextAnchor.MiddleCenter, padding = new RectOffset(6, 6, 3, 3), drawBackground = true, bgTint = new Color(0.32f, 0.32f, 0.32f, 1f) };
            s.textField = new GUIStyle { name = "textfield", padding = new RectOffset(3, 3, 3, 3), drawBackground = true, bgTint = new Color(0.12f, 0.12f, 0.12f, 1f) };
            s.textArea = new GUIStyle(s.textField) { name = "textarea", wordWrap = true };
            s.toggle = new GUIStyle { name = "toggle", padding = new RectOffset(15, 0, 3, 0) };
            s.window = new GUIStyle { name = "window", alignment = TextAnchor.UpperCenter, padding = new RectOffset(8, 8, 18, 8), drawBackground = true, bgTint = new Color(0.2f, 0.2f, 0.2f, 0.9f) };
            s.horizontalSlider = new GUIStyle { name = "horizontalslider", fixedHeight = 12 };
            s.horizontalSliderThumb = new GUIStyle { name = "horizontalsliderthumb" };
            s.verticalSlider = new GUIStyle { name = "verticalslider" };
            s.verticalSliderThumb = new GUIStyle { name = "verticalsliderthumb" };
            return s;
        }
    }

    public class GUIContent
    {
        public string text { get; set; } = "";
        public Texture image { get; set; }
        public string tooltip { get; set; } = "";
        public GUIContent() { }
        public GUIContent(string text) { this.text = text ?? ""; }
        public GUIContent(string text, string tooltip) { this.text = text ?? ""; this.tooltip = tooltip ?? ""; }
        public GUIContent(Texture image) { this.image = image; }
        public GUIContent(string text, Texture image) { this.text = text ?? ""; this.image = image; }
        public GUIContent(GUIContent src) { text = src.text; image = src.image; tooltip = src.tooltip; }
        public static GUIContent none => new GUIContent("");
        internal static GUIContent Temp(string t) => new GUIContent(t);
    }

    public sealed class GUILayoutOption { internal int type; internal float value; internal GUILayoutOption(int t, float v) { type = t; value = v; } }

    internal struct GuiCmd
    {
        public int kind; // 0 label, 1 box, 2 button, 3 toggle, 4 hslider, 5 textfield, 6 texture, 7 vslider
        public Rect rect; public string text; public float fontSize; public float rot; public string extra; public FontStyle fontStyle; public TextAnchor align;
        public Color textColor, bgColor; public bool wrap, rich, hot, drawBg; public float value, min, max; public bool on;
        public string font; public int tex; public RectOffset pad; public bool clip;
    }

    public class GUI
    {
        internal static readonly List<GuiCmd> cmds = new List<GuiCmd>();
        static GUISkin s_Skin;
        public static GUISkin skin { get => s_Skin ??= GUISkin.CreateDefault(); set => s_Skin = value ?? GUISkin.CreateDefault(); }
        public static Color color { get; set; } = Color.white;
        public static Color backgroundColor { get; set; } = Color.white;
        public static Color contentColor { get; set; } = Color.white;
        public static bool enabled { get; set; } = true;
        public static bool changed { get; set; }
        public static int depth { get; set; }
        public static string tooltip { get; set; } = "";
        public static Matrix4x4 matrix { get; set; } = Matrix4x4.identity;
        static readonly Stack<Vector2> s_Groups = new Stack<Vector2>();
        static Vector2 s_Offset;
        internal static int s_FocusId = -1, s_ControlCounter;
        static string s_NextName; static readonly Dictionary<string, int> s_Names = new Dictionary<string, int>();
        static int s_ActiveSlider = -1;

        internal static void BeginFrame()
        {
            cmds.Clear(); s_Groups.Clear(); s_ClipRects.Clear(); s_Offset = Vector2.zero; s_ControlCounter = 0; s_Names.Clear();
            if (!InputState.mouseHeld[0]) s_ActiveScroll = -1;
            color = Color.white; backgroundColor = Color.white; contentColor = Color.white; enabled = true; changed = false; matrix = Matrix4x4.identity;
            GUILayout.BeginFrame();
            Event.current = new Event { type = EventType.Repaint, mousePosition = InputState.GuiMouse };
            if (!InputState.mouseHeld[0]) s_ActiveSlider = -1;
        }
        internal static void EndFrame() { }

        static Color Mul(Color a, Color b) => new Color(a.r * b.r, a.g * b.g, a.b * b.b, a.a * b.a);
        static Rect Off(Rect r) => new Rect(r.x + s_Offset.x, r.y + s_Offset.y, r.width, r.height);
        static void Emit(int kind, Rect r, string text, GUIStyle st, bool hot = false, float value = 0, float min = 0, float max = 0, bool on = false)
        {
            if (cmds.Count > 5000) return;
            st ??= skin.label;
            var state = on && st.onNormal.background != null ? st.onNormal : (hot && st.active.background != null ? st.active : st.normal);
            var tc = Mul(Mul(on && st.onNormal.textColor != default ? st.normal.textColor : state.textColor, color), contentColor);
            if (!enabled) tc.a *= 0.5f;
            Color bg = Mul(Mul(st.bgTint, backgroundColor), color);
            int tex = 0; bool drawBg = st.drawBackground;
            if (state.background != null) { drawBg = true; tex = Background(state.background, ref bg); }
            cmds.Add(new GuiCmd
            {
                kind = kind, rect = Off(r), text = text ?? "", fontSize = st.EffFont, fontStyle = st.fontStyle, align = st.alignment,
                textColor = tc, bgColor = bg, wrap = st.wordWrap, rich = st.richText, hot = hot,
                drawBg = drawBg, value = value, min = min, max = max, on = on, font = FontFamily(st.font ?? skin.font), tex = tex, pad = st.padding
            });
        }
        // a texture behind a control: a solid colour when it has one colour (the usual 1x1 texture), else the image
        static int Background(Texture2D t, ref Color bg)
        {
            if (t.UniformColor(out var c)) { bg = Mul(Mul(c, backgroundColor), color); return 0; }
            bg = Mul(backgroundColor, color);
            return RenderSync.TextureRef(t);
        }
        static string FontFamily(Font f)
        {
            if (f == null) return null;
            if (f.fontNames != null && f.fontNames.Length > 0 && !(f.fontNames.Length == 1 && f.fontNames[0] == "Arial" && f.name == "LegacyRuntime")) return string.Join(",", f.fontNames);
            return f.name == "LegacyRuntime" || f.name == "Arial" ? null : f.name;
        }
        static void EmitTexture(Rect r, Texture image, ScaleMode mode)
        {
            if (image == null || cmds.Count > 5000) return;
            Color tint = color; int tex = 0;
            if (image is Texture2D t2) { if (t2.UniformColor(out var c)) tint = Mul(c, color); else tex = RenderSync.TextureRef(t2); }
            cmds.Add(new GuiCmd { kind = 6, rect = Off(r), text = "", fontSize = 12, textColor = Color.white, bgColor = tint, drawBg = true, tex = tex, value = (int)mode, pad = new RectOffset() });
        }
        // clipping (groups, scroll views, windows): everything until the matching PopClip is cut to this rectangle
        static readonly Stack<Rect> s_ClipRects = new Stack<Rect>();
        static void PushClip(Rect absolute)
        {
            if (s_ClipRects.Count > 0) { var p = s_ClipRects.Peek(); float x0 = Math.Max(p.x, absolute.x), y0 = Math.Max(p.y, absolute.y), x1 = Math.Min(p.xMax, absolute.xMax), y1 = Math.Min(p.yMax, absolute.yMax); absolute = new Rect(x0, y0, Math.Max(0, x1 - x0), Math.Max(0, y1 - y0)); }
            s_ClipRects.Push(absolute);
            if (cmds.Count <= 5000) cmds.Add(new GuiCmd { kind = 8, rect = absolute, text = "", pad = new RectOffset() });
        }
        static void PopClip()
        {
            if (s_ClipRects.Count == 0) return;
            s_ClipRects.Pop();
            if (cmds.Count <= 5000) cmds.Add(new GuiCmd { kind = 9, rect = default, text = "", pad = new RectOffset() });
        }
        internal static bool MouseInClip() => s_ClipRects.Count == 0 || s_ClipRects.Peek().Contains(InputState.GuiMouse);
        static bool Inside(Rect r) => Off(r).Contains(InputState.GuiMouse) && MouseInClip();
        static bool Clicked(Rect r) => enabled && InputState.mouseUpThisFrame[0] && Inside(r) && Off(r).Contains(InputState.GuiMousePressPos);
        static int NextId() { int id = ++s_ControlCounter; if (s_NextName != null) { s_Names[s_NextName] = id; s_NextName = null; } return id; }

        public static void Label(Rect position, string text) => Label(position, GUIContent.Temp(text), skin.label);
        public static void Label(Rect position, Texture image) { NextId(); EmitTexture(position, image, ScaleMode.ScaleToFit); }
        public static void Label(Rect position, GUIContent content) => Label(position, content, skin.label);
        public static void Label(Rect position, string text, GUIStyle style) => Label(position, GUIContent.Temp(text), style);
        public static void Label(Rect position, Texture image, GUIStyle style) { NextId(); EmitTexture(position, image, ScaleMode.ScaleToFit); }
        public static void Label(Rect position, GUIContent content, GUIStyle style) { NextId(); if (content?.image != null) EmitTexture(position, content.image, ScaleMode.ScaleToFit); Emit(0, position, content?.text, style); }
        public static void Box(Rect position, string text) => Box(position, GUIContent.Temp(text), skin.box);
        public static void Box(Rect position, Texture image) { Box(position, GUIContent.none, skin.box); EmitTexture(position, image, ScaleMode.ScaleToFit); }
        public static void Box(Rect position, GUIContent content) => Box(position, content, skin.box);
        public static void Box(Rect position, string text, GUIStyle style) => Box(position, GUIContent.Temp(text), style);
        public static void Box(Rect position, GUIContent content, GUIStyle style) { NextId(); Emit(1, position, content?.text, style ?? skin.box); }
        public static bool Button(Rect position, string text) => Button(position, GUIContent.Temp(text), skin.button);
        public static bool Button(Rect position, Texture image) => Button(position, GUIContent.none, skin.button);
        public static bool Button(Rect position, GUIContent content) => Button(position, content, skin.button);
        public static bool Button(Rect position, string text, GUIStyle style) => Button(position, GUIContent.Temp(text), style);
        public static bool Button(Rect position, GUIContent content, GUIStyle style)
        {
            NextId();
            bool hot = Inside(position) && InputState.mouseHeld[0];
            Emit(2, position, content?.text, style ?? skin.button, hot);
            bool c = Clicked(position);
            if (c) changed = true;
            return c;
        }
        public static bool RepeatButton(Rect position, string text) => RepeatButton(position, GUIContent.Temp(text), skin.button);
        public static bool RepeatButton(Rect position, GUIContent content, GUIStyle style)
        {
            NextId();
            bool hot = enabled && Inside(position) && InputState.mouseHeld[0];
            Emit(2, position, content?.text, style ?? skin.button, hot);
            return hot;
        }
        public static bool Toggle(Rect position, bool value, string text) => Toggle(position, value, GUIContent.Temp(text), skin.toggle);
        public static bool Toggle(Rect position, bool value, GUIContent content) => Toggle(position, value, content, skin.toggle);
        public static bool Toggle(Rect position, bool value, string text, GUIStyle style) => Toggle(position, value, GUIContent.Temp(text), style);
        public static bool Toggle(Rect position, bool value, GUIContent content, GUIStyle style)
        {
            NextId();
            if (Clicked(position)) { value = !value; changed = true; }
            Emit(3, position, content?.text, style ?? skin.toggle, false, 0, 0, 0, value);
            return value;
        }
        public static float HorizontalSlider(Rect position, float value, float leftValue, float rightValue) => HorizontalSlider(position, value, leftValue, rightValue, skin.horizontalSlider, skin.horizontalSliderThumb);
        public static float HorizontalSlider(Rect position, float value, float leftValue, float rightValue, GUIStyle slider, GUIStyle thumb)
        {
            int id = NextId();
            if (enabled && InputState.mouseDownThisFrame[0] && Inside(position)) s_ActiveSlider = id;
            if (s_ActiveSlider == id && InputState.mouseHeld[0])
            {
                var r = Off(position);
                float t = Mathf.Clamp01((InputState.GuiMouse.x - r.x) / Mathf.Max(1, r.width));
                float nv = Mathf.Lerp(leftValue, rightValue, t);
                if (nv != value) changed = true;
                value = nv;
            }
            Emit(4, position, "", slider, s_ActiveSlider == id, value, leftValue, rightValue);
            return value;
        }
        public static float VerticalSlider(Rect position, float value, float topValue, float bottomValue)
        {
            int id = NextId();
            if (enabled && InputState.mouseDownThisFrame[0] && Inside(position)) s_ActiveSlider = id;
            if (s_ActiveSlider == id && InputState.mouseHeld[0])
            {
                var r = Off(position);
                float t = Mathf.Clamp01((InputState.GuiMouse.y - r.y) / Mathf.Max(1, r.height));
                value = Mathf.Lerp(topValue, bottomValue, t); changed = true;
            }
            Emit(7, position, "", skin.verticalSlider, s_ActiveSlider == id, value, topValue, bottomValue);
            return value;
        }
        public static string TextField(Rect position, string text) => TextField(position, text, -1, skin.textField);
        public static string TextField(Rect position, string text, int maxLength) => TextField(position, text, maxLength, skin.textField);
        public static string TextField(Rect position, string text, GUIStyle style) => TextField(position, text, -1, style);
        public static string TextField(Rect position, string text, int maxLength, GUIStyle style)
        {
            int id = NextId();
            text ??= "";
            if (enabled && InputState.mouseDownThisFrame[0]) { if (Inside(position)) s_FocusId = id; else if (s_FocusId == id) s_FocusId = -1; }
            if (s_FocusId == id)
            {
                foreach (char ch in InputState.inputString)
                {
                    if (ch == '\b') { if (text.Length > 0) text = text.Substring(0, text.Length - 1); }
                    else if (ch == '\n' || ch == '\r') { }
                    else if (maxLength < 0 || text.Length < maxLength) text += ch;
                }
                if (InputState.inputString.Length > 0) changed = true;
            }
            Emit(5, position, text + (s_FocusId == id && (Time.realtimeSinceStartup % 1f) < 0.5f ? "|" : ""), style ?? skin.textField, s_FocusId == id);
            return text;
        }
        public static string TextArea(Rect position, string text) => TextField(position, text, -1, skin.textArea);
        public static string PasswordField(Rect position, string password, char maskChar) { var r = TextField(position, password); return r; }
        public static void DrawTexture(Rect position, Texture image) => DrawTexture(position, image, ScaleMode.StretchToFill);
        public static void DrawTexture(Rect position, Texture image, ScaleMode scaleMode) { NextId(); EmitTexture(position, image, scaleMode); }
        public static void DrawTexture(Rect position, Texture image, ScaleMode scaleMode, bool alphaBlend) => DrawTexture(position, image, scaleMode);
        public static void DrawTexture(Rect position, Texture image, ScaleMode scaleMode, bool alphaBlend, float imageAspect) => DrawTexture(position, image, scaleMode);
        public static void DrawTexture(Rect position, Texture image, ScaleMode scaleMode, bool alphaBlend, float imageAspect, Color color, float borderWidth, float borderRadius)
        { var c = GUI.color; GUI.color = Mul(c, color); DrawTexture(position, image, scaleMode); GUI.color = c; }
        public static void DrawTextureWithTexCoords(Rect position, Texture image, Rect texCoords) => DrawTexture(position, image);
        public static void DrawTextureWithTexCoords(Rect position, Texture image, Rect texCoords, bool alphaBlend) => DrawTexture(position, image);
        public static void BeginGroup(Rect position) { var abs = Off(position); s_Groups.Push(s_Offset); s_Offset = abs.position; PushClip(abs); }
        public static void BeginGroup(Rect position, string text) { Box(position, text); BeginGroup(position); }
        public static void BeginGroup(Rect position, GUIContent content) { Box(position, content); BeginGroup(position); }
        public static void BeginGroup(Rect position, GUIStyle style) { if (style != null && (style.drawBackground || style.normal.background != null)) Box(position, GUIContent.none, style); BeginGroup(position); }
        public static void BeginGroup(Rect position, string text, GUIStyle style) { Box(position, text, style); BeginGroup(position); }
        public static void BeginGroup(Rect position, GUIContent content, GUIStyle style) { Box(position, content, style); BeginGroup(position); }
        public static void EndGroup() { if (s_Groups.Count > 0) { s_Offset = s_Groups.Pop(); PopClip(); } else Debug.LogError("GUI Error: You are pushing more GUIClips than you are popping. Make sure they are balanced."); }

        // ---- scroll views ----
        const float k_Bar = 15f;
        static int s_ActiveScroll = -1; static float s_ScrollGrab; static bool s_ScrollGrabH;
        static readonly Stack<bool> s_ScrollStack = new Stack<bool>();
        public static Vector2 BeginScrollView(Rect position, Vector2 scrollPosition, Rect viewRect) => BeginScrollView(position, scrollPosition, viewRect, false, false);
        public static Vector2 BeginScrollView(Rect position, Vector2 scrollPosition, Rect viewRect, GUIStyle horizontalScrollbar, GUIStyle verticalScrollbar) => BeginScrollView(position, scrollPosition, viewRect, false, false);
        public static Vector2 BeginScrollView(Rect position, Vector2 scrollPosition, Rect viewRect, bool alwaysShowHorizontal, bool alwaysShowVertical, GUIStyle horizontalScrollbar, GUIStyle verticalScrollbar) => BeginScrollView(position, scrollPosition, viewRect, alwaysShowHorizontal, alwaysShowVertical);
        public static Vector2 BeginScrollView(Rect position, Vector2 scrollPosition, Rect viewRect, bool alwaysShowHorizontal, bool alwaysShowVertical, GUIStyle horizontalScrollbar, GUIStyle verticalScrollbar, GUIStyle background) => BeginScrollView(position, scrollPosition, viewRect, alwaysShowHorizontal, alwaysShowVertical);
        public static Vector2 BeginScrollView(Rect position, Vector2 scrollPosition, Rect viewRect, bool alwaysShowHorizontal, bool alwaysShowVertical)
        {
            int id = NextId();
            var abs = Off(position);
            bool needV = alwaysShowVertical || viewRect.height > position.height;
            bool needH = alwaysShowHorizontal || viewRect.width > position.width - (needV ? k_Bar : 0);
            if (needH && !needV && viewRect.height > position.height - k_Bar) needV = true;
            float clipW = Math.Max(0, position.width - (needV ? k_Bar : 0)), clipH = Math.Max(0, position.height - (needH ? k_Bar : 0));
            float maxX = Math.Max(0, viewRect.width - clipW), maxY = Math.Max(0, viewRect.height - clipH);
            var mouse = InputState.GuiMouse;
            bool over = abs.Contains(mouse) && MouseInClip();
            if (enabled && over && InputState.wheel.y != 0) { if (maxY > 0) scrollPosition.y -= InputState.wheel.y * 30f; else scrollPosition.x -= InputState.wheel.y * 30f; }
            // scrollbars: drag the thumb, or click the track to jump
            if (needV)
            {
                var track = new Rect(abs.xMax - k_Bar, abs.y, k_Bar, clipH);
                float th = maxY > 0 ? Math.Max(18, clipH * clipH / Math.Max(1, viewRect.height)) : clipH;
                float ty = maxY > 0 ? track.y + (track.height - th) * Mathf.Clamp01(scrollPosition.y / maxY) : track.y;
                if (enabled && InputState.mouseDownThisFrame[0] && track.Contains(mouse) && MouseInClip()) { s_ActiveScroll = id; s_ScrollGrabH = false; s_ScrollGrab = mouse.y >= ty && mouse.y <= ty + th ? mouse.y - ty : th / 2; }
                if (s_ActiveScroll == id && !s_ScrollGrabH && InputState.mouseHeld[0] && track.height > th) scrollPosition.y = (mouse.y - s_ScrollGrab - track.y) / (track.height - th) * maxY;
                scrollPosition.y = Mathf.Clamp(scrollPosition.y, 0, maxY);
                ty = maxY > 0 ? track.y + (track.height - th) * Mathf.Clamp01(scrollPosition.y / maxY) : track.y;
                Bar(track, new Rect(track.x + 3, ty + 2, k_Bar - 6, Math.Max(0, th - 4)), s_ActiveScroll == id);
            }
            else scrollPosition.y = 0;
            if (needH)
            {
                var track = new Rect(abs.x, abs.yMax - k_Bar, clipW, k_Bar);
                float tw = maxX > 0 ? Math.Max(18, clipW * clipW / Math.Max(1, viewRect.width)) : clipW;
                float tx = maxX > 0 ? track.x + (track.width - tw) * Mathf.Clamp01(scrollPosition.x / maxX) : track.x;
                if (enabled && InputState.mouseDownThisFrame[0] && track.Contains(mouse) && MouseInClip()) { s_ActiveScroll = id; s_ScrollGrabH = true; s_ScrollGrab = mouse.x >= tx && mouse.x <= tx + tw ? mouse.x - tx : tw / 2; }
                if (s_ActiveScroll == id && s_ScrollGrabH && InputState.mouseHeld[0] && track.width > tw) scrollPosition.x = (mouse.x - s_ScrollGrab - track.x) / (track.width - tw) * maxX;
                scrollPosition.x = Mathf.Clamp(scrollPosition.x, 0, maxX);
                tx = maxX > 0 ? track.x + (track.width - tw) * Mathf.Clamp01(scrollPosition.x / maxX) : track.x;
                Bar(track, new Rect(tx + 2, track.y + 3, Math.Max(0, tw - 4), k_Bar - 6), s_ActiveScroll == id);
            }
            else scrollPosition.x = 0;
            s_Groups.Push(s_Offset);
            s_Offset = new Vector2(abs.x - scrollPosition.x - viewRect.x, abs.y - scrollPosition.y - viewRect.y);
            PushClip(new Rect(abs.x, abs.y, clipW, clipH));
            return scrollPosition;
        }
        static void Bar(Rect track, Rect thumb, bool active)
        {
            cmds.Add(new GuiCmd { kind = 1, rect = track, text = "", fontSize = 12, bgColor = Mul(new Color(0.13f, 0.13f, 0.13f, 0.8f), color), drawBg = true, pad = new RectOffset() });
            cmds.Add(new GuiCmd { kind = 1, rect = thumb, text = "", fontSize = 12, bgColor = Mul(active ? new Color(0.6f, 0.6f, 0.6f, 1) : new Color(0.42f, 0.42f, 0.42f, 1), color), drawBg = true, pad = new RectOffset() });
        }
        public static void EndScrollView() => EndScrollView(true);
        public static void EndScrollView(bool handleScrollWheel)
        {
            if (s_Groups.Count == 0) { Debug.LogError("GUI Error: You are pushing more GUIClips than you are popping. Make sure they are balanced."); return; }
            s_Offset = s_Groups.Pop(); PopClip();
        }
        public static void ScrollTo(Rect position) { }
        public static bool ScrollTowards(Rect position, float maxDelta) => false;
        public static void BeginClip(Rect position) => BeginGroup(position);
        public static void EndClip() => EndGroup();
        public delegate void WindowFunction(int id);
        public static Rect Window(int id, Rect clientRect, WindowFunction func, string text)
        {
            Emit(1, clientRect, text, skin.window);
            BeginGroup(clientRect);
            try { func(id); } finally { EndGroup(); }
            return clientRect;
        }
        public static Rect Window(int id, Rect clientRect, WindowFunction func, string text, GUIStyle style)
        {
            Emit(1, clientRect, text, style ?? skin.window);
            BeginGroup(clientRect);
            try { func(id); } finally { EndGroup(); }
            return clientRect;
        }
        public static Rect Window(int id, Rect clientRect, WindowFunction func, GUIContent content) => Window(id, clientRect, func, content?.text);
        public static Rect ModalWindow(int id, Rect clientRect, WindowFunction func, string text) => Window(id, clientRect, func, text);
        public static void DragWindow() { }
        public static void DragWindow(Rect position) { }
        public static void SetNextControlName(string name) { s_NextName = name; }
        public static string GetNameOfFocusedControl() { foreach (var kv in s_Names) if (kv.Value == s_FocusId) return kv.Key; return ""; }
        public static void FocusControl(string name) { if (s_Names.TryGetValue(name, out var id)) s_FocusId = id; }
        public static void UnfocusWindow() { }
        public static int SelectionGrid(Rect position, int selected, string[] texts, int xCount)
        {
            int n = texts.Length; int rows = Mathf.CeilToInt(n / (float)Math.Max(1, xCount));
            float w = position.width / Math.Max(1, xCount), h = position.height / Math.Max(1, rows);
            for (int i = 0; i < n; i++)
            {
                var r = new Rect(position.x + (i % xCount) * w, position.y + (i / xCount) * h, w - 2, h - 2);
                var st = new GUIStyle(skin.button);
                if (i == selected) st.bgTint = new Color(0.25f, 0.45f, 0.8f, 1f);
                if (Button(r, texts[i], st)) selected = i;
            }
            return selected;
        }
        public static int Toolbar(Rect position, int selected, string[] texts) => SelectionGrid(position, selected, texts, texts.Length);
    }

    public class GUILayout
    {
        sealed class Group { public bool horizontal; public float x, y, width, height = -1, cursor, maxCross; public bool isArea, isScroll; public int scrollKey; }
        static readonly Dictionary<int, Vector2> s_ScrollContent = new Dictionary<int, Vector2>();
        static int s_ScrollIndex;
        static readonly Stack<Group> s_Stack = new Stack<Group>();
        static Group s_Root;
        internal static void BeginFrame()
        {
            s_Stack.Clear();
            s_Root = new Group { horizontal = false, x = 0, y = 0, width = Screen.width, height = Screen.height, isArea = true };
            s_ScrollIndex = 0;
            s_Stack.Push(s_Root);
        }
        static Group Cur => s_Stack.Count > 0 ? s_Stack.Peek() : s_Root ?? new Group { width = Screen.width };

        static Rect Place(GUIContent content, GUIStyle style, GUILayoutOption[] options, bool stretchDefault, float minH = 0)
        {
            var g = Cur;
            Vector2 size = style.CalcSize(content);
            if (minH > 0) size.y = Math.Max(size.y, minH);
            bool stretch = stretchDefault && style.stretchWidth;
            float? fw = null, fh = null;
            if (options != null)
                foreach (var o in options)
                {
                    switch (o.type)
                    {
                        case 0: fw = o.value; break;
                        case 1: fh = o.value; break;
                        case 2: size.x = Math.Max(size.x, o.value); break;
                        case 3: size.y = Math.Max(size.y, o.value); break;
                        case 4: stretch = o.value > 0; break;
                        case 6: if (size.x > o.value) size.x = o.value; break;
                    }
                }
            if (style.fixedWidth > 0) fw = style.fixedWidth;
            if (style.fixedHeight > 0) fh = style.fixedHeight;
            var m = style.margin;
            Rect r;
            if (g.horizontal)
            {
                float w = fw ?? size.x;
                float h = fh ?? size.y;
                r = new Rect(g.x + g.cursor + m.left, g.y + m.top, w, h);
                g.cursor += w + m.horizontal;
                g.maxCross = Math.Max(g.maxCross, h + m.vertical);
            }
            else
            {
                float w = fw ?? (stretch ? g.width - m.horizontal : Math.Min(size.x, g.width - m.horizontal));
                float h = fh ?? size.y;
                r = new Rect(g.x + m.left, g.y + g.cursor + m.top, w, h);
                g.cursor += h + Math.Max(m.top, m.bottom);
                g.maxCross = Math.Max(g.maxCross, w + m.horizontal);
            }
            return r;
        }

        public static void Label(string text, params GUILayoutOption[] options) => Label(GUIContent.Temp(text), GUI.skin.label, options);
        public static void Label(Texture image, params GUILayoutOption[] options) => Label(GUIContent.none, GUI.skin.label, options);
        public static void Label(GUIContent content, params GUILayoutOption[] options) => Label(content, GUI.skin.label, options);
        public static void Label(string text, GUIStyle style, params GUILayoutOption[] options) => Label(GUIContent.Temp(text), style, options);
        public static void Label(GUIContent content, GUIStyle style, params GUILayoutOption[] options) => GUI.Label(Place(content, style, options, true), content, style);
        public static void Box(string text, params GUILayoutOption[] options) => Box(GUIContent.Temp(text), GUI.skin.box, options);
        public static void Box(GUIContent content, params GUILayoutOption[] options) => Box(content, GUI.skin.box, options);
        public static void Box(string text, GUIStyle style, params GUILayoutOption[] options) => Box(GUIContent.Temp(text), style, options);
        public static void Box(GUIContent content, GUIStyle style, params GUILayoutOption[] options) => GUI.Box(Place(content, style, options, true), content, style);
        public static bool Button(string text, params GUILayoutOption[] options) => Button(GUIContent.Temp(text), GUI.skin.button, options);
        public static bool Button(Texture image, params GUILayoutOption[] options) => Button(GUIContent.none, GUI.skin.button, options);
        public static bool Button(GUIContent content, params GUILayoutOption[] options) => Button(content, GUI.skin.button, options);
        public static bool Button(string text, GUIStyle style, params GUILayoutOption[] options) => Button(GUIContent.Temp(text), style, options);
        public static bool Button(GUIContent content, GUIStyle style, params GUILayoutOption[] options) => GUI.Button(Place(content, style, options, true, 22), content, style);
        public static bool RepeatButton(string text, params GUILayoutOption[] options) => GUI.RepeatButton(Place(GUIContent.Temp(text), GUI.skin.button, options, true, 22), GUIContent.Temp(text), GUI.skin.button);
        public static bool Toggle(bool value, string text, params GUILayoutOption[] options) => GUI.Toggle(Place(GUIContent.Temp(text), GUI.skin.toggle, options, true, 18), value, text);
        public static bool Toggle(bool value, GUIContent content, params GUILayoutOption[] options) => GUI.Toggle(Place(content, GUI.skin.toggle, options, true, 18), value, content);
        public static string TextField(string text, params GUILayoutOption[] options) => GUI.TextField(Place(GUIContent.Temp(text ?? " "), GUI.skin.textField, options, true, 20), text);
        public static string TextField(string text, int maxLength, params GUILayoutOption[] options) => GUI.TextField(Place(GUIContent.Temp(text ?? " "), GUI.skin.textField, options, true, 20), text, maxLength);
        public static string TextArea(string text, params GUILayoutOption[] options) => GUI.TextArea(Place(GUIContent.Temp(text ?? " "), GUI.skin.textArea, options, true, 40), text);
        public static float HorizontalSlider(float value, float leftValue, float rightValue, params GUILayoutOption[] options) => GUI.HorizontalSlider(Place(GUIContent.Temp(""), GUI.skin.horizontalSlider, options, true, 14), value, leftValue, rightValue);
        public static float VerticalSlider(float value, float topValue, float bottomValue, params GUILayoutOption[] options) => GUI.VerticalSlider(Place(GUIContent.Temp(""), GUI.skin.verticalSlider, options, false, 100), value, topValue, bottomValue);
        public static int Toolbar(int selected, string[] texts, params GUILayoutOption[] options) => GUI.Toolbar(Place(GUIContent.Temp(string.Join("  ", texts)), GUI.skin.button, options, true, 22), selected, texts);
        public static int SelectionGrid(int selected, string[] texts, int xCount, params GUILayoutOption[] options) => GUI.SelectionGrid(Place(GUIContent.Temp(""), GUI.skin.button, options, true, 22 * Mathf.CeilToInt(texts.Length / (float)Math.Max(1, xCount))), selected, texts, xCount);
        public static void Space(float pixels)
        {
            var g = Cur;
            g.cursor += pixels;
        }
        public static void FlexibleSpace() { Cur.cursor += 4; }
        public static void BeginHorizontal(params GUILayoutOption[] options) => BeginHorizontal(GUIStyle.none, options);
        public static void BeginHorizontal(GUIStyle style, params GUILayoutOption[] options)
        {
            var g = Cur;
            Group ng;
            if (g.horizontal) ng = new Group { horizontal = true, x = g.x + g.cursor, y = g.y, width = g.width - g.cursor };
            else ng = new Group { horizontal = true, x = g.x, y = g.y + g.cursor, width = g.width };
            s_Stack.Push(ng);
        }
        public static void BeginHorizontal(string text, GUIStyle style, params GUILayoutOption[] options) => BeginHorizontal(style, options);
        public static void EndHorizontal() => EndGroupInternal();
        public static void BeginVertical(params GUILayoutOption[] options) => BeginVertical(GUIStyle.none, options);
        public static void BeginVertical(GUIStyle style, params GUILayoutOption[] options)
        {
            var g = Cur;
            float w = g.width;
            if (options != null) foreach (var o in options) if (o.type == 0) w = o.value;
            Group ng;
            if (g.horizontal) ng = new Group { horizontal = false, x = g.x + g.cursor, y = g.y, width = options != null && Array.Exists(options, o => o.type == 0) ? w : 200 };
            else ng = new Group { horizontal = false, x = g.x, y = g.y + g.cursor, width = w };
            s_Stack.Push(ng);
        }
        public static void BeginVertical(string text, GUIStyle style, params GUILayoutOption[] options) => BeginVertical(style, options);
        public static void EndVertical() => EndGroupInternal();
        static void EndGroupInternal()
        {
            if (s_Stack.Count <= 1) { Debug.LogError("GUI Error: You are pushing more GUIClips than you are popping. Make sure they are balanced."); return; }
            var g = s_Stack.Pop();
            if (g.isArea) return;
            var parent = Cur;
            if (parent.horizontal) { parent.cursor += g.horizontal ? g.cursor : g.maxCross; parent.maxCross = Math.Max(parent.maxCross, g.horizontal ? g.maxCross : g.cursor); }
            else { parent.cursor += g.horizontal ? g.maxCross : g.cursor; parent.maxCross = Math.Max(parent.maxCross, g.horizontal ? g.cursor : g.maxCross); }
        }
        public static void BeginArea(Rect screenRect) => s_Stack.Push(new Group { horizontal = false, x = screenRect.x, y = screenRect.y, width = screenRect.width, height = screenRect.height, isArea = true });
        public static void BeginArea(Rect screenRect, string text) { GUI.Box(screenRect, text); BeginArea(screenRect); }
        public static void BeginArea(Rect screenRect, GUIStyle style) { if (style != null && style.drawBackground) GUI.Box(screenRect, "", style); BeginArea(screenRect); }
        public static void BeginArea(Rect screenRect, string text, GUIStyle style) { GUI.Box(screenRect, text, style); BeginArea(screenRect); }
        public static void BeginArea(Rect screenRect, GUIContent content) { GUI.Box(screenRect, content); BeginArea(screenRect); }
        public static void EndArea() { if (s_Stack.Count > 1) s_Stack.Pop(); }
        public static Vector2 BeginScrollView(Vector2 scrollPosition, params GUILayoutOption[] options) => BeginScrollView(scrollPosition, false, false, options);
        public static Vector2 BeginScrollView(Vector2 scrollPosition, GUIStyle style, params GUILayoutOption[] options) => BeginScrollView(scrollPosition, false, false, options);
        public static Vector2 BeginScrollView(Vector2 scrollPosition, GUIStyle horizontalScrollbar, GUIStyle verticalScrollbar, params GUILayoutOption[] options) => BeginScrollView(scrollPosition, false, false, options);
        public static Vector2 BeginScrollView(Vector2 scrollPosition, bool alwaysShowHorizontal, bool alwaysShowVertical, GUIStyle horizontalScrollbar, GUIStyle verticalScrollbar, GUIStyle background, params GUILayoutOption[] options) => BeginScrollView(scrollPosition, alwaysShowHorizontal, alwaysShowVertical, options);
        public static Vector2 BeginScrollView(Vector2 scrollPosition, bool alwaysShowHorizontal, bool alwaysShowVertical, params GUILayoutOption[] options)
        {
            int key = s_ScrollIndex++;
            var g = Cur;
            // the content's size is measured while it is laid out, and used from the next frame (like Unity's layout pass)
            bool known = s_ScrollContent.TryGetValue(key, out var content);
            float? fw = null, fh = null, minH = null, maxH = null;
            if (options != null) foreach (var o in options) { if (o.type == 0) fw = o.value; else if (o.type == 1) fh = o.value; else if (o.type == 3) minH = o.value; else if (o.type == 7) maxH = o.value; }
            float avail = AvailableHeight();
            float h = fh ?? Math.Max(minH ?? 0, Math.Min(maxH ?? float.MaxValue, known ? Math.Min(content.y, avail) : avail));
            float w = fw ?? (g.horizontal ? Math.Max(content.x + k_Bar, 50) : g.width);
            var r = Place(GUIContent.none, new GUIStyle { fixedWidth = w, fixedHeight = Math.Max(0, h), margin = new RectOffset() }, null, false);
            bool needV = alwaysShowVertical || (known && content.y > r.height);
            float innerW = r.width - (needV ? k_Bar : 0);
            var view = new Rect(0, 0, Math.Max(innerW, known ? content.x : 0), known ? content.y : r.height);
            scrollPosition = GUI.BeginScrollView(r, scrollPosition, view, alwaysShowHorizontal, alwaysShowVertical);
            s_Stack.Push(new Group { horizontal = false, x = 0, y = 0, width = innerW, isArea = true, isScroll = true, scrollKey = key });
            return scrollPosition;
        }
        const float k_Bar = 15f;
        static float AvailableHeight()
        {
            float used = 0;
            foreach (var g in s_Stack) { if (!g.horizontal) used += g.cursor; if (g.isArea && g.height >= 0) return Math.Max(20, g.height - used); }
            return Math.Max(20, Screen.height - used);
        }
        public static void EndScrollView() => EndScrollView(true);
        public static void EndScrollView(bool handleScrollWheel)
        {
            var g = Cur;
            if (!g.isScroll || s_Stack.Count <= 1) { Debug.LogError("GUI Error: You are pushing more GUIClips than you are popping. Make sure they are balanced."); return; }
            s_Stack.Pop();
            s_ScrollContent[g.scrollKey] = new Vector2(g.maxCross, g.cursor + 2);
            GUI.EndScrollView(handleScrollWheel);
        }
        public static GUILayoutOption Width(float width) => new GUILayoutOption(0, width);
        public static GUILayoutOption Height(float height) => new GUILayoutOption(1, height);
        public static GUILayoutOption MinWidth(float minWidth) => new GUILayoutOption(2, minWidth);
        public static GUILayoutOption MinHeight(float minHeight) => new GUILayoutOption(3, minHeight);
        public static GUILayoutOption ExpandWidth(bool expand) => new GUILayoutOption(4, expand ? 1 : 0);
        public static GUILayoutOption ExpandHeight(bool expand) => new GUILayoutOption(5, expand ? 1 : 0);
        public static GUILayoutOption MaxWidth(float maxWidth) => new GUILayoutOption(6, maxWidth);
        public static GUILayoutOption MaxHeight(float maxHeight) => new GUILayoutOption(7, maxHeight);
        public static Rect GetRect(float width, float height) => Place(GUIContent.none, new GUIStyle { fixedWidth = width, fixedHeight = height, margin = new RectOffset() }, null, false);
        public static Rect GetRect(GUIContent content, GUIStyle style, params GUILayoutOption[] options) => Place(content, style, options, true);
    }

    public static class GUIUtility
    {
        public static int hotControl { get; set; }
        public static int keyboardControl { get => GUI.s_FocusId; set => GUI.s_FocusId = value; }
        public static string systemCopyBuffer { get; set; } = "";
        public static Vector2 GUIToScreenPoint(Vector2 guiPoint) => guiPoint;
        public static Vector2 ScreenToGUIPoint(Vector2 screenPoint) => screenPoint;
        public static int GetControlID(FocusType focus) => ++GUI.s_ControlCounter;
        public static void ExitGUI() { }
    }
    public enum FocusType { Native = 0, Keyboard = 1, Passive = 2 }
}
