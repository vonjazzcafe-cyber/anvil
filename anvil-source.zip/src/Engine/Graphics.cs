// Anvil — shaders, materials, property blocks, textures, renderers, mesh filters, fonts and 3D text.
using System;
using System.Collections.Generic;
using Anvil;
using UnityEngine.Rendering;

namespace UnityEngine
{
    public sealed class Shader : Object
    {
        static readonly Dictionary<string, Shader> s_ByName = new Dictionary<string, Shader>();
        static readonly Dictionary<string, int> s_Ids = new Dictionary<string, int>();
        static readonly List<string> s_IdNames = new List<string>();
        internal static readonly Dictionary<int, object> s_Globals = new Dictionary<int, object>();
        Shader() { }
        public static Shader Find(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            if (!s_ByName.TryGetValue(name, out var s)) s_ByName[name] = s = new Shader { m_Name = name, m_IsAsset = true };
            return s;
        }
        internal static Shader Default => Find(UnityEngine.Rendering.GraphicsSettings.isURP ? "Universal Render Pipeline/Lit" : "Standard");
        public static int PropertyToID(string name)
        {
            name ??= "";
            if (!s_Ids.TryGetValue(name, out int id)) { id = s_IdNames.Count + 1; s_Ids[name] = id; s_IdNames.Add(name); }
            return id;
        }
        internal static string NameOf(int id) => id > 0 && id <= s_IdNames.Count ? s_IdNames[id - 1] : "";
        public bool isSupported => true;
        public int renderQueue => 2000;
        public int maximumLOD { get; set; } = 600;
        public static int globalMaximumLOD { get; set; } = 600;
        public int passCount => 1;
        public int FindPropertyIndex(string propertyName) => Material.KnownProperty(propertyName) ? 0 : -1;
        public static void SetGlobalColor(string name, Color value) => s_Globals[PropertyToID(name)] = value;
        public static void SetGlobalColor(int nameID, Color value) => s_Globals[nameID] = value;
        public static void SetGlobalFloat(string name, float value) => s_Globals[PropertyToID(name)] = value;
        public static void SetGlobalFloat(int nameID, float value) => s_Globals[nameID] = value;
        public static void SetGlobalInt(string name, int value) => s_Globals[PropertyToID(name)] = (float)value;
        public static void SetGlobalInteger(string name, int value) => s_Globals[PropertyToID(name)] = (float)value;
        public static void SetGlobalVector(string name, Vector4 value) => s_Globals[PropertyToID(name)] = value;
        public static void SetGlobalVector(int nameID, Vector4 value) => s_Globals[nameID] = value;
        public static void SetGlobalTexture(string name, Texture value) => s_Globals[PropertyToID(name)] = value;
        public static void SetGlobalMatrix(string name, Matrix4x4 value) => s_Globals[PropertyToID(name)] = value;
        public static Color GetGlobalColor(string name) => s_Globals.TryGetValue(PropertyToID(name), out var v) && v is Color c ? c : Color.clear;
        public static float GetGlobalFloat(string name) => s_Globals.TryGetValue(PropertyToID(name), out var v) && v is float f ? f : 0f;
        public static Vector4 GetGlobalVector(string name) => s_Globals.TryGetValue(PropertyToID(name), out var v) && v is Vector4 f ? f : Vector4.zero;
        public static void EnableKeyword(string keyword) { }
        public static void DisableKeyword(string keyword) { }
        public static bool IsKeywordEnabled(string keyword) => false;
        public static void WarmupAllShaders() { }
        internal bool IsUnlit => m_Name != null && (m_Name.Contains("Unlit") || m_Name.StartsWith("Sprites/") || m_Name.Contains("Particles") || m_Name.StartsWith("UI/") || m_Name.StartsWith("GUI/") || m_Name.Contains("Hidden/Internal-Colored"));
        internal bool UsesVertexColor => m_Name != null && (m_Name.StartsWith("Sprites/") || m_Name.Contains("Particles") || m_Name.Contains("Vertex") || m_Name.StartsWith("UI/") || m_Name.Contains("Hidden/Internal-Colored"));
    }

    public class Material : Object
    {
        static readonly int k_Color = Shader.PropertyToID("_Color"), k_BaseColor = Shader.PropertyToID("_BaseColor");
        static readonly int k_MainTex = Shader.PropertyToID("_MainTex"), k_BaseMap = Shader.PropertyToID("_BaseMap");
        internal readonly Dictionary<int, Color> m_ColorsById = new Dictionary<int, Color>();
        internal readonly Dictionary<int, float> m_FloatsById = new Dictionary<int, float>();
        internal readonly Dictionary<int, Vector4> m_Vectors = new Dictionary<int, Vector4>();
        internal readonly Dictionary<int, Texture> m_Textures = new Dictionary<int, Texture>();
        internal readonly Dictionary<int, Vector4> m_TexST = new Dictionary<int, Vector4>();
        internal readonly Dictionary<int, Matrix4x4> m_Matrices = new Dictionary<int, Matrix4x4>();
        internal readonly HashSet<string> m_Keywords = new HashSet<string>();
        internal string m_AssetPath;
        internal int m_Version;
        internal readonly int m_Uid = ++s_NextUid;
        static int s_NextUid;
        Shader m_Shader;

        // older code paths read these
        internal Color m_Color { get => GetColor(k_Color); set => SetColor(k_Color, value); }
        internal Dictionary<string, float> m_Floats { get { var d = new Dictionary<string, float>(); foreach (var kv in m_FloatsById) d[Shader.NameOf(kv.Key)] = kv.Value; return d; } }

        public Material(Shader shader) { m_Shader = shader; m_Name = shader != null ? shader.name : "New Material"; Defaults(); }
        public Material(Material source)
        {
            m_Shader = source.m_Shader; m_Name = source.m_Name;
            foreach (var kv in source.m_ColorsById) m_ColorsById[kv.Key] = kv.Value;
            foreach (var kv in source.m_FloatsById) m_FloatsById[kv.Key] = kv.Value;
            foreach (var kv in source.m_Vectors) m_Vectors[kv.Key] = kv.Value;
            foreach (var kv in source.m_Textures) m_Textures[kv.Key] = kv.Value;
            foreach (var kv in source.m_TexST) m_TexST[kv.Key] = kv.Value;
            foreach (var kv in source.m_Matrices) m_Matrices[kv.Key] = kv.Value;
            foreach (var k in source.m_Keywords) m_Keywords.Add(k);
            renderQueue = source.renderQueue; enableInstancing = source.enableInstancing;
        }
        public Material(string contents) : this(Shader.Default) { }
        internal Material() { m_Name = "Default-Material"; m_Shader = Shader.Default; Defaults(); }
        void Defaults()
        {
            m_ColorsById[k_Color] = Color.white;
            m_FloatsById[Shader.PropertyToID("_Smoothness")] = 0.5f;
            m_FloatsById[Shader.PropertyToID("_Glossiness")] = 0.5f;
        }
        internal static readonly HashSet<string> s_Known = new HashSet<string> { "_Color", "_BaseColor", "_MainTex", "_BaseMap", "_Metallic", "_Smoothness", "_Glossiness", "_EmissionColor", "_BumpMap", "_BumpScale", "_Cutoff", "_Surface", "_Mode", "_Cull", "_SrcBlend", "_DstBlend", "_ZWrite", "_OcclusionMap", "_MetallicGlossMap", "_SpecColor", "_EmissionMap", "_AlphaClip", "_Blend", "_QueueOffset", "_TintColor" };
        internal static bool KnownProperty(string n) => s_Known.Contains(n);
        static int Main(int id) => id == k_BaseColor ? k_Color : id == k_BaseMap ? k_MainTex : id;
        void Touch() => m_Version++;

        public Shader shader { get => m_Shader; set { m_Shader = value; Touch(); } }
        public Color color { get => GetColor(k_Color); set => SetColor(k_Color, value); }
        public Texture mainTexture { get => GetTexture(k_MainTex); set => SetTexture(k_MainTex, value); }
        public Vector2 mainTextureScale { get => GetTextureScale(k_MainTex); set => SetTextureScale(k_MainTex, value); }
        public Vector2 mainTextureOffset { get => GetTextureOffset(k_MainTex); set => SetTextureOffset(k_MainTex, value); }
        public int renderQueue { get; set; } = 2000;
        public bool enableInstancing { get; set; }
        public bool doubleSidedGI { get; set; }
        public MaterialGlobalIlluminationFlags globalIlluminationFlags { get; set; } = MaterialGlobalIlluminationFlags.EmissiveIsBlack;
        public string[] shaderKeywords { get { var a = new string[m_Keywords.Count]; m_Keywords.CopyTo(a); return a; } set { m_Keywords.Clear(); if (value != null) foreach (var k in value) m_Keywords.Add(k); Touch(); } }
        public int passCount => 1;

        public void SetColor(string name, Color value) => SetColor(Shader.PropertyToID(name), value);
        public void SetColor(int nameID, Color value) { m_ColorsById[Main(nameID)] = value; Touch(); }
        public Color GetColor(string name) => GetColor(Shader.PropertyToID(name));
        public Color GetColor(int nameID) => m_ColorsById.TryGetValue(Main(nameID), out var c) ? c : (Main(nameID) == k_Color ? Color.white : Color.black);
        public void SetFloat(string name, float value) => SetFloat(Shader.PropertyToID(name), value);
        public void SetFloat(int nameID, float value) { m_FloatsById[nameID] = value; Touch(); }
        public float GetFloat(string name) => GetFloat(Shader.PropertyToID(name));
        public float GetFloat(int nameID) => m_FloatsById.TryGetValue(nameID, out var f) ? f : 0f;
        public void SetInt(string name, int value) => SetFloat(name, value);
        public void SetInt(int nameID, int value) => SetFloat(nameID, value);
        public int GetInt(string name) => (int)GetFloat(name);
        public int GetInt(int nameID) => (int)GetFloat(nameID);
        public void SetInteger(string name, int value) => SetFloat(name, value);
        public void SetInteger(int nameID, int value) => SetFloat(nameID, value);
        public int GetInteger(string name) => (int)GetFloat(name);
        public int GetInteger(int nameID) => (int)GetFloat(nameID);
        public void SetVector(string name, Vector4 value) => SetVector(Shader.PropertyToID(name), value);
        public void SetVector(int nameID, Vector4 value) { if (Main(nameID) == k_Color) { SetColor(nameID, value); return; } m_Vectors[nameID] = value; Touch(); }
        public Vector4 GetVector(string name) => GetVector(Shader.PropertyToID(name));
        public Vector4 GetVector(int nameID) => Main(nameID) == k_Color || m_ColorsById.ContainsKey(nameID) ? (Vector4)GetColor(nameID) : (m_Vectors.TryGetValue(nameID, out var v) ? v : Vector4.zero);
        public void SetMatrix(string name, Matrix4x4 value) { m_Matrices[Shader.PropertyToID(name)] = value; Touch(); }
        public void SetMatrix(int nameID, Matrix4x4 value) { m_Matrices[nameID] = value; Touch(); }
        public Matrix4x4 GetMatrix(string name) => m_Matrices.TryGetValue(Shader.PropertyToID(name), out var m) ? m : Matrix4x4.identity;
        public void SetTexture(string name, Texture value) => SetTexture(Shader.PropertyToID(name), value);
        public void SetTexture(int nameID, Texture value) { m_Textures[Main(nameID)] = value; Touch(); }
        public Texture GetTexture(string name) => GetTexture(Shader.PropertyToID(name));
        public Texture GetTexture(int nameID) => m_Textures.TryGetValue(Main(nameID), out var t) ? t : null;
        public void SetTextureScale(string name, Vector2 value) => SetTextureScale(Shader.PropertyToID(name), value);
        public void SetTextureScale(int nameID, Vector2 value) { var st = ST(nameID); m_TexST[Main(nameID)] = new Vector4(value.x, value.y, st.z, st.w); Touch(); }
        public void SetTextureOffset(string name, Vector2 value) => SetTextureOffset(Shader.PropertyToID(name), value);
        public void SetTextureOffset(int nameID, Vector2 value) { var st = ST(nameID); m_TexST[Main(nameID)] = new Vector4(st.x, st.y, value.x, value.y); Touch(); }
        public Vector2 GetTextureScale(string name) => GetTextureScale(Shader.PropertyToID(name));
        public Vector2 GetTextureScale(int nameID) { var st = ST(nameID); return new Vector2(st.x, st.y); }
        public Vector2 GetTextureOffset(string name) => GetTextureOffset(Shader.PropertyToID(name));
        public Vector2 GetTextureOffset(int nameID) { var st = ST(nameID); return new Vector2(st.z, st.w); }
        internal Vector4 ST(int nameID) => m_TexST.TryGetValue(Main(nameID), out var v) ? v : new Vector4(1, 1, 0, 0);
        public void SetFloatArray(string name, float[] values) { }
        public void SetVectorArray(string name, Vector4[] values) { }
        public void SetColorArray(string name, Color[] values) { }
        public void SetBuffer(string name, object value) { }
        public bool HasProperty(string name) => HasProperty(Shader.PropertyToID(name));
        public bool HasProperty(int nameID)
        {
            nameID = Main(nameID);
            return KnownProperty(Shader.NameOf(nameID)) || m_ColorsById.ContainsKey(nameID) || m_FloatsById.ContainsKey(nameID) || m_Vectors.ContainsKey(nameID) || m_Textures.ContainsKey(nameID);
        }
        public bool HasColor(string name) => HasProperty(name);
        public bool HasColor(int nameID) => HasProperty(nameID);
        public bool HasFloat(string name) => HasProperty(name);
        public bool HasFloat(int nameID) => HasProperty(nameID);
        public bool HasInt(string name) => HasProperty(name);
        public bool HasInteger(string name) => HasProperty(name);
        public bool HasVector(string name) => HasProperty(name);
        public bool HasTexture(string name) => HasProperty(name);
        public bool HasMatrix(string name) => m_Matrices.ContainsKey(Shader.PropertyToID(name));
        public void EnableKeyword(string keyword) { m_Keywords.Add(keyword); Touch(); }
        public void DisableKeyword(string keyword) { m_Keywords.Remove(keyword); Touch(); }
        public bool IsKeywordEnabled(string keyword) => m_Keywords.Contains(keyword);
        public void SetOverrideTag(string tag, string val) { }
        public string GetTag(string tag, bool searchFallbacks) => "";
        public string GetTag(string tag, bool searchFallbacks, string defaultValue) => defaultValue;
        public void SetShaderPassEnabled(string passName, bool enabled) { }
        public bool GetShaderPassEnabled(string passName) => true;
        public int FindPass(string passName) => 0;
        public string GetPassName(int pass) => "";
        public string[] GetTexturePropertyNames() { var r = new List<string>(); foreach (var k in m_Textures.Keys) r.Add(Shader.NameOf(k)); return r.ToArray(); }
        public void CopyPropertiesFromMaterial(Material mat)
        {
            foreach (var kv in mat.m_ColorsById) m_ColorsById[kv.Key] = kv.Value;
            foreach (var kv in mat.m_FloatsById) m_FloatsById[kv.Key] = kv.Value;
            foreach (var kv in mat.m_Vectors) m_Vectors[kv.Key] = kv.Value;
            foreach (var kv in mat.m_Textures) m_Textures[kv.Key] = kv.Value;
            foreach (var kv in mat.m_TexST) m_TexST[kv.Key] = kv.Value;
            Touch();
        }
        public void CopyMatchingPropertiesFromMaterial(Material mat) => CopyPropertiesFromMaterial(mat);
        public void Lerp(Material start, Material end, float t) { color = Color.Lerp(start.color, end.color, t); }
        internal static Material s_Default;
        internal static Material DefaultMaterial => s_Default ??= new Material { m_Name = "Default-Material", m_IsAsset = true };
    }

    [Flags] public enum MaterialGlobalIlluminationFlags { None = 0, RealtimeEmissive = 1, BakedEmissive = 2, AnyEmissive = 3, EmissiveIsBlack = 4 }

    public sealed class MaterialPropertyBlock
    {
        internal readonly Dictionary<int, Color> m_Colors = new Dictionary<int, Color>();
        internal readonly Dictionary<int, float> m_Floats = new Dictionary<int, float>();
        internal readonly Dictionary<int, Vector4> m_Vectors = new Dictionary<int, Vector4>();
        internal readonly Dictionary<int, Texture> m_Textures = new Dictionary<int, Texture>();
        internal readonly Dictionary<int, Matrix4x4> m_Matrices = new Dictionary<int, Matrix4x4>();
        public bool isEmpty => m_Colors.Count == 0 && m_Floats.Count == 0 && m_Vectors.Count == 0 && m_Textures.Count == 0 && m_Matrices.Count == 0;
        public void Clear() { m_Colors.Clear(); m_Floats.Clear(); m_Vectors.Clear(); m_Textures.Clear(); m_Matrices.Clear(); }
        public void SetColor(string name, Color value) => m_Colors[Shader.PropertyToID(name)] = value;
        public void SetColor(int nameID, Color value) => m_Colors[nameID] = value;
        public void SetFloat(string name, float value) => m_Floats[Shader.PropertyToID(name)] = value;
        public void SetFloat(int nameID, float value) => m_Floats[nameID] = value;
        public void SetInt(string name, int value) => SetFloat(name, value);
        public void SetInt(int nameID, int value) => SetFloat(nameID, value);
        public void SetInteger(string name, int value) => SetFloat(name, value);
        public void SetInteger(int nameID, int value) => SetFloat(nameID, value);
        public void SetVector(string name, Vector4 value) => m_Vectors[Shader.PropertyToID(name)] = value;
        public void SetVector(int nameID, Vector4 value) => m_Vectors[nameID] = value;
        public void SetTexture(string name, Texture value) => m_Textures[Shader.PropertyToID(name)] = value;
        public void SetTexture(int nameID, Texture value) => m_Textures[nameID] = value;
        public void SetMatrix(string name, Matrix4x4 value) => m_Matrices[Shader.PropertyToID(name)] = value;
        public void SetMatrix(int nameID, Matrix4x4 value) => m_Matrices[nameID] = value;
        public void SetFloatArray(string name, float[] values) { }
        public void SetFloatArray(int nameID, float[] values) { }
        public void SetVectorArray(string name, Vector4[] values) { }
        public void SetVectorArray(int nameID, Vector4[] values) { }
        public void SetBuffer(string name, object value) { }
        public Color GetColor(string name) => GetColor(Shader.PropertyToID(name));
        public Color GetColor(int nameID) => m_Colors.TryGetValue(nameID, out var c) ? c : (m_Vectors.TryGetValue(nameID, out var v) ? (Color)v : Color.clear);
        public float GetFloat(string name) => GetFloat(Shader.PropertyToID(name));
        public float GetFloat(int nameID) => m_Floats.TryGetValue(nameID, out var f) ? f : 0f;
        public int GetInt(string name) => (int)GetFloat(name);
        public int GetInteger(string name) => (int)GetFloat(name);
        public Vector4 GetVector(string name) => GetVector(Shader.PropertyToID(name));
        public Vector4 GetVector(int nameID) => m_Vectors.TryGetValue(nameID, out var v) ? v : (m_Colors.TryGetValue(nameID, out var c) ? (Vector4)c : Vector4.zero);
        public Texture GetTexture(string name) => GetTexture(Shader.PropertyToID(name));
        public Texture GetTexture(int nameID) => m_Textures.TryGetValue(nameID, out var t) ? t : null;
        public Matrix4x4 GetMatrix(string name) => m_Matrices.TryGetValue(Shader.PropertyToID(name), out var m) ? m : Matrix4x4.identity;
        public bool HasColor(string name) => m_Colors.ContainsKey(Shader.PropertyToID(name));
        public bool HasColor(int nameID) => m_Colors.ContainsKey(nameID);
        public bool HasFloat(string name) => m_Floats.ContainsKey(Shader.PropertyToID(name));
        public bool HasFloat(int nameID) => m_Floats.ContainsKey(nameID);
        public bool HasInt(string name) => HasFloat(name);
        public bool HasInteger(string name) => HasFloat(name);
        public bool HasVector(string name) => m_Vectors.ContainsKey(Shader.PropertyToID(name));
        public bool HasTexture(string name) => m_Textures.ContainsKey(Shader.PropertyToID(name));
        public bool HasMatrix(string name) => m_Matrices.ContainsKey(Shader.PropertyToID(name));
        public bool HasProperty(string name) { int id = Shader.PropertyToID(name); return m_Colors.ContainsKey(id) || m_Floats.ContainsKey(id) || m_Vectors.ContainsKey(id) || m_Textures.ContainsKey(id) || m_Matrices.ContainsKey(id); }
        public bool HasProperty(int id) => m_Colors.ContainsKey(id) || m_Floats.ContainsKey(id) || m_Vectors.ContainsKey(id) || m_Textures.ContainsKey(id) || m_Matrices.ContainsKey(id);
        internal void CopyTo(MaterialPropertyBlock d)
        {
            d.Clear();
            foreach (var kv in m_Colors) d.m_Colors[kv.Key] = kv.Value;
            foreach (var kv in m_Floats) d.m_Floats[kv.Key] = kv.Value;
            foreach (var kv in m_Vectors) d.m_Vectors[kv.Key] = kv.Value;
            foreach (var kv in m_Textures) d.m_Textures[kv.Key] = kv.Value;
            foreach (var kv in m_Matrices) d.m_Matrices[kv.Key] = kv.Value;
        }
        internal int Hash()
        {
            unchecked
            {
                int h = 17;
                foreach (var kv in m_Colors) h = h * 31 + kv.Key * 7 + kv.Value.GetHashCode();
                foreach (var kv in m_Floats) h = h * 31 + kv.Key * 11 + kv.Value.GetHashCode();
                foreach (var kv in m_Vectors) h = h * 31 + kv.Key * 13 + kv.Value.GetHashCode();
                foreach (var kv in m_Textures) h = h * 31 + kv.Key * 17 + (kv.Value != null ? kv.Value.m_Uid * 1000 + kv.Value.m_Version : 0);
                return h;
            }
        }
    }

    public class Texture : Object
    {
        internal readonly int m_Uid = ++s_NextUid;
        internal int m_Version = 1;
        static int s_NextUid;
        internal int m_Width, m_Height;
        public virtual int width { get => m_Width; set => m_Width = value; }
        public virtual int height { get => m_Height; set => m_Height = value; }
        public FilterMode filterMode { get; set; } = FilterMode.Bilinear;
        public TextureWrapMode wrapMode { get; set; } = TextureWrapMode.Repeat;
        public TextureWrapMode wrapModeU { get => wrapMode; set => wrapMode = value; }
        public TextureWrapMode wrapModeV { get => wrapMode; set => wrapMode = value; }
        public int anisoLevel { get; set; } = 1;
        public float mipMapBias { get; set; }
        public virtual int mipmapCount => 1;
        public Vector2 texelSize => new Vector2(1f / Math.Max(1, width), 1f / Math.Max(1, height));
        public bool isReadable => !(this is Texture2D t2 && t2.m_AssetPath != null && t2.RGBA() == null);
        public uint updateCount => (uint)m_Version;
        public void IncrementUpdateCount() { m_Version++; }
        public static int masterTextureLimit { get; set; }
        public static AnisotropicFiltering anisotropicFiltering { get; set; } = AnisotropicFiltering.Enable;
        internal virtual Color32[] RGBA() => null;
    }

    public class Texture2D : Texture
    {
        internal string m_AssetPath;
        internal static Texture2D FromAsset(string path, int w, int h)
        {
            var t = new Texture2D(1, 1) { m_AssetPath = path, m_IsAsset = true, m_Name = System.IO.Path.GetFileNameWithoutExtension(path) };
            t.m_Width = Math.Max(1, w); t.m_Height = Math.Max(1, h); t.m_Pixels = null; t.m_Applied = null;
            return t;
        }
        void Readable() { if (m_Pixels == null) throw new UnityException("Texture '" + name + "' is not readable, the texture memory can not be accessed from scripts. You can make the texture readable in the Texture Import Settings."); }
        Color32[] m_Pixels;
        Color32[] m_Applied;   // what the renderer sees (updated by Apply)
        public TextureFormat format { get; private set; } = TextureFormat.RGBA32;
        bool m_Mips;
        public Texture2D(int width, int height) : this(width, height, TextureFormat.RGBA32, true, false) { }
        public Texture2D(int width, int height, TextureFormat textureFormat, bool mipChain) : this(width, height, textureFormat, mipChain, false) { }
        public Texture2D(int width, int height, TextureFormat textureFormat, bool mipChain, bool linear)
        {
            if (width <= 0 || height <= 0) throw new ArgumentException("Texture dimensions must be greater than zero.");
            m_Width = width; m_Height = height; format = textureFormat; m_Mips = mipChain;
            m_Pixels = new Color32[width * height];
            var fill = new Color32(205, 205, 205, 205); // a new texture starts grey, like Unity's
            for (int i = 0; i < m_Pixels.Length; i++) m_Pixels[i] = fill;
            m_Applied = (Color32[])m_Pixels.Clone();
        }
        public Texture2D(int width, int height, TextureFormat textureFormat, int mipCount, bool linear) : this(width, height, textureFormat, mipCount != 1, linear) { }
        public override int width { get => m_Width; set => throw new NotSupportedException("Can't set texture width."); }
        public override int height { get => m_Height; set => throw new NotSupportedException("Can't set texture height."); }
        public override int mipmapCount => m_Mips ? 1 + (int)Math.Floor(Math.Log(Math.Max(m_Width, m_Height), 2)) : 1;
        static Texture2D Solid(string name, Color32 c) { var t = new Texture2D(4, 4) { m_Name = name, m_IsAsset = true }; t.Fill(c); t.Apply(); return t; }
        static Texture2D s_White, s_Black, s_Gray, s_Red, s_Normal, s_LinearGray;
        public static Texture2D whiteTexture => s_White ??= Solid("UnityWhite", new Color32(255, 255, 255, 255));
        public static Texture2D blackTexture => s_Black ??= Solid("UnityBlack", new Color32(0, 0, 0, 255));
        public static Texture2D grayTexture => s_Gray ??= Solid("UnityGrey", new Color32(128, 128, 128, 255));
        public static Texture2D linearGrayTexture => s_LinearGray ??= Solid("UnityLinearGrey", new Color32(128, 128, 128, 255));
        public static Texture2D redTexture => s_Red ??= Solid("UnityRed", new Color32(255, 0, 0, 255));
        public static Texture2D normalTexture => s_Normal ??= Solid("UnityNormalMap", new Color32(128, 128, 255, 255));
        void Fill(Color32 c) { for (int i = 0; i < m_Pixels.Length; i++) m_Pixels[i] = c; }
        int Index(int x, int y)
        {
            Readable();
            if (wrapMode == TextureWrapMode.Repeat) { x = ((x % m_Width) + m_Width) % m_Width; y = ((y % m_Height) + m_Height) % m_Height; }
            else { x = Math.Clamp(x, 0, m_Width - 1); y = Math.Clamp(y, 0, m_Height - 1); }
            return y * m_Width + x;
        }
        public void SetPixel(int x, int y, Color color) { Readable(); if (x < 0 || y < 0 || x >= m_Width || y >= m_Height) return; m_Pixels[y * m_Width + x] = color; }
        public void SetPixel(int x, int y, Color color, int mipLevel) => SetPixel(x, y, color);
        public Color GetPixel(int x, int y) => m_Pixels[Index(x, y)];
        public Color GetPixel(int x, int y, int mipLevel) => GetPixel(x, y);
        public Color GetPixelBilinear(float u, float v)
        {
            float fx = u * m_Width - 0.5f, fy = v * m_Height - 0.5f;
            int x0 = (int)Math.Floor(fx), y0 = (int)Math.Floor(fy); float tx = fx - x0, ty = fy - y0;
            Color a = GetPixel(x0, y0), b = GetPixel(x0 + 1, y0), c = GetPixel(x0, y0 + 1), d = GetPixel(x0 + 1, y0 + 1);
            return Color.Lerp(Color.Lerp(a, b, tx), Color.Lerp(c, d, tx), ty);
        }
        public Color[] GetPixels() { Readable(); var r = new Color[m_Pixels.Length]; for (int i = 0; i < r.Length; i++) r[i] = m_Pixels[i]; return r; }
        public Color[] GetPixels(int miplevel) => GetPixels();
        public Color[] GetPixels(int x, int y, int blockWidth, int blockHeight)
        {
            var r = new Color[blockWidth * blockHeight];
            for (int j = 0; j < blockHeight; j++) for (int i = 0; i < blockWidth; i++) r[j * blockWidth + i] = m_Pixels[Index(x + i, y + j)];
            return r;
        }
        public Color32[] GetPixels32() { Readable(); return (Color32[])m_Pixels.Clone(); }
        public Color32[] GetPixels32(int miplevel) => GetPixels32();
        public void SetPixels(Color[] colors) { Readable(); if (colors.Length != m_Pixels.Length) throw new ArgumentException("Array size must be at least width*height"); for (int i = 0; i < colors.Length; i++) m_Pixels[i] = colors[i]; }
        public void SetPixels(Color[] colors, int miplevel) => SetPixels(colors);
        public void SetPixels(int x, int y, int blockWidth, int blockHeight, Color[] colors)
        {
            for (int j = 0; j < blockHeight; j++) for (int i = 0; i < blockWidth; i++) SetPixel(x + i, y + j, colors[j * blockWidth + i]);
        }
        public void SetPixels(int x, int y, int blockWidth, int blockHeight, Color[] colors, int miplevel) => SetPixels(x, y, blockWidth, blockHeight, colors);
        public void SetPixels32(Color32[] colors) { Readable(); if (colors.Length != m_Pixels.Length) throw new ArgumentException("Array size must be at least width*height"); Array.Copy(colors, m_Pixels, colors.Length); }
        public void SetPixels32(Color32[] colors, int miplevel) => SetPixels32(colors);
        public void SetPixels32(int x, int y, int blockWidth, int blockHeight, Color32[] colors)
        {
            for (int j = 0; j < blockHeight; j++) for (int i = 0; i < blockWidth; i++) if (x + i < m_Width && y + j < m_Height) m_Pixels[(y + j) * m_Width + x + i] = colors[j * blockWidth + i];
        }
        public byte[] GetRawTextureData() { Readable(); var b = new byte[m_Pixels.Length * 4]; for (int i = 0; i < m_Pixels.Length; i++) { b[i * 4] = m_Pixels[i].r; b[i * 4 + 1] = m_Pixels[i].g; b[i * 4 + 2] = m_Pixels[i].b; b[i * 4 + 3] = m_Pixels[i].a; } return b; }
        public void LoadRawTextureData(byte[] data) { Readable(); for (int i = 0; i < m_Pixels.Length && i * 4 + 3 < data.Length; i++) m_Pixels[i] = new Color32(data[i * 4], data[i * 4 + 1], data[i * 4 + 2], data[i * 4 + 3]); }
        public void Apply() => Apply(true, false);
        public void Apply(bool updateMipmaps) => Apply(updateMipmaps, false);
        public void Apply(bool updateMipmaps, bool makeNoLongerReadable) { if (m_Pixels == null) return; m_Applied = (Color32[])m_Pixels.Clone(); m_Version++; }
        public bool Reinitialize(int width, int height) => Reinitialize(width, height, format, m_Mips);
        public bool Reinitialize(int width, int height, TextureFormat format, bool hasMipMap)
        {
            m_Width = width; m_Height = height; this.format = format; m_Mips = hasMipMap;
            m_Pixels = new Color32[width * height]; return true;
        }
        public void Compress(bool highQuality) { }
        internal override Color32[] RGBA() => m_Applied;
        int m_UniformVer = -1; bool m_Uniform; Color m_UniformColor;
        // true when every pixel (as last applied) has the same colour, the common 1x1 'solid colour' texture
        internal bool UniformColor(out Color c)
        {
            if (m_Applied == null) { c = Color.white; return false; }
            if (m_UniformVer != m_Version)
            {
                m_UniformVer = m_Version; m_Uniform = true;
                var p = m_Applied; var first = p.Length > 0 ? p[0] : default;
                for (int i = 1; i < p.Length; i++) if (p[i].r != first.r || p[i].g != first.g || p[i].b != first.b || p[i].a != first.a) { m_Uniform = false; break; }
                m_UniformColor = first;
            }
            c = m_UniformColor; return m_Uniform;
        }
    }

    public class Renderer : Component
    {
        internal Material[] m_Materials = Array.Empty<Material>();
        internal bool[] m_Instanced = Array.Empty<bool>();
        internal MaterialPropertyBlock m_Block; internal int m_BlockVersion;
        internal readonly Dictionary<int, MaterialPropertyBlock> m_SlotBlocks = new Dictionary<int, MaterialPropertyBlock>();
        internal bool m_Enabled = true;
        public bool enabled { get => m_Enabled; set => m_Enabled = value; }
        public bool isVisible => m_Enabled && gameObject.activeInHierarchy;
        public ShadowCastingMode shadowCastingMode { get; set; } = ShadowCastingMode.On;
        public bool receiveShadows { get; set; } = true;
        public bool forceRenderingOff { get; set; }
        public int sortingOrder { get; set; }
        public int sortingLayerID { get; set; }
        public string sortingLayerName { get; set; } = "Default";
        public uint renderingLayerMask { get; set; } = 1;
        public int rendererPriority { get; set; }
        public bool allowOcclusionWhenDynamic { get; set; } = true;
        public bool staticShadowCaster { get; set; }
        public MotionVectorGenerationMode motionVectorGenerationMode { get; set; } = MotionVectorGenerationMode.Object;
        public LightProbeUsage lightProbeUsage { get; set; } = LightProbeUsage.BlendProbes;
        public ReflectionProbeUsage reflectionProbeUsage { get; set; } = ReflectionProbeUsage.BlendProbes;
        public int lightmapIndex { get; set; } = -1;
        public Vector4 lightmapScaleOffset { get; set; } = new Vector4(1, 1, 0, 0);
        public Transform probeAnchor { get; set; }

        // first material slot (older code paths use these)
        internal Material m_SharedMaterial
        {
            get => m_Materials.Length > 0 ? m_Materials[0] : null;
            set { if (m_Materials.Length == 0) { m_Materials = new Material[1]; m_Instanced = new bool[1]; } m_Materials[0] = value; m_Instanced[0] = false; }
        }
        internal bool m_MaterialIsInstance
        {
            get => m_Instanced.Length > 0 && m_Instanced[0];
            set { if (m_Instanced.Length > 0) m_Instanced[0] = value; }
        }
        public Material sharedMaterial
        {
            get => m_SharedMaterial;
            set => m_SharedMaterial = value;
        }
        public Material material
        {
            get { if (m_Materials.Length == 0 || m_Materials[0] == null) return null; return Instance(0); }
            set { m_SharedMaterial = value; m_MaterialIsInstance = value != null && !value.m_IsAsset; }
        }
        Material Instance(int i)
        {
            if (!m_Instanced[i] && m_Materials[i] != null)
            {
                var src = m_Materials[i];
                m_Materials[i] = new Material(src) { m_Name = src.name + " (Instance)" };
                m_Instanced[i] = true;
            }
            return m_Materials[i];
        }
        public Material[] sharedMaterials
        {
            get => (Material[])m_Materials.Clone();
            set { m_Materials = value != null ? (Material[])value.Clone() : Array.Empty<Material>(); m_Instanced = new bool[m_Materials.Length]; }
        }
        public Material[] materials
        {
            get { for (int i = 0; i < m_Materials.Length; i++) Instance(i); return (Material[])m_Materials.Clone(); }
            set { sharedMaterials = value; for (int i = 0; i < m_Instanced.Length; i++) m_Instanced[i] = m_Materials[i] != null && !m_Materials[i].m_IsAsset; }
        }
        public void GetSharedMaterials(List<Material> m) { m.Clear(); m.AddRange(m_Materials); }
        public void GetMaterials(List<Material> m) { m.Clear(); m.AddRange(materials); }
        public void SetSharedMaterials(List<Material> materials) => sharedMaterials = materials.ToArray();
        public void SetMaterials(List<Material> materials) => this.materials = materials.ToArray();
        public void SetPropertyBlock(MaterialPropertyBlock properties)
        {
            if (properties == null || properties.isEmpty) { m_Block = null; m_BlockVersion++; return; }
            m_Block ??= new MaterialPropertyBlock(); properties.CopyTo(m_Block); m_BlockVersion++;
        }
        public void SetPropertyBlock(MaterialPropertyBlock properties, int materialIndex)
        {
            if (properties == null || properties.isEmpty) m_SlotBlocks.Remove(materialIndex);
            else { var b = new MaterialPropertyBlock(); properties.CopyTo(b); m_SlotBlocks[materialIndex] = b; }
            m_BlockVersion++;
        }
        public void GetPropertyBlock(MaterialPropertyBlock dest) { if (dest == null) throw new ArgumentNullException(nameof(dest)); if (m_Block != null) m_Block.CopyTo(dest); else dest.Clear(); }
        public void GetPropertyBlock(MaterialPropertyBlock dest, int materialIndex) { if (m_SlotBlocks.TryGetValue(materialIndex, out var b)) b.CopyTo(dest); else dest.Clear(); }
        public bool HasPropertyBlock() => m_Block != null || m_SlotBlocks.Count > 0;
        public Bounds bounds
        {
            get
            {
                var mf = GetComponent<MeshFilter>();
                Bounds local = mf != null && mf.sharedMesh != null ? mf.sharedMesh.bounds : LocalBoundsOverride();
                return Geometry.TransformBounds(transform.localToWorldMatrix, local);
            }
            set { }
        }
        internal virtual Bounds LocalBoundsOverride() => new Bounds(Vector3.zero, Vector3.zero);
        public Bounds localBounds { get { var mf = GetComponent<MeshFilter>(); return mf != null && mf.sharedMesh != null ? mf.sharedMesh.bounds : LocalBoundsOverride(); } set { } }
        public Matrix4x4 localToWorldMatrix => transform.localToWorldMatrix;
        public Matrix4x4 worldToLocalMatrix => transform.worldToLocalMatrix;
        public void ResetBounds() { }
        public void ResetLocalBounds() { }
        internal override void OnAddedInternal() { if (m_Materials.Length == 0 && UsesDefaultMaterial) m_SharedMaterial = Material.DefaultMaterial; }
        internal virtual bool UsesDefaultMaterial => true;
        internal override void CopyFromInternal(Component src)
        {
            var r = (Renderer)src;
            m_Materials = (Material[])r.m_Materials.Clone(); m_Instanced = new bool[m_Materials.Length];
            for (int i = 0; i < m_Materials.Length; i++) if (r.m_Instanced[i] && m_Materials[i] != null && !m_Materials[i].m_IsAsset) { m_Materials[i] = new Material(m_Materials[i]); m_Instanced[i] = true; }
            if (r.m_Block != null) { m_Block = new MaterialPropertyBlock(); r.m_Block.CopyTo(m_Block); }
        }
    }
    public enum MotionVectorGenerationMode { Camera = 0, Object = 1, ForceNoMotion = 2 }
    public class MeshRenderer : Renderer
    {
        public Mesh additionalVertexStreams { get; set; }
        public Mesh enlightenVertexStream { get; set; }
        public int subMeshStartIndex => 0;
        public float scaleInLightmap { get; set; } = 1f;
        public ReceiveGI receiveGI { get; set; } = ReceiveGI.LightProbes;
        public bool stitchLightmapSeams { get; set; }
    }
    public enum ReceiveGI { Lightmaps = 1, LightProbes = 2 }
    public class SkinnedMeshRenderer : Renderer
    {
        Mesh m_Mesh;
        Transform[] m_Bones = Array.Empty<Transform>();
        public Mesh sharedMesh { get => m_Mesh; set => m_Mesh = value; }
        public Transform[] bones { get => (Transform[])m_Bones.Clone(); set => m_Bones = value ?? Array.Empty<Transform>(); }
        internal Transform[] BonesRaw => m_Bones;
        public Transform rootBone { get; set; }
        public bool updateWhenOffscreen { get; set; }
        public bool skinnedMotionVectors { get; set; } = true;
        public SkinQuality quality { get; set; }
        Bounds m_LocalBounds; bool m_HasLocalBounds;
        public new Bounds localBounds { get => m_HasLocalBounds ? m_LocalBounds : (m_Mesh != null ? m_Mesh.bounds : default); set { m_LocalBounds = value; m_HasLocalBounds = true; } }
        internal override Bounds LocalBoundsOverride() => localBounds;
        public new Bounds bounds { get => Geometry.TransformBounds((rootBone != null ? rootBone : transform).localToWorldMatrix, localBounds); set { } }
        readonly Dictionary<int, float> m_BlendWeights = new Dictionary<int, float>();
        public float GetBlendShapeWeight(int index) => m_BlendWeights.TryGetValue(index, out var w) ? w : 0f;
        public void SetBlendShapeWeight(int index, float value) { m_BlendWeights[index] = value; }
        internal bool CanSkin => m_Mesh != null && m_Bones.Length > 0 && m_Mesh.BindposesRaw.Length > 0 && m_Mesh.BoneWeightsRaw.Length == m_Mesh.vertexCount;
        // bone matrices the way Unity's skinning uses them: bone.localToWorldMatrix * bindpose
        internal Matrix4x4 SkinMatrix(int i)
        {
            var bp = m_Mesh.BindposesRaw;
            var b = i < m_Bones.Length ? m_Bones[i] : null;
            var bind = i < bp.Length ? bp[i] : Matrix4x4.identity;
            return (b != null ? b.localToWorldMatrix : transform.localToWorldMatrix) * bind;
        }
        public void BakeMesh(Mesh mesh) => BakeMesh(mesh, false);
        // the posed mesh, in this renderer's local space (like Unity)
        public void BakeMesh(Mesh mesh, bool useScale)
        {
            if (mesh == null) throw new ArgumentNullException(nameof(mesh));
            if (m_Mesh == null) { mesh.Clear(); return; }
            var src = m_Mesh;
            var v = src.vertices; var n = src.normals;
            if (CanSkin)
            {
                var w2l = useScale ? transform.worldToLocalMatrix : Matrix4x4.TRS(transform.position, transform.rotation, Vector3.one).inverse;
                var mats = new Matrix4x4[m_Bones.Length];
                for (int i = 0; i < mats.Length; i++) mats[i] = w2l * SkinMatrix(i);
                var bw = src.BoneWeightsRaw;
                for (int i = 0; i < v.Length; i++)
                {
                    var w = bw[i];
                    Vector3 p = Vector3.zero, q = Vector3.zero;
                    void Add(int bi, float wt) { if (wt <= 0 || bi < 0 || bi >= mats.Length) return; p += mats[bi].MultiplyPoint3x4(v[i]) * wt; if (n.Length == v.Length) q += mats[bi].MultiplyVector(n[i]) * wt; }
                    Add(w.boneIndex0, w.weight0); Add(w.boneIndex1, w.weight1); Add(w.boneIndex2, w.weight2); Add(w.boneIndex3, w.weight3);
                    v[i] = p; if (n.Length == v.Length) n[i] = q.normalized;
                }
            }
            mesh.Clear();
            mesh.vertices = v;
            if (n.Length == v.Length) mesh.normals = n;
            var uv = src.uv; if (uv.Length == v.Length) mesh.uv = uv;
            mesh.subMeshCount = src.subMeshCount;
            for (int s = 0; s < src.subMeshCount; s++) mesh.SetIndices(src.GetIndices(s), src.GetTopology(s), s);
            mesh.RecalculateBounds();
        }
        internal override void CopyFromInternal(Component src)
        {
            base.CopyFromInternal(src);
            var o = (SkinnedMeshRenderer)src;
            m_LocalBounds = o.m_LocalBounds; m_HasLocalBounds = o.m_HasLocalBounds;
        }
    }
    public enum SkinQuality { Auto = 0, Bone1 = 1, Bone2 = 2, Bone4 = 4 }

    public sealed class MeshFilter : Component
    {
        internal Mesh m_Mesh;
        bool m_MeshIsInstance;
        public Mesh sharedMesh { get => m_Mesh; set { m_Mesh = value; m_MeshIsInstance = false; } }
        // like Unity: reading .mesh gives this filter its own copy of a shared mesh, the first time
        public Mesh mesh
        {
            get
            {
                if (m_Mesh != null && !m_MeshIsInstance)
                {
                    var src = m_Mesh; m_Mesh = src.CloneMesh(); m_Mesh.m_Name = src.name + " Instance"; m_MeshIsInstance = true;
                }
                return m_Mesh;
            }
            set { m_Mesh = value; m_MeshIsInstance = value != null; }
        }
        internal override void CopyFromInternal(Component src) { m_Mesh = ((MeshFilter)src).m_Mesh; }
    }

    public class Font : Object
    {
        internal readonly int m_Uid = ++s_NextUid; static int s_NextUid;
        Material m_Material;
        public Font() { m_Name = "Font"; }
        public Font(string name) { m_Name = name; }
        public Material material { get => m_Material ??= new Material(Shader.Find("GUI/Text Shader")) { m_Name = "Font Material" }; set => m_Material = value; }
        public string[] fontNames { get; set; } = new[] { "Arial" };
        public bool dynamic => true;
        public int fontSize { get; internal set; } = 16;
        public int ascent => (int)(fontSize * 0.8f);
        public int lineHeight => (int)Math.Ceiling(fontSize * 1.15f);
        public bool HasCharacter(char c) => true;
        public void RequestCharactersInTexture(string characters) { }
        public void RequestCharactersInTexture(string characters, int size) { }
        public void RequestCharactersInTexture(string characters, int size, FontStyle style) { }
        public bool GetCharacterInfo(char ch, out CharacterInfo info) => GetCharacterInfo(ch, out info, fontSize, FontStyle.Normal);
        public bool GetCharacterInfo(char ch, out CharacterInfo info, int size) => GetCharacterInfo(ch, out info, size, FontStyle.Normal);
        public bool GetCharacterInfo(char ch, out CharacterInfo info, int size, FontStyle style)
        {
            if (size <= 0) size = fontSize;
            info = new CharacterInfo { index = ch, size = size, style = style, advance = (int)Math.Round(TextMetrics.CharWidth(ch) * size) };
            return true;
        }
        public static Font CreateDynamicFontFromOSFont(string fontname, int size) => new Font(fontname) { fontSize = size, fontNames = new[] { fontname } };
        public static Font CreateDynamicFontFromOSFont(string[] fontnames, int size) => new Font(fontnames != null && fontnames.Length > 0 ? fontnames[0] : "Arial") { fontSize = size, fontNames = fontnames ?? new[] { "Arial" } };
        public static string[] GetOSInstalledFontNames() => new[] { "Arial", "Verdana", "Tahoma", "Trebuchet MS", "Times New Roman", "Georgia", "Courier New", "Consolas" };
        public static string[] GetPathsToOSFonts() => Array.Empty<string>();
        internal static Font s_Default;
        internal static Font Default => s_Default ??= new Font("LegacyRuntime") { m_IsAsset = true };
        public static event Action<Font> textureRebuilt { add { } remove { } }
    }
    public struct CharacterInfo
    {
        public int index; public int size; public FontStyle style;
        public int advance { get; set; }
        public int glyphWidth { get => advance; set { } }
        public int glyphHeight { get => size; set { } }
        public int bearing { get; set; }
        public int minX { get; set; } public int maxX { get => advance; set { } }
        public int minY { get; set; } public int maxY { get => size; set { } }
    }
    internal static class TextMetrics
    {
        // rough average widths (fraction of the font size) for a sans-serif font
        internal static float CharWidth(char c)
        {
            if (c == ' ') return 0.28f;
            if ("il.,:;'|!".IndexOf(c) >= 0) return 0.25f;
            if ("mwMW".IndexOf(c) >= 0) return 0.85f;
            if (char.IsUpper(c) || char.IsDigit(c)) return 0.62f;
            return 0.52f;
        }
    }

    [RequireComponent(typeof(MeshRenderer))]
    public sealed class TextMesh : Component
    {
        internal int m_Version = 1;
        string m_Text = "Hello World"; Font m_Font; int m_FontSize; FontStyle m_FontStyle; float m_OffsetZ; TextAlignment m_Alignment; TextAnchor m_Anchor = TextAnchor.UpperLeft;
        float m_CharacterSize = 1f, m_LineSpacing = 1f, m_TabSize = 4f; bool m_RichText = true; Color m_Color = Color.white;
        void Set<T>(ref T field, T v) { if (!EqualityComparer<T>.Default.Equals(field, v)) { field = v; m_Version++; } }
        public string text { get => m_Text; set => Set(ref m_Text, value ?? ""); }
        public Font font { get => m_Font; set { Set(ref m_Font, value); var r = GetComponent<MeshRenderer>(); if (r != null && value != null && r.m_SharedMaterial == Material.DefaultMaterial) r.m_SharedMaterial = value.material; } }
        public int fontSize { get => m_FontSize; set => Set(ref m_FontSize, value); }
        public FontStyle fontStyle { get => m_FontStyle; set => Set(ref m_FontStyle, value); }
        public float offsetZ { get => m_OffsetZ; set => Set(ref m_OffsetZ, value); }
        public TextAlignment alignment { get => m_Alignment; set => Set(ref m_Alignment, value); }
        public TextAnchor anchor { get => m_Anchor; set => Set(ref m_Anchor, value); }
        public float characterSize { get => m_CharacterSize; set => Set(ref m_CharacterSize, value); }
        public float lineSpacing { get => m_LineSpacing; set => Set(ref m_LineSpacing, value); }
        public float tabSize { get => m_TabSize; set => Set(ref m_TabSize, value); }
        public bool richText { get => m_RichText; set => Set(ref m_RichText, value); }
        public Color color { get => m_Color; set => Set(ref m_Color, value); }
        internal override void OnAddedInternal()
        {
            var r = GetComponent<MeshRenderer>();
            if (r != null && (r.m_SharedMaterial == null || r.m_SharedMaterial == Material.DefaultMaterial)) r.m_SharedMaterial = Font.Default.material;
        }
        internal override void CopyFromInternal(Component src)
        {
            var t = (TextMesh)src;
            m_Text = t.m_Text; m_Font = t.m_Font; m_FontSize = t.m_FontSize; m_FontStyle = t.m_FontStyle; m_OffsetZ = t.m_OffsetZ; m_Alignment = t.m_Alignment; m_Anchor = t.m_Anchor;
            m_CharacterSize = t.m_CharacterSize; m_LineSpacing = t.m_LineSpacing; m_TabSize = t.m_TabSize; m_RichText = t.m_RichText; m_Color = t.m_Color; m_Version++;
        }
    }
}

namespace UnityEngine.Rendering
{
    public static class GraphicsSettings
    {
        internal static bool isURP = true;
        public static object currentRenderPipeline => null;
        public static object defaultRenderPipeline { get; set; }
        public static bool lightsUseLinearIntensity { get; set; } = true;
        public static bool useScriptableRenderPipelineBatching { get; set; } = true;
    }
}
