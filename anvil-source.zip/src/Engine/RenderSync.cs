// Anvil — what the renderer on the page needs beyond transforms: mesh and texture data (sent when they change),
// each renderer's materials (sent when they change), 3D text, and per-frame geometry for lines, trails and particles.
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using UnityEngine;
using UnityEngine.Rendering;

namespace Anvil
{
    internal static class RenderSync
    {
        // ---- meshes ----
        static readonly Dictionary<int, (WeakReference<Mesh> mesh, int version)> s_Meshes = new Dictionary<int, (WeakReference<Mesh>, int)>();
        internal static readonly List<(int uid, byte[] data)> meshUploads = new List<(int, byte[])>();
        static readonly List<int> s_MeshGone = new List<int>();
        // ---- textures ----
        static readonly Dictionary<int, (WeakReference<Texture> tex, int version)> s_Textures = new Dictionary<int, (WeakReference<Texture>, int)>();
        internal static readonly List<(int uid, int w, int h, int flags, byte[] rgba)> textureUploads = new List<(int, int, int, int, byte[])>();
        // ---- materials per renderer slot ----
        static readonly Dictionary<int, int> s_SlotSig = new Dictionary<int, int>();
        static readonly Dictionary<int, string> s_PendingMats = new Dictionary<int, string>();
        // ---- text ----
        static readonly Dictionary<int, int> s_TextVer = new Dictionary<int, int>();
        static readonly Dictionary<int, string> s_PendingTexts = new Dictionary<int, string>();
        // ---- per-frame geometry ----
        internal static readonly List<double> extras = new List<double>();
        static readonly List<Vector3> s_Pts = new List<Vector3>(); static readonly List<float> s_Ts = new List<float>(); static readonly List<float> s_Pf = new List<float>();
        static int s_Frame;

        internal static void Reset()
        {
            s_Meshes.Clear(); meshUploads.Clear(); meshAssetUploads.Clear(); s_MeshGone.Clear(); s_Textures.Clear(); textureUploads.Clear(); textureAssetUploads.Clear();
            s_SlotSig.Clear(); s_PendingMats.Clear(); s_TextVer.Clear(); s_PendingTexts.Clear(); extras.Clear();
        }

        internal static void BeginFrame()
        {
            meshUploads.Clear(); textureUploads.Clear(); extras.Clear(); extras.Add(0);
            if (++s_Frame % 120 == 0) Sweep();
        }
        static void Sweep()
        {
            List<int> gone = null;
            foreach (var kv in s_Meshes) if (!kv.Value.mesh.TryGetTarget(out var m) || m.m_Destroyed) (gone ??= new List<int>()).Add(kv.Key);
            if (gone != null) foreach (var k in gone) { s_Meshes.Remove(k); s_MeshGone.Add(k); }
            List<int> tg = null;
            foreach (var kv in s_Textures) if (!kv.Value.tex.TryGetTarget(out var t) || t.m_Destroyed) (tg ??= new List<int>()).Add(kv.Key);
            if (tg != null) foreach (var k in tg) s_Textures.Remove(k);
        }

        // mesh reference for a frame item: primitive code (> 0) or -uid for a mesh built by code (0 = nothing to draw)
        internal static int MeshRef(Mesh m)
        {
            if (m == null || m.m_Destroyed) return 0;
            if (m.m_Primitive != null)
                switch (m.m_Primitive) { case "Cube": return 1; case "Sphere": return 2; case "Capsule": return 3; case "Cylinder": return 4; case "Plane": return 5; case "Quad": return 6; }
            if (!s_Meshes.TryGetValue(m.m_Uid, out var e) || e.version != m.m_Version)
            {
                s_Meshes[m.m_Uid] = (new WeakReference<Mesh>(m), m.m_Version);
                if (m.IsPristineAsset) meshAssetUploads.Add((m.m_Uid, m.m_AssetKey)); // the page already has this model's mesh
                else meshUploads.Add((m.m_Uid, m.Pack()));
            }
            return -m.m_Uid;
        }
        internal static readonly List<(int uid, string key)> meshAssetUploads = new List<(int, string)>();
        internal static readonly List<(int uid, string path)> textureAssetUploads = new List<(int, string)>();
        internal static int TextureRef(Texture t)
        {
            if (t == null || t.m_Destroyed) return 0;
            if (t is Texture2D at && at.m_AssetPath != null && at.RGBA() == null)
            {
                // an imported image: the page already has it, send only its path once
                if (!s_Textures.ContainsKey(t.m_Uid)) { s_Textures[t.m_Uid] = (new WeakReference<Texture>(t), t.m_Version); textureAssetUploads.Add((t.m_Uid, at.m_AssetPath)); }
                return t.m_Uid;
            }
            if (!s_Textures.TryGetValue(t.m_Uid, out var e) || e.version != t.m_Version)
            {
                var px = t.RGBA();
                if (px == null) return 0;
                s_Textures[t.m_Uid] = (new WeakReference<Texture>(t), t.m_Version);
                var bytes = new byte[px.Length * 4];
                for (int i = 0; i < px.Length; i++) { bytes[i * 4] = px[i].r; bytes[i * 4 + 1] = px[i].g; bytes[i * 4 + 2] = px[i].b; bytes[i * 4 + 3] = px[i].a; }
                int flags = (int)t.filterMode | ((int)t.wrapMode << 4);
                textureUploads.Add((t.m_Uid, t.width, t.height, flags, bytes));
            }
            return t.m_Uid;
        }

        // ---- materials ----
        static readonly int k_Color = Shader.PropertyToID("_Color"), k_BaseColor = Shader.PropertyToID("_BaseColor"), k_Emission = Shader.PropertyToID("_EmissionColor");
        static readonly int k_MainTex = Shader.PropertyToID("_MainTex"), k_BaseMap = Shader.PropertyToID("_BaseMap"), k_Metallic = Shader.PropertyToID("_Metallic");
        static readonly int k_Smooth = Shader.PropertyToID("_Smoothness"), k_Gloss = Shader.PropertyToID("_Glossiness"), k_Surface = Shader.PropertyToID("_Surface"), k_Mode = Shader.PropertyToID("_Mode");
        static readonly int k_Cutoff = Shader.PropertyToID("_Cutoff"), k_AlphaClip = Shader.PropertyToID("_AlphaClip"), k_Blend = Shader.PropertyToID("_Blend"), k_Cull = Shader.PropertyToID("_Cull"), k_Tint = Shader.PropertyToID("_TintColor");

        // Makes sure the page has this renderer's current materials; returns the slot id the frame item refers to.
        internal static int MaterialSlot(Renderer r, int subCount)
        {
            int slot = r.m_InstanceID;
            int n = Math.Max(1, subCount);
            int sig;
            unchecked
            {
                sig = 17 + n * 31 + r.m_BlockVersion * 7919;
                for (int i = 0; i < n; i++)
                {
                    var m = i < r.m_Materials.Length ? r.m_Materials[i] : (r.m_Materials.Length > 0 ? r.m_Materials[r.m_Materials.Length - 1] : null);
                    sig = sig * 31 + (m == null ? 1 : m.m_Uid * 65599 + m.m_Version);
                    if (m != null) foreach (var t in m.m_Textures.Values) if (t != null) sig = sig * 31 + t.m_Uid * 997 + t.m_Version;
                }
                if (r.m_Block != null) sig = sig * 31 + r.m_Block.Hash();
                foreach (var kv in r.m_SlotBlocks) sig = sig * 31 + kv.Key * 13 + kv.Value.Hash();
            }
            if (s_SlotSig.TryGetValue(slot, out var old) && old == sig) return slot;
            s_SlotSig[slot] = sig;
            var sb = new StringBuilder("[");
            for (int i = 0; i < n; i++)
            {
                if (i > 0) sb.Append(',');
                var m = i < r.m_Materials.Length ? r.m_Materials[i] : (r.m_Materials.Length > 0 ? r.m_Materials[r.m_Materials.Length - 1] : null);
                r.m_SlotBlocks.TryGetValue(i, out var slotBlock);
                WriteMaterial(sb, m, slotBlock ?? r.m_Block, r is ParticleSystemRenderer);
            }
            sb.Append(']');
            s_PendingMats[slot] = sb.ToString();
            return slot;
        }
        static void WriteMaterial(StringBuilder sb, Material m, MaterialPropertyBlock b, bool particles)
        {
            if (m == null || m.m_Destroyed) { sb.Append("{\"missing\":1}"); return; }
            Color c = m.GetColor(k_Color);
            if (m.m_ColorsById.TryGetValue(k_Tint, out var tint)) c = tint * 2f;
            Color e = m.IsKeywordEnabled("_EMISSION") || m.m_ColorsById.ContainsKey(k_Emission) ? m.GetColor(k_Emission) : Color.black;
            Texture tex = m.GetTexture(k_MainTex);
            float metal = m.GetFloat(k_Metallic), smooth = m.m_FloatsById.ContainsKey(k_Smooth) ? m.GetFloat(k_Smooth) : m.GetFloat(k_Gloss);
            var st = m.ST(k_MainTex);
            if (b != null)
            {
                if (b.m_Colors.TryGetValue(k_BaseColor, out var bc) || b.m_Colors.TryGetValue(k_Color, out bc)) c = bc;
                else if (b.m_Vectors.TryGetValue(k_BaseColor, out var bv) || b.m_Vectors.TryGetValue(k_Color, out bv)) c = bv;
                if (b.m_Colors.TryGetValue(k_Emission, out var be)) e = be;
                if (b.m_Textures.TryGetValue(k_BaseMap, out var bt) || b.m_Textures.TryGetValue(k_MainTex, out bt)) tex = bt;
                if (b.m_Floats.TryGetValue(k_Metallic, out var bm)) metal = bm;
                if (b.m_Floats.TryGetValue(k_Smooth, out var bs) || b.m_Floats.TryGetValue(k_Gloss, out bs)) smooth = bs;
            }
            var sh = m.shader;
            bool unlit = sh != null && sh.IsUnlit, vcol = sh != null && sh.UsesVertexColor;
            bool transparent = m.GetFloat(k_Surface) >= 0.5f || m.GetFloat(k_Mode) >= 2f || c.a < 0.999f || (sh != null && (sh.name.Contains("Transparent") || sh.name.StartsWith("Sprites/") || sh.name.Contains("Particles")));
            bool additive = (sh != null && (sh.name.Contains("Additive") || sh.name.Contains("Add"))) || m.GetFloat(k_Blend) == 2f;
            float cutoff = m.GetFloat(k_AlphaClip) >= 0.5f || m.GetFloat(k_Mode) == 1f || (sh != null && sh.name.Contains("Cutout")) ? (m.HasProperty(k_Cutoff) && m.m_FloatsById.ContainsKey(k_Cutoff) ? m.GetFloat(k_Cutoff) : 0.5f) : 0f;
            int texRef = TextureRef(tex);
            sb.Append("{\"c\":[").Append(F(c.r)).Append(',').Append(F(c.g)).Append(',').Append(F(c.b)).Append(',').Append(F(c.a)).Append(']');
            sb.Append(",\"m\":").Append(F(metal)).Append(",\"s\":").Append(F(smooth));
            if (e.r > 0 || e.g > 0 || e.b > 0) sb.Append(",\"e\":[").Append(F(e.r)).Append(',').Append(F(e.g)).Append(',').Append(F(e.b)).Append(']');
            if (texRef != 0) { sb.Append(",\"t\":").Append(texRef); if (st != new Vector4(1, 1, 0, 0)) sb.Append(",\"st\":[").Append(F(st.x)).Append(',').Append(F(st.y)).Append(',').Append(F(st.z)).Append(',').Append(F(st.w)).Append(']'); }
            if (unlit) sb.Append(",\"u\":1");
            if (vcol) sb.Append(",\"vc\":1");
            if (transparent) sb.Append(",\"tr\":1");
            if (additive) sb.Append(",\"add\":1");
            if (cutoff > 0) sb.Append(",\"cut\":").Append(F(cutoff));
            if (m.GetFloat(k_Cull) == 0f && m.m_FloatsById.ContainsKey(k_Cull)) sb.Append(",\"ds\":1");
            if (particles) sb.Append(",\"p\":1");
            sb.Append('}');
        }
        static string F(float v) => float.IsFinite(v) ? Math.Round(v, 4).ToString(System.Globalization.CultureInfo.InvariantCulture) : "0";

        // ---- text ----
        internal static void Text(TextMesh t)
        {
            int id = t.m_InstanceID;
            if (s_TextVer.TryGetValue(id, out var v) && v == t.m_Version) return;
            s_TextVer[id] = t.m_Version;
            var sb = new StringBuilder("{");
            sb.Append("\"text\":").Append(JsonSerializer.Serialize(t.text ?? ""));
            sb.Append(",\"size\":").Append(t.fontSize).Append(",\"cs\":").Append(F(t.characterSize)).Append(",\"ls\":").Append(F(t.lineSpacing));
            sb.Append(",\"anchor\":").Append((int)t.anchor).Append(",\"align\":").Append((int)t.alignment).Append(",\"style\":").Append((int)t.fontStyle);
            sb.Append(",\"rich\":").Append(t.richText ? 1 : 0).Append(",\"z\":").Append(F(t.offsetZ));
            var c = t.color; sb.Append(",\"c\":[").Append(F(c.r)).Append(',').Append(F(c.g)).Append(',').Append(F(c.b)).Append(',').Append(F(c.a)).Append(']');
            var font = t.font != null ? t.font.name : "";
            sb.Append(",\"font\":").Append(JsonSerializer.Serialize(font));
            sb.Append('}');
            s_PendingTexts[id] = sb.ToString();
        }

        // ---- lines, trails, particles (rebuilt every frame) ----
        internal static void Line(LineLikeRenderer r)
        {
            int n = r.WorldPoints(s_Pts, s_Ts);
            if (n < 2) return;
            int slot = MaterialSlot(r, 1);
            var e = extras;
            e.Add(1); e.Add(r.m_GameObject.m_InstanceID); e.Add(slot); e.Add(n);
            e.Add(r.alignment == LineAlignment.TransformZ ? 1 : 0);
            var fz = r.transform.forward; e.Add(fz.x); e.Add(fz.y); e.Add(fz.z);
            e.Add(r.numCapVertices); e.Add(r.textureMode == LineTextureMode.Tile ? 1 : 0);
            for (int i = 0; i < n; i++)
            {
                var p = s_Pts[i]; float t = s_Ts[i]; var c = r.ColorAt(t);
                e.Add(p.x); e.Add(p.y); e.Add(p.z); e.Add(r.WidthAt(t)); e.Add(c.r); e.Add(c.g); e.Add(c.b); e.Add(c.a);
            }
            extras[0] = extras[0] + 1;
        }
        // a skinned mesh: [3, id, slot, boneCount, meshRef, enabled, castShadows, receiveShadows, then per bone bone.localToWorld * bindpose]
        internal static void Skinned(SkinnedMeshRenderer r)
        {
            var mesh = r.sharedMesh;
            int mref = MeshRef(mesh);
            if (mref == 0) return;
            int slot = MaterialSlot(r, mesh.RenderSubCount);
            int nb = r.BonesRaw.Length;
            var e = extras;
            e.Add(3); e.Add(r.m_GameObject.m_InstanceID); e.Add(slot); e.Add(nb);
            e.Add(mref); e.Add(r.m_Enabled && !r.forceRenderingOff ? 1 : 0); e.Add(r.shadowCastingMode != ShadowCastingMode.Off ? 1 : 0); e.Add(r.receiveShadows ? 1 : 0);
            for (int i = 0; i < nb; i++)
            {
                var m = r.SkinMatrix(i);
                for (int c = 0; c < 4; c++) for (int row = 0; row < 4; row++) e.Add(m[row, c]);
            }
            extras[0] = extras[0] + 1;
        }
        internal static void Particles(ParticleSystem ps, ParticleSystemRenderer r)
        {
            s_Pf.Clear();
            int n = ps.RenderData(s_Pf);
            if (n == 0 || r == null || !r.m_Enabled || r.renderMode == ParticleSystemRenderMode.None) return;
            int slot = MaterialSlot(r, 1);
            var e = extras;
            e.Add(2); e.Add(ps.m_GameObject.m_InstanceID); e.Add(slot); e.Add(n);
            e.Add((int)r.renderMode); e.Add(r.velocityScale); e.Add(r.lengthScale); e.Add(r.maxParticleSize);
            for (int i = 0; i < s_Pf.Count; i++) e.Add(s_Pf[i]);
            extras[0] = extras[0] + 1;
        }

        internal static void WriteEvents(Utf8JsonWriter w)
        {
            AudioSync.Write(w);
            if (meshAssetUploads.Count > 0)
            {
                w.WriteStartArray("meshAssets");
                foreach (var (uid, key) in meshAssetUploads) { w.WriteStartArray(); w.WriteNumberValue(uid); w.WriteStringValue(key); w.WriteEndArray(); }
                w.WriteEndArray();
                meshAssetUploads.Clear();
            }
            if (textureAssetUploads.Count > 0)
            {
                w.WriteStartArray("texAssets");
                foreach (var (uid, path) in textureAssetUploads) { w.WriteStartArray(); w.WriteNumberValue(uid); w.WriteStringValue(path); w.WriteEndArray(); }
                w.WriteEndArray();
                textureAssetUploads.Clear();
            }
            if (s_PendingMats.Count > 0)
            {
                w.WriteStartObject("mats");
                foreach (var kv in s_PendingMats) { w.WritePropertyName(kv.Key.ToString()); w.WriteRawValue(kv.Value, true); }
                w.WriteEndObject();
                s_PendingMats.Clear();
            }
            if (s_PendingTexts.Count > 0)
            {
                w.WriteStartObject("texts");
                foreach (var kv in s_PendingTexts) { w.WritePropertyName(kv.Key.ToString()); w.WriteRawValue(kv.Value, true); }
                w.WriteEndObject();
                s_PendingTexts.Clear();
            }
            if (s_MeshGone.Count > 0)
            {
                w.WriteStartArray("meshGone"); foreach (var k in s_MeshGone) w.WriteNumberValue(k); w.WriteEndArray();
                s_MeshGone.Clear();
            }
        }
    }
}
