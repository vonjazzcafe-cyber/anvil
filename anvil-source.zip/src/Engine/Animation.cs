// Anvil — animation: AnimationClip (from imported models or built with SetCurve), the Animator with an Animator
// Controller (states, transitions, parameters, 1D blend trees, layers), the legacy Animation component, animation
// events and StateMachineBehaviours. Clips are sampled every frame after Update and before LateUpdate, like Unity.
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text.Json;
using Anvil;

namespace UnityEngine
{
    // enum values as in Unity 6000.3
    public enum AnimationCullingType { AlwaysAnimate = 0, BasedOnRenderers = 1, BasedOnClipBounds = 2, BasedOnUserBounds = 3 }
    public enum AnimationUpdateMode { Normal = 0, Fixed = 1 }
    public enum AnimatorCullingMode { AlwaysAnimate = 0, CullUpdateTransforms = 1, CullCompletely = 2, BasedOnRenderers = 1 }
    public enum AnimatorUpdateMode { Normal = 0, Fixed = 1, UnscaledTime = 2, AnimatePhysics = 1 }
    public enum HumanBodyBones { Hips = 0, LeftUpperLeg = 1, RightUpperLeg = 2, LeftLowerLeg = 3, RightLowerLeg = 4, LeftFoot = 5, RightFoot = 6, Spine = 7, Chest = 8, UpperChest = 54, Neck = 9, Head = 10, LeftShoulder = 11, RightShoulder = 12, LeftUpperArm = 13, RightUpperArm = 14, LeftLowerArm = 15, RightLowerArm = 16, LeftHand = 17, RightHand = 18, LeftToes = 19, RightToes = 20, LeftEye = 21, RightEye = 22, Jaw = 23, LeftThumbProximal = 24, LeftThumbIntermediate = 25, LeftThumbDistal = 26, LeftIndexProximal = 27, LeftIndexIntermediate = 28, LeftIndexDistal = 29, LeftMiddleProximal = 30, LeftMiddleIntermediate = 31, LeftMiddleDistal = 32, LeftRingProximal = 33, LeftRingIntermediate = 34, LeftRingDistal = 35, LeftLittleProximal = 36, LeftLittleIntermediate = 37, LeftLittleDistal = 38, RightThumbProximal = 39, RightThumbIntermediate = 40, RightThumbDistal = 41, RightIndexProximal = 42, RightIndexIntermediate = 43, RightIndexDistal = 44, RightMiddleProximal = 45, RightMiddleIntermediate = 46, RightMiddleDistal = 47, RightRingProximal = 48, RightRingIntermediate = 49, RightRingDistal = 50, RightLittleProximal = 51, RightLittleIntermediate = 52, RightLittleDistal = 53, LastBone = 55 }
    public enum AnimatorControllerParameterType { Float = 1, Int = 3, Bool = 4, Trigger = 9 }
    public enum AvatarIKGoal { LeftFoot = 0, RightFoot = 1, LeftHand = 2, RightHand = 3 }
    public enum AvatarIKHint { LeftKnee = 0, RightKnee = 1, LeftElbow = 2, RightElbow = 3 }
    public enum AvatarTarget { Root = 0, Body = 1, LeftFoot = 2, RightFoot = 3, LeftHand = 4, RightHand = 5 }
    public enum AnimationBlendMode { Blend = 0, Additive = 1 }
    public enum AnimationPlayMode { Stop = 0, Queue = 1, Mix = 2 }
    public enum AnimatorRecorderMode { Offline = 0, Playback = 1, Record = 2 }

    public class Motion : Object
    {
        public virtual float averageDuration => 0f;
        public float averageAngularSpeed => 0f;
        public Vector3 averageSpeed => Vector3.zero;
        public float apparentSpeed => 0f;
        public virtual bool isLooping => false;
        public bool legacy { get; set; }
        public bool isHumanMotion => false;
    }

    public sealed class AnimationEvent
    {
        public string functionName { get; set; } = "";
        public string stringParameter { get; set; } = "";
        public float floatParameter { get; set; }
        public int intParameter { get; set; }
        public Object objectReferenceParameter { get; set; }
        public float time { get; set; }
        public SendMessageOptions messageOptions { get; set; } = SendMessageOptions.RequireReceiver;
        public bool isFiredByLegacy { get; internal set; }
        public bool isFiredByAnimator { get; internal set; }
        public AnimationState animationState { get; internal set; }
        public AnimatorStateInfo animatorStateInfo { get; internal set; }
        public AnimatorClipInfo animatorClipInfo { get; internal set; }
        public AnimationEvent() { }
        internal AnimationEvent Copy() => (AnimationEvent)MemberwiseClone();
    }

    public sealed class AnimationClip : Motion
    {
        // baked transform tracks (imported models): kind 0 localPosition, 1 localRotation, 2 localScale
        internal sealed class Track { public string path; public int kind; public float[] values; }
        // curves set from scripts: a float property of a component (or GameObject.m_IsActive) on the object at path
        internal sealed class FloatCurve { public string path; public Type type; public string property; public AnimationCurve curve; }
        internal readonly List<Track> m_Tracks = new List<Track>();
        internal readonly List<FloatCurve> m_Curves = new List<FloatCurve>();
        internal int m_Frames; internal float m_Fps = 30f;
        float m_Length; bool m_LengthSet;
        internal readonly List<AnimationEvent> m_Events = new List<AnimationEvent>();
        internal int m_Version;
        // imported clips load their keys the first time they're needed
        internal string m_AssetKey; bool m_Loaded = true;
        internal static Func<string, byte[]> s_AssetData;
        internal bool m_Loop;

        public AnimationClip() { m_Name = ""; }
        internal static AnimationClip FromAsset(string key, string name, float length, bool loop)
        {
            var c = new AnimationClip { m_Name = name, m_AssetKey = key, m_Loaded = false, m_Loop = loop, m_IsAsset = true };
            c.m_Length = length; c.m_LengthSet = true;
            return c;
        }
        internal void Load()
        {
            if (m_Loaded) return;
            m_Loaded = true;
            var b = s_AssetData?.Invoke(m_AssetKey);
            if (b == null || b.Length < 16) return;
            var i32 = System.Runtime.InteropServices.MemoryMarshal.Cast<byte, int>(b.AsSpan());
            var f32 = System.Runtime.InteropServices.MemoryMarshal.Cast<byte, float>(b.AsSpan());
            int o = 0;
            m_Frames = i32[o++]; int n = i32[o++]; m_Fps = f32[o++]; m_Length = f32[o++]; m_LengthSet = true;
            for (int t = 0; t < n; t++)
            {
                int kind = i32[o++], plen = i32[o++];
                string path = System.Text.Encoding.UTF8.GetString(b, o * 4, plen); o += (plen + 3) / 4;
                int dim = kind == 1 ? 4 : 3;
                var v = new float[m_Frames * dim];
                for (int k = 0; k < v.Length; k++) v[k] = f32[o++];
                m_Tracks.Add(new Track { path = path, kind = kind, values = v });
            }
        }
        public float length { get { Load(); if (m_LengthSet) return m_Length; float l = 0; foreach (var c in m_Curves) if (c.curve.length > 0) l = Math.Max(l, c.curve[c.curve.length - 1].time); return l; } }
        public float frameRate { get => m_Fps; set => m_Fps = value; }
        public WrapMode wrapMode { get; set; }
        public Bounds localBounds { get; set; }
        public new bool legacy { get => base.legacy; set => base.legacy = value; }
        public bool humanMotion => false;
        public bool empty { get { Load(); return m_Tracks.Count == 0 && m_Curves.Count == 0; } }
        public bool hasGenericRootTransform => false;
        public bool hasMotionFloatCurves => false;
        public bool hasMotionCurves => false;
        public bool hasRootCurves => false;
        public override bool isLooping => m_Loop || wrapMode == WrapMode.Loop;
        public override float averageDuration => length;
        public AnimationEvent[] events
        {
            get { var a = new AnimationEvent[m_Events.Count]; for (int i = 0; i < a.Length; i++) a[i] = m_Events[i].Copy(); return a; }
            set { m_Events.Clear(); if (value != null) foreach (var e in value) m_Events.Add(e.Copy()); m_Events.Sort((a, b) => a.time.CompareTo(b.time)); }
        }
        public void AddEvent(AnimationEvent evt) { if (evt == null) throw new ArgumentNullException(nameof(evt)); m_Events.Add(evt.Copy()); m_Events.Sort((a, b) => a.time.CompareTo(b.time)); }
        public void SetCurve(string relativePath, Type type, string propertyName, AnimationCurve curve)
        {
            if (relativePath == null) throw new ArgumentNullException(nameof(relativePath));
            if (type == null) throw new ArgumentNullException(nameof(type));
            if (propertyName == null) throw new ArgumentNullException(nameof(propertyName));
            Load();
            m_Curves.RemoveAll(c => c.path == relativePath && c.type == type && c.property == propertyName);
            if (curve != null) m_Curves.Add(new FloatCurve { path = relativePath, type = type, property = propertyName, curve = curve });
            m_Version++;
        }
        public void ClearCurves() { Load(); m_Curves.Clear(); m_Tracks.Clear(); m_Version++; }
        public void EnsureQuaternionContinuity() { }
        // poses the GameObject as this clip does at the given time
        public void SampleAnimation(GameObject go, float time)
        {
            if (go == null) throw new ArgumentNullException(nameof(go));
            var b = new PoseBinder(go.transform);
            b.Begin(); b.Add(this, time, 1f); b.Apply(1f, false, null);
        }
        internal float Wrap(float t, WrapMode mode)
        {
            float len = length;
            if (len <= 0) return 0;
            switch (mode)
            {
                case WrapMode.Loop: { float r = t % len; return r < 0 ? r + len : r; }
                case WrapMode.PingPong: { float r = t % (2 * len); if (r < 0) r += 2 * len; return r > len ? 2 * len - r : r; }
                default: return Mathf.Clamp(t, 0, len);
            }
        }
    }

    public class RuntimeAnimatorController : Object
    {
        internal List<AnimationClip> m_Clips = new List<AnimationClip>();
        internal Anvil.ControllerDef m_Def;
        public AnimationClip[] animationClips => m_Clips.ToArray();
    }
    public class AnimatorOverrideController : RuntimeAnimatorController
    {
        RuntimeAnimatorController m_Base;
        internal readonly Dictionary<AnimationClip, AnimationClip> m_Overrides = new Dictionary<AnimationClip, AnimationClip>();
        public AnimatorOverrideController() { }
        public AnimatorOverrideController(RuntimeAnimatorController controller) { runtimeAnimatorController = controller; }
        public RuntimeAnimatorController runtimeAnimatorController
        {
            get => m_Base;
            set { m_Base = value; m_Def = value?.m_Def; m_Clips = value != null ? new List<AnimationClip>(value.m_Clips) : new List<AnimationClip>(); m_Overrides.Clear(); }
        }
        public AnimationClip this[string name]
        {
            get { foreach (var c in m_Clips) if (c.name == name) return m_Overrides.TryGetValue(c, out var o) ? o : c; return null; }
            set { foreach (var c in m_Clips) if (c.name == name) m_Overrides[c] = value; }
        }
        public AnimationClip this[AnimationClip clip]
        {
            get => clip != null && m_Overrides.TryGetValue(clip, out var o) ? o : clip;
            set { if (clip != null) m_Overrides[clip] = value; }
        }
        public int overridesCount => m_Clips.Count;
        public void GetOverrides(List<KeyValuePair<AnimationClip, AnimationClip>> overrides)
        {
            overrides.Clear();
            foreach (var c in m_Clips) overrides.Add(new KeyValuePair<AnimationClip, AnimationClip>(c, m_Overrides.TryGetValue(c, out var o) ? o : null));
        }
        public void ApplyOverrides(IList<KeyValuePair<AnimationClip, AnimationClip>> overrides) { foreach (var kv in overrides) if (kv.Key != null) m_Overrides[kv.Key] = kv.Value; }
        internal AnimationClip Map(AnimationClip c) => c != null && m_Overrides.TryGetValue(c, out var o) && o != null ? o : c;
    }

    public sealed class Avatar : Object
    {
        public bool isValid => false;
        public bool isHuman => false;
    }

    public abstract class StateMachineBehaviour : ScriptableObject
    {
        public virtual void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) { }
        public virtual void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) { }
        public virtual void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) { }
        public virtual void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) { }
        public virtual void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) { }
        public virtual void OnStateMachineEnter(Animator animator, int stateMachinePathHash) { }
        public virtual void OnStateMachineExit(Animator animator, int stateMachinePathHash) { }
    }

    public struct AnimatorStateInfo
    {
        internal int m_FullPath, m_Name, m_Path, m_Tag, m_Loop;
        internal float m_NormalizedTime, m_Length, m_Speed, m_SpeedMultiplier;
        public bool IsName(string name) { int h = Animator.StringToHash(name); return h == m_FullPath || h == m_Name || h == m_Path; }
        public int fullPathHash => m_FullPath;
        public int nameHash => m_Path;
        public int shortNameHash => m_Name;
        public float normalizedTime => m_NormalizedTime;
        public float length => m_Length;
        public float speed => m_Speed;
        public float speedMultiplier => m_SpeedMultiplier;
        public int tagHash => m_Tag;
        public bool IsTag(string tag) => Animator.StringToHash(tag) == m_Tag;
        public bool loop => m_Loop != 0;
    }
    public struct AnimatorTransitionInfo
    {
        internal int m_FullPath, m_Name, m_UserName; internal float m_NormalizedTime, m_Duration; internal bool m_AnyState, m_HasFixedDuration;
        public bool IsName(string name) => Animator.StringToHash(name) == m_Name || Animator.StringToHash(name) == m_FullPath;
        public bool IsUserName(string name) => Animator.StringToHash(name) == m_UserName;
        public int fullPathHash => m_FullPath;
        public int nameHash => m_Name;
        public int userNameHash => m_UserName;
        public DurationUnit durationUnit => m_HasFixedDuration ? DurationUnit.Fixed : DurationUnit.Normalized;
        public float duration => m_Duration;
        public float normalizedTime => m_NormalizedTime;
        public bool anyState => m_AnyState;
    }
    public struct AnimatorClipInfo
    {
        internal AnimationClip m_Clip; internal float m_Weight;
        public AnimationClip clip => m_Clip;
        public float weight => m_Weight;
    }
    public class AnimatorControllerParameter
    {
        internal string m_Name = ""; internal AnimatorControllerParameterType m_Type; internal float m_DefaultFloat; internal int m_DefaultInt; internal bool m_DefaultBool;
        public string name => m_Name;
        public int nameHash => Animator.StringToHash(m_Name);
        public AnimatorControllerParameterType type { get => m_Type; set => m_Type = value; }
        public float defaultFloat { get => m_DefaultFloat; set => m_DefaultFloat = value; }
        public int defaultInt { get => m_DefaultInt; set => m_DefaultInt = value; }
        public bool defaultBool { get => m_DefaultBool; set => m_DefaultBool = value; }
        public override bool Equals(object o) => o is AnimatorControllerParameter p && p.m_Name == m_Name && p.m_Type == m_Type;
        public override int GetHashCode() => m_Name.GetHashCode();
    }

    public class Animator : Behaviour
    {
        RuntimeAnimatorController m_Controller;
        internal Anvil.AnimatorRuntime m_Rt;
        public RuntimeAnimatorController runtimeAnimatorController { get => m_Controller; set { m_Controller = value; m_Rt = null; } }
        public Avatar avatar { get; set; }
        public float speed { get; set; } = 1f;
        public bool applyRootMotion { get; set; }
        public AnimatorUpdateMode updateMode { get; set; }
        public AnimatorCullingMode cullingMode { get; set; }
        public bool animatePhysics { get => updateMode == AnimatorUpdateMode.Fixed; set => updateMode = value ? AnimatorUpdateMode.Fixed : AnimatorUpdateMode.Normal; }
        public bool fireEvents { get; set; } = true;
        public bool keepAnimatorStateOnDisable { get; set; }
        public bool keepAnimatorControllerStateOnDisable { get => keepAnimatorStateOnDisable; set => keepAnimatorStateOnDisable = value; }
        public bool writeDefaultValuesOnDisable { get; set; }
        public bool logWarnings { get; set; } = true;
        public bool stabilizeFeet { get; set; }
        public bool layersAffectMassCenter { get; set; }
        public bool linearVelocityBlending { get; set; }
        public float feetPivotActive { get; set; }
        public bool isHuman => false;
        public bool isOptimizable => false;
        public bool hasRootMotion => false;
        public bool hasTransformHierarchy => true;
        public bool hasBoundPlayables => false;
        public bool isInitialized => m_Rt != null;
        public bool isMatchingTarget => false;
        public float humanScale => 1f;
        public float gravityWeight => 0f;
        public float leftFeetBottomHeight => 0f;
        public float rightFeetBottomHeight => 0f;
        public float pivotWeight => 0.5f;
        public Vector3 pivotPosition => transform.position;
        public Vector3 deltaPosition => Vector3.zero;
        public Quaternion deltaRotation => Quaternion.identity;
        public Vector3 velocity => Vector3.zero;
        public Vector3 angularVelocity => Vector3.zero;
        public Vector3 rootPosition { get => transform.position; set => transform.position = value; }
        public Quaternion rootRotation { get => transform.rotation; set => transform.rotation = value; }
        public Vector3 bodyPosition { get => transform.position; set { } }
        public Quaternion bodyRotation { get => transform.rotation; set { } }
        public Vector3 targetPosition => transform.position;
        public Quaternion targetRotation => transform.rotation;
        public Transform avatarRoot => transform;
        public float playbackTime { get; set; }
        public float recorderStartTime { get; set; }
        public float recorderStopTime { get; set; }
        public AnimatorRecorderMode recorderMode => AnimatorRecorderMode.Offline;

        internal Anvil.AnimatorRuntime Rt
        {
            get
            {
                if (m_Rt == null && m_Controller != null && m_Controller.m_Def != null) m_Rt = new Anvil.AnimatorRuntime(this, m_Controller);
                return m_Rt;
            }
        }
        internal override void OnAddedInternal() { AnimationSystem.animators.Add(this); }
        internal override void OnRemovedInternal() { AnimationSystem.animators.Remove(this); }

        // ---- hashes (CRC32, like Unity) ----
        static readonly uint[] s_Crc = MakeCrc();
        static uint[] MakeCrc() { var t = new uint[256]; for (uint n = 0; n < 256; n++) { uint c = n; for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? 0xEDB88320u ^ (c >> 1) : c >> 1; t[n] = c; } return t; }
        public static int StringToHash(string name)
        {
            if (name == null) return 0;
            uint c = 0xFFFFFFFFu;
            foreach (var b in System.Text.Encoding.UTF8.GetBytes(name)) c = s_Crc[(c ^ b) & 0xFF] ^ (c >> 8);
            return unchecked((int)(c ^ 0xFFFFFFFFu));
        }

        // ---- parameters ----
        public AnimatorControllerParameter[] parameters => Rt?.ParametersArray() ?? Array.Empty<AnimatorControllerParameter>();
        public int parameterCount => Rt?.paramList.Count ?? 0;
        public AnimatorControllerParameter GetParameter(int index) { var p = parameters; if (index < 0 || index >= p.Length) throw new IndexOutOfRangeException("Index must be between 0 and " + p.Length); return p[index]; }
        public float GetFloat(string name) => Rt?.GetFloat(StringToHash(name), name) ?? 0f;
        public float GetFloat(int id) => Rt?.GetFloat(id, null) ?? 0f;
        public void SetFloat(string name, float value) => Rt?.SetFloat(StringToHash(name), name, value);
        public void SetFloat(int id, float value) => Rt?.SetFloat(id, null, value);
        public void SetFloat(string name, float value, float dampTime, float deltaTime) => SetFloat(StringToHash(name), name, value, dampTime, deltaTime);
        public void SetFloat(int id, float value, float dampTime, float deltaTime) => SetFloat(id, null, value, dampTime, deltaTime);
        void SetFloat(int id, string name, float value, float dampTime, float deltaTime)
        {
            var rt = Rt; if (rt == null) return;
            float cur = rt.GetFloat(id, name);
            float k = dampTime > 0 ? 1f - Mathf.Exp(-deltaTime / Math.Max(1e-5f, dampTime * 0.5f)) : 1f;
            rt.SetFloat(id, name, cur + (value - cur) * k);
        }
        public bool GetBool(string name) => Rt?.GetBool(StringToHash(name), name) ?? false;
        public bool GetBool(int id) => Rt?.GetBool(id, null) ?? false;
        public void SetBool(string name, bool value) => Rt?.SetBool(StringToHash(name), name, value);
        public void SetBool(int id, bool value) => Rt?.SetBool(id, null, value);
        public int GetInteger(string name) => Rt?.GetInt(StringToHash(name), name) ?? 0;
        public int GetInteger(int id) => Rt?.GetInt(id, null) ?? 0;
        public void SetInteger(string name, int value) => Rt?.SetInt(StringToHash(name), name, value);
        public void SetInteger(int id, int value) => Rt?.SetInt(id, null, value);
        public void SetTrigger(string name) => Rt?.SetTrigger(StringToHash(name), name, true);
        public void SetTrigger(int id) => Rt?.SetTrigger(id, null, true);
        public void ResetTrigger(string name) => Rt?.SetTrigger(StringToHash(name), name, false);
        public void ResetTrigger(int id) => Rt?.SetTrigger(id, null, false);
        public bool IsParameterControlledByCurve(string name) => false;
        public bool IsParameterControlledByCurve(int id) => false;
        public Vector3 GetVector(string name) => Vector3.zero;
        public Vector3 GetVector(int id) => Vector3.zero;
        public void SetVector(string name, Vector3 value) { }
        public void SetVector(int id, Vector3 value) { }
        public Quaternion GetQuaternion(string name) => Quaternion.identity;
        public Quaternion GetQuaternion(int id) => Quaternion.identity;
        public void SetQuaternion(string name, Quaternion value) { }
        public void SetQuaternion(int id, Quaternion value) { }

        // ---- layers and states ----
        public int layerCount => Rt?.layers.Length ?? 0;
        public string GetLayerName(int layerIndex) => Rt != null && layerIndex >= 0 && layerIndex < Rt.layers.Length ? Rt.layers[layerIndex].def.name : null;
        public int GetLayerIndex(string layerName) { var rt = Rt; if (rt == null) return -1; for (int i = 0; i < rt.layers.Length; i++) if (rt.layers[i].def.name == layerName) return i; return -1; }
        public float GetLayerWeight(int layerIndex) => Rt != null && layerIndex >= 0 && layerIndex < Rt.layers.Length ? (layerIndex == 0 ? 1f : Rt.layers[layerIndex].weight) : 0f;
        public void SetLayerWeight(int layerIndex, float weight) { var rt = Rt; if (rt != null && layerIndex > 0 && layerIndex < rt.layers.Length) rt.layers[layerIndex].weight = Mathf.Clamp01(weight); }
        public AnimatorStateInfo GetCurrentAnimatorStateInfo(int layerIndex) => Rt?.StateInfo(layerIndex, false) ?? default;
        public AnimatorStateInfo GetNextAnimatorStateInfo(int layerIndex) => Rt?.StateInfo(layerIndex, true) ?? default;
        public AnimatorTransitionInfo GetAnimatorTransitionInfo(int layerIndex) => Rt?.TransitionInfo(layerIndex) ?? default;
        public bool IsInTransition(int layerIndex) => Rt != null && layerIndex >= 0 && layerIndex < Rt.layers.Length && Rt.layers[layerIndex].next != null;
        public AnimatorClipInfo[] GetCurrentAnimatorClipInfo(int layerIndex) => Rt?.ClipInfo(layerIndex, false) ?? Array.Empty<AnimatorClipInfo>();
        public AnimatorClipInfo[] GetNextAnimatorClipInfo(int layerIndex) => Rt?.ClipInfo(layerIndex, true) ?? Array.Empty<AnimatorClipInfo>();
        public void GetCurrentAnimatorClipInfo(int layerIndex, List<AnimatorClipInfo> clips) { clips.Clear(); clips.AddRange(GetCurrentAnimatorClipInfo(layerIndex)); }
        public void GetNextAnimatorClipInfo(int layerIndex, List<AnimatorClipInfo> clips) { clips.Clear(); clips.AddRange(GetNextAnimatorClipInfo(layerIndex)); }
        public int GetCurrentAnimatorClipInfoCount(int layerIndex) => GetCurrentAnimatorClipInfo(layerIndex).Length;
        public int GetNextAnimatorClipInfoCount(int layerIndex) => GetNextAnimatorClipInfo(layerIndex).Length;
        public bool HasState(int layerIndex, int stateID) => Rt != null && layerIndex >= 0 && layerIndex < Rt.layers.Length && Rt.layers[layerIndex].Find(stateID) != null;

        public void Play(string stateName) => Play(stateName, -1, float.NegativeInfinity);
        public void Play(string stateName, int layer) => Play(stateName, layer, float.NegativeInfinity);
        public void Play(string stateName, int layer, float normalizedTime) => Rt?.Play(StringToHash(stateName), stateName, layer, normalizedTime, false);
        public void Play(int stateNameHash) => Play(stateNameHash, -1, float.NegativeInfinity);
        public void Play(int stateNameHash, int layer) => Play(stateNameHash, layer, float.NegativeInfinity);
        public void Play(int stateNameHash, int layer, float normalizedTime) => Rt?.Play(stateNameHash, null, layer, normalizedTime, false);
        public void PlayInFixedTime(string stateName) => PlayInFixedTime(stateName, -1, float.NegativeInfinity);
        public void PlayInFixedTime(string stateName, int layer) => PlayInFixedTime(stateName, layer, float.NegativeInfinity);
        public void PlayInFixedTime(string stateName, int layer, float fixedTime) => Rt?.Play(StringToHash(stateName), stateName, layer, fixedTime, true);
        public void PlayInFixedTime(int stateNameHash) => PlayInFixedTime(stateNameHash, -1, float.NegativeInfinity);
        public void PlayInFixedTime(int stateNameHash, int layer) => PlayInFixedTime(stateNameHash, layer, float.NegativeInfinity);
        public void PlayInFixedTime(int stateNameHash, int layer, float fixedTime) => Rt?.Play(stateNameHash, null, layer, fixedTime, true);
        public void CrossFade(string stateName, float normalizedTransitionDuration) => CrossFade(stateName, normalizedTransitionDuration, -1, float.NegativeInfinity, 0f);
        public void CrossFade(string stateName, float normalizedTransitionDuration, int layer) => CrossFade(stateName, normalizedTransitionDuration, layer, float.NegativeInfinity, 0f);
        public void CrossFade(string stateName, float normalizedTransitionDuration, int layer, float normalizedTimeOffset) => CrossFade(stateName, normalizedTransitionDuration, layer, normalizedTimeOffset, 0f);
        public void CrossFade(string stateName, float normalizedTransitionDuration, int layer, float normalizedTimeOffset, float normalizedTransitionTime) => Rt?.CrossFade(StringToHash(stateName), stateName, normalizedTransitionDuration, layer, normalizedTimeOffset, false);
        public void CrossFade(int stateHashName, float normalizedTransitionDuration) => CrossFade(stateHashName, normalizedTransitionDuration, -1, float.NegativeInfinity, 0f);
        public void CrossFade(int stateHashName, float normalizedTransitionDuration, int layer) => CrossFade(stateHashName, normalizedTransitionDuration, layer, float.NegativeInfinity, 0f);
        public void CrossFade(int stateHashName, float normalizedTransitionDuration, int layer, float normalizedTimeOffset) => CrossFade(stateHashName, normalizedTransitionDuration, layer, normalizedTimeOffset, 0f);
        public void CrossFade(int stateHashName, float normalizedTransitionDuration, int layer, float normalizedTimeOffset, float normalizedTransitionTime) => Rt?.CrossFade(stateHashName, null, normalizedTransitionDuration, layer, normalizedTimeOffset, false);
        public void CrossFadeInFixedTime(string stateName, float fixedTransitionDuration) => CrossFadeInFixedTime(stateName, fixedTransitionDuration, -1, 0f, 0f);
        public void CrossFadeInFixedTime(string stateName, float fixedTransitionDuration, int layer) => CrossFadeInFixedTime(stateName, fixedTransitionDuration, layer, 0f, 0f);
        public void CrossFadeInFixedTime(string stateName, float fixedTransitionDuration, int layer, float fixedTimeOffset) => CrossFadeInFixedTime(stateName, fixedTransitionDuration, layer, fixedTimeOffset, 0f);
        public void CrossFadeInFixedTime(string stateName, float fixedTransitionDuration, int layer, float fixedTimeOffset, float normalizedTransitionTime) => Rt?.CrossFade(StringToHash(stateName), stateName, fixedTransitionDuration, layer, fixedTimeOffset, true);
        public void CrossFadeInFixedTime(int stateHashName, float fixedTransitionDuration) => CrossFadeInFixedTime(stateHashName, fixedTransitionDuration, -1, 0f, 0f);
        public void CrossFadeInFixedTime(int stateHashName, float fixedTransitionDuration, int layer) => CrossFadeInFixedTime(stateHashName, fixedTransitionDuration, layer, 0f, 0f);
        public void CrossFadeInFixedTime(int stateHashName, float fixedTransitionDuration, int layer, float fixedTimeOffset) => CrossFadeInFixedTime(stateHashName, fixedTransitionDuration, layer, fixedTimeOffset, 0f);
        public void CrossFadeInFixedTime(int stateHashName, float fixedTransitionDuration, int layer, float fixedTimeOffset, float normalizedTransitionTime) => Rt?.CrossFade(stateHashName, null, fixedTransitionDuration, layer, fixedTimeOffset, true);
        public void ForceStateNormalizedTime(float normalizedTime) => Play(0, 0, normalizedTime);
        // evaluates the animator now (deltaTime in seconds), like Unity's manual update
        public void Update(float deltaTime) { var rt = Rt; if (rt != null) rt.Tick(deltaTime); }
        public void Rebind() { m_Rt = null; }
        public void Rebind(bool writeDefaultValues) { if (writeDefaultValues) m_Rt?.WriteDefaults(); m_Rt = null; }
        public void WriteDefaultValues() { m_Rt?.WriteDefaults(); }
        public void ApplyBuiltinRootMotion() { }
        public void StartPlayback() { }
        public void StopPlayback() { }
        public void StartRecording(int frameCount) { }
        public void StopRecording() { }
        public bool IsControlled(Transform transform) => false;
        public Transform GetBoneTransform(HumanBodyBones humanBoneId) => null;
        public void SetIKPosition(AvatarIKGoal goal, Vector3 goalPosition) { }
        public Vector3 GetIKPosition(AvatarIKGoal goal) => Vector3.zero;
        public void SetIKRotation(AvatarIKGoal goal, Quaternion goalRotation) { }
        public Quaternion GetIKRotation(AvatarIKGoal goal) => Quaternion.identity;
        public void SetIKPositionWeight(AvatarIKGoal goal, float value) { }
        public float GetIKPositionWeight(AvatarIKGoal goal) => 0f;
        public void SetIKRotationWeight(AvatarIKGoal goal, float value) { }
        public float GetIKRotationWeight(AvatarIKGoal goal) => 0f;
        public void SetIKHintPosition(AvatarIKHint hint, Vector3 hintPosition) { }
        public Vector3 GetIKHintPosition(AvatarIKHint hint) => Vector3.zero;
        public void SetIKHintPositionWeight(AvatarIKHint hint, float value) { }
        public float GetIKHintPositionWeight(AvatarIKHint hint) => 0f;
        public void SetLookAtPosition(Vector3 lookAtPosition) { }
        public void SetLookAtWeight(float weight) { }
        public void SetLookAtWeight(float weight, float bodyWeight) { }
        public void SetLookAtWeight(float weight, float bodyWeight, float headWeight) { }
        public void SetLookAtWeight(float weight, float bodyWeight, float headWeight, float eyesWeight) { }
        public void SetLookAtWeight(float weight, float bodyWeight, float headWeight, float eyesWeight, float clampWeight) { }
        public void SetBoneLocalRotation(HumanBodyBones humanBoneId, Quaternion rotation) { }
        public T GetBehaviour<T>() where T : StateMachineBehaviour { var rt = Rt; if (rt != null) foreach (var b in rt.AllBehaviours()) if (b is T t) return t; return null; }
        public T[] GetBehaviours<T>() where T : StateMachineBehaviour { var l = new List<T>(); var rt = Rt; if (rt != null) foreach (var b in rt.AllBehaviours()) if (b is T t) l.Add(t); return l.ToArray(); }
        public StateMachineBehaviour[] GetBehaviours(int fullPathHash, int layerIndex) { var rt = Rt; if (rt == null || layerIndex < 0 || layerIndex >= rt.layers.Length) return Array.Empty<StateMachineBehaviour>(); var s = rt.layers[layerIndex].Find(fullPathHash); return s != null ? s.behaviours.ToArray() : Array.Empty<StateMachineBehaviour>(); }
        public void MatchTarget(Vector3 matchPosition, Quaternion matchRotation, AvatarTarget targetBodyPart, MatchTargetWeightMask weightMask, float startNormalizedTime) { }
        public void MatchTarget(Vector3 matchPosition, Quaternion matchRotation, AvatarTarget targetBodyPart, MatchTargetWeightMask weightMask, float startNormalizedTime, float targetNormalizedTime) { }
        public void MatchTarget(Vector3 matchPosition, Quaternion matchRotation, AvatarTarget targetBodyPart, MatchTargetWeightMask weightMask, float startNormalizedTime, float targetNormalizedTime, bool completeMatch) { }
        public void InterruptMatchTarget() { }
        public void InterruptMatchTarget(bool completeMatch) { }
        internal void OnEnabledChanged(bool on)
        {
            if (!on && writeDefaultValuesOnDisable) m_Rt?.WriteDefaults();
            if (!on && !keepAnimatorStateOnDisable) m_Rt = null;
        }
    }
    public struct MatchTargetWeightMask
    {
        public MatchTargetWeightMask(Vector3 positionXYZWeight, float rotationWeight) { this.positionXYZWeight = positionXYZWeight; this.rotationWeight = rotationWeight; }
        public Vector3 positionXYZWeight { get; set; }
        public float rotationWeight { get; set; }
    }

    public class TrackedReference
    {
        public static implicit operator bool(TrackedReference exists) => exists != null;
    }
    public sealed class AnimationState : TrackedReference
    {
        internal Animation m_Owner; internal AnimationClip m_Clip; internal string m_Name;
        internal float m_Time, m_Weight, m_Speed = 1f, m_TargetWeight, m_FadeSpeed; internal bool m_Enabled, m_StopWhenFaded;
        internal float m_LastTime;
        public bool enabled { get => m_Enabled; set { m_Enabled = value; } }
        public float weight { get => m_Weight; set { m_Weight = value; m_TargetWeight = value; m_FadeSpeed = 0; } }
        public WrapMode wrapMode { get; set; }
        public float time { get => m_Time; set { m_Time = value; m_LastTime = value; } }
        public float normalizedTime { get => length > 0 ? m_Time / length : 0f; set => time = value * length; }
        public float speed { get => m_Speed; set => m_Speed = value; }
        public float normalizedSpeed { get => length > 0 ? m_Speed / length : 0f; set => m_Speed = value * length; }
        public float length => m_Clip != null ? m_Clip.length : 0f;
        public int layer { get; set; }
        public AnimationClip clip => m_Clip;
        public string name { get => m_Name; set => m_Name = value; }
        public AnimationBlendMode blendMode { get; set; }
        public void AddMixingTransform(Transform mix) { }
        public void AddMixingTransform(Transform mix, bool recursive) { }
        public void RemoveMixingTransform(Transform mix) { }
        internal WrapMode EffectiveWrap => wrapMode != WrapMode.Default ? wrapMode : m_Owner != null && m_Owner.wrapMode != WrapMode.Default ? m_Owner.wrapMode : m_Clip != null && m_Clip.wrapMode != WrapMode.Default ? m_Clip.wrapMode : WrapMode.Once;
    }

    public sealed class Animation : Behaviour, IEnumerable
    {
        internal readonly List<AnimationState> m_States = new List<AnimationState>();
        AnimationClip m_Clip;
        internal Anvil.PoseBinder m_Binder;
        internal bool m_AutoPlayed;
        public AnimationClip clip { get => m_Clip; set { m_Clip = value; if (value != null && GetState(value.name) == null) AddClip(value, value.name); } }
        public bool playAutomatically { get; set; } = true;
        public WrapMode wrapMode { get; set; }
        public bool animatePhysics { get; set; }
        public AnimationUpdateMode updateMode { get; set; }
        public bool animateOnlyIfVisible { get; set; } = true;
        public AnimationCullingType cullingType { get; set; }
        public Bounds localBounds { get; set; }
        internal override void OnAddedInternal() { AnimationSystem.animations.Add(this); }
        internal override void OnRemovedInternal() { AnimationSystem.animations.Remove(this); }
        internal AnimationState GetState(string name) { foreach (var s in m_States) if (s.m_Name == name) return s; return null; }
        public AnimationState this[string name] => GetState(name);
        public AnimationClip GetClip(string name) => GetState(name)?.m_Clip;
        public int GetClipCount() => m_States.Count;
        public bool isPlaying { get { foreach (var s in m_States) if (s.m_Enabled) return true; return false; } }
        public bool IsPlaying(string name) { var s = GetState(name); return s != null && s.m_Enabled; }
        public void AddClip(AnimationClip clip, string newName) => AddClip(clip, newName, int.MinValue, int.MaxValue, false);
        public void AddClip(AnimationClip clip, string newName, int firstFrame, int lastFrame) => AddClip(clip, newName, firstFrame, lastFrame, false);
        public void AddClip(AnimationClip clip, string newName, int firstFrame, int lastFrame, bool addLoopFrame)
        {
            if (clip == null) throw new ArgumentNullException(nameof(clip));
            var s = GetState(newName);
            if (s == null) { s = new AnimationState { m_Owner = this, m_Name = newName }; m_States.Add(s); }
            s.m_Clip = clip; m_Binder = null;
        }
        public void RemoveClip(AnimationClip clip) { m_States.RemoveAll(s => s.m_Clip == clip); m_Binder = null; }
        public void RemoveClip(string clipName) { m_States.RemoveAll(s => s.m_Name == clipName); m_Binder = null; }
        public bool Play() => Play(PlayMode.StopSameLayer);
        public bool Play(PlayMode mode) { if (m_Clip == null) return false; return Play(m_Clip.name, mode); }
        public bool Play(string animation) => Play(animation, PlayMode.StopSameLayer);
        public bool Play(string animation, PlayMode mode)
        {
            var s = GetState(animation);
            if (s == null) { Debug.LogWarning($"The animation state {animation} could not be played because it couldn't be found!\nPlease attach an animation clip with the name '{animation}' or call this function only for existing animations.", this); return false; }
            foreach (var o in m_States) if (o != s && (mode == PlayMode.StopAll || o.layer == s.layer)) { o.m_Enabled = false; o.m_Weight = 0; o.time = 0; }
            if (!s.m_Enabled) s.time = 0;
            s.m_Enabled = true; s.m_Weight = 1; s.m_TargetWeight = 1; s.m_FadeSpeed = 0; s.m_StopWhenFaded = false;
            return true;
        }
        public bool Play(AnimationPlayMode mode) => Play((PlayMode)mode);
        public bool Play(string animation, AnimationPlayMode mode) => Play(animation, (PlayMode)mode);
        public void CrossFade(string animation) => CrossFade(animation, 0.3f, PlayMode.StopSameLayer);
        public void CrossFade(string animation, float fadeLength) => CrossFade(animation, fadeLength, PlayMode.StopSameLayer);
        public void CrossFade(string animation, float fadeLength, PlayMode mode)
        {
            var s = GetState(animation); if (s == null) { Debug.LogWarning($"The animation state {animation} could not be played because it couldn't be found!", this); return; }
            float rate = fadeLength > 0 ? 1f / fadeLength : 1e6f;
            foreach (var o in m_States) if (o != s && (mode == PlayMode.StopAll || o.layer == s.layer) && o.m_Enabled) { o.m_TargetWeight = 0; o.m_FadeSpeed = rate; o.m_StopWhenFaded = true; }
            if (!s.m_Enabled) { s.time = 0; s.m_Weight = 0; }
            s.m_Enabled = true; s.m_TargetWeight = 1; s.m_FadeSpeed = rate; s.m_StopWhenFaded = false;
        }
        public void Blend(string animation) => Blend(animation, 1f, 0.3f);
        public void Blend(string animation, float targetWeight) => Blend(animation, targetWeight, 0.3f);
        public void Blend(string animation, float targetWeight, float fadeLength)
        {
            var s = GetState(animation); if (s == null) return;
            if (!s.m_Enabled) { s.m_Enabled = true; s.m_Weight = 0; }
            s.m_TargetWeight = targetWeight; s.m_FadeSpeed = fadeLength > 0 ? Math.Abs(targetWeight - s.m_Weight) / fadeLength : 1e6f; s.m_StopWhenFaded = false;
        }
        public AnimationState CrossFadeQueued(string animation) => CrossFadeQueued(animation, 0.3f, QueueMode.CompleteOthers, PlayMode.StopSameLayer);
        public AnimationState CrossFadeQueued(string animation, float fadeLength) => CrossFadeQueued(animation, fadeLength, QueueMode.CompleteOthers, PlayMode.StopSameLayer);
        public AnimationState CrossFadeQueued(string animation, float fadeLength, QueueMode queue) => CrossFadeQueued(animation, fadeLength, queue, PlayMode.StopSameLayer);
        public AnimationState CrossFadeQueued(string animation, float fadeLength, QueueMode queue, PlayMode mode) { CrossFade(animation, fadeLength, mode); return GetState(animation); }
        public AnimationState PlayQueued(string animation) => PlayQueued(animation, QueueMode.CompleteOthers, PlayMode.StopSameLayer);
        public AnimationState PlayQueued(string animation, QueueMode queue) => PlayQueued(animation, queue, PlayMode.StopSameLayer);
        public AnimationState PlayQueued(string animation, QueueMode queue, PlayMode mode) { Play(animation, mode); return GetState(animation); }
        public void Stop() { foreach (var s in m_States) { s.m_Enabled = false; s.time = 0; s.m_Weight = 0; } }
        public void Stop(string name) { var s = GetState(name); if (s != null) { s.m_Enabled = false; s.time = 0; s.m_Weight = 0; } }
        public void Rewind() { foreach (var s in m_States) s.time = 0; }
        public void Rewind(string name) { var s = GetState(name); if (s != null) s.time = 0; }
        public void Sample() { AnimationSystem.SampleLegacy(this, 0f); }
        public void SyncLayer(int layer) { }
        public IEnumerator GetEnumerator() => m_States.GetEnumerator();
    }
}

namespace Anvil
{
    using UnityEngine;

    // ---------------- controller definition (from the .controller asset JSON) ----------------
    internal sealed class ControllerDef
    {
        internal sealed class Param { public string name; public AnimatorControllerParameterType type; public float f; public int i; public bool b; }
        internal sealed class Condition { public string param; public int mode; public float threshold; } // mode: 1 If, 2 IfNot, 3 Greater, 4 Less, 6 Equals, 7 NotEqual (UnityEditor.Animations.AnimatorConditionMode)
        internal sealed class Transition { public string to; public bool exit; public bool hasExitTime; public float exitTime = 0.75f; public bool fixedDuration = true; public float duration = 0.25f; public float offset; public bool canTransitionToSelf = true; public List<Condition> conditions = new List<Condition>(); public string name; }
        internal sealed class Child { public string motion; public float threshold; public float timeScale = 1f; }
        internal sealed class State
        {
            public string name, tag = "", motion, speedParam, blendParam; public float speed = 1f, cycleOffset; public bool blendTree;
            public List<Child> children = new List<Child>(); public List<Transition> transitions = new List<Transition>(); public List<string> behaviours = new List<string>();
        }
        internal sealed class Layer { public string name = "Base Layer"; public float weight = 1f; public bool additive; public string defaultState; public List<State> states = new List<State>(); public List<Transition> anyState = new List<Transition>(); }
        public readonly List<Param> parameters = new List<Param>();
        public readonly List<Layer> layers = new List<Layer>();

        static string S(JsonElement e, string k) => e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;
        static float F(JsonElement e, string k, float d) => e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Number ? (float)v.GetDouble() : d;
        static bool B(JsonElement e, string k, bool d) => e.TryGetProperty(k, out var v) ? v.ValueKind == JsonValueKind.True ? true : v.ValueKind == JsonValueKind.False ? false : d : d;
        static IEnumerable<JsonElement> A(JsonElement e, string k) { if (e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Array) foreach (var x in v.EnumerateArray()) yield return x; }
        static Transition T(JsonElement t)
        {
            var tr = new Transition { to = S(t, "to"), exit = B(t, "exit", false), hasExitTime = B(t, "hasExitTime", false), exitTime = F(t, "exitTime", 0.75f), fixedDuration = B(t, "fixedDuration", true), duration = F(t, "duration", 0.25f), offset = F(t, "offset", 0f), canTransitionToSelf = B(t, "canTransitionToSelf", true), name = S(t, "name") };
            foreach (var c in A(t, "conditions"))
            {
                string m = S(c, "mode") ?? "If";
                int mode = m == "If" ? 1 : m == "IfNot" ? 2 : m == "Greater" ? 3 : m == "Less" ? 4 : m == "Equals" ? 6 : m == "NotEqual" ? 7 : 1;
                tr.conditions.Add(new Condition { param = S(c, "param"), mode = mode, threshold = F(c, "threshold", 0f) });
            }
            return tr;
        }
        internal static ControllerDef Parse(JsonElement root)
        {
            var d = new ControllerDef();
            foreach (var p in A(root, "parameters"))
            {
                string t = S(p, "type") ?? "Float";
                var type = t == "Int" ? AnimatorControllerParameterType.Int : t == "Bool" ? AnimatorControllerParameterType.Bool : t == "Trigger" ? AnimatorControllerParameterType.Trigger : AnimatorControllerParameterType.Float;
                var prm = new Param { name = S(p, "name") ?? "", type = type };
                if (p.TryGetProperty("default", out var dv))
                {
                    if (dv.ValueKind == JsonValueKind.Number) { prm.f = (float)dv.GetDouble(); prm.i = (int)Math.Round(dv.GetDouble()); }
                    else if (dv.ValueKind == JsonValueKind.True) prm.b = true;
                }
                d.parameters.Add(prm);
            }
            foreach (var l in A(root, "layers"))
            {
                var layer = new Layer { name = S(l, "name") ?? "Base Layer", weight = F(l, "weight", 1f), additive = S(l, "blending") == "Additive", defaultState = S(l, "defaultState") };
                foreach (var s in A(l, "states"))
                {
                    var st = new State { name = S(s, "name") ?? "State", tag = S(s, "tag") ?? "", motion = S(s, "motion"), speed = F(s, "speed", 1f), speedParam = S(s, "speedParam"), cycleOffset = F(s, "cycleOffset", 0f) };
                    if (s.TryGetProperty("blendTree", out var bt) && bt.ValueKind == JsonValueKind.Object)
                    {
                        st.blendTree = true; st.blendParam = S(bt, "param");
                        foreach (var c in A(bt, "children")) st.children.Add(new Child { motion = S(c, "motion"), threshold = F(c, "threshold", 0f), timeScale = F(c, "timeScale", 1f) });
                        st.children.Sort((a, b) => a.threshold.CompareTo(b.threshold));
                    }
                    foreach (var t in A(s, "transitions")) st.transitions.Add(T(t));
                    foreach (var b in A(s, "behaviours")) if (b.ValueKind == JsonValueKind.String) st.behaviours.Add(b.GetString());
                    layer.states.Add(st);
                }
                foreach (var t in A(l, "anyState")) layer.anyState.Add(T(t));
                d.layers.Add(layer);
            }
            if (d.layers.Count == 0) d.layers.Add(new Layer());
            return d;
        }
    }

    // ---------------- pose blending: binds clip curves to the objects under a root ----------------
    internal sealed class PoseBinder
    {
        // a property that clips write: kind 0 position, 1 rotation, 2 scale, 3 euler (from float curves), 4 float member, 5 active
        sealed class Target
        {
            public Transform t; public int kind; public object obj; public MemberInfo member; public string sub; public int comp = -1;
            public Vector4 def; public Vector4 acc; public float w; public Vector4 layerAcc; public float layerW; public Vector4 result; public bool touched;
        }
        readonly Transform m_Root;
        readonly Dictionary<string, Target> m_Targets = new Dictionary<string, Target>();
        readonly List<Target> m_List = new List<Target>();
        readonly Dictionary<AnimationClip, (int version, List<(Target target, int track, List<(int comp, int curve)> curves)> map)> m_ClipMaps = new Dictionary<AnimationClip, (int, List<(Target, int, List<(int, int)>)>)>();
        internal PoseBinder(Transform root) { m_Root = root; }

        Target Get(string path, int kind, Type type, string prop, int comp)
        {
            string key = path + "|" + kind + "|" + type?.Name + "|" + prop;
            if (m_Targets.TryGetValue(key, out var tg)) return tg;
            var t = string.IsNullOrEmpty(path) ? m_Root : m_Root.Find(path);
            if (t == null) { m_Targets[key] = null; return null; }
            tg = new Target { t = t, kind = kind };
            if (kind == 4)
            {
                var c = type == typeof(GameObject) ? (object)t.gameObject : t.GetComponent(type);
                if (c == null) { m_Targets[key] = null; return null; }
                // "intensity", "m_Color.r", "color.r", "someField"
                string name = prop, sub = null;
                int dot = prop.IndexOf('.'); if (dot > 0) { name = prop.Substring(0, dot); sub = prop.Substring(dot + 1); }
                if (name.StartsWith("m_") && name.Length > 2) name = char.ToLowerInvariant(name[2]) + name.Substring(3);
                var ct = c.GetType();
                MemberInfo mi = ct.GetProperty(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic) ?? (MemberInfo)ct.GetField(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                    ?? ct.GetField("m_" + char.ToUpperInvariant(name[0]) + name.Substring(1), BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (mi == null) { Debug.LogWarning($"Animation: {ct.Name} has no property '{prop}' (path '{path}')"); m_Targets[key] = null; return null; }
                tg.obj = c; tg.member = mi; tg.sub = sub;
            }
            tg.def = Read(tg);
            m_Targets[key] = tg; m_List.Add(tg);
            return tg;
        }
        static object GetM(Target t) => t.member is PropertyInfo p ? p.GetValue(t.obj) : ((FieldInfo)t.member).GetValue(t.obj);
        static void SetM(Target t, object v) { if (t.member is PropertyInfo p) { if (p.CanWrite) p.SetValue(t.obj, v); } else ((FieldInfo)t.member).SetValue(t.obj, v); }
        static float Comp(object v, string sub)
        {
            switch (v)
            {
                case float f: return f;
                case double d: return (float)d;
                case int i: return i;
                case bool b: return b ? 1 : 0;
                case Vector2 v2: return sub == "y" ? v2.y : v2.x;
                case Vector3 v3: return sub == "y" ? v3.y : sub == "z" ? v3.z : v3.x;
                case Vector4 v4: return sub == "y" ? v4.y : sub == "z" ? v4.z : sub == "w" ? v4.w : v4.x;
                case Color c: return sub == "g" ? c.g : sub == "b" ? c.b : sub == "a" ? c.a : c.r;
            }
            return 0;
        }
        static object WithComp(object v, string sub, float x)
        {
            switch (v)
            {
                case float _: return x;
                case double _: return (double)x;
                case int _: return (int)Math.Round(x);
                case bool _: return x > 0.5f;
                case Vector2 v2: if (sub == "y") v2.y = x; else v2.x = x; return v2;
                case Vector3 v3: if (sub == "y") v3.y = x; else if (sub == "z") v3.z = x; else v3.x = x; return v3;
                case Vector4 v4: if (sub == "y") v4.y = x; else if (sub == "z") v4.z = x; else if (sub == "w") v4.w = x; else v4.x = x; return v4;
                case Color c: if (sub == "g") c.g = x; else if (sub == "b") c.b = x; else if (sub == "a") c.a = x; else c.r = x; return c;
            }
            return v;
        }
        static Vector4 Read(Target t)
        {
            switch (t.kind)
            {
                case 0: { var p = t.t.localPosition; return new Vector4(p.x, p.y, p.z, 0); }
                case 1: { var q = t.t.localRotation; return new Vector4(q.x, q.y, q.z, q.w); }
                case 2: { var s = t.t.localScale; return new Vector4(s.x, s.y, s.z, 0); }
                case 3: { var e = t.t.localEulerAngles; return new Vector4(e.x, e.y, e.z, 0); }
                case 5: return new Vector4(t.t.gameObject.activeSelf ? 1 : 0, 0, 0, 0);
                default: return new Vector4(Comp(GetM(t), t.sub), 0, 0, 0);
            }
        }
        List<(Target, int, List<(int, int)>)> Map(AnimationClip clip)
        {
            clip.Load();
            if (m_ClipMaps.TryGetValue(clip, out var e) && e.version == clip.m_Version) return e.map;
            var map = new List<(Target, int, List<(int, int)>)>();
            for (int i = 0; i < clip.m_Tracks.Count; i++)
            {
                var tr = clip.m_Tracks[i];
                var tg = Get(tr.path, tr.kind, null, null, -1);
                if (tg != null) map.Add((tg, i, null));
            }
            // float curves: one entry per target, with the components its curves set
            var groups = new Dictionary<Target, List<(int, int)>>();
            for (int i = 0; i < clip.m_Curves.Count; i++)
            {
                var c = clip.m_Curves[i];
                string p = c.property;
                Target tg = null; int comp = 0;
                string axis = p.Length > 2 && p[p.Length - 2] == '.' ? p.Substring(p.Length - 1) : null;
                string head = axis != null ? p.Substring(0, p.Length - 2) : p;
                if (c.type == typeof(Transform))
                {
                    int kind = head == "localPosition" || head == "m_LocalPosition" ? 0 : head == "localRotation" || head == "m_LocalRotation" ? 1 : head == "localScale" || head == "m_LocalScale" ? 2
                        : head == "localEulerAngles" || head == "localEulerAnglesRaw" || head == "localEulerAnglesBaked" || head == "m_LocalEulerAngles" ? 3 : -1;
                    comp = axis == "x" ? 0 : axis == "y" ? 1 : axis == "z" ? 2 : axis == "w" ? 3 : -1;
                    if (kind < 0 || comp < 0) { Debug.LogWarning($"Animation: unsupported Transform property '{p}'"); continue; }
                    tg = Get(c.path, kind, null, null, -1);
                }
                else if (c.type == typeof(GameObject) && (p == "m_IsActive" || p == "isActive" || p == "active")) tg = Get(c.path, 5, null, null, -1);
                else tg = Get(c.path, 4, c.type, p, -1);
                if (tg == null) continue;
                if (!groups.TryGetValue(tg, out var list)) { groups[tg] = list = new List<(int, int)>(); map.Add((tg, -1, list)); }
                list.Add((comp, i));
            }
            m_ClipMaps[clip] = (clip.m_Version, map);
            return map;
        }
        internal void Begin() { foreach (var t in m_List) { t.result = t.def; t.touched = false; } BeginLayer(); }
        void BeginLayer() { foreach (var t in m_List) { t.acc = default; t.w = 0; } }
        static Vector4 TrackValue(AnimationClip c, AnimationClip.Track tr, float time)
        {
            int dim = tr.kind == 1 ? 4 : 3;
            int frames = c.m_Frames; if (frames <= 0) return default;
            float f = Mathf.Clamp(time * c.m_Fps, 0, frames - 1);
            int a = (int)f; int b = Math.Min(frames - 1, a + 1); float k = f - a;
            var v = tr.values;
            if (dim == 4)
            {
                var qa = new Quaternion(v[a * 4], v[a * 4 + 1], v[a * 4 + 2], v[a * 4 + 3]); var qb = new Quaternion(v[b * 4], v[b * 4 + 1], v[b * 4 + 2], v[b * 4 + 3]);
                var q = Quaternion.Slerp(qa, qb, k); return new Vector4(q.x, q.y, q.z, q.w);
            }
            return new Vector4(v[a * 3] + (v[b * 3] - v[a * 3]) * k, v[a * 3 + 1] + (v[b * 3 + 1] - v[a * 3 + 1]) * k, v[a * 3 + 2] + (v[b * 3 + 2] - v[a * 3 + 2]) * k, 0);
        }
        // adds a clip sampled at time (seconds, already wrapped) with weight to the current layer
        internal void Add(AnimationClip clip, float time, float weight)
        {
            if (clip == null || weight <= 0) return;
            var map = Map(clip);
            foreach (var (tg, track, curves) in map)
            {
                Vector4 v;
                if (track >= 0) v = TrackValue(clip, clip.m_Tracks[track], time);
                else
                {
                    // curves set some components; the others keep the default pose
                    v = tg.def;
                    foreach (var (comp, curve) in curves) v[comp] = clip.m_Curves[curve].curve.Evaluate(time);
                    if (tg.kind == 1) { var q = Quaternion.Normalize(new Quaternion(v.x, v.y, v.z, v.w)); v = new Vector4(q.x, q.y, q.z, q.w); }
                }
                if (tg.kind == 1)
                {
                    // keep quaternions in one hemisphere before averaging
                    var refq = tg.w > 0 ? tg.acc : tg.result;
                    if (Vector4.Dot(refq, v) < 0) v = new Vector4(-v.x, -v.y, -v.z, -v.w);
                }
                tg.acc += v * weight; tg.w += weight;
            }
        }
        // finishes a layer: override layers replace (by weight), additive layers add the difference from the default pose
        internal void EndLayer(float layerWeight, bool additive)
        {
            foreach (var t in m_List)
            {
                if (t.w <= 0) continue;
                Vector4 v = t.acc / t.w;
                float w = Math.Min(1f, t.w) * layerWeight;
                if (t.kind == 1)
                {
                    var q = new Quaternion(v.x, v.y, v.z, v.w); q = Quaternion.Normalize(q);
                    var cur = new Quaternion(t.result.x, t.result.y, t.result.z, t.result.w);
                    Quaternion r;
                    if (additive) { var d = Quaternion.Inverse(new Quaternion(t.def.x, t.def.y, t.def.z, t.def.w)) * q; r = cur * Quaternion.Slerp(Quaternion.identity, d, w); }
                    else r = Quaternion.Slerp(cur, q, w);
                    t.result = new Vector4(r.x, r.y, r.z, r.w);
                }
                else if (additive) t.result += (v - t.def) * w;
                else t.result = Vector4.Lerp(t.result, v, w);
                t.touched = true;
            }
            BeginLayer();
        }
        internal void Apply(float layerWeight, bool additive, object _)
        {
            EndLayer(layerWeight, additive);
            Write(false);
        }
        internal void Write(bool defaults)
        {
            foreach (var t in m_List)
            {
                if (!defaults && !t.touched) continue;
                var v = defaults ? t.def : t.result;
                if (t.t == null) continue;
                switch (t.kind)
                {
                    case 0: t.t.localPosition = new Vector3(v.x, v.y, v.z); break;
                    case 1: t.t.localRotation = Quaternion.Normalize(new Quaternion(v.x, v.y, v.z, v.w)); break;
                    case 2: t.t.localScale = new Vector3(v.x, v.y, v.z); break;
                    case 3: t.t.localEulerAngles = new Vector3(v.x, v.y, v.z); break;
                    case 5: { bool on = v.x > 0.5f; if (t.t.gameObject.activeSelf != on) t.t.gameObject.SetActive(on); break; }
                    case 4: try { SetM(t, WithComp(GetM(t), t.sub, v.x)); } catch { } break;
                }
            }
        }
    }

    // ---------------- an Animator's state machine at runtime ----------------
    internal sealed class AnimatorRuntime
    {
        internal sealed class StateRt
        {
            public ControllerDef.State def; public int shortHash, fullHash, tagHash; public AnimationClip clip; public List<(AnimationClip clip, float threshold, float timeScale)> children = new List<(AnimationClip, float, float)>();
            public List<StateMachineBehaviour> behaviours = new List<StateMachineBehaviour>();
        }
        internal sealed class LayerRt
        {
            public ControllerDef.Layer def; public List<StateRt> states = new List<StateRt>(); public float weight;
            public StateRt cur, next; public float curTime, nextTime, transElapsed, transDuration; public ControllerDef.Transition trans; public bool transFromAny;
            public StateRt Find(int hash) { foreach (var s in states) if (s.shortHash == hash || s.fullHash == hash) return s; return null; }
        }
        sealed class P { public ControllerDef.Param def; public float f; public int i; public bool b; }
        readonly Animator m_Animator;
        internal readonly LayerRt[] layers;
        readonly Dictionary<int, P> m_Params = new Dictionary<int, P>();
        internal readonly List<AnimatorControllerParameter> paramList = new List<AnimatorControllerParameter>();
        readonly PoseBinder m_Binder;
        readonly HashSet<int> m_Warned = new HashSet<int>();
        readonly RuntimeAnimatorController m_Controller;

        internal AnimatorRuntime(Animator a, RuntimeAnimatorController c)
        {
            m_Animator = a; m_Controller = c;
            var def = c.m_Def;
            foreach (var p in def.parameters)
            {
                m_Params[Animator.StringToHash(p.name)] = new P { def = p, f = p.f, i = p.i, b = p.b };
                paramList.Add(new AnimatorControllerParameter { m_Name = p.name, m_Type = p.type, m_DefaultFloat = p.f, m_DefaultInt = p.i, m_DefaultBool = p.b });
            }
            layers = new LayerRt[def.layers.Count];
            for (int li = 0; li < layers.Length; li++)
            {
                var ld = def.layers[li];
                var l = new LayerRt { def = ld, weight = li == 0 ? 1f : ld.weight };
                foreach (var sd in ld.states)
                {
                    var s = new StateRt { def = sd, shortHash = Animator.StringToHash(sd.name), fullHash = Animator.StringToHash(ld.name + "." + sd.name), tagHash = Animator.StringToHash(sd.tag ?? "") };
                    s.clip = Clip(sd.motion);
                    foreach (var ch in sd.children) s.children.Add((Clip(ch.motion), ch.threshold, ch.timeScale));
                    foreach (var bn in sd.behaviours)
                    {
                        var bt = World.FindUserType(bn);
                        if (bt != null && typeof(StateMachineBehaviour).IsAssignableFrom(bt)) { try { s.behaviours.Add((StateMachineBehaviour)ScriptableObject.CreateInstance(bt)); } catch (Exception e) { Debug.LogException(e); } }
                    }
                    l.states.Add(s);
                }
                l.cur = l.states.Find(x => x.def.name == ld.defaultState) ?? (l.states.Count > 0 ? l.states[0] : null);
                if (l.cur != null) l.curTime = l.cur.def.cycleOffset * Length(l.cur);
                layers[li] = l;
            }
            m_Binder = new PoseBinder(a.transform);
            m_EnterPending = true;
        }
        bool m_EnterPending;
        AnimationClip Clip(string key)
        {
            if (string.IsNullOrEmpty(key)) return null;
            var clip = ProjectAssets.Current.Resolve(key, typeof(AnimationClip)) as AnimationClip;
            if (m_Controller is AnimatorOverrideController oc) clip = oc.Map(clip);
            return clip;
        }
        internal IEnumerable<StateMachineBehaviour> AllBehaviours() { foreach (var l in layers) foreach (var s in l.states) foreach (var b in s.behaviours) yield return b; }
        internal AnimatorControllerParameter[] ParametersArray() => paramList.ToArray();

        // ---- parameters ----
        P Param(int id, string name, AnimatorControllerParameterType want)
        {
            if (m_Params.TryGetValue(id, out var p) && (p.def.type == want || (want == AnimatorControllerParameterType.Bool && p.def.type == AnimatorControllerParameterType.Trigger))) return p;
            if (m_Animator.logWarnings && m_Warned.Add(id * 31 + (int)want)) Debug.LogWarning($"Parameter '{name ?? "Hash " + id}' does not exist.", m_Animator);
            return null;
        }
        internal float GetFloat(int id, string n) => Param(id, n, AnimatorControllerParameterType.Float)?.f ?? 0f;
        internal void SetFloat(int id, string n, float v) { var p = Param(id, n, AnimatorControllerParameterType.Float); if (p != null) p.f = v; }
        internal int GetInt(int id, string n) => Param(id, n, AnimatorControllerParameterType.Int)?.i ?? 0;
        internal void SetInt(int id, string n, int v) { var p = Param(id, n, AnimatorControllerParameterType.Int); if (p != null) p.i = v; }
        internal bool GetBool(int id, string n) => Param(id, n, AnimatorControllerParameterType.Bool)?.b ?? false;
        internal void SetBool(int id, string n, bool v) { var p = Param(id, n, AnimatorControllerParameterType.Bool); if (p != null) p.b = v; }
        internal void SetTrigger(int id, string n, bool v) { var p = Param(id, n, AnimatorControllerParameterType.Trigger); if (p != null) p.b = v; }
        float ParamValue(string name)
        {
            if (name == null || !m_Params.TryGetValue(Animator.StringToHash(name), out var p)) return 0;
            return p.def.type == AnimatorControllerParameterType.Float ? p.f : p.def.type == AnimatorControllerParameterType.Int ? p.i : p.b ? 1 : 0;
        }

        // ---- states ----
        float Length(StateRt s)
        {
            if (s == null) return 1f;
            if (!s.def.blendTree) return s.clip != null ? Math.Max(1e-4f, s.clip.length) : 1f;
            float tot = 0, l = 0;
            foreach (var (c, w) in BlendWeights(s)) { tot += w; l += w * (c.clip != null ? c.clip.length / Math.Max(1e-4f, c.timeScale) : 1f); }
            return tot > 0 ? Math.Max(1e-4f, l / tot) : 1f;
        }
        IEnumerable<((AnimationClip clip, float threshold, float timeScale) c, float w)> BlendWeights(StateRt s)
        {
            var ch = s.children; if (ch.Count == 0) yield break;
            float x = ParamValue(s.def.blendParam);
            if (ch.Count == 1 || x <= ch[0].threshold) { yield return (ch[0], 1f); yield break; }
            if (x >= ch[ch.Count - 1].threshold) { yield return (ch[ch.Count - 1], 1f); yield break; }
            for (int i = 0; i + 1 < ch.Count; i++)
                if (x >= ch[i].threshold && x <= ch[i + 1].threshold)
                {
                    float span = ch[i + 1].threshold - ch[i].threshold;
                    float k = span > 0 ? (x - ch[i].threshold) / span : 0;
                    yield return (ch[i], 1 - k); yield return (ch[i + 1], k); yield break;
                }
        }
        bool Loops(StateRt s)
        {
            if (s == null) return false;
            if (!s.def.blendTree) return s.clip != null && s.clip.isLooping;
            foreach (var c in s.children) if (c.clip != null && c.clip.isLooping) return true;
            return false;
        }
        float StateSpeed(StateRt s) => s.def.speed * (s.def.speedParam != null ? ParamValue(s.def.speedParam) : 1f);
        void Sample(StateRt s, float time, float weight, List<(AnimationClip, float)> fired)
        {
            if (s == null || weight <= 0) return;
            float len = Length(s);
            float nt = time / len;
            bool loop = Loops(s);
            float phase = loop ? nt - Mathf.Floor(nt) : Mathf.Clamp01(nt);
            if (!s.def.blendTree) { if (s.clip != null) m_Binder.Add(s.clip, phase * s.clip.length, weight); return; }
            foreach (var (c, w) in BlendWeights(s)) if (c.clip != null) m_Binder.Add(c.clip, phase * c.clip.length, weight * w);
        }

        bool Conditions(ControllerDef.Transition t)
        {
            foreach (var c in t.conditions)
            {
                if (c.param == null || !m_Params.TryGetValue(Animator.StringToHash(c.param), out var p)) return false;
                switch (p.def.type)
                {
                    case AnimatorControllerParameterType.Float:
                        if (c.mode == 3 ? !(p.f > c.threshold) : c.mode == 4 ? !(p.f < c.threshold) : true) return false; break;
                    case AnimatorControllerParameterType.Int:
                        if (c.mode == 3 ? !(p.i > c.threshold) : c.mode == 4 ? !(p.i < c.threshold) : c.mode == 6 ? p.i != (int)c.threshold : c.mode == 7 ? p.i == (int)c.threshold : true) return false; break;
                    default:
                        if (c.mode == 1 && !p.b) return false;
                        if (c.mode == 2 && p.b) return false;
                        break;
                }
            }
            return true;
        }
        void ConsumeTriggers(ControllerDef.Transition t)
        {
            foreach (var c in t.conditions)
                if (c.param != null && m_Params.TryGetValue(Animator.StringToHash(c.param), out var p) && p.def.type == AnimatorControllerParameterType.Trigger) p.b = false;
        }
        // exit time: crossed this frame (for exitTime < 1 on a looping state, at that point in every loop)
        static bool ExitReached(float prevNt, float nt, float exitTime, bool loop)
        {
            if (exitTime < 1f && loop)
            {
                float a = prevNt - Mathf.Floor(prevNt), loopsA = Mathf.Floor(prevNt), loopsB = Mathf.Floor(nt);
                if (loopsB > loopsA) return true;
                float b = nt - loopsB;
                return a < exitTime && b >= exitTime;
            }
            return prevNt < exitTime && nt >= exitTime;
        }
        void StartTransition(LayerRt l, int li, StateRt to, ControllerDef.Transition t, bool fromAny)
        {
            l.next = to; l.trans = t; l.transFromAny = fromAny; l.transElapsed = 0;
            l.transDuration = t.fixedDuration ? t.duration : t.duration * Length(l.cur);
            l.nextTime = t.offset * Length(to);
            ConsumeTriggers(t);
            Enter(to, li, true);
            if (l.transDuration <= 0) Finish(l, li);
        }
        void Finish(LayerRt l, int li)
        {
            var old = l.cur;
            l.cur = l.next; l.curTime = l.nextTime; l.next = null; l.trans = null;
            Exit(old, li, false);
        }
        void Enter(StateRt s, int li, bool asNext) { foreach (var b in s.behaviours) try { b.OnStateEnter(m_Animator, InfoFor(layers[li], s, asNext), li); } catch (Exception e) { Debug.LogException(e); } }
        void Exit(StateRt s, int li, bool asNext) { if (s == null) return; foreach (var b in s.behaviours) try { b.OnStateExit(m_Animator, InfoFor(layers[li], s, asNext), li); } catch (Exception e) { Debug.LogException(e); } }

        internal void Play(int hash, string name, int layer, float time, bool fixedTime)
        {
            bool found = false;
            for (int li = 0; li < layers.Length; li++)
            {
                if (layer >= 0 && li != layer) continue;
                var l = layers[li]; var s = l.Find(hash);
                if (s == null) continue;
                found = true;
                if (float.IsNegativeInfinity(time)) { if (l.cur == s && l.next == null) continue; time = 0; }
                if (l.next != null) { Exit(l.cur, li, false); l.cur = l.next; l.next = null; }
                var old = l.cur;
                l.cur = s; l.curTime = fixedTime ? time : time * Length(s);
                if (old != s) { Exit(old, li, false); Enter(s, li, false); }
                if (layer < 0) break;
            }
            if (!found && m_Animator.logWarnings) Debug.LogWarning($"Animator.GotoState: State could not be found", m_Animator);
        }
        internal void CrossFade(int hash, string name, float duration, int layer, float offset, bool fixedTime)
        {
            for (int li = 0; li < layers.Length; li++)
            {
                if (layer >= 0 && li != layer) continue;
                var l = layers[li]; var s = l.Find(hash);
                if (s == null) continue;
                if (l.next != null) Finish(l, li);
                var t = new ControllerDef.Transition { fixedDuration = fixedTime, duration = duration, offset = 0 };
                StartTransition(l, li, s, t, false);
                if (!float.IsNegativeInfinity(offset)) l.nextTime = fixedTime ? offset : offset * Length(s);
                return;
            }
            if (m_Animator.logWarnings) Debug.LogWarning($"Animator.GotoState: State could not be found", m_Animator);
        }

        internal void Tick(float dt)
        {
            dt *= m_Animator.speed;
            if (m_EnterPending) { m_EnterPending = false; for (int li = 0; li < layers.Length; li++) if (layers[li].cur != null) Enter(layers[li].cur, li, false); }
            var fired = new List<(AnimationClip, float)>();
            for (int li = 0; li < layers.Length; li++)
            {
                var l = layers[li];
                if (l.cur == null) continue;
                // advance
                float lenCur = Length(l.cur);
                float prevNt = l.curTime / lenCur;
                float prevCurTime = l.curTime;
                l.curTime += dt * StateSpeed(l.cur);
                float nt = l.curTime / lenCur;
                FireEvents(l.cur, prevCurTime, l.curTime);
                if (l.next != null)
                {
                    float prevNext = l.nextTime;
                    l.nextTime += dt * StateSpeed(l.next);
                    FireEvents(l.next, prevNext, l.nextTime);
                    l.transElapsed += Math.Abs(dt);
                    if (l.transElapsed >= l.transDuration) Finish(l, li);
                }
                else
                {
                    // any state first, then the current state's transitions (in order)
                    bool done = false;
                    foreach (var t in l.def.anyState)
                    {
                        var to = l.states.Find(x => x.def.name == t.to);
                        if (to == null || (!t.canTransitionToSelf && to == l.cur)) continue;
                        if (t.hasExitTime && !ExitReached(prevNt, nt, t.exitTime, Loops(l.cur))) continue;
                        if (!t.hasExitTime && t.conditions.Count == 0) continue;
                        if (!Conditions(t)) continue;
                        StartTransition(l, li, to, t, true); done = true; break;
                    }
                    if (!done)
                        foreach (var t in l.cur.def.transitions)
                        {
                            if (t.hasExitTime && !ExitReached(prevNt, nt, t.exitTime, Loops(l.cur))) continue;
                            if (!t.hasExitTime && t.conditions.Count == 0) continue;
                            if (!Conditions(t)) continue;
                            var to = t.exit ? l.states.Find(x => x.def.name == l.def.defaultState) ?? l.states[0] : l.states.Find(x => x.def.name == t.to);
                            if (to == null) continue;
                            StartTransition(l, li, to, t, false); break;
                        }
                }
                foreach (var b in l.cur.behaviours) try { b.OnStateUpdate(m_Animator, InfoFor(l, l.cur, false), li); } catch (Exception e) { Debug.LogException(e); }
                if (l.next != null) foreach (var b in l.next.behaviours) try { b.OnStateUpdate(m_Animator, InfoFor(l, l.next, true), li); } catch (Exception e) { Debug.LogException(e); }
            }
            // pose
            m_Binder.Begin();
            for (int li = 0; li < layers.Length; li++)
            {
                var l = layers[li];
                if (l.cur == null) continue;
                float tw = l.next != null && l.transDuration > 0 ? Mathf.Clamp01(l.transElapsed / l.transDuration) : 0f;
                Sample(l.cur, l.curTime, 1f - tw, fired);
                if (l.next != null) Sample(l.next, l.nextTime, tw, fired);
                m_Binder.EndLayer(li == 0 ? 1f : l.weight, li > 0 && l.def.additive);
            }
            m_Binder.Write(false);
        }
        void FireEvents(StateRt s, float t0, float t1)
        {
            if (!m_Animator.fireEvents || t1 <= t0) return;
            var clip = s.clip; if (clip == null || clip.m_Events.Count == 0) return;
            float len = Length(s); if (len <= 0) return;
            bool loop = Loops(s);
            float a = t0 / len, b = t1 / len;
            foreach (var ev in clip.m_Events.ToArray())
            {
                float en = ev.time / Math.Max(1e-5f, clip.length);
                bool hit = loop ? Mathf.Floor(b - en) > Mathf.Floor(a - en) || (a <= 0 && en <= 0 && b > 0) : a < en && b >= en || (a <= 0 && en <= 0 && b > 0);
                if (!hit) continue;
                var e = ev.Copy(); e.isFiredByAnimator = true;
                AnimationSystem.Fire(m_Animator.gameObject, e);
            }
        }
        AnimatorStateInfo InfoFor(LayerRt l, StateRt s, bool next)
        {
            float len = Length(s);
            float t = next ? l.nextTime : l.curTime;
            return new AnimatorStateInfo { m_FullPath = s.fullHash, m_Path = s.fullHash, m_Name = s.shortHash, m_Tag = s.tagHash, m_Loop = Loops(s) ? 1 : 0, m_Length = len, m_NormalizedTime = t / len, m_Speed = s.def.speed, m_SpeedMultiplier = s.def.speedParam != null ? ParamValue(s.def.speedParam) : 1f };
        }
        internal AnimatorStateInfo StateInfo(int li, bool next)
        {
            if (li < 0 || li >= layers.Length) { Debug.LogError("Invalid Layer Index '" + li + "'"); return default; }
            var l = layers[li]; var s = next ? l.next : l.cur;
            return s == null ? default : InfoFor(l, s, next);
        }
        internal AnimatorTransitionInfo TransitionInfo(int li)
        {
            if (li < 0 || li >= layers.Length) return default;
            var l = layers[li];
            if (l.next == null || l.trans == null) return default;
            string n = (l.transFromAny ? "AnyState" : l.cur.def.name) + " -> " + l.next.def.name;
            return new AnimatorTransitionInfo { m_Name = Animator.StringToHash(n), m_FullPath = Animator.StringToHash(l.def.name + "." + n), m_UserName = Animator.StringToHash(l.trans.name ?? ""), m_NormalizedTime = l.transDuration > 0 ? l.transElapsed / l.transDuration : 1f, m_Duration = l.trans.duration, m_HasFixedDuration = l.trans.fixedDuration, m_AnyState = l.transFromAny };
        }
        internal AnimatorClipInfo[] ClipInfo(int li, bool next)
        {
            if (li < 0 || li >= layers.Length) return Array.Empty<AnimatorClipInfo>();
            var l = layers[li]; var s = next ? l.next : l.cur;
            if (s == null) return Array.Empty<AnimatorClipInfo>();
            float lw = l.next == null ? 1f : (next ? Mathf.Clamp01(l.transElapsed / Math.Max(1e-5f, l.transDuration)) : 1f - Mathf.Clamp01(l.transElapsed / Math.Max(1e-5f, l.transDuration)));
            if (!s.def.blendTree) return s.clip != null ? new[] { new AnimatorClipInfo { m_Clip = s.clip, m_Weight = lw } } : Array.Empty<AnimatorClipInfo>();
            var list = new List<AnimatorClipInfo>();
            foreach (var (c, w) in BlendWeights(s)) if (c.clip != null) list.Add(new AnimatorClipInfo { m_Clip = c.clip, m_Weight = w * lw });
            return list.ToArray();
        }
        internal void WriteDefaults() => m_Binder.Write(true);
    }

    internal static class AnimationSystem
    {
        internal static readonly HashSet<Animator> animators = new HashSet<Animator>();
        internal static readonly HashSet<Animation> animations = new HashSet<Animation>();
        internal static void Reset() { animators.Clear(); animations.Clear(); }

        // after Update (and coroutines), before LateUpdate
        internal static void Update(float dt, float unscaledDt)
        {
            if (animators.Count > 0)
                foreach (var a in new List<Animator>(animators))
                {
                    if (a == null || a.m_Destroyed || !a.m_Enabled || !a.gameObject.activeInHierarchy || a.updateMode == AnimatorUpdateMode.Fixed) continue;
                    try { a.Rt?.Tick(a.updateMode == AnimatorUpdateMode.UnscaledTime ? unscaledDt : dt); } catch (Exception e) { Debug.LogException(e); }
                }
            if (animations.Count > 0)
                foreach (var an in new List<Animation>(animations))
                {
                    if (an == null || an.m_Destroyed || !an.m_Enabled || !an.gameObject.activeInHierarchy || an.animatePhysics) continue;
                    try { SampleLegacy(an, dt); } catch (Exception e) { Debug.LogException(e); }
                }
        }
        // after each physics step, for Animators set to Animate Physics
        internal static void FixedUpdate(float dt)
        {
            foreach (var a in new List<Animator>(animators))
            {
                if (a == null || a.m_Destroyed || !a.m_Enabled || !a.gameObject.activeInHierarchy || a.updateMode != AnimatorUpdateMode.Fixed) continue;
                try { a.Rt?.Tick(dt); } catch (Exception e) { Debug.LogException(e); }
            }
            foreach (var an in new List<Animation>(animations))
            {
                if (an == null || an.m_Destroyed || !an.m_Enabled || !an.gameObject.activeInHierarchy || !an.animatePhysics) continue;
                try { SampleLegacy(an, dt); } catch (Exception e) { Debug.LogException(e); }
            }
        }
        internal static void AutoPlay(Animation an)
        {
            if (an.m_AutoPlayed) return;
            an.m_AutoPlayed = true;
            if (an.playAutomatically && an.clip != null) an.Play();
        }
        internal static void SampleLegacy(Animation an, float dt)
        {
            AutoPlay(an);
            an.m_Binder ??= new PoseBinder(an.transform);
            var b = an.m_Binder;
            b.Begin();
            bool any = false;
            foreach (var s in an.m_States.ToArray())
            {
                if (!s.m_Enabled || s.m_Clip == null) continue;
                // fade
                if (s.m_FadeSpeed > 0)
                {
                    s.m_Weight = Mathf.MoveTowards(s.m_Weight, s.m_TargetWeight, s.m_FadeSpeed * dt);
                    if (Math.Abs(s.m_Weight - s.m_TargetWeight) < 1e-5f) { s.m_FadeSpeed = 0; if (s.m_StopWhenFaded && s.m_TargetWeight <= 0) { s.m_Enabled = false; s.time = 0; continue; } }
                }
                float t0 = s.m_Time;
                s.m_Time += dt * s.m_Speed;
                var mode = s.EffectiveWrap;
                float len = s.length;
                if (an.isActiveAndEnabled) FireLegacyEvents(an, s, t0, s.m_Time, mode);
                if ((mode == WrapMode.Once || mode == WrapMode.Default) && len > 0 && s.m_Time >= len)
                {
                    // Once: stops at the end and rewinds
                    b.Add(s.m_Clip, len, s.m_Weight); any = true;
                    s.m_Enabled = false; s.time = 0; s.m_Weight = 0;
                    continue;
                }
                b.Add(s.m_Clip, s.m_Clip.Wrap(s.m_Time, mode == WrapMode.ClampForever ? WrapMode.Clamp : mode), s.m_Weight);
                any = true;
            }
            if (any) b.Apply(1f, false, null);
        }
        static void FireLegacyEvents(Animation an, AnimationState s, float t0, float t1, WrapMode mode)
        {
            var clip = s.m_Clip; if (clip.m_Events.Count == 0 || t1 <= t0) return;
            float len = clip.length; if (len <= 0) return;
            bool loop = mode == WrapMode.Loop || mode == WrapMode.PingPong;
            foreach (var ev in clip.m_Events.ToArray())
            {
                bool hit = loop ? Mathf.Floor((t1 - ev.time) / len) > Mathf.Floor((t0 - ev.time) / len) : t0 < ev.time && t1 >= ev.time || (t0 <= 0 && ev.time <= 0 && t1 > 0);
                if (!hit) continue;
                var e = ev.Copy(); e.isFiredByLegacy = true; e.animationState = s;
                Fire(an.gameObject, e);
            }
        }
        internal static void Fire(GameObject go, AnimationEvent e)
        {
            if (string.IsNullOrEmpty(e.functionName)) return;
            // like Unity: calls the method on every script of the GameObject; the argument type picks the parameter
            bool found = false;
            foreach (var c in go.m_Components.ToArray())
            {
                if (!(c is MonoBehaviour mb) || c.m_Destroyed) continue;
                var mi = c.GetType().GetMethod(e.functionName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
                if (mi == null) continue;
                found = true;
                var ps = mi.GetParameters();
                object[] args = null;
                if (ps.Length == 1)
                {
                    var pt = ps[0].ParameterType;
                    args = new object[] { pt == typeof(string) ? e.stringParameter : pt == typeof(float) ? e.floatParameter : pt == typeof(int) ? e.intParameter : pt == typeof(AnimationEvent) ? (object)e : typeof(Object).IsAssignableFrom(pt) ? e.objectReferenceParameter : pt.IsEnum ? Enum.ToObject(pt, e.intParameter) : null };
                }
                else if (ps.Length > 1) continue;
                try { var r = mi.Invoke(c, args); if (r is IEnumerator en && mb.isActiveAndEnabledForCoroutines) mb.StartCoroutine(en); }
                catch (TargetInvocationException ex) { Debug.LogException(ex.InnerException ?? ex, c); }
            }
            if (!found && e.messageOptions == SendMessageOptions.RequireReceiver)
                Debug.LogError($"'{go.name}' AnimationEvent '{e.functionName}' on animation '{(e.animationState != null ? e.animationState.name : "")}' has no receiver! Are you missing a component?", go);
        }
    }
}
