// Anvil — UnityEngine.Windows.Speech (Unity's voice recognition on Windows), on the browser's speech recognition.
// DictationRecognizer gives everything you say as text; KeywordRecognizer fires when one of its keywords is heard.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace UnityEngine.Windows.Speech
{
    public enum ConfidenceLevel { High = 0, Medium = 1, Low = 2, Rejected = 3 }
    public enum SpeechSystemStatus { Stopped = 0, Running = 1, Failed = 2 }
    public enum SpeechError { NoError = 0, TopicLanguageNotSupported = 1, GrammarLanguageMismatch = 2, GrammarCompilationFailure = 3, AudioQualityFailure = 4, PauseLimitExceeded = 5, TimeoutExceeded = 6, NetworkFailure = 7, MicrophoneUnavailable = 8, UnknownError = 9 }
    public enum DictationCompletionCause { Complete = 0, AudioQualityFailure = 1, Canceled = 2, TimeoutExceeded = 3, PauseLimitExceeded = 4, NetworkFailure = 5, MicrophoneUnavailable = 6, UnknownError = 7 }
    public enum DictationTopicConstraint { WebSearch = 0, Form = 1, Dictation = 2 }

    public struct SemanticMeaning { public string key; public string[] values; }

    public struct PhraseRecognizedEventArgs
    {
        public readonly ConfidenceLevel confidence;
        public readonly SemanticMeaning[] semanticMeanings;
        public readonly string text;
        public readonly DateTime phraseStartTime;
        public readonly TimeSpan phraseDuration;
        internal PhraseRecognizedEventArgs(string text, ConfidenceLevel confidence)
        { this.text = text; this.confidence = confidence; semanticMeanings = Array.Empty<SemanticMeaning>(); phraseStartTime = DateTime.Now; phraseDuration = TimeSpan.Zero; }
    }

    public abstract class PhraseRecognizer : IDisposable
    {
        public delegate void PhraseRecognizedDelegate(PhraseRecognizedEventArgs args);
        public event PhraseRecognizedDelegate OnPhraseRecognized;
        internal ConfidenceLevel m_Min = ConfidenceLevel.Medium;
        bool m_Running;
        public bool IsRunning => m_Running;
        public void Start() { m_Running = true; Anvil.SpeechHub.Add(this); }
        public void Stop() { m_Running = false; Anvil.SpeechHub.Remove(this); }
        public void Dispose() => Stop();
        internal void Raise(string text, ConfidenceLevel c) { if (c <= m_Min) OnPhraseRecognized?.Invoke(new PhraseRecognizedEventArgs(text, c)); }
        internal abstract void Heard(string text, ConfidenceLevel c);
    }

    public sealed class KeywordRecognizer : PhraseRecognizer
    {
        readonly string[] m_Keywords;
        public IEnumerable<string> Keywords => m_Keywords;
        public KeywordRecognizer(string[] keywords) : this(keywords, ConfidenceLevel.Medium) { }
        public KeywordRecognizer(string[] keywords, ConfidenceLevel minimumConfidence)
        {
            if (keywords == null || keywords.Length == 0) throw new ArgumentException("At least one keyword must be specified.", nameof(keywords));
            m_Keywords = keywords.ToArray(); m_Min = minimumConfidence;
        }
        internal override void Heard(string text, ConfidenceLevel c)
        {
            string t = " " + Anvil.SpeechHub.Normalize(text) + " ";
            foreach (var k in m_Keywords)
                if (!string.IsNullOrWhiteSpace(k) && t.Contains(" " + Anvil.SpeechHub.Normalize(k) + " ")) Raise(k, c);
        }
    }

    public sealed class GrammarRecognizer : PhraseRecognizer
    {
        public string GrammarFilePath { get; }
        public GrammarRecognizer(string grammarFilePath) : this(grammarFilePath, ConfidenceLevel.Medium) { }
        public GrammarRecognizer(string grammarFilePath, ConfidenceLevel minimumConfidence) { GrammarFilePath = grammarFilePath; m_Min = minimumConfidence; }
        internal override void Heard(string text, ConfidenceLevel c) => Raise(text, c);
    }

    public sealed class DictationRecognizer : IDisposable
    {
        public delegate void DictationHypothesisDelegate(string text);
        public delegate void DictationResultDelegate(string text, ConfidenceLevel confidence);
        public delegate void DictationCompletedDelegate(DictationCompletionCause cause);
        public delegate void DictationErrorHandler(string error, int hresult);
        public event DictationHypothesisDelegate DictationHypothesis;
        public event DictationResultDelegate DictationResult;
        public event DictationCompletedDelegate DictationComplete;
        public event DictationErrorHandler DictationError;
        readonly ConfidenceLevel m_Min;
        SpeechSystemStatus m_Status;
        public SpeechSystemStatus Status => m_Status;
        public float AutoSilenceTimeoutSeconds { get; set; } = 20f;
        public float InitialSilenceTimeoutSeconds { get; set; } = 5f;
        public DictationRecognizer() : this(ConfidenceLevel.Medium, DictationTopicConstraint.Dictation) { }
        public DictationRecognizer(ConfidenceLevel confidenceLevel) : this(confidenceLevel, DictationTopicConstraint.Dictation) { }
        public DictationRecognizer(DictationTopicConstraint topic) : this(ConfidenceLevel.Medium, topic) { }
        public DictationRecognizer(ConfidenceLevel minimumConfidence, DictationTopicConstraint topic) { m_Min = minimumConfidence; }
        public void Start() { m_Status = SpeechSystemStatus.Running; Anvil.SpeechHub.Add(this); }
        public void Stop() { if (m_Status == SpeechSystemStatus.Running) { m_Status = SpeechSystemStatus.Stopped; Anvil.SpeechHub.Remove(this); DictationComplete?.Invoke(DictationCompletionCause.Complete); } }
        public void Dispose() { m_Status = SpeechSystemStatus.Stopped; Anvil.SpeechHub.Remove(this); }
        internal void Hypothesis(string text) => DictationHypothesis?.Invoke(text);
        internal void Result(string text, ConfidenceLevel c) { if (c <= m_Min) DictationResult?.Invoke(text, c); }
        internal void Error(string e) { DictationError?.Invoke(e, -1); m_Status = SpeechSystemStatus.Failed; }
    }

    public static class PhraseRecognitionSystem
    {
        public delegate void ErrorDelegate(SpeechError errorCode);
        public delegate void StatusDelegate(SpeechSystemStatus status);
        public static event ErrorDelegate OnError;
        public static event StatusDelegate OnStatusChanged;
        public static bool isSupported => true;
        public static SpeechSystemStatus Status => Anvil.SpeechHub.Listening ? SpeechSystemStatus.Running : SpeechSystemStatus.Stopped;
        public static void Restart() { Anvil.SpeechHub.Restart(); OnStatusChanged?.Invoke(Status); }
        public static void Shutdown() { Anvil.SpeechHub.StopAll(); OnStatusChanged?.Invoke(SpeechSystemStatus.Stopped); }
        internal static void RaiseError(SpeechError e) => OnError?.Invoke(e);
    }
}

namespace Anvil
{
    using UnityEngine;
    using UnityEngine.Windows.Speech;

    internal static class SpeechHub
    {
        internal static Action<string> s_Start;
        internal static Action s_Stop;
        internal static Func<string> s_Poll;
        static readonly List<object> s_Active = new List<object>();
        internal static bool Listening => s_Active.Count > 0;

        internal static void Add(object r) { if (!s_Active.Contains(r)) s_Active.Add(r); if (s_Active.Count == 1) s_Start?.Invoke("en-US"); }
        internal static void Remove(object r) { s_Active.Remove(r); if (s_Active.Count == 0) s_Stop?.Invoke(); }
        internal static void StopAll() { s_Active.Clear(); s_Stop?.Invoke(); }
        internal static void Restart() { if (s_Active.Count > 0) s_Start?.Invoke("en-US"); }
        internal static void Reset() { if (s_Active.Count > 0) StopAll(); }

        static readonly Regex s_Punct = new Regex(@"[^\p{L}\p{N}\s\-\.]", RegexOptions.Compiled);
        static readonly Regex s_Space = new Regex(@"\s+", RegexOptions.Compiled);
        internal static string Normalize(string s) => s_Space.Replace(s_Punct.Replace((s ?? "").ToLowerInvariant(), " "), " ").Trim().TrimEnd('.');

        static ConfidenceLevel Level(double c) => c <= 0 ? ConfidenceLevel.Medium : c > 0.8 ? ConfidenceLevel.High : c > 0.5 ? ConfidenceLevel.Medium : c > 0.25 ? ConfidenceLevel.Low : ConfidenceLevel.Rejected;

        // once a frame, before Update: deliver what was heard
        internal static void Pump()
        {
            if (s_Active.Count == 0 || s_Poll == null) return;
            string json;
            try { json = s_Poll(); } catch { return; }
            if (string.IsNullOrEmpty(json)) return;
            try
            {
                using var doc = JsonDocument.Parse(json);
                foreach (var e in doc.RootElement.EnumerateArray())
                {
                    int kind = e[0].GetInt32(); string text = e[1].GetString() ?? ""; var level = Level(e[2].GetDouble());
                    foreach (var r in s_Active.ToArray())
                    {
                        try
                        {
                            if (r is DictationRecognizer d)
                            {
                                if (kind == 0) d.Hypothesis(text);
                                else if (kind == 1) d.Result(text, level);
                                else if (kind == 3) d.Error(text);
                            }
                            else if (r is PhraseRecognizer p && kind == 1) p.Heard(text, level);
                        }
                        catch (Exception ex) { Debug.LogException(ex); }
                    }
                    if (kind == 3) { Debug.LogWarning("Speech: " + text); PhraseRecognitionSystem.RaiseError(text.Contains("internet") ? SpeechError.NetworkFailure : text.Contains("icrophone") ? SpeechError.MicrophoneUnavailable : SpeechError.UnknownError); }
                }
            }
            catch (Exception ex) { Debug.LogException(ex); }
        }
    }
}
