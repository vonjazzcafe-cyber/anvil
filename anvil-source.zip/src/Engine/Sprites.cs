// Anvil — SpriteRenderer: draws a Sprite as a textured quad (unlit, alpha-blended, like Unity's Sprites/Default),
// with color tint, flipX/flipY, Sliced/Tiled sizes (stretched) and sortingOrder for draw order.
using System;
using UnityEngine.Rendering;

namespace UnityEngine
{
    public enum SpriteSortPoint { Center = 0, Pivot = 1 }
    public enum SpriteTileMode { Continuous = 0, Adaptive = 1 }

    public sealed class SpriteRenderer : Renderer
    {
        Sprite m_Sprite; Color m_Color = Color.white; bool m_FlipX, m_FlipY;
        SpriteDrawMode m_DrawMode; Vector2 m_Size = Vector2.one;
        internal Mesh m_Quad; Material m_Own; int m_Sig = int.MinValue;

        public SpriteRenderer() { shadowCastingMode = ShadowCastingMode.Off; receiveShadows = false; }
        // like Unity, a new SpriteRenderer starts with the Sprites-Default material (not the 3D default)
        internal override void OnAddedInternal() { if (m_Materials.Length == 0 || m_Materials[0] == null || m_Materials[0] == Material.DefaultMaterial) { EnsureOwn(); m_SharedMaterial = m_Own; } }
        void EnsureOwn() { if (m_Own == null) m_Own = new Material(Shader.Find("Sprites/Default")) { name = "Sprites-Default" }; }
        public Sprite sprite { get => m_Sprite; set { m_Sprite = value; if (value != null && m_DrawMode == SpriteDrawMode.Simple) m_Size = new Vector2(value.rect.width / value.pixelsPerUnit, value.rect.height / value.pixelsPerUnit); } }
        public Color color { get => m_Color; set => m_Color = value; }
        public bool flipX { get => m_FlipX; set => m_FlipX = value; }
        public bool flipY { get => m_FlipY; set => m_FlipY = value; }
        public SpriteDrawMode drawMode { get => m_DrawMode; set => m_DrawMode = value; }
        public Vector2 size { get => m_Size; set => m_Size = value; }
        public SpriteTileMode tileMode { get; set; }
        public float adaptiveModeThreshold { get; set; } = 0.5f;
        public SpriteMaskInteraction maskInteraction { get; set; }
        public SpriteSortPoint spriteSortPoint { get; set; }
        public void RegisterSpriteChangeCallback(Events.UnityAction<SpriteRenderer> callback) { }
        public void UnregisterSpriteChangeCallback(Events.UnityAction<SpriteRenderer> callback) { }

        internal override Bounds LocalBoundsOverride()
        {
            if (m_Sprite == null) return new Bounds(Vector3.zero, Vector3.zero);
            var b = m_Sprite.bounds;
            if (m_DrawMode != SpriteDrawMode.Simple) b = new Bounds(b.center, new Vector3(m_Size.x, m_Size.y, 0));
            return b;
        }

        // the quad for this frame (rebuilt only when the sprite, flips or size change)
        internal Mesh RenderMesh()
        {
            if (m_Sprite == null || m_Sprite.texture == null) return null;
            int sig;
            unchecked { sig = m_Sprite.m_InstanceID * 31 + (m_FlipX ? 1 : 0) + (m_FlipY ? 2 : 0) + (int)m_DrawMode * 4 + m_Size.GetHashCode() * 17 + m_Color.GetHashCode() * 7919; }
            if (m_Quad != null && sig == m_Sig) return m_Quad;
            m_Sig = sig;
            var sp = m_Sprite;
            float ppu = Math.Max(0.0001f, sp.pixelsPerUnit);
            float w = sp.rect.width / ppu, h = sp.rect.height / ppu;
            float x0 = -sp.pivot.x / ppu, y0 = -sp.pivot.y / ppu;
            if (m_DrawMode != SpriteDrawMode.Simple && sp.rect.width > 0 && sp.rect.height > 0)
            {
                float sx = m_Size.x / w, sy = m_Size.y / h; x0 *= sx; y0 *= sy; w = m_Size.x; h = m_Size.y;
            }
            float x1 = x0 + w, y1 = y0 + h;
            if (m_FlipX) { x0 = -x0; x1 = -x1; }
            if (m_FlipY) { y0 = -y0; y1 = -y1; }
            float tw = Math.Max(1, sp.texture.width), th = Math.Max(1, sp.texture.height);
            float u0 = sp.rect.xMin / tw, u1 = sp.rect.xMax / tw, v0 = sp.rect.yMin / th, v1 = sp.rect.yMax / th;
            m_Quad ??= new Mesh { name = "Sprite" };
            m_Quad.Clear();
            m_Quad.vertices = new[] { new Vector3(x0, y0, 0), new Vector3(x1, y0, 0), new Vector3(x0, y1, 0), new Vector3(x1, y1, 0) };
            m_Quad.uv = new[] { new Vector2(u0, v0), new Vector2(u1, v0), new Vector2(u0, v1), new Vector2(u1, v1) };
            m_Quad.normals = new[] { Vector3.back, Vector3.back, Vector3.back, Vector3.back };
            // like Unity, the tint travels in the vertex colours (the Sprites shader multiplies them in)
            m_Quad.colors = new[] { m_Color, m_Color, m_Color, m_Color };
            // both windings, so a flipped sprite still faces the camera
            m_Quad.triangles = new[] { 0, 2, 1, 2, 3, 1, 0, 1, 2, 2, 1, 3 };
            m_Quad.RecalculateBounds();
            return m_Quad;
        }
        // a material of its own carries the tint and the sprite's texture, unless the script set a material
        internal void PrepareMaterial()
        {
            EnsureOwn();
            if (m_Materials.Length == 0 || m_Materials[0] == null || m_Materials[0] == Material.DefaultMaterial) { m_Materials = new[] { m_Own }; m_Instanced = new[] { false }; }
            var m = m_Materials[0];
            if (m == m_Own || m.shader?.name == "Sprites/Default")
            {
                if (m.color != Color.white) m.color = Color.white;
                var tex = m_Sprite != null ? m_Sprite.texture : null;
                if (m.mainTexture != tex) m.mainTexture = tex;
            }
        }
    }
}
