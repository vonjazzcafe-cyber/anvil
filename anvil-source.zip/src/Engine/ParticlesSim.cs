// Anvil — ParticleSystem simulation (playback state, emission, per-particle update, collisions).
using System;
using System.Collections.Generic;
using Anvil;

namespace UnityEngine
{
    public sealed partial class ParticleSystem
    {
        internal Particle[] m_Particles = new Particle[64];
        internal int m_Count;
        float m_Time, m_DelayLeft, m_EmitAcc, m_DistAcc, m_TotalTime;
        bool m_Playing, m_Paused, m_Emitting, m_PlayOnAwakePending = true, m_StoppedNotified = true;
        Vector3 m_LastPos; bool m_HasLastPos;
        System.Random m_Rng = new System.Random(Environment.TickCount);
        int[] m_BurstCycles = Array.Empty<int>();
        public uint randomSeed { get; set; }
        public bool useAutoRandomSeed { get; set; } = true;

        internal static Material s_DefaultMat;
        internal static Material DefaultMaterial => s_DefaultMat ??= new Material(Shader.Find("Universal Render Pipeline/Particles/Unlit")) { m_Name = "ParticlesUnlit", m_IsAsset = true };

        public bool isPlaying => m_Playing && !m_Paused;
        public bool isEmitting => m_Playing && m_Emitting && !m_Paused;
        public bool isStopped => !m_Playing && m_Count == 0;
        public bool isPaused => m_Paused;
        public int particleCount => m_Count;
        public float time { get => m_Time; set => m_Time = Mathf.Clamp(value, 0, m_Main.duration); }
        public float totalTime => m_TotalTime;
        public bool automaticCullingEnabled => false;
        public bool proceduralSimulationSupported => true;
        public bool has3DParticleRotations => m_Main.startRotation3D || m_RotOL.separateAxes;
        public bool hasNonUniformParticleSizes => m_Main.startSize3D || m_SizeOL.separateAxes;

        internal override void OnAddedInternal()
        {
            if (GetComponent<ParticleSystemRenderer>() == null) m_GameObject.AddComponent<ParticleSystemRenderer>();
            Effects.systems.Add(this);
            m_PlayOnAwakePending = true;
        }
        internal override void OnRemovedInternal() { Effects.systems.Remove(this); }
        internal override void OnActiveChangedInternal(bool active) { if (active) m_PlayOnAwakePending = true; else { m_Count = 0; m_Playing = false; } }
        internal override void CopyFromInternal(Component src)
        {
            var o = (ParticleSystem)src;
            CopyFields(o.m_Main, m_Main); CopyFields(o.m_Emission, m_Emission); m_Emission.bursts = new List<Burst>(o.m_Emission.bursts);
            CopyFields(o.m_Shape, m_Shape); CopyFields(o.m_VelOL, m_VelOL); CopyFields(o.m_ForceOL, m_ForceOL); CopyFields(o.m_Limit, m_Limit);
            CopyFields(o.m_ColorOL, m_ColorOL); CopyFields(o.m_ColorBS, m_ColorBS); CopyFields(o.m_SizeOL, m_SizeOL); CopyFields(o.m_SizeBS, m_SizeBS);
            CopyFields(o.m_RotOL, m_RotOL); CopyFields(o.m_RotBS, m_RotBS); CopyFields(o.m_Noise, m_Noise); CopyFields(o.m_Collision, m_Collision);
            m_Collision.planes = new List<Transform>(o.m_Collision.planes);
            m_InheritEnabled = o.m_InheritEnabled; m_InheritCurve = o.m_InheritCurve; m_InheritMode = o.m_InheritMode;
            randomSeed = o.randomSeed; useAutoRandomSeed = o.useAutoRandomSeed;
        }
        static void CopyFields(object src, object dst) { foreach (var f in src.GetType().GetFields()) f.SetValue(dst, f.GetValue(src)); }

        float Rand() => (float)m_Rng.NextDouble();
        // the particle system has its own random numbers, so it doesn't change the sequence scripts get from Random
        Vector3 RandOnSphere() { float z = Rand() * 2 - 1, a = Rand() * Mathf.PI * 2, r = Mathf.Sqrt(1 - z * z); return new Vector3(r * Mathf.Cos(a), r * Mathf.Sin(a), z); }
        Vector3 RandInSphere() => RandOnSphere() * Mathf.Pow(Rand(), 1f / 3f);
        float Dt => (m_Main.useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime) * m_Main.simulationSpeed;

        // ---------------- playback ----------------
        public void Play() => Play(true);
        public void Play(bool withChildren)
        {
            if (!m_Playing || m_Paused)
            {
                if (!m_Paused)
                {
                    m_Time = 0; m_EmitAcc = 0; m_DistAcc = 0; m_HasLastPos = false;
                    m_DelayLeft = m_Main.startDelay.Evaluate(0, Rand()) * m_Main.startDelayMultiplier;
                    m_BurstCycles = new int[m_Emission.bursts.Count];
                    if (useAutoRandomSeed) m_Rng = new System.Random(Environment.TickCount ^ GetHashCode()); else m_Rng = new System.Random((int)randomSeed);
                    if (m_Main.prewarm && m_Main.loop) Prewarm();
                }
                m_Playing = true; m_Paused = false; m_Emitting = true; m_StoppedNotified = false;
            }
            m_PlayOnAwakePending = false;
            if (withChildren) foreach (var c in Children()) c.Play(false);
        }
        public void Stop() => Stop(true, ParticleSystemStopBehavior.StopEmitting);
        public void Stop(bool withChildren) => Stop(withChildren, ParticleSystemStopBehavior.StopEmitting);
        public void Stop(bool withChildren, ParticleSystemStopBehavior stopBehavior)
        {
            m_Emitting = false; m_Paused = false;
            if (stopBehavior == ParticleSystemStopBehavior.StopEmittingAndClear) { m_Count = 0; m_Playing = false; }
            m_PlayOnAwakePending = false;
            if (withChildren) foreach (var c in Children()) c.Stop(false, stopBehavior);
        }
        public void Pause() => Pause(true);
        public void Pause(bool withChildren) { if (m_Playing) m_Paused = true; if (withChildren) foreach (var c in Children()) c.Pause(false); }
        public void Clear() => Clear(true);
        public void Clear(bool withChildren) { m_Count = 0; if (withChildren) foreach (var c in Children()) c.Clear(false); }
        public bool IsAlive() => IsAlive(true);
        public bool IsAlive(bool withChildren)
        {
            if (m_Count > 0 || isEmitting) return true;
            if (withChildren) foreach (var c in Children()) if (c.IsAlive(false)) return true;
            return false;
        }
        public void Simulate(float t) => Simulate(t, true, true, true);
        public void Simulate(float t, bool withChildren) => Simulate(t, withChildren, true, true);
        public void Simulate(float t, bool withChildren, bool restart) => Simulate(t, withChildren, restart, true);
        public void Simulate(float t, bool withChildren, bool restart, bool fixedTimeStep)
        {
            if (restart) { m_Count = 0; m_Playing = false; m_Paused = false; Play(false); }
            float step = 1f / 30f; while (t > 0) { float d = Math.Min(step, t); Advance(d); t -= d; }
            m_Paused = true;
            if (withChildren) foreach (var c in Children()) c.Simulate(t, false, restart, fixedTimeStep);
        }
        public void TriggerSubEmitter(int subEmitterIndex) { }
        public void TriggerSubEmitter(int subEmitterIndex, ref Particle particle) { }
        public void TriggerSubEmitter(int subEmitterIndex, List<Particle> particles) { }
        public void AllocateAxisOfRotationAttribute() { }
        public void AllocateMeshIndexAttribute() { }
        public void AllocateCustomDataAttribute(ParticleSystemCustomData stream) { }
        public int GetCustomParticleData(List<Vector4> customData, ParticleSystemCustomData streamIndex) { customData.Clear(); for (int i = 0; i < m_Count; i++) customData.Add(Vector4.zero); return m_Count; }
        public void SetCustomParticleData(List<Vector4> customData, ParticleSystemCustomData streamIndex) { }
        public static void ResetPreMappedBufferMemory() { }
        public static void SetMaximumPreMappedBufferCounts(int vertexBuffersCount, int indexBuffersCount) { }
        IEnumerable<ParticleSystem> Children()
        {
            foreach (var t in transform.m_Children) foreach (var ps in t.GetComponentsInChildren<ParticleSystem>(true)) if (ps != this) yield return ps;
        }
        void Prewarm() { float t = m_Main.duration; float step = 1f / 30f; while (t > 0) { Advance(step); t -= step; } m_Time = 0; }

        public int GetParticles(Particle[] particles) => GetParticles(particles, particles.Length, 0);
        public int GetParticles(Particle[] particles, int size) => GetParticles(particles, size, 0);
        public int GetParticles(Particle[] particles, int size, int offset)
        {
            if (particles == null) throw new ArgumentNullException(nameof(particles));
            int n = Math.Min(Math.Min(size, particles.Length), Math.Max(0, m_Count - offset));
            for (int i = 0; i < n; i++) particles[i] = m_Particles[offset + i];
            return n;
        }
        public void SetParticles(Particle[] particles) => SetParticles(particles, particles.Length, 0);
        public void SetParticles(Particle[] particles, int size) => SetParticles(particles, size, 0);
        public void SetParticles(Particle[] particles, int size, int offset)
        {
            int n = Math.Min(size, particles.Length);
            Ensure(offset + n);
            for (int i = 0; i < n; i++) m_Particles[offset + i] = particles[i];
            m_Count = offset + n;
            // particles whose lifetime was set to 0 or less are removed
            int w = 0; for (int i = 0; i < m_Count; i++) if (m_Particles[i].m_Lifetime > 0) m_Particles[w++] = m_Particles[i];
            m_Count = w;
        }
        void Ensure(int n) { if (m_Particles.Length < n) Array.Resize(ref m_Particles, Math.Max(n, m_Particles.Length * 2)); }

        public void Emit(int count)
        {
            for (int i = 0; i < count; i++) Spawn(null);
        }
        public void Emit(EmitParams emitParams, int count)
        {
            for (int i = 0; i < count; i++) Spawn(emitParams);
        }
        [Obsolete] public void Emit(Vector3 position, Vector3 velocity, float size, float lifetime, Color32 color)
        {
            var ep = new EmitParams { position = position, velocity = velocity, startSize = size, startLifetime = lifetime, startColor = color };
            Spawn(ep);
        }

        // ---------------- per frame ----------------
        internal void FrameUpdate()
        {
            if (m_Destroyed || m_GameObject == null) return;
            if (!m_GameObject.activeInHierarchy) return;
            if (m_PlayOnAwakePending) { m_PlayOnAwakePending = false; if (m_Main.playOnAwake && !m_Playing) Play(false); }
            if (m_Paused) return;
            float dt = Dt;
            if (dt <= 0) return;
            Advance(dt);
        }

        void Advance(float dt)
        {
            m_TotalTime += dt;
            var tr = transform;
            Vector3 pos = tr.position;
            if (m_Playing && m_Emitting)
            {
                if (m_DelayLeft > 0) { m_DelayLeft -= dt; if (m_DelayLeft > 0) { m_HasLastPos = false; goto simulate; } dt = -m_DelayLeft; }
                float prevT = m_Time;
                m_Time += dt;
                float dur = Math.Max(0.0001f, m_Main.duration);
                if (m_Emission.enabled)
                {
                    float rate = m_Emission.rateOverTime.Evaluate(Mathf.Clamp01(m_Time / dur), Rand());
                    m_EmitAcc += rate * dt;
                    if (m_HasLastPos && m_Emission.rateOverDistance.Max > 0)
                    {
                        m_DistAcc += (pos - m_LastPos).magnitude * m_Emission.rateOverDistance.Evaluate(Mathf.Clamp01(m_Time / dur), Rand());
                        int nd = (int)m_DistAcc; m_DistAcc -= nd; for (int i = 0; i < nd; i++) Spawn(null);
                    }
                    int n = (int)m_EmitAcc; m_EmitAcc -= n;
                    for (int i = 0; i < n; i++) Spawn(null);
                    Bursts(prevT, Math.Min(m_Time, dur));
                }
                if (m_Time >= dur)
                {
                    if (m_Main.loop) { m_Time -= dur; for (int i = 0; i < m_BurstCycles.Length; i++) m_BurstCycles[i] = 0; if (m_Emission.enabled) Bursts(-1e-6f, m_Time); }
                    else { m_Time = dur; m_Emitting = false; }
                }
            }
            simulate:
            m_LastPos = pos; m_HasLastPos = true;
            Step(dt);
            if (m_Playing && !m_Emitting && m_Count == 0)
            {
                m_Playing = false;
                if (!m_StoppedNotified) { m_StoppedNotified = true; OnStopped(); }
            }
        }

        void Bursts(float from, float to)
        {
            var b = m_Emission.bursts;
            if (m_BurstCycles.Length != b.Count) Array.Resize(ref m_BurstCycles, b.Count);
            for (int i = 0; i < b.Count; i++)
            {
                var br = b[i];
                int cycles = br.cycleCount <= 0 ? int.MaxValue : br.cycleCount; // 0 = infinite
                while (m_BurstCycles[i] < cycles)
                {
                    float t = br.time + m_BurstCycles[i] * Math.Max(0.0001f, br.repeatInterval);
                    if (t > to || t > m_Main.duration) break;
                    if (t > from || (from <= 0 && t <= 0 && m_BurstCycles[i] == 0))
                    {
                        if (Rand() <= br.probability) { int n = (int)Math.Round(br.count.Evaluate(Mathf.Clamp01(t / m_Main.duration), Rand())); for (int k = 0; k < n; k++) Spawn(null); }
                    }
                    m_BurstCycles[i]++;
                }
            }
        }

        void OnStopped()
        {
            switch (m_Main.stopAction)
            {
                case ParticleSystemStopAction.Disable: m_GameObject.SetActive(false); break;
                case ParticleSystemStopAction.Destroy: Object.Destroy(m_GameObject); break;
                case ParticleSystemStopAction.Callback: m_GameObject.SendMessage("OnParticleSystemStopped", SendMessageOptions.DontRequireReceiver); break;
            }
        }

        bool WorldSpace => m_Main.simulationSpace == ParticleSystemSimulationSpace.World;
        Matrix4x4 SpaceMatrix()
        {
            var t = m_Main.simulationSpace == ParticleSystemSimulationSpace.Custom && m_Main.customSimulationSpace != null ? m_Main.customSimulationSpace : transform;
            var m = t.localToWorldMatrix;
            if (m_Main.scalingMode != ParticleSystemScalingMode.Hierarchy && t == transform) m = Matrix4x4.TRS(t.position, t.rotation, m_Main.scalingMode == ParticleSystemScalingMode.Local ? t.localScale : Vector3.one);
            return m;
        }

        void Spawn(EmitParams? ep)
        {
            if (m_Count >= m_Main.maxParticles)
            {
                if (m_Main.ringBufferMode == ParticleSystemRingBufferMode.Disabled) return;
                Array.Copy(m_Particles, 1, m_Particles, 0, m_Count - 1); m_Count--;
            }
            Ensure(m_Count + 1);
            float normT = Mathf.Clamp01(m_Time / Math.Max(0.0001f, m_Main.duration));
            var p = new Particle();
            // shape: local position + direction
            Vector3 lp = Vector3.zero, dir = Vector3.forward;
            if (m_Shape.enabled) ShapeSample(out lp, out dir);
            float speed = m_Main.startSpeed.Evaluate(normT, Rand());
            Vector3 v = dir * speed;
            var sp = SpaceMatrix();
            bool world = WorldSpace || m_Main.simulationSpace == ParticleSystemSimulationSpace.Custom;
            Matrix4x4 emitM = transform.localToWorldMatrix;
            if (m_Main.scalingMode != ParticleSystemScalingMode.Hierarchy) emitM = Matrix4x4.TRS(transform.position, transform.rotation, m_Main.scalingMode == ParticleSystemScalingMode.Local ? transform.localScale : Vector3.one);
            if (WorldSpace) { lp = emitM.MultiplyPoint3x4(lp); v = emitM.MultiplyVector(v); }
            else if (m_Main.simulationSpace == ParticleSystemSimulationSpace.Custom && m_Main.customSimulationSpace != null) { var inv = m_Main.customSimulationSpace.worldToLocalMatrix; lp = inv.MultiplyPoint3x4(emitM.MultiplyPoint3x4(lp)); v = inv.MultiplyVector(emitM.MultiplyVector(v)); }
            if (m_InheritEnabled && world && m_HasLastPos && Time.deltaTime > 0) v += (transform.position - m_LastPos) / Time.deltaTime * m_InheritCurve.Evaluate(0, Rand());
            p.m_Position = lp; p.m_Velocity = v;
            float life = Math.Max(0.0001f, m_Main.startLifetime.Evaluate(normT, Rand()));
            p.m_StartLifetime = life; p.m_Lifetime = life;
            float r1 = Rand();
            p.m_StartSize = m_Main.startSize3D ? new Vector3(m_Main.startSize.Evaluate(normT, r1), m_Main.startSizeY.Evaluate(normT, r1), m_Main.startSizeZ.Evaluate(normT, r1)) : Vector3.one * m_Main.startSize.Evaluate(normT, r1);
            p.m_Rotation = m_Main.startRotation3D ? new Vector3(m_Main.startRotationX.Evaluate(normT, Rand()), m_Main.startRotationY.Evaluate(normT, Rand()), m_Main.startRotation.Evaluate(normT, Rand())) : new Vector3(0, 0, m_Main.startRotation.Evaluate(normT, Rand()));
            if (m_Main.flipRotation > 0 && Rand() < m_Main.flipRotation) p.m_Rotation = -p.m_Rotation;
            p.m_StartColor = m_Main.startColor.Evaluate(normT, Rand());
            p.m_RandomSeed = (uint)m_Rng.Next();
            if (ep.HasValue)
            {
                var e = ep.Value;
                if (e.m_PositionSet) p.m_Position = e.m_ApplyShapeToPosition ? p.m_Position + e.m_Particle.m_Position : e.m_Particle.m_Position;
                if (e.m_VelocitySet) p.m_Velocity = e.m_Particle.m_Velocity;
                if (e.m_StartLifetimeSet) { p.m_StartLifetime = Math.Max(0.0001f, e.m_Particle.m_StartLifetime); p.m_Lifetime = p.m_StartLifetime; }
                if (e.m_StartSizeSet) p.m_StartSize = e.m_Particle.m_StartSize;
                if (e.m_RotationSet) p.m_Rotation = e.m_Particle.m_Rotation;
                if (e.m_AngularVelocitySet) p.m_AngularVelocity = e.m_Particle.m_AngularVelocity;
                if (e.m_StartColorSet) p.m_StartColor = e.m_Particle.m_StartColor;
                if (e.m_RandomSeedSet) p.m_RandomSeed = e.m_Particle.m_RandomSeed;
                if (e.m_AxisOfRotationSet) p.axisOfRotation = e.m_Particle.axisOfRotation;
            }
            m_Particles[m_Count++] = p;
        }

        void ShapeSample(out Vector3 pos, out Vector3 dir)
        {
            var s = m_Shape;
            float arc = s.arc * Mathf.Deg2Rad;
            float RadiusSample() { float inner = 1 - s.radiusThickness; return s.radius * Mathf.Lerp(inner, 1, Mathf.Sqrt(Rand())); }
            switch (s.shapeType)
            {
                case ParticleSystemShapeType.Sphere: case ParticleSystemShapeType.SphereShell:
                    {
                        dir = RandOnSphere(); float r = s.shapeType == ParticleSystemShapeType.SphereShell ? s.radius : s.radius * Mathf.Lerp(1 - s.radiusThickness, 1, Mathf.Pow(Rand(), 1f / 3f)); pos = dir * r; break;
                    }
                case ParticleSystemShapeType.Hemisphere: case ParticleSystemShapeType.HemisphereShell:
                    {
                        dir = RandOnSphere(); if (dir.z < 0) dir.z = -dir.z; float r = s.shapeType == ParticleSystemShapeType.HemisphereShell ? s.radius : s.radius * Mathf.Lerp(1 - s.radiusThickness, 1, Mathf.Pow(Rand(), 1f / 3f)); pos = dir * r; break;
                    }
                case ParticleSystemShapeType.Box: case ParticleSystemShapeType.BoxShell: case ParticleSystemShapeType.BoxEdge:
                    pos = new Vector3(Rand() - 0.5f, Rand() - 0.5f, Rand() - 0.5f); dir = Vector3.forward; break;
                case ParticleSystemShapeType.Circle: case ParticleSystemShapeType.CircleEdge:
                    {
                        float a = Rand() * arc; float r = s.shapeType == ParticleSystemShapeType.CircleEdge ? s.radius : RadiusSample();
                        var d = new Vector3(Mathf.Cos(a), Mathf.Sin(a), 0); pos = d * r; dir = d; break;
                    }
                case ParticleSystemShapeType.SingleSidedEdge:
                    pos = new Vector3((Rand() * 2 - 1) * s.radius, 0, 0); dir = Vector3.up; break;
                case ParticleSystemShapeType.Rectangle:
                    pos = new Vector3(Rand() - 0.5f, Rand() - 0.5f, 0); dir = Vector3.forward; break;
                case ParticleSystemShapeType.Donut:
                    {
                        float a = Rand() * arc; var ring = new Vector3(Mathf.Cos(a), Mathf.Sin(a), 0) * s.radius; var tube = RandInSphere() * s.donutRadius;
                        pos = ring + tube; dir = (pos - ring).sqrMagnitude > 0 ? (pos - ring).normalized : ring.normalized; break;
                    }
                case ParticleSystemShapeType.Mesh: case ParticleSystemShapeType.MeshRenderer:
                    {
                        var mesh = s.shapeType == ParticleSystemShapeType.Mesh ? s.mesh : s.meshRenderer?.GetComponent<MeshFilter>()?.sharedMesh;
                        var verts = mesh?.vertices; var nrm = mesh?.normals;
                        if (verts != null && verts.Length > 0) { int i = m_Rng.Next(verts.Length); pos = verts[i]; dir = nrm != null && i < nrm.Length ? nrm[i] : Vector3.up; }
                        else { pos = Vector3.zero; dir = Vector3.up; }
                        break;
                    }
                default: // cone variants: emit from the base disc, directions spread by the angle (cone points along +Z)
                    {
                        float a = Rand() * arc; float rr = RadiusSample(); float frac = s.radius > 0 ? rr / s.radius : 0;
                        var d2 = new Vector3(Mathf.Cos(a), Mathf.Sin(a), 0);
                        float ang = s.angle * Mathf.Deg2Rad;
                        pos = d2 * rr;
                        dir = (Vector3.forward + d2 * Mathf.Tan(ang) * frac).normalized;
                        if (s.shapeType == ParticleSystemShapeType.ConeVolume || s.shapeType == ParticleSystemShapeType.ConeVolumeShell) pos += dir * (Rand() * s.length);
                        break;
                    }
            }
            if (s.randomPositionAmount > 0) pos += RandInSphere() * s.randomPositionAmount;
            if (s.sphericalDirectionAmount > 0 && pos.sqrMagnitude > 0) dir = Vector3.Slerp(dir, pos.normalized, s.sphericalDirectionAmount);
            if (s.randomDirectionAmount > 0) dir = Vector3.Slerp(dir, RandOnSphere(), s.randomDirectionAmount);
            var shapeM = Matrix4x4.TRS(s.position, Quaternion.Euler(s.rotation), s.scale);
            if (s.shapeType == ParticleSystemShapeType.Box || s.shapeType == ParticleSystemShapeType.Rectangle) pos = Vector3.Scale(pos, Vector3.one); // box size comes from scale
            pos = shapeM.MultiplyPoint3x4(pos); dir = shapeM.MultiplyVector(dir).normalized;
        }

        void Step(float dt)
        {
            if (m_Count == 0) return;
            var sp = SpaceMatrix();
            Vector3 gravityWorld = Physics.gravity;
            Vector3 gravity = WorldSpace ? gravityWorld : transform.InverseTransformDirection(gravityWorld);
            float normSys = Mathf.Clamp01(m_Time / Math.Max(0.0001f, m_Main.duration));
            float gm = m_Main.gravityModifier.Evaluate(normSys, 0.5f);
            int w = 0;
            for (int i = 0; i < m_Count; i++)
            {
                ref var p = ref m_Particles[i];
                p.m_Lifetime -= dt;
                if (p.m_Lifetime <= 0) continue;
                float age = 1 - p.m_Lifetime / p.m_StartLifetime;
                float rnd = (p.m_RandomSeed & 0xffff) / 65535f;
                p.m_Velocity += gravity * gm * dt;
                if (m_ForceOL.enabled)
                {
                    var f = new Vector3(m_ForceOL.x.Evaluate(age, rnd), m_ForceOL.y.Evaluate(age, rnd), m_ForceOL.z.Evaluate(age, rnd));
                    p.m_Velocity += ToSimSpace(f, m_ForceOL.space) * dt;
                }
                Vector3 anim = Vector3.zero;
                if (m_VelOL.enabled)
                {
                    anim = ToSimSpace(new Vector3(m_VelOL.x.Evaluate(age, rnd), m_VelOL.y.Evaluate(age, rnd), m_VelOL.z.Evaluate(age, rnd)), m_VelOL.space);
                    float rad = m_VelOL.radial.Evaluate(age, rnd);
                    if (rad != 0 && p.m_Position.sqrMagnitude > 0) anim += p.m_Position.normalized * rad;
                }
                if (m_Noise.enabled)
                {
                    float fq = m_Noise.frequency, t = m_TotalTime * m_Noise.scrollSpeed.Evaluate(age, rnd);
                    var q = p.m_Position * fq;
                    var nv = new Vector3(Mathf.PerlinNoise(q.y + t, q.z) - 0.5f, Mathf.PerlinNoise(q.z + 31.4f + t, q.x) - 0.5f, Mathf.PerlinNoise(q.x + 17.7f + t, q.y) - 0.5f) * 2f;
                    float st = m_Noise.strength.Evaluate(age, rnd);
                    anim += nv * st * m_Noise.positionAmount.Evaluate(age, rnd);
                }
                if (m_Limit.enabled)
                {
                    float lim = m_Limit.limit.Evaluate(age, rnd);
                    float spd = p.m_Velocity.magnitude;
                    if (spd > lim) p.m_Velocity = Vector3.Lerp(p.m_Velocity, p.m_Velocity / spd * lim, m_Limit.dampen);
                    float drag = m_Limit.drag.Evaluate(age, rnd);
                    if (drag > 0) p.m_Velocity *= Math.Max(0, 1 - drag * dt);
                }
                p.m_AnimatedVelocity = anim;
                Vector3 total = p.m_Velocity + anim;
                Vector3 prev = p.m_Position;
                p.m_Position += total * dt;
                p.m_Rotation += p.m_AngularVelocity * dt;
                if (m_RotOL.enabled) p.m_Rotation += new Vector3(m_RotOL.separateAxes ? m_RotOL.x.Evaluate(age, rnd) : 0, m_RotOL.separateAxes ? m_RotOL.y.Evaluate(age, rnd) : 0, m_RotOL.z.Evaluate(age, rnd)) * dt;
                if (m_Collision.enabled && Collide(ref p, prev, sp)) { if (p.m_Lifetime <= 0) continue; }
                m_Particles[w++] = p;
            }
            m_Count = w;
        }

        Vector3 ToSimSpace(Vector3 v, ParticleSystemSimulationSpace space)
        {
            if (space == ParticleSystemSimulationSpace.World && !WorldSpace) return transform.InverseTransformDirection(v);
            if (space == ParticleSystemSimulationSpace.Local && WorldSpace) return transform.TransformDirection(v);
            return v;
        }

        bool Collide(ref Particle p, Vector3 prev, Matrix4x4 sp)
        {
            var c = m_Collision;
            Vector3 a = WorldSpace ? prev : sp.MultiplyPoint3x4(prev), b = WorldSpace ? p.m_Position : sp.MultiplyPoint3x4(p.m_Position);
            float radius = CurrentSize(ref p).x * 0.5f * c.radiusScale;
            float age = 1 - p.m_Lifetime / p.m_StartLifetime; float rnd = (p.m_RandomSeed & 0xffff) / 65535f;
            Vector3 hitPoint = default, normal = default; GameObject hitGo = null; bool hit = false;
            if (c.type == ParticleSystemCollisionType.Planes)
            {
                foreach (var pl in c.planes)
                {
                    if (pl == null) continue;
                    Vector3 n = pl.up, o = pl.position;
                    float da = Vector3.Dot(a - o, n) - radius, db = Vector3.Dot(b - o, n) - radius;
                    if (da >= 0 && db < 0) { float t = da / (da - db); hitPoint = Vector3.Lerp(a, b, t); normal = n; hit = true; break; }
                }
            }
            else
            {
                var d = b - a; float len = d.magnitude;
                if (len > 1e-6f && Physics.SphereCast(a, Math.Max(0.001f, radius), d / len, out var rh, len, c.collidesWith, QueryTriggerInteraction.Ignore))
                { hitPoint = rh.point + rh.normal * radius; normal = rh.normal; hitGo = rh.collider != null ? rh.collider.gameObject : null; hit = true; }
            }
            if (!hit) return false;
            Vector3 v = WorldSpace ? p.m_Velocity : sp.MultiplyVector(p.m_Velocity);
            float speed = v.magnitude;
            Vector3 vn = normal * Vector3.Dot(v, normal), vt = v - vn;
            float bounce = c.bounce.Evaluate(age, rnd), dampen = c.dampen.Evaluate(age, rnd);
            v = (vt - vn * bounce) * (1 - dampen);
            Vector3 np = hitPoint;
            if (WorldSpace) { p.m_Position = np; p.m_Velocity = v; }
            else { var inv = sp.inverse; p.m_Position = inv.MultiplyPoint3x4(np); p.m_Velocity = inv.MultiplyVector(v); }
            p.m_Lifetime -= p.m_StartLifetime * c.lifetimeLoss.Evaluate(age, rnd);
            if (speed < c.minKillSpeed || speed > c.maxKillSpeed) p.m_Lifetime = 0;
            if (c.sendCollisionMessages && hitGo != null)
            {
                hitGo.SendMessage("OnParticleCollision", m_GameObject, SendMessageOptions.DontRequireReceiver);
                m_GameObject.SendMessage("OnParticleCollision", hitGo, SendMessageOptions.DontRequireReceiver);
            }
            return true;
        }

        internal Vector3 CurrentSize(ref Particle p)
        {
            Vector3 s = p.m_StartSize;
            float age = p.m_StartLifetime > 0 ? 1 - p.m_Lifetime / p.m_StartLifetime : 0; float rnd = (p.m_RandomSeed & 0xffff) / 65535f;
            if (m_SizeOL.enabled)
            {
                if (m_SizeOL.separateAxes) s = Vector3.Scale(s, new Vector3(m_SizeOL.size.Evaluate(age, rnd), m_SizeOL.y.Evaluate(age, rnd), m_SizeOL.z.Evaluate(age, rnd)));
                else s *= m_SizeOL.size.Evaluate(age, rnd);
            }
            if (m_SizeBS.enabled)
            {
                float sp = (p.m_Velocity + p.m_AnimatedVelocity).magnitude; float t = Mathf.InverseLerp(m_SizeBS.range.x, m_SizeBS.range.y, sp);
                s *= m_SizeBS.size.Evaluate(t, rnd);
            }
            return s;
        }
        internal Color32 CurrentColor(ref Particle p)
        {
            Color c = p.m_StartColor;
            float age = p.m_StartLifetime > 0 ? 1 - p.m_Lifetime / p.m_StartLifetime : 0; float rnd = (p.m_RandomSeed & 0xffff) / 65535f;
            if (m_ColorOL.enabled) c *= m_ColorOL.color.Evaluate(age, rnd);
            if (m_ColorBS.enabled) { float sp = (p.m_Velocity + p.m_AnimatedVelocity).magnitude; c *= m_ColorBS.color.Evaluate(Mathf.InverseLerp(m_ColorBS.range.x, m_ColorBS.range.y, sp), rnd); }
            return c;
        }

        // world-space data for the renderer: per particle position(3) size(1) colour(4) velocity(3) rotation(1)
        internal int RenderData(List<float> o)
        {
            if (m_Count == 0) return 0;
            var m = WorldSpace ? Matrix4x4.identity : SpaceMatrix();
            float scale = WorldSpace ? 1 : 1; // sizes aren't scaled by the transform (like Unity's default 'Local' scaling)
            for (int i = 0; i < m_Count; i++)
            {
                ref var p = ref m_Particles[i];
                var pos = WorldSpace ? p.m_Position : m.MultiplyPoint3x4(p.m_Position);
                var vel = WorldSpace ? p.m_Velocity + p.m_AnimatedVelocity : m.MultiplyVector(p.m_Velocity + p.m_AnimatedVelocity);
                var size = CurrentSize(ref p).x * scale;
                Color col = CurrentColor(ref p);
                o.Add(pos.x); o.Add(pos.y); o.Add(pos.z); o.Add(size);
                o.Add(col.r); o.Add(col.g); o.Add(col.b); o.Add(col.a);
                o.Add(vel.x); o.Add(vel.y); o.Add(vel.z); o.Add(p.m_Rotation.z);
            }
            return m_Count;
        }
    }
}
