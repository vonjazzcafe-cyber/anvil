// Anvil — UnityEngine.Mesh: vertex data, sub-meshes and the Unity API to build meshes from code.
// Built-in primitives keep their name (the editor draws them with its own geometry) but also have real vertex data,
// so mesh.vertices works on them too. Meshes built or changed by scripts are sent to the renderer when they change.
using System;
using System.Collections.Generic;
using Anvil;
using UnityEngine.Rendering;

namespace UnityEngine
{
    public struct CombineInstance
    {
        public Mesh mesh { get; set; }
        public int subMeshIndex { get; set; }
        public Matrix4x4 transform { get; set; }
        public Vector4 lightmapScaleOffset { get; set; }
        public Vector4 realtimeLightmapScaleOffset { get; set; }
    }

    public struct BoneWeight
    {
        public float weight0 { get; set; } public float weight1 { get; set; } public float weight2 { get; set; } public float weight3 { get; set; }
        public int boneIndex0 { get; set; } public int boneIndex1 { get; set; } public int boneIndex2 { get; set; } public int boneIndex3 { get; set; }
    }

    public sealed class Mesh : Object
    {
        internal string m_Primitive;          // "Cube", "Sphere"... for built-in meshes until a script changes them
        internal readonly int m_Uid = ++s_NextUid;
        internal int m_Version = 1;
        static int s_NextUid;

        Vector3[] m_Vertices = Array.Empty<Vector3>();
        Vector3[] m_Normals = Array.Empty<Vector3>();
        Vector4[] m_Tangents = Array.Empty<Vector4>();
        Color[] m_Colors = Array.Empty<Color>();
        readonly Vector4[][] m_UV = new Vector4[8][];
        readonly int[] m_UVDim = new int[8];
        internal struct Sub { public int[] indices; public MeshTopology topology; public int baseVertex; }
        internal List<Sub> m_Subs = new List<Sub> { new Sub { indices = Array.Empty<int>(), topology = MeshTopology.Triangles } };
        Bounds m_Bounds;
        bool m_DataBuilt;                     // primitives build their vertex data on first use

        public Mesh() { m_Name = ""; m_DataBuilt = true; }
        // a mesh inside an imported model file ("Assets/Robot.fbx#2"): its data comes from the page the first time it's needed
        internal string m_AssetKey;
        internal int m_AssetSubs = 1;
        internal static Func<string, byte[]> s_AssetData;
        internal static Mesh FromAsset(string key, string name, int subs, Bounds bounds)
        {
            var m = new Mesh { m_AssetKey = key, m_Name = name, m_DataBuilt = false, m_AssetSubs = Math.Max(1, subs) };
            m.m_Bounds = bounds; m.m_IsAsset = true;
            return m;
        }
        // drawn straight from the page's copy of the model (nothing to upload) while no script has changed it
        internal bool IsPristineAsset => m_AssetKey != null && m_Version == 1;
        internal int RenderSubCount => m_Primitive != null ? 1 : (!m_DataBuilt && m_AssetKey != null ? m_AssetSubs : m_Subs.Count);
        internal static Mesh Primitive(string n)
        {
            var m = new Mesh { m_Primitive = n, m_Name = n, m_DataBuilt = n == null };
            m.m_Bounds = PrimitiveMeshes.BoundsOf(n);
            m.m_IsAsset = true;
            return m;
        }
        void Data()
        {
            if (m_DataBuilt) return;
            m_DataBuilt = true;
            if (m_AssetKey != null)
            {
                var bytes = s_AssetData?.Invoke(m_AssetKey);
                if (bytes != null && bytes.Length >= 12) Unpack(bytes);
                return;
            }
            PrimitiveMeshes.Build(m_Primitive, this);
        }
        // a script changed the data: from now on this mesh is drawn from its own vertices
        void Changed() { Data(); m_Primitive = null; m_Version++; }

        public IndexFormat indexFormat { get; set; } = IndexFormat.UInt16;
        public bool isReadable => true;
        public int vertexCount { get { Data(); return m_Vertices.Length; } }
        public int subMeshCount
        {
            get { Data(); return m_Subs.Count; }
            set
            {
                Data(); value = Math.Max(0, value);
                while (m_Subs.Count < value) m_Subs.Add(new Sub { indices = Array.Empty<int>(), topology = MeshTopology.Triangles });
                if (m_Subs.Count > value) m_Subs.RemoveRange(value, m_Subs.Count - value);
                Changed();
            }
        }
        public Bounds bounds { get { Data(); return m_Bounds; } set { Data(); m_Bounds = value; } }
        public int vertexBufferCount => 1;
        public int blendShapeCount => 0;
        Matrix4x4[] m_Bindposes = Array.Empty<Matrix4x4>();
        BoneWeight[] m_BoneWeights = Array.Empty<BoneWeight>();
        public Matrix4x4[] bindposes { get { Data(); return (Matrix4x4[])m_Bindposes.Clone(); } set { Data(); m_Bindposes = value ?? Array.Empty<Matrix4x4>(); Changed(); } }
        public BoneWeight[] boneWeights { get { Data(); return (BoneWeight[])m_BoneWeights.Clone(); } set { Data(); m_BoneWeights = value ?? Array.Empty<BoneWeight>(); Changed(); } }
        internal Matrix4x4[] BindposesRaw { get { Data(); return m_Bindposes; } }
        internal BoneWeight[] BoneWeightsRaw { get { Data(); return m_BoneWeights; } }
        public void GetBindposes(List<Matrix4x4> list) { Data(); list.Clear(); list.AddRange(m_Bindposes); }
        public void GetBoneWeights(List<BoneWeight> list) { Data(); list.Clear(); list.AddRange(m_BoneWeights); }

        // ---- vertex channels (getters return copies, like Unity) ----
        public Vector3[] vertices
        {
            get { Data(); return (Vector3[])m_Vertices.Clone(); }
            set { SetVerticesInternal(value ?? Array.Empty<Vector3>(), 0, value?.Length ?? 0); }
        }
        public Vector3[] normals { get { Data(); return (Vector3[])m_Normals.Clone(); } set { Data(); m_Normals = Fit(value, "normals"); Changed(); } }
        public Vector4[] tangents { get { Data(); return (Vector4[])m_Tangents.Clone(); } set { Data(); m_Tangents = Fit(value, "tangents"); Changed(); } }
        public Color[] colors { get { Data(); return (Color[])m_Colors.Clone(); } set { Data(); m_Colors = Fit(value, "colors"); Changed(); } }
        public Color32[] colors32
        {
            get { Data(); var r = new Color32[m_Colors.Length]; for (int i = 0; i < r.Length; i++) r[i] = m_Colors[i]; return r; }
            set { Data(); var c = new Color[value?.Length ?? 0]; for (int i = 0; i < c.Length; i++) c[i] = value[i]; m_Colors = Fit(c, "colors"); Changed(); }
        }
        public Vector2[] uv { get => GetUV2(0); set => SetUV(0, value); }
        public Vector2[] uv2 { get => GetUV2(1); set => SetUV(1, value); }
        public Vector2[] uv3 { get => GetUV2(2); set => SetUV(2, value); }
        public Vector2[] uv4 { get => GetUV2(3); set => SetUV(3, value); }
        public Vector2[] uv5 { get => GetUV2(4); set => SetUV(4, value); }
        public Vector2[] uv6 { get => GetUV2(5); set => SetUV(5, value); }
        public Vector2[] uv7 { get => GetUV2(6); set => SetUV(6, value); }
        public Vector2[] uv8 { get => GetUV2(7); set => SetUV(7, value); }
        public int[] triangles
        {
            get
            {
                Data(); var all = new List<int>();
                foreach (var s in m_Subs) if (s.topology == MeshTopology.Triangles) foreach (var i in s.indices) all.Add(i + s.baseVertex);
                return all.ToArray();
            }
            set
            {
                Data();
                var v = value ?? Array.Empty<int>();
                if (!CheckIndices(v, 0, "triangles")) return;
                if (v.Length % 3 != 0) { Debug.LogError("Failed setting triangles. The number of supplied triangle indices must be a multiple of 3."); return; }
                m_Subs.Clear(); m_Subs.Add(new Sub { indices = (int[])v.Clone(), topology = MeshTopology.Triangles });
                RecalcBounds(); Changed();
            }
        }

        T[] Fit<T>(T[] v, string what)
        {
            v ??= Array.Empty<T>();
            if (v.Length != 0 && v.Length != m_Vertices.Length) { Debug.LogError($"Mesh.{what} is out of bounds. The supplied array needs to be the same size as the Mesh.vertices array."); return v.Length > m_Vertices.Length ? v[..m_Vertices.Length] : Resize(v, m_Vertices.Length); }
            return (T[])v.Clone();
        }
        static T[] Resize<T>(T[] a, int n) { var r = new T[n]; Array.Copy(a, r, Math.Min(n, a.Length)); return r; }
        Vector2[] GetUV2(int ch)
        {
            Data(); var src = m_UV[ch]; if (src == null) return Array.Empty<Vector2>();
            var r = new Vector2[src.Length]; for (int i = 0; i < r.Length; i++) r[i] = new Vector2(src[i].x, src[i].y); return r;
        }
        void SetUV(int ch, Vector2[] v)
        {
            Data();
            if (v == null || v.Length == 0) { m_UV[ch] = null; m_UVDim[ch] = 0; Changed(); return; }
            var r = new Vector4[v.Length]; for (int i = 0; i < r.Length; i++) r[i] = new Vector4(v[i].x, v[i].y, 0, 0);
            m_UV[ch] = Fit(r, "uv"); m_UVDim[ch] = 2; Changed();
        }
        void SetVerticesInternal(IList<Vector3> v, int start, int length)
        {
            Data();
            var arr = new Vector3[length];
            for (int i = 0; i < length; i++) arr[i] = v[start + i];
            int n = arr.Length;
            if (n != m_Vertices.Length)
            {
                // other vertex channels follow the new vertex count
                if (m_Normals.Length > 0) m_Normals = Resize(m_Normals, n);
                if (m_Tangents.Length > 0) m_Tangents = Resize(m_Tangents, n);
                if (m_Colors.Length > 0) m_Colors = Resize(m_Colors, n);
                for (int c = 0; c < 8; c++) if (m_UV[c] != null) m_UV[c] = Resize(m_UV[c], n);
            }
            m_Vertices = arr;
            RecalcBounds(); Changed();
        }
        bool CheckIndices(IList<int> idx, int baseVertex, string what)
        {
            int n = m_Vertices.Length;
            for (int i = 0; i < idx.Count; i++)
            {
                int k = idx[i] + baseVertex;
                if (k < 0 || k >= n) { Debug.LogError($"Failed setting {what}. Some indices are referencing out of bounds vertices. IndexCount: {idx.Count}, VertexCount: {n}"); return false; }
            }
            return true;
        }

        // ---- Set* / Get* ----
        public void SetVertices(Vector3[] inVertices) => SetVerticesInternal(inVertices ?? Array.Empty<Vector3>(), 0, inVertices?.Length ?? 0);
        public void SetVertices(List<Vector3> inVertices) => SetVerticesInternal(inVertices ?? new List<Vector3>(), 0, inVertices?.Count ?? 0);
        public void SetVertices(Vector3[] inVertices, int start, int length) => SetVerticesInternal(inVertices, start, length);
        public void SetVertices(List<Vector3> inVertices, int start, int length) => SetVerticesInternal(inVertices, start, length);
        public void SetVertices(Vector3[] inVertices, int start, int length, MeshUpdateFlags flags) => SetVerticesInternal(inVertices, start, length);
        public void SetVertices(List<Vector3> inVertices, int start, int length, MeshUpdateFlags flags) => SetVerticesInternal(inVertices, start, length);
        public void SetNormals(Vector3[] inNormals) => normals = inNormals;
        public void SetNormals(List<Vector3> inNormals) => normals = inNormals?.ToArray();
        public void SetNormals(List<Vector3> inNormals, int start, int length) => normals = inNormals.GetRange(start, length).ToArray();
        public void SetNormals(Vector3[] inNormals, int start, int length) => normals = inNormals[start..(start + length)];
        public void SetTangents(Vector4[] inTangents) => tangents = inTangents;
        public void SetTangents(List<Vector4> inTangents) => tangents = inTangents?.ToArray();
        public void SetColors(Color[] inColors) => colors = inColors;
        public void SetColors(List<Color> inColors) => colors = inColors?.ToArray();
        public void SetColors(Color32[] inColors) => colors32 = inColors;
        public void SetColors(List<Color32> inColors) => colors32 = inColors?.ToArray();
        public void SetUVs(int channel, Vector2[] uvs) => SetUVsAny(channel, uvs, 2, x => new Vector4(x.x, x.y, 0, 0));
        public void SetUVs(int channel, List<Vector2> uvs) => SetUVsAny(channel, uvs, 2, x => new Vector4(x.x, x.y, 0, 0));
        public void SetUVs(int channel, Vector3[] uvs) => SetUVsAny(channel, uvs, 3, x => new Vector4(x.x, x.y, x.z, 0));
        public void SetUVs(int channel, List<Vector3> uvs) => SetUVsAny(channel, uvs, 3, x => new Vector4(x.x, x.y, x.z, 0));
        public void SetUVs(int channel, Vector4[] uvs) => SetUVsAny(channel, uvs, 4, x => x);
        public void SetUVs(int channel, List<Vector4> uvs) => SetUVsAny(channel, uvs, 4, x => x);
        void SetUVsAny<T>(int channel, IList<T> uvs, int dim, Func<T, Vector4> f)
        {
            if (channel < 0 || channel > 7) throw new ArgumentException("The uv index is invalid. Must be in the range 0 to 7.");
            Data();
            if (uvs == null || uvs.Count == 0) { m_UV[channel] = null; m_UVDim[channel] = 0; Changed(); return; }
            var r = new Vector4[uvs.Count]; for (int i = 0; i < r.Length; i++) r[i] = f(uvs[i]);
            m_UV[channel] = Fit(r, "uv"); m_UVDim[channel] = dim; Changed();
        }
        public void GetVertices(List<Vector3> vertices) { Data(); vertices.Clear(); vertices.AddRange(m_Vertices); }
        public void GetNormals(List<Vector3> normals) { Data(); normals.Clear(); normals.AddRange(m_Normals); }
        public void GetTangents(List<Vector4> tangents) { Data(); tangents.Clear(); tangents.AddRange(m_Tangents); }
        public void GetColors(List<Color> colors) { Data(); colors.Clear(); colors.AddRange(m_Colors); }
        public void GetColors(List<Color32> colors) { Data(); colors.Clear(); foreach (var c in m_Colors) colors.Add(c); }
        public void GetUVs(int channel, List<Vector2> uvs) { Data(); uvs.Clear(); if (m_UV[channel] != null) foreach (var u in m_UV[channel]) uvs.Add(new Vector2(u.x, u.y)); }
        public void GetUVs(int channel, List<Vector3> uvs) { Data(); uvs.Clear(); if (m_UV[channel] != null) foreach (var u in m_UV[channel]) uvs.Add(new Vector3(u.x, u.y, u.z)); }
        public void GetUVs(int channel, List<Vector4> uvs) { Data(); uvs.Clear(); if (m_UV[channel] != null) uvs.AddRange(m_UV[channel]); }
        public bool HasVertexAttribute(VertexAttribute attr)
        {
            Data();
            switch (attr)
            {
                case VertexAttribute.Position: return m_Vertices.Length > 0;
                case VertexAttribute.Normal: return m_Normals.Length > 0;
                case VertexAttribute.Tangent: return m_Tangents.Length > 0;
                case VertexAttribute.Color: return m_Colors.Length > 0;
                default: int ch = (int)attr - (int)VertexAttribute.TexCoord0; return ch >= 0 && ch < 8 && m_UV[ch] != null;
            }
        }

        Sub GetSub(int submesh)
        {
            Data();
            if (submesh < 0 || submesh >= m_Subs.Count) throw new IndexOutOfRangeException($"Specified sub mesh ({submesh}) is out of range. Must be greater or equal to 0 and less than subMeshCount ({m_Subs.Count}).");
            return m_Subs[submesh];
        }
        public int[] GetTriangles(int submesh) => GetTriangles(submesh, true);
        public int[] GetTriangles(int submesh, bool applyBaseVertex)
        {
            var s = GetSub(submesh); if (s.topology != MeshTopology.Triangles) return Array.Empty<int>();
            var r = (int[])s.indices.Clone(); if (applyBaseVertex && s.baseVertex != 0) for (int i = 0; i < r.Length; i++) r[i] += s.baseVertex; return r;
        }
        public void GetTriangles(List<int> triangles, int submesh) { triangles.Clear(); triangles.AddRange(GetTriangles(submesh)); }
        public void GetTriangles(List<int> triangles, int submesh, bool applyBaseVertex) { triangles.Clear(); triangles.AddRange(GetTriangles(submesh, applyBaseVertex)); }
        public int[] GetIndices(int submesh) => GetIndices(submesh, true);
        public int[] GetIndices(int submesh, bool applyBaseVertex) { var s = GetSub(submesh); var r = (int[])s.indices.Clone(); if (applyBaseVertex && s.baseVertex != 0) for (int i = 0; i < r.Length; i++) r[i] += s.baseVertex; return r; }
        public void GetIndices(List<int> indices, int submesh) { indices.Clear(); indices.AddRange(GetIndices(submesh)); }
        public void GetIndices(List<int> indices, int submesh, bool applyBaseVertex) { indices.Clear(); indices.AddRange(GetIndices(submesh, applyBaseVertex)); }
        public MeshTopology GetTopology(int submesh) => GetSub(submesh).topology;
        public uint GetIndexCount(int submesh) => (uint)GetSub(submesh).indices.Length;
        public uint GetIndexStart(int submesh) { Data(); uint s = 0; for (int i = 0; i < submesh && i < m_Subs.Count; i++) s += (uint)m_Subs[i].indices.Length; return s; }
        public uint GetBaseVertex(int submesh) => (uint)GetSub(submesh).baseVertex;

        public void SetTriangles(int[] triangles, int submesh) => SetIndicesImpl(triangles, MeshTopology.Triangles, submesh, true, 0, "triangles");
        public void SetTriangles(int[] triangles, int submesh, bool calculateBounds) => SetIndicesImpl(triangles, MeshTopology.Triangles, submesh, calculateBounds, 0, "triangles");
        public void SetTriangles(int[] triangles, int submesh, bool calculateBounds, int baseVertex) => SetIndicesImpl(triangles, MeshTopology.Triangles, submesh, calculateBounds, baseVertex, "triangles");
        public void SetTriangles(List<int> triangles, int submesh) => SetIndicesImpl(triangles, MeshTopology.Triangles, submesh, true, 0, "triangles");
        public void SetTriangles(List<int> triangles, int submesh, bool calculateBounds) => SetIndicesImpl(triangles, MeshTopology.Triangles, submesh, calculateBounds, 0, "triangles");
        public void SetTriangles(List<int> triangles, int submesh, bool calculateBounds, int baseVertex) => SetIndicesImpl(triangles, MeshTopology.Triangles, submesh, calculateBounds, baseVertex, "triangles");
        public void SetIndices(int[] indices, MeshTopology topology, int submesh) => SetIndicesImpl(indices, topology, submesh, true, 0, "indices");
        public void SetIndices(int[] indices, MeshTopology topology, int submesh, bool calculateBounds) => SetIndicesImpl(indices, topology, submesh, calculateBounds, 0, "indices");
        public void SetIndices(int[] indices, MeshTopology topology, int submesh, bool calculateBounds, int baseVertex) => SetIndicesImpl(indices, topology, submesh, calculateBounds, baseVertex, "indices");
        public void SetIndices(List<int> indices, MeshTopology topology, int submesh) => SetIndicesImpl(indices, topology, submesh, true, 0, "indices");
        public void SetIndices(List<int> indices, MeshTopology topology, int submesh, bool calculateBounds) => SetIndicesImpl(indices, topology, submesh, calculateBounds, 0, "indices");
        public void SetIndices(List<int> indices, MeshTopology topology, int submesh, bool calculateBounds, int baseVertex) => SetIndicesImpl(indices, topology, submesh, calculateBounds, baseVertex, "indices");
        void SetIndicesImpl(IList<int> idx, MeshTopology topology, int submesh, bool calculateBounds, int baseVertex, string what)
        {
            Data();
            idx ??= Array.Empty<int>();
            if (submesh < 0 || submesh >= m_Subs.Count) { Debug.LogError($"Failed setting {what}. Submesh index is out of bounds."); return; }
            if (!CheckIndices(idx, baseVertex, what)) return;
            int per = topology == MeshTopology.Triangles ? 3 : topology == MeshTopology.Quads ? 4 : topology == MeshTopology.Lines ? 2 : 1;
            if (idx.Count % per != 0) { Debug.LogError($"Failed setting {what}. The number of supplied indices must be a multiple of {per}."); return; }
            var arr = new int[idx.Count]; idx.CopyTo(arr, 0);
            m_Subs[submesh] = new Sub { indices = arr, topology = topology, baseVertex = baseVertex };
            if (calculateBounds) RecalcBounds();
            Changed();
        }

        public void Clear() => Clear(true);
        public void Clear(bool keepVertexLayout)
        {
            m_DataBuilt = true; m_Primitive = null; m_AssetKey = null;
            m_BoneWeights = Array.Empty<BoneWeight>(); m_Bindposes = Array.Empty<Matrix4x4>();
            m_Vertices = Array.Empty<Vector3>(); m_Normals = Array.Empty<Vector3>(); m_Tangents = Array.Empty<Vector4>(); m_Colors = Array.Empty<Color>();
            for (int i = 0; i < 8; i++) { m_UV[i] = null; m_UVDim[i] = 0; }
            m_Subs.Clear(); m_Subs.Add(new Sub { indices = Array.Empty<int>(), topology = MeshTopology.Triangles });
            m_Bounds = default; m_Version++;
        }
        public void RecalculateBounds() { Data(); RecalcBounds(); }
        public void RecalculateBounds(MeshUpdateFlags flags) => RecalculateBounds();
        void RecalcBounds()
        {
            if (m_Vertices.Length == 0) { m_Bounds = default; return; }
            Vector3 mn = m_Vertices[0], mx = m_Vertices[0];
            foreach (var v in m_Vertices) { mn = Vector3.Min(mn, v); mx = Vector3.Max(mx, v); }
            m_Bounds = new Bounds((mn + mx) * 0.5f, mx - mn);
        }
        public void RecalculateNormals() => RecalculateNormals(MeshUpdateFlags.Default);
        public void RecalculateNormals(MeshUpdateFlags flags)
        {
            Data();
            var n = new Vector3[m_Vertices.Length];
            foreach (var s in m_Subs)
            {
                if (s.topology != MeshTopology.Triangles) continue;
                var ix = s.indices; int b = s.baseVertex;
                for (int i = 0; i + 2 < ix.Length; i += 3)
                {
                    int a0 = ix[i] + b, a1 = ix[i + 1] + b, a2 = ix[i + 2] + b;
                    // Unity is left-handed: clockwise triangles face the viewer, so the normal is (b-a)x(c-a)
                    var fn = Vector3.Cross(m_Vertices[a1] - m_Vertices[a0], m_Vertices[a2] - m_Vertices[a0]);
                    n[a0] += fn; n[a1] += fn; n[a2] += fn;
                }
            }
            for (int i = 0; i < n.Length; i++) n[i] = n[i].sqrMagnitude > 0 ? n[i].normalized : Vector3.zero;
            m_Normals = n; Changed();
        }
        public void RecalculateTangents() => RecalculateTangents(MeshUpdateFlags.Default);
        public void RecalculateTangents(MeshUpdateFlags flags)
        {
            Data();
            int vc = m_Vertices.Length;
            var uv = m_UV[0];
            if (uv == null || m_Normals.Length != vc) { m_Tangents = new Vector4[vc]; for (int i = 0; i < vc; i++) m_Tangents[i] = new Vector4(1, 0, 0, 1); Changed(); return; }
            var t1 = new Vector3[vc]; var t2 = new Vector3[vc];
            foreach (var s in m_Subs)
            {
                if (s.topology != MeshTopology.Triangles) continue;
                var ix = s.indices; int b = s.baseVertex;
                for (int i = 0; i + 2 < ix.Length; i += 3)
                {
                    int i0 = ix[i] + b, i1 = ix[i + 1] + b, i2 = ix[i + 2] + b;
                    Vector3 e1 = m_Vertices[i1] - m_Vertices[i0], e2 = m_Vertices[i2] - m_Vertices[i0];
                    float s1 = uv[i1].x - uv[i0].x, s2 = uv[i2].x - uv[i0].x, u1 = uv[i1].y - uv[i0].y, u2 = uv[i2].y - uv[i0].y;
                    float d = s1 * u2 - s2 * u1; float r = Math.Abs(d) < 1e-12f ? 0 : 1f / d;
                    var sdir = (e1 * u2 - e2 * u1) * r; var tdir = (e2 * s1 - e1 * s2) * r;
                    t1[i0] += sdir; t1[i1] += sdir; t1[i2] += sdir; t2[i0] += tdir; t2[i1] += tdir; t2[i2] += tdir;
                }
            }
            m_Tangents = new Vector4[vc];
            for (int i = 0; i < vc; i++)
            {
                var nn = m_Normals[i]; var t = t1[i];
                var tt = (t - nn * Vector3.Dot(nn, t)); tt = tt.sqrMagnitude > 0 ? tt.normalized : Vector3.right;
                float w = Vector3.Dot(Vector3.Cross(nn, t), t2[i]) < 0 ? -1f : 1f;
                m_Tangents[i] = new Vector4(tt.x, tt.y, tt.z, w);
            }
            Changed();
        }
        public void RecalculateUVDistributionMetrics(float uvAreaThreshold = 1e-9f) { }
        public float GetUVDistributionMetric(int uvSetIndex) => 1f;
        public void MarkDynamic() { }
        public void MarkModified() { m_Version++; }
        public void UploadMeshData(bool markNoLongerReadable) { m_Version++; }
        public void Optimize() { }
        public void OptimizeIndexBuffers() { }
        public void OptimizeReorderVertexBuffer() { }

        public void CombineMeshes(CombineInstance[] combine) => CombineMeshes(combine, true, true, false);
        public void CombineMeshes(CombineInstance[] combine, bool mergeSubMeshes) => CombineMeshes(combine, mergeSubMeshes, true, false);
        public void CombineMeshes(CombineInstance[] combine, bool mergeSubMeshes, bool useMatrices) => CombineMeshes(combine, mergeSubMeshes, useMatrices, false);
        public void CombineMeshes(CombineInstance[] combine, bool mergeSubMeshes, bool useMatrices, bool hasLightmapData)
        {
            var v = new List<Vector3>(); var nrm = new List<Vector3>(); var uv0 = new List<Vector4>(); var col = new List<Color>();
            var subs = new List<Sub>(); var merged = new List<int>();
            bool anyNormals = false, anyUV = false, anyColors = false;
            foreach (var ci in combine) { if (ci.mesh == null) continue; ci.mesh.Data(); anyNormals |= ci.mesh.m_Normals.Length > 0; anyUV |= ci.mesh.m_UV[0] != null; anyColors |= ci.mesh.m_Colors.Length > 0; }
            foreach (var ci in combine)
            {
                var m = ci.mesh; if (m == null) continue;
                int b = v.Count; var mat = ci.transform; bool useM = useMatrices && mat != default;
                for (int i = 0; i < m.m_Vertices.Length; i++)
                {
                    v.Add(useM ? mat.MultiplyPoint3x4(m.m_Vertices[i]) : m.m_Vertices[i]);
                    if (anyNormals) nrm.Add(i < m.m_Normals.Length ? (useM ? mat.MultiplyVector(m.m_Normals[i]).normalized : m.m_Normals[i]) : Vector3.up);
                    if (anyUV) uv0.Add(m.m_UV[0] != null ? m.m_UV[0][i] : Vector4.zero);
                    if (anyColors) col.Add(i < m.m_Colors.Length ? m.m_Colors[i] : Color.white);
                }
                var s = m.m_Subs[Math.Clamp(ci.subMeshIndex, 0, m.m_Subs.Count - 1)];
                var ix = new int[s.indices.Length]; for (int i = 0; i < ix.Length; i++) ix[i] = s.indices[i] + s.baseVertex + b;
                if (mergeSubMeshes) merged.AddRange(ix); else subs.Add(new Sub { indices = ix, topology = s.topology });
            }
            Clear();
            m_Vertices = v.ToArray(); m_Normals = nrm.ToArray(); m_Colors = col.ToArray();
            if (anyUV) { m_UV[0] = uv0.ToArray(); m_UVDim[0] = 2; }
            m_Subs = mergeSubMeshes ? new List<Sub> { new Sub { indices = merged.ToArray(), topology = MeshTopology.Triangles } } : (subs.Count > 0 ? subs : new List<Sub> { new Sub { indices = Array.Empty<int>() } });
            RecalcBounds(); Changed();
        }

        internal Mesh CloneMesh()
        {
            Data();
            var m = new Mesh { m_Name = m_Name, m_Primitive = m_Primitive, indexFormat = indexFormat, m_DataBuilt = true };
            m.m_Vertices = (Vector3[])m_Vertices.Clone(); m.m_Normals = (Vector3[])m_Normals.Clone(); m.m_Tangents = (Vector4[])m_Tangents.Clone(); m.m_Colors = (Color[])m_Colors.Clone();
            for (int i = 0; i < 8; i++) { m.m_UV[i] = (Vector4[])m_UV[i]?.Clone(); m.m_UVDim[i] = m_UVDim[i]; }
            m.m_Subs = new List<Sub>(); foreach (var s in m_Subs) m.m_Subs.Add(new Sub { indices = (int[])s.indices.Clone(), topology = s.topology, baseVertex = s.baseVertex });
            m.m_Bounds = m_Bounds;
            m.m_Bindposes = (Matrix4x4[])m_Bindposes.Clone(); m.m_BoneWeights = (BoneWeight[])m_BoneWeights.Clone();
            return m;
        }

        // Packs the mesh for the renderer: [vc, flags(1 normals, 2 uv, 4 colors), subCount, then per sub: start,count,topology]
        // followed by floats: positions, normals?, uv?, colors?, then int indices (base vertex applied).
        internal byte[] Pack()
        {
            Data();
            int vc = m_Vertices.Length;
            bool hasN = m_Normals.Length == vc && vc > 0, hasUV = m_UV[0] != null && m_UV[0].Length == vc, hasC = m_Colors.Length == vc && vc > 0;
            bool hasSkin = m_BoneWeights.Length == vc && vc > 0;
            int idxTotal = 0; foreach (var s in m_Subs) idxTotal += s.indices.Length;
            int ints = 3 + m_Subs.Count * 3;
            int floats = vc * 3 + (hasN ? vc * 3 : 0) + (hasUV ? vc * 2 : 0) + (hasC ? vc * 4 : 0);
            int skin = hasSkin ? vc * 8 + 1 + m_Bindposes.Length * 16 : 0;
            var bytes = new byte[(ints + floats + idxTotal + skin) * 4];
            var span = System.Runtime.InteropServices.MemoryMarshal.Cast<byte, int>(bytes.AsSpan());
            var fspan = System.Runtime.InteropServices.MemoryMarshal.Cast<byte, float>(bytes.AsSpan());
            int o = 0;
            span[o++] = vc; span[o++] = (hasN ? 1 : 0) | (hasUV ? 2 : 0) | (hasC ? 4 : 0) | (hasSkin ? 8 : 0); span[o++] = m_Subs.Count;
            int start = 0;
            foreach (var s in m_Subs) { span[o++] = start; span[o++] = s.indices.Length; span[o++] = (int)s.topology; start += s.indices.Length; }
            foreach (var v in m_Vertices) { fspan[o++] = v.x; fspan[o++] = v.y; fspan[o++] = v.z; }
            if (hasN) foreach (var v in m_Normals) { fspan[o++] = v.x; fspan[o++] = v.y; fspan[o++] = v.z; }
            if (hasUV) foreach (var v in m_UV[0]) { fspan[o++] = v.x; fspan[o++] = v.y; }
            if (hasC) foreach (var c in m_Colors) { fspan[o++] = c.r; fspan[o++] = c.g; fspan[o++] = c.b; fspan[o++] = c.a; }
            foreach (var s in m_Subs) foreach (var i in s.indices) span[o++] = i + s.baseVertex;
            if (hasSkin)
            {
                foreach (var w in m_BoneWeights) { span[o++] = w.boneIndex0; span[o++] = w.boneIndex1; span[o++] = w.boneIndex2; span[o++] = w.boneIndex3; }
                foreach (var w in m_BoneWeights) { fspan[o++] = w.weight0; fspan[o++] = w.weight1; fspan[o++] = w.weight2; fspan[o++] = w.weight3; }
                span[o++] = m_Bindposes.Length;
                foreach (var m in m_Bindposes) for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) fspan[o++] = m[r, c];
            }
            return bytes;
        }
        // the inverse of Pack (an imported model's meshes arrive from the page in this format)
        internal void Unpack(byte[] bytes)
        {
            var span = System.Runtime.InteropServices.MemoryMarshal.Cast<byte, int>(bytes.AsSpan());
            var fspan = System.Runtime.InteropServices.MemoryMarshal.Cast<byte, float>(bytes.AsSpan());
            int o = 0;
            int vc = span[o++], flags = span[o++], subCount = span[o++];
            var subs = new (int start, int count, int topo)[subCount];
            for (int i = 0; i < subCount; i++) { subs[i] = (span[o], span[o + 1], span[o + 2]); o += 3; }
            var v = new Vector3[vc]; for (int i = 0; i < vc; i++) { v[i] = new Vector3(fspan[o], fspan[o + 1], fspan[o + 2]); o += 3; }
            m_Vertices = v;
            if ((flags & 1) != 0) { var n = new Vector3[vc]; for (int i = 0; i < vc; i++) { n[i] = new Vector3(fspan[o], fspan[o + 1], fspan[o + 2]); o += 3; } m_Normals = n; }
            if ((flags & 2) != 0) { var u = new Vector4[vc]; for (int i = 0; i < vc; i++) { u[i] = new Vector4(fspan[o], fspan[o + 1], 0, 0); o += 2; } m_UV[0] = u; m_UVDim[0] = 2; }
            if ((flags & 4) != 0) { var c = new Color[vc]; for (int i = 0; i < vc; i++) { c[i] = new Color(fspan[o], fspan[o + 1], fspan[o + 2], fspan[o + 3]); o += 4; } m_Colors = c; }
            int idxStart = o, idxTotal = 0;
            m_Subs = new List<Sub>();
            foreach (var (start, count, topo) in subs)
            {
                var ix = new int[count]; for (int i = 0; i < count; i++) ix[i] = span[idxStart + start + i];
                m_Subs.Add(new Sub { indices = ix, topology = (MeshTopology)topo });
                idxTotal = Math.Max(idxTotal, start + count);
            }
            if (m_Subs.Count == 0) m_Subs.Add(new Sub { indices = Array.Empty<int>(), topology = MeshTopology.Triangles });
            o = idxStart + idxTotal;
            if ((flags & 8) != 0)
            {
                var bw = new BoneWeight[vc];
                for (int i = 0; i < vc; i++) { bw[i].boneIndex0 = span[o]; bw[i].boneIndex1 = span[o + 1]; bw[i].boneIndex2 = span[o + 2]; bw[i].boneIndex3 = span[o + 3]; o += 4; }
                for (int i = 0; i < vc; i++) { bw[i].weight0 = fspan[o]; bw[i].weight1 = fspan[o + 1]; bw[i].weight2 = fspan[o + 2]; bw[i].weight3 = fspan[o + 3]; o += 4; }
                int nb = span[o++];
                var bp = new Matrix4x4[nb];
                for (int b = 0; b < nb; b++) { var m = new Matrix4x4(); for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) m[r, c] = fspan[o++]; bp[b] = m; }
                m_BoneWeights = bw; m_Bindposes = bp;
            }
            RecalcBounds();
        }

        // used by the primitive builder
        internal void SetRaw(Vector3[] v, Vector3[] n, Vector2[] uv, int[] tris)
        {
            m_Vertices = v; m_Normals = n;
            var u = new Vector4[uv.Length]; for (int i = 0; i < u.Length; i++) u[i] = new Vector4(uv[i].x, uv[i].y, 0, 0);
            m_UV[0] = u; m_UVDim[0] = 2;
            m_Subs = new List<Sub> { new Sub { indices = tris, topology = MeshTopology.Triangles } };
            RecalcBounds();
        }
    }

    // Unity-like vertex data for the built-in primitives (same sizes and orientation as Unity's).
    internal static class PrimitiveMeshes
    {
        internal static Bounds BoundsOf(string n)
        {
            switch (n)
            {
                case "Cube": case "Sphere": return new Bounds(Vector3.zero, Vector3.one);
                case "Capsule": case "Cylinder": return new Bounds(Vector3.zero, new Vector3(1, 2, 1));
                case "Plane": return new Bounds(Vector3.zero, new Vector3(10, 0, 10));
                case "Quad": return new Bounds(Vector3.zero, new Vector3(1, 1, 0));
                default: return default;
            }
        }
        internal static void Build(string n, Mesh m)
        {
            var v = new List<Vector3>(); var nr = new List<Vector3>(); var uv = new List<Vector2>(); var t = new List<int>();
            switch (n)
            {
                case "Cube": Cube(v, nr, uv, t); break;
                case "Quad":
                    v.AddRange(new[] { new Vector3(-0.5f, -0.5f, 0), new Vector3(0.5f, -0.5f, 0), new Vector3(-0.5f, 0.5f, 0), new Vector3(0.5f, 0.5f, 0) });
                    for (int i = 0; i < 4; i++) nr.Add(new Vector3(0, 0, -1));
                    uv.AddRange(new[] { new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 1), new Vector2(1, 1) });
                    t.AddRange(new[] { 0, 3, 1, 3, 0, 2 });
                    break;
                case "Plane":
                    for (int z = 0; z <= 10; z++) for (int x = 0; x <= 10; x++) { v.Add(new Vector3(5 - x, 0, 5 - z)); nr.Add(Vector3.up); uv.Add(new Vector2(x / 10f, z / 10f)); }
                    for (int z = 0; z < 10; z++) for (int x = 0; x < 10; x++) { int a = z * 11 + x; t.AddRange(new[] { a, a + 1, a + 11, a + 11, a + 1, a + 12 }); }
                    // keep the faces pointing up (clockwise seen from above)
                    for (int i = 0; i < t.Count; i += 3) { var p0 = v[t[i]]; var c = Vector3.Cross(v[t[i + 1]] - p0, v[t[i + 2]] - p0); if (c.y < 0) { int s = t[i + 1]; t[i + 1] = t[i + 2]; t[i + 2] = s; } }
                    break;
                case "Sphere": Lathe(v, nr, uv, t, 24, 16, (k, rings) => { float a = Mathf.PI * k / rings; return (0.5f * Mathf.Sin(a), -0.5f * Mathf.Cos(a)); }); break;
                case "Capsule":
                    Lathe(v, nr, uv, t, 24, 18, (k, rings) =>
                    {
                        // two hemispheres (radius 0.5) joined by a cylinder: total height 2
                        int half = rings / 2; float a;
                        if (k <= half) { a = Mathf.PI * 0.5f * k / half; return (0.5f * Mathf.Sin(a), -0.5f - 0.5f * Mathf.Cos(a)); }
                        a = Mathf.PI * 0.5f * (k - half) / half; return (0.5f * Mathf.Cos(a), 0.5f + 0.5f * Mathf.Sin(a));
                    });
                    break;
                case "Cylinder": Cylinder(v, nr, uv, t, 20); break;
            }
            m.SetRaw(v.ToArray(), nr.ToArray(), uv.ToArray(), t.ToArray());
        }
        static void Cube(List<Vector3> v, List<Vector3> nr, List<Vector2> uv, List<int> t)
        {
            Vector3[] dirs = { Vector3.forward, Vector3.back, Vector3.up, Vector3.down, Vector3.left, Vector3.right };
            foreach (var d in dirs)
            {
                Vector3 up = Mathf.Abs(d.y) > 0.5f ? Vector3.forward : Vector3.up;
                Vector3 right = Vector3.Cross(up, d); // left-handed: right x up = forward
                int b = v.Count;
                Vector3 c = d * 0.5f;
                v.Add(c - right * 0.5f - up * 0.5f); v.Add(c + right * 0.5f - up * 0.5f); v.Add(c - right * 0.5f + up * 0.5f); v.Add(c + right * 0.5f + up * 0.5f);
                for (int i = 0; i < 4; i++) nr.Add(d);
                uv.Add(new Vector2(0, 0)); uv.Add(new Vector2(1, 0)); uv.Add(new Vector2(0, 1)); uv.Add(new Vector2(1, 1));
                AddQuad(v, t, b, d);
            }
        }
        // two triangles for verts b..b+3 laid out (0 bottom-left, 1 bottom-right, 2 top-left, 3 top-right), facing 'normal'
        static void AddQuad(List<Vector3> v, List<int> t, int b, Vector3 normal)
        {
            int[] tri = { b, b + 2, b + 1, b + 2, b + 3, b + 1 };
            var c = Vector3.Cross(v[tri[1]] - v[tri[0]], v[tri[2]] - v[tri[0]]);
            if (Vector3.Dot(c, normal) < 0) { tri = new[] { b, b + 1, b + 2, b + 2, b + 1, b + 3 }; }
            t.AddRange(tri);
        }
        // surface of revolution around Y; profile(k, rings) gives (radius, y) for ring k = 0..rings
        static void Lathe(List<Vector3> v, List<Vector3> nr, List<Vector2> uv, List<int> t, int seg, int rings, Func<int, int, (float r, float y)> profile)
        {
            var pts = new (float r, float y)[rings + 1];
            for (int k = 0; k <= rings; k++) pts[k] = profile(k, rings);
            for (int k = 0; k <= rings; k++)
            {
                // profile normal from neighbours
                var prev = pts[Math.Max(0, k - 1)]; var next = pts[Math.Min(rings, k + 1)];
                float dr = next.r - prev.r, dy = next.y - prev.y; var pn = new Vector2(dy, -dr).normalized;
                for (int s = 0; s <= seg; s++)
                {
                    float a = 2 * Mathf.PI * s / seg; float cs = Mathf.Cos(a), sn = Mathf.Sin(a);
                    v.Add(new Vector3(pts[k].r * cs, pts[k].y, pts[k].r * sn));
                    var n3 = new Vector3(pn.x * cs, pn.y, pn.x * sn); if (k == 0) n3 = Vector3.down; if (k == rings) n3 = Vector3.up;
                    nr.Add(n3.normalized); uv.Add(new Vector2((float)s / seg, (float)k / rings));
                }
            }
            for (int k = 0; k < rings; k++) for (int s = 0; s < seg; s++)
                {
                    int a = k * (seg + 1) + s, b = a + seg + 1;
                    Tri(v, t, a, b, a + 1, nr[a] + nr[b] + nr[a + 1]); Tri(v, t, a + 1, b, b + 1, nr[a + 1] + nr[b] + nr[b + 1]);
                }
        }
        static void Tri(List<Vector3> v, List<int> t, int a, int b, int c, Vector3 outward)
        {
            var cr = Vector3.Cross(v[b] - v[a], v[c] - v[a]);
            if (cr.sqrMagnitude < 1e-14f) return;
            if (Vector3.Dot(cr, outward) < 0) { t.Add(a); t.Add(c); t.Add(b); } else { t.Add(a); t.Add(b); t.Add(c); }
        }
        static void Cylinder(List<Vector3> v, List<Vector3> nr, List<Vector2> uv, List<int> t, int seg)
        {
            // side
            for (int k = 0; k <= 1; k++) for (int s = 0; s <= seg; s++)
                {
                    float a = 2 * Mathf.PI * s / seg; var d = new Vector3(Mathf.Cos(a), 0, Mathf.Sin(a));
                    v.Add(d * 0.5f + new Vector3(0, k == 0 ? -1 : 1, 0)); nr.Add(d); uv.Add(new Vector2((float)s / seg, k));
                }
            for (int s = 0; s < seg; s++) { int a = s, b = s + seg + 1; Tri(v, t, a, b, a + 1, nr[a]); Tri(v, t, a + 1, b, b + 1, nr[a + 1]); }
            // caps
            foreach (int sign in new[] { -1, 1 })
            {
                int c = v.Count; v.Add(new Vector3(0, sign, 0)); nr.Add(new Vector3(0, sign, 0)); uv.Add(new Vector2(0.5f, 0.5f));
                for (int s = 0; s <= seg; s++) { float a = 2 * Mathf.PI * s / seg; v.Add(new Vector3(0.5f * Mathf.Cos(a), sign, 0.5f * Mathf.Sin(a))); nr.Add(new Vector3(0, sign, 0)); uv.Add(new Vector2(0.5f + 0.5f * Mathf.Cos(a), 0.5f + 0.5f * Mathf.Sin(a))); }
                for (int s = 0; s < seg; s++) Tri(v, t, c, c + 1 + s, c + 2 + s, new Vector3(0, sign, 0));
            }
        }
    }
}

namespace UnityEngine.Rendering
{
    [Flags] public enum MeshUpdateFlags { Default = 0, DontValidateIndices = 1, DontResetBoneBounds = 2, DontNotifyMeshUsers = 4, DontRecalculateBounds = 8 }
    public enum VertexAttribute { Position = 0, Normal = 1, Tangent = 2, Color = 3, TexCoord0 = 4, TexCoord1 = 5, TexCoord2 = 6, TexCoord3 = 7, TexCoord4 = 8, TexCoord5 = 9, TexCoord6 = 10, TexCoord7 = 11, BlendWeight = 12, BlendIndices = 13 }
}
