// uGUI event system: handler interfaces, event data, EventSystem, input modules, ExecuteEvents.
using System;
using System.Collections.Generic;
using System.Linq;
using Anvil;

namespace UnityEngine.EventSystems
{
    public interface IEventSystemHandler { }
    public interface IPointerMoveHandler : IEventSystemHandler { void OnPointerMove(PointerEventData eventData); }
    public interface IPointerEnterHandler : IEventSystemHandler { void OnPointerEnter(PointerEventData eventData); }
    public interface IPointerExitHandler : IEventSystemHandler { void OnPointerExit(PointerEventData eventData); }
    public interface IPointerDownHandler : IEventSystemHandler { void OnPointerDown(PointerEventData eventData); }
    public interface IPointerUpHandler : IEventSystemHandler { void OnPointerUp(PointerEventData eventData); }
    public interface IPointerClickHandler : IEventSystemHandler { void OnPointerClick(PointerEventData eventData); }
    public interface IInitializePotentialDragHandler : IEventSystemHandler { void OnInitializePotentialDrag(PointerEventData eventData); }
    public interface IBeginDragHandler : IEventSystemHandler { void OnBeginDrag(PointerEventData eventData); }
    public interface IDragHandler : IEventSystemHandler { void OnDrag(PointerEventData eventData); }
    public interface IEndDragHandler : IEventSystemHandler { void OnEndDrag(PointerEventData eventData); }
    public interface IDropHandler : IEventSystemHandler { void OnDrop(PointerEventData eventData); }
    public interface IScrollHandler : IEventSystemHandler { void OnScroll(PointerEventData eventData); }
    public interface IUpdateSelectedHandler : IEventSystemHandler { void OnUpdateSelected(BaseEventData eventData); }
    public interface ISelectHandler : IEventSystemHandler { void OnSelect(BaseEventData eventData); }
    public interface IDeselectHandler : IEventSystemHandler { void OnDeselect(BaseEventData eventData); }
    public interface IMoveHandler : IEventSystemHandler { void OnMove(AxisEventData eventData); }
    public interface ISubmitHandler : IEventSystemHandler { void OnSubmit(BaseEventData eventData); }
    public interface ICancelHandler : IEventSystemHandler { void OnCancel(BaseEventData eventData); }

    public enum EventHandle { Unused = 0, Used = 1 }
    public enum EventTriggerType { PointerEnter = 0, PointerExit = 1, PointerDown = 2, PointerUp = 3, PointerClick = 4, Drag = 5, Drop = 6, Scroll = 7, UpdateSelected = 8, Select = 9, Deselect = 10, Move = 11, InitializePotentialDrag = 12, BeginDrag = 13, EndDrag = 14, Submit = 15, Cancel = 16 }
    public enum MoveDirection { Left = 0, Up = 1, Right = 2, Down = 3, None = 4 }

    public abstract class AbstractEventData
    {
        protected bool m_Used;
        public virtual void Reset() { m_Used = false; }
        public virtual void Use() { m_Used = true; }
        public virtual bool used => m_Used;
    }
    public class BaseEventData : AbstractEventData
    {
        readonly EventSystem m_EventSystem;
        public BaseEventData(EventSystem eventSystem) { m_EventSystem = eventSystem; }
        public BaseInputModule currentInputModule => m_EventSystem != null ? m_EventSystem.currentInputModule : null;
        public GameObject selectedObject { get => m_EventSystem?.currentSelectedGameObject; set => m_EventSystem?.SetSelectedGameObject(value, this); }
    }
    public class AxisEventData : BaseEventData
    {
        public Vector2 moveVector { get; set; }
        public MoveDirection moveDir { get; set; }
        public AxisEventData(EventSystem eventSystem) : base(eventSystem) { moveVector = Vector2.zero; moveDir = MoveDirection.None; }
    }

    public struct RaycastResult
    {
        GameObject m_GameObject;
        public GameObject gameObject { get => m_GameObject; set => m_GameObject = value; }
        public BaseRaycaster module;
        public float distance, index;
        public int depth, sortingGroupID, sortingGroupOrder, sortingLayer, sortingOrder, displayIndex;
        public Vector3 worldPosition, worldNormal;
        public Vector2 screenPosition;
        public bool isValid => module != null && gameObject != null;
        public void Clear() { this = default; }
        public override string ToString() => isValid ? "Name: " + gameObject + "\nmodule: " + module + "\ndistance: " + distance + "\nindex: " + index + "\ndepth: " + depth + "\nworldNormal: " + worldNormal + "\nworldPosition: " + worldPosition + "\nscreenPosition: " + screenPosition : "";
    }

    public class PointerEventData : BaseEventData
    {
        public enum InputButton { Left = 0, Right = 1, Middle = 2 }
        public enum FramePressState { Pressed = 0, Released = 1, PressedAndReleased = 2, NotChanged = 3 }
        public GameObject pointerEnter { get; set; }
        public GameObject lastPress { get; private set; }
        GameObject m_PointerPress;
        public GameObject pointerPress { get => m_PointerPress; set { if (m_PointerPress == value) return; lastPress = m_PointerPress; m_PointerPress = value; } }
        public GameObject rawPointerPress { get; set; }
        public GameObject pointerDrag { get; set; }
        public GameObject pointerClick { get; set; }
        public RaycastResult pointerCurrentRaycast { get; set; }
        public RaycastResult pointerPressRaycast { get; set; }
        public List<GameObject> hovered = new List<GameObject>();
        public bool eligibleForClick { get; set; }
        public int displayIndex { get; set; }
        public int pointerId { get; set; }
        public Vector2 position { get; set; }
        public Vector2 delta { get; set; }
        public Vector2 pressPosition { get; set; }
        [Obsolete("Use either pointerCurrentRaycast.worldPosition or pointerPressRaycast.worldPosition")] public Vector3 worldPosition { get; set; }
        [Obsolete("Use either pointerCurrentRaycast.worldNormal or pointerPressRaycast.worldNormal")] public Vector3 worldNormal { get; set; }
        public float clickTime { get; set; }
        public int clickCount { get; set; }
        public Vector2 scrollDelta { get; set; }
        public bool useDragThreshold { get; set; }
        public bool dragging { get; set; }
        public InputButton button { get; set; }
        public float pressure { get; set; } = 1f;
        public float tangentialPressure { get; set; }
        public float altitudeAngle { get; set; }
        public float azimuthAngle { get; set; }
        public float twist { get; set; }
        public Vector2 tilt { get; set; }
        public Vector2 radius { get; set; }
        public Vector2 radiusVariance { get; set; }
        public bool fullyExited { get; set; }
        public bool reentered { get; set; }
        public Camera enterEventCamera => pointerCurrentRaycast.module != null ? pointerCurrentRaycast.module.eventCamera : null;
        public Camera pressEventCamera => pointerPressRaycast.module != null ? pointerPressRaycast.module.eventCamera : null;
        public PointerEventData(EventSystem eventSystem) : base(eventSystem) { eligibleForClick = false; pointerId = -1; useDragThreshold = true; }
        public bool IsPointerMoving() => delta.sqrMagnitude > 0f;
        public bool IsScrolling() => scrollDelta.sqrMagnitude > 0f;
        public override string ToString() => "<b>Position</b>: " + position + "\n<b>delta</b>: " + delta + "\n<b>eligibleForClick</b>: " + eligibleForClick + "\n<b>pointerEnter</b>: " + pointerEnter + "\n<b>pointerPress</b>: " + pointerPress + "\n<b>pointerDrag</b>: " + pointerDrag + "\n<b>Use Drag Threshold</b>: " + useDragThreshold;
    }

    public static class ExecuteEvents
    {
        public delegate void EventFunction<T1>(T1 handler, BaseEventData eventData);
        public static T ValidateEventData<T>(BaseEventData data) where T : class
        {
            if (!(data is T t)) throw new ArgumentException($"Invalid type: {data.GetType()} passed to event expecting {typeof(T)}");
            return t;
        }
        public static EventFunction<IPointerMoveHandler> pointerMoveHandler { get; } = (h, d) => h.OnPointerMove(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IPointerEnterHandler> pointerEnterHandler { get; } = (h, d) => h.OnPointerEnter(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IPointerExitHandler> pointerExitHandler { get; } = (h, d) => h.OnPointerExit(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IPointerDownHandler> pointerDownHandler { get; } = (h, d) => h.OnPointerDown(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IPointerUpHandler> pointerUpHandler { get; } = (h, d) => h.OnPointerUp(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IPointerClickHandler> pointerClickHandler { get; } = (h, d) => h.OnPointerClick(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IInitializePotentialDragHandler> initializePotentialDrag { get; } = (h, d) => h.OnInitializePotentialDrag(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IBeginDragHandler> beginDragHandler { get; } = (h, d) => h.OnBeginDrag(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IDragHandler> dragHandler { get; } = (h, d) => h.OnDrag(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IEndDragHandler> endDragHandler { get; } = (h, d) => h.OnEndDrag(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IDropHandler> dropHandler { get; } = (h, d) => h.OnDrop(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IScrollHandler> scrollHandler { get; } = (h, d) => h.OnScroll(ValidateEventData<PointerEventData>(d));
        public static EventFunction<IUpdateSelectedHandler> updateSelectedHandler { get; } = (h, d) => h.OnUpdateSelected(d);
        public static EventFunction<ISelectHandler> selectHandler { get; } = (h, d) => h.OnSelect(d);
        public static EventFunction<IDeselectHandler> deselectHandler { get; } = (h, d) => h.OnDeselect(d);
        public static EventFunction<IMoveHandler> moveHandler { get; } = (h, d) => h.OnMove(ValidateEventData<AxisEventData>(d));
        public static EventFunction<ISubmitHandler> submitHandler { get; } = (h, d) => h.OnSubmit(d);
        public static EventFunction<ICancelHandler> cancelHandler { get; } = (h, d) => h.OnCancel(d);

        static void GetHandlers<T>(GameObject go, List<IEventSystemHandler> results) where T : IEventSystemHandler
        {
            if (go == null || !go.activeInHierarchy) return;
            foreach (var c in go.m_Components)
            {
                if (c == null || c.m_Destroyed || !(c is T)) continue;
                if (c is Behaviour b && !b.isActiveAndEnabled) continue;
                results.Add((IEventSystemHandler)c);
            }
        }
        public static bool Execute<T>(GameObject target, BaseEventData eventData, EventFunction<T> functor) where T : IEventSystemHandler
        {
            var list = new List<IEventSystemHandler>();
            GetHandlers<T>(target, list);
            foreach (var h in list)
            {
                try { functor((T)h, eventData); }
                catch (Exception e) { Debug.LogException(e); }
            }
            return list.Count > 0;
        }
        public static GameObject ExecuteHierarchy<T>(GameObject root, BaseEventData eventData, EventFunction<T> callbackFunction) where T : IEventSystemHandler
        {
            for (var t = root != null ? root.transform : null; t != null; t = t.parent)
            {
                if (Execute(t.gameObject, eventData, callbackFunction)) return t.gameObject;
                if (eventData != null && eventData.used) break;
            }
            return null;
        }
        public static bool CanHandleEvent<T>(GameObject go) where T : IEventSystemHandler
        {
            var list = new List<IEventSystemHandler>(); GetHandlers<T>(go, list); return list.Count > 0;
        }
        public static GameObject GetEventHandler<T>(GameObject root) where T : IEventSystemHandler
        {
            for (var t = root != null ? root.transform : null; t != null; t = t.parent)
                if (CanHandleEvent<T>(t.gameObject)) return t.gameObject;
            return null;
        }
    }

    public abstract class UIBehaviour : MonoBehaviour
    {
        protected virtual void Awake() { }
        protected virtual void OnEnable() { }
        protected virtual void Start() { }
        protected virtual void OnDisable() { }
        protected virtual void OnDestroy() { }
        public virtual bool IsActive() => isActiveAndEnabled;
        protected virtual void OnValidate() { }
        protected virtual void Reset() { }
        protected virtual void OnRectTransformDimensionsChange() { }
        protected virtual void OnBeforeTransformParentChanged() { }
        protected virtual void OnTransformParentChanged() { }
        protected virtual void OnDidApplyAnimationProperties() { }
        protected virtual void OnCanvasGroupChanged() { }
        protected virtual void OnCanvasHierarchyChanged() { }
        public bool IsDestroyed() => this == null;
    }

    public abstract class BaseRaycaster : UIBehaviour
    {
        public abstract void Raycast(PointerEventData eventData, List<RaycastResult> resultAppendList);
        public abstract Camera eventCamera { get; }
        public virtual int sortOrderPriority => int.MinValue;
        public virtual int renderOrderPriority => int.MinValue;
        public BaseRaycaster rootRaycaster => this;
        public override string ToString() => "Name: " + gameObject + "\neventCamera: " + eventCamera + "\nsortOrderPriority: " + sortOrderPriority + "\nrenderOrderPriority: " + renderOrderPriority;
    }

    // 3D objects with colliders get pointer events when the camera has a PhysicsRaycaster
    [RequireComponent(typeof(Camera))]
    public class PhysicsRaycaster : BaseRaycaster
    {
        public override Camera eventCamera => GetComponent<Camera>();
        public LayerMask eventMask { get; set; } = -1;
        public int maxRayIntersections { get; set; }
        public int finalEventMask => eventMask;
        public virtual int depth => eventCamera != null ? (int)eventCamera.depth : 0xFFFFFF;
        public override void Raycast(PointerEventData eventData, List<RaycastResult> resultAppendList)
        {
            var cam = eventCamera; if (cam == null) return;
            var ray = cam.ScreenPointToRay(new Vector3(eventData.position.x, eventData.position.y, 0));
            if (Physics.Raycast(ray, out var hit, cam.farClipPlane - cam.nearClipPlane, eventMask))
                resultAppendList.Add(new RaycastResult { gameObject = hit.collider.gameObject, module = this, distance = hit.distance, worldPosition = hit.point, worldNormal = hit.normal, screenPosition = eventData.position, index = resultAppendList.Count, sortingLayer = 0, sortingOrder = 0 });
        }
    }
    public class Physics2DRaycaster : PhysicsRaycaster { }

    public abstract class BaseInput : UIBehaviour
    {
        public virtual string compositionString => "";
        public virtual IMECompositionMode imeCompositionMode { get; set; }
        public virtual Vector2 compositionCursorPos { get; set; }
        public virtual bool mousePresent => true;
        public virtual bool GetMouseButtonDown(int button) => InputState.mouseDownThisFrame[button];
        public virtual bool GetMouseButtonUp(int button) => InputState.mouseUpThisFrame[button];
        public virtual bool GetMouseButton(int button) => InputState.mouseHeld[button];
        public virtual Vector2 mousePosition => InputState.mousePos;
        public virtual Vector2 mouseScrollDelta => InputState.wheel;
        public virtual bool touchSupported => false;
        public virtual int touchCount => 0;
        public virtual Touch GetTouch(int index) => default;
        public virtual float GetAxisRaw(string axisName) => Input.GetAxisRaw(axisName);
        public virtual bool GetButtonDown(string buttonName) => Input.GetButtonDown(buttonName);
    }

    public abstract class BaseInputModule : UIBehaviour
    {
        protected BaseInput m_InputOverride;
        public BaseInput inputOverride { get => m_InputOverride; set => m_InputOverride = value; }
        public BaseInput input => m_InputOverride;
        public bool sendPointerHoverToParent { get; set; } = true;
        protected EventSystem eventSystem => GetComponent<EventSystem>();
        public abstract void Process();
        public virtual bool ShouldActivateModule() => enabled && gameObject.activeInHierarchy;
        public virtual void DeactivateModule() { }
        public virtual void ActivateModule() { }
        public virtual void UpdateModule() { }
        public virtual bool IsModuleSupported() => true;
        public virtual bool IsPointerOverGameObject(int pointerId) => EventSystem.current != null && EventSystem.current.m_HoverTarget != null;
        public virtual int ConvertUIToolkitPointerId(PointerEventData sourcePointerData) => sourcePointerData.pointerId;
        protected static RaycastResult FindFirstRaycast(List<RaycastResult> candidates) { foreach (var c in candidates) if (c.gameObject != null) return c; return default; }
        protected static MoveDirection DetermineMoveDirection(float x, float y) => DetermineMoveDirection(x, y, 0.6f);
        protected static MoveDirection DetermineMoveDirection(float x, float y, float deadZone)
        {
            if (new Vector2(x, y).sqrMagnitude < deadZone * deadZone) return MoveDirection.None;
            if (Mathf.Abs(x) > Mathf.Abs(y)) return x > 0 ? MoveDirection.Right : MoveDirection.Left;
            return y > 0 ? MoveDirection.Up : MoveDirection.Down;
        }
        protected static GameObject FindCommonRoot(GameObject g1, GameObject g2)
        {
            if (g1 == null || g2 == null) return null;
            for (var t1 = g1.transform; t1 != null; t1 = t1.parent)
                for (var t2 = g2.transform; t2 != null; t2 = t2.parent) if (t1 == t2) return t1.gameObject;
            return null;
        }
    }
    public abstract class PointerInputModule : BaseInputModule
    {
        public const int kMouseLeftId = -1, kMouseRightId = -2, kMouseMiddleId = -3, kFakeTouchesId = -4;
        public override void Process() { }
    }
    public class StandaloneInputModule : PointerInputModule
    {
        public enum InputMode { Mouse = 0, Buttons = 1 }
        public string horizontalAxis { get; set; } = "Horizontal";
        public string verticalAxis { get; set; } = "Vertical";
        public string submitButton { get; set; } = "Submit";
        public string cancelButton { get; set; } = "Cancel";
        public float inputActionsPerSecond { get; set; } = 10f;
        public float repeatDelay { get; set; } = 0.5f;
        public bool forceModuleActive { get; set; }
        public InputMode inputMode => InputMode.Mouse;
    }
    [Obsolete("TouchInputModule is no longer required as Touch input is now handled in StandaloneInputModule.")]
    public class TouchInputModule : PointerInputModule { public bool forceModuleActive { get; set; } }

    [DisallowMultipleComponent]
    public class EventSystem : UIBehaviour
    {
        static readonly List<EventSystem> s_Systems = new List<EventSystem>();
        public static EventSystem current
        {
            get => s_Systems.Count > 0 ? s_Systems[0] : null;
            set { int i = s_Systems.IndexOf(value); if (i > 0) { s_Systems.RemoveAt(i); s_Systems.Insert(0, value); } }
        }
        internal static void ResetStatics() { s_Systems.Clear(); }
        public bool sendNavigationEvents { get; set; } = true;
        public int pixelDragThreshold { get; set; } = 10;
        public GameObject firstSelectedGameObject { get; set; }
        public GameObject currentSelectedGameObject => m_Selected;
        [Obsolete("lastSelectedGameObject is no longer supported")] public GameObject lastSelectedGameObject => null;
        public bool isFocused => true;
        public bool alreadySelecting => m_Selecting;
        public BaseInputModule currentInputModule => GetComponent<BaseInputModule>();

        GameObject m_Selected; bool m_Selecting;
        internal GameObject m_HoverTarget;
        readonly PointerEventData m_Pointer;
        float m_LastClickTime; GameObject m_LastClickTarget;
        float m_NavRepeat; MoveDirection m_LastNav = MoveDirection.None;

        protected EventSystem() { m_Pointer = new PointerEventData(this) { pointerId = PointerInputModule.kMouseLeftId }; }
        protected override void OnEnable() { if (!s_Systems.Contains(this)) s_Systems.Add(this); }
        protected override void OnDisable() { s_Systems.Remove(this); }
        protected override void Start() { if (firstSelectedGameObject != null && m_Selected == null) SetSelectedGameObject(firstSelectedGameObject); }

        public void SetSelectedGameObject(GameObject selected) => SetSelectedGameObject(selected, new BaseEventData(this));
        public void SetSelectedGameObject(GameObject selected, BaseEventData pointer)
        {
            if (m_Selecting) { Debug.LogError("Attempting to select " + selected + "while already selecting an object."); return; }
            m_Selecting = true;
            try
            {
                if (selected == m_Selected) return;
                ExecuteEvents.Execute(m_Selected, pointer, ExecuteEvents.deselectHandler);
                m_Selected = selected;
                ExecuteEvents.Execute(m_Selected, pointer, ExecuteEvents.selectHandler);
            }
            finally { m_Selecting = false; }
        }
        public bool IsPointerOverGameObject() => m_HoverTarget != null;
        public bool IsPointerOverGameObject(int pointerId) => m_HoverTarget != null;
        public void RaycastAll(PointerEventData eventData, List<RaycastResult> raycastResults)
        {
            raycastResults.Clear();
            UI.UIRuntime.RaycastUI(eventData, raycastResults);
            foreach (var pr in World.FindObjectsOfType<PhysicsRaycaster>(false)) if (pr.isActiveAndEnabled) pr.Raycast(eventData, raycastResults);
        }
        public void UpdateModules() { }
        public override string ToString() => "<b>Selected:</b>" + currentSelectedGameObject;

        protected virtual void Update()
        {
            if (current != this) return;
            var module = currentInputModule;
            if (module == null || !module.isActiveAndEnabled) return;
            if (m_Selected != null && !m_Selected.activeInHierarchy) m_Selected = null;
            ProcessPointer();
            ProcessKeys();
        }

        readonly List<RaycastResult> m_Hits = new List<RaycastResult>();
        void ProcessPointer()
        {
            var e = m_Pointer;
            var pos = InputState.mousePos;
            e.delta = pos - e.position;
            e.position = pos;
            e.scrollDelta = InputState.wheel;
            e.button = PointerEventData.InputButton.Left;
            if (UI.UIRuntime.HandlePopupInput(pos)) { m_HoverTarget = UI.UIRuntime.popupOwnerComponent?.gameObject; return; }
            RaycastAll(e, m_Hits);
            var hit = m_Hits.Count > 0 ? m_Hits[0] : default;
            e.pointerCurrentRaycast = hit;
            var target = hit.gameObject;
            m_HoverTarget = target != null && (hit.module is UI.GraphicRaycaster) ? target : null;

            // enter / exit
            if (e.pointerEnter != target)
            {
                var common = FindCommon(e.pointerEnter, target);
                for (var t = e.pointerEnter != null ? e.pointerEnter.transform : null; t != null && (common == null || t != common.transform); t = t.parent)
                {
                    if (t.gameObject == null) break;
                    ExecuteEvents.Execute(t.gameObject, e, ExecuteEvents.pointerExitHandler);
                    e.hovered.Remove(t.gameObject);
                }
                e.pointerEnter = target;
                var enters = new List<GameObject>();
                for (var t = target != null ? target.transform : null; t != null && (common == null || t != common.transform); t = t.parent) enters.Add(t.gameObject);
                for (int i = enters.Count - 1; i >= 0; i--) { ExecuteEvents.Execute(enters[i], e, ExecuteEvents.pointerEnterHandler); if (!e.hovered.Contains(enters[i])) e.hovered.Add(enters[i]); }
            }
            if (e.IsPointerMoving() && target != null) ExecuteEvents.ExecuteHierarchy(target, e, ExecuteEvents.pointerMoveHandler);

            if (InputState.mouseDownThisFrame[0])
            {
                e.eligibleForClick = true; e.delta = Vector2.zero; e.dragging = false; e.useDragThreshold = true;
                e.pressPosition = pos; e.pointerPressRaycast = hit;
                // deselect when clicking something that isn't selectable
                var newPress = ExecuteEvents.ExecuteHierarchy(target, e, ExecuteEvents.pointerDownHandler);
                var newClick = ExecuteEvents.GetEventHandler<IPointerClickHandler>(target);
                if (newPress == null) newPress = newClick;
                if (ExecuteEvents.GetEventHandler<ISelectHandler>(target) != m_Selected && !(newPress != null && ExecuteEvents.CanHandleEvent<ISelectHandler>(newPress))) SetSelectedGameObject(null, e);
                float now = Time.unscaledTime;
                if (newPress == m_LastClickTarget && now - m_LastClickTime < 0.3f) e.clickCount++; else e.clickCount = 1;
                m_LastClickTime = now; m_LastClickTarget = newPress;
                e.clickTime = now;
                e.pointerPress = newPress; e.rawPointerPress = target; e.pointerClick = newClick;
                e.pointerDrag = ExecuteEvents.GetEventHandler<IDragHandler>(target);
                if (e.pointerDrag != null) ExecuteEvents.Execute(e.pointerDrag, e, ExecuteEvents.initializePotentialDrag);
            }
            // drag
            if (InputState.mouseHeld[0] && e.pointerDrag != null)
            {
                if (!e.dragging && (!e.useDragThreshold || (e.pressPosition - pos).sqrMagnitude >= pixelDragThreshold * pixelDragThreshold))
                {
                    ExecuteEvents.Execute(e.pointerDrag, e, ExecuteEvents.beginDragHandler);
                    e.dragging = true;
                }
                if (e.dragging && e.IsPointerMoving())
                {
                    if (e.pointerPress != e.pointerDrag) { ExecuteEvents.Execute(e.pointerPress, e, ExecuteEvents.pointerUpHandler); e.eligibleForClick = false; e.pointerPress = null; e.rawPointerPress = null; }
                    ExecuteEvents.Execute(e.pointerDrag, e, ExecuteEvents.dragHandler);
                }
            }
            if (InputState.mouseUpThisFrame[0])
            {
                ExecuteEvents.Execute(e.pointerPress, e, ExecuteEvents.pointerUpHandler);
                var clickHandler = ExecuteEvents.GetEventHandler<IPointerClickHandler>(target);
                if (e.pointerClick != null && e.pointerClick == clickHandler && e.eligibleForClick) ExecuteEvents.Execute(e.pointerClick, e, ExecuteEvents.pointerClickHandler);
                if (e.pointerDrag != null && e.dragging) ExecuteEvents.ExecuteHierarchy(target, e, ExecuteEvents.dropHandler);
                e.eligibleForClick = false; e.pointerPress = null; e.rawPointerPress = null; e.pointerClick = null;
                if (e.pointerDrag != null && e.dragging) ExecuteEvents.Execute(e.pointerDrag, e, ExecuteEvents.endDragHandler);
                e.dragging = false; e.pointerDrag = null;
            }
            if (e.scrollDelta.sqrMagnitude > 0 && target != null)
            {
                var sh = ExecuteEvents.GetEventHandler<IScrollHandler>(target);
                ExecuteEvents.ExecuteHierarchy(sh, e, ExecuteEvents.scrollHandler);
            }
        }
        static GameObject FindCommon(GameObject a, GameObject b)
        {
            if (a == null || b == null) return null;
            for (var t1 = a.transform; t1 != null; t1 = t1.parent)
                for (var t2 = b.transform; t2 != null; t2 = t2.parent) if (t1 == t2) return t1.gameObject;
            return null;
        }
        void ProcessKeys()
        {
            if (m_Selected == null) return;
            var data = new BaseEventData(this);
            ExecuteEvents.Execute(m_Selected, data, ExecuteEvents.updateSelectedHandler);
            if (data.used || !sendNavigationEvents) return;
            bool submit = InputState.downThisFrame.Contains("Enter") || InputState.downThisFrame.Contains("NumpadEnter") || InputState.downThisFrame.Contains("Space");
            bool cancel = InputState.downThisFrame.Contains("Escape");
            if (submit) ExecuteEvents.Execute(m_Selected, new BaseEventData(this), ExecuteEvents.submitHandler);
            if (cancel) ExecuteEvents.Execute(m_Selected, new BaseEventData(this), ExecuteEvents.cancelHandler);
            float x = (InputState.held.Contains("ArrowRight") ? 1 : 0) - (InputState.held.Contains("ArrowLeft") ? 1 : 0);
            float y = (InputState.held.Contains("ArrowUp") ? 1 : 0) - (InputState.held.Contains("ArrowDown") ? 1 : 0);
            var dir = BaseInputModuleHelpers.Dir(x, y);
            if (dir == MoveDirection.None) { m_LastNav = MoveDirection.None; return; }
            float now = Time.unscaledTime;
            if (dir == m_LastNav && now < m_NavRepeat) return;
            m_NavRepeat = now + (dir == m_LastNav ? 0.1f : 0.5f); m_LastNav = dir;
            ExecuteEvents.Execute(m_Selected, new AxisEventData(this) { moveVector = new Vector2(x, y), moveDir = dir }, ExecuteEvents.moveHandler);
        }
    }
    static class BaseInputModuleHelpers
    {
        internal static MoveDirection Dir(float x, float y)
        {
            if (x == 0 && y == 0) return MoveDirection.None;
            if (Mathf.Abs(x) > Mathf.Abs(y)) return x > 0 ? MoveDirection.Right : MoveDirection.Left;
            return y > 0 ? MoveDirection.Up : MoveDirection.Down;
        }
    }

    public class EventTrigger : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler, IPointerClickHandler, IInitializePotentialDragHandler, IBeginDragHandler, IDragHandler, IEndDragHandler, IDropHandler, IScrollHandler, IUpdateSelectedHandler, ISelectHandler, IDeselectHandler, IMoveHandler, ISubmitHandler, ICancelHandler
    {
        [Serializable] public class TriggerEvent : Events.UnityEvent<BaseEventData> { }
        [Serializable] public class Entry { public EventTriggerType eventID = EventTriggerType.PointerClick; public TriggerEvent callback = new TriggerEvent(); }
        [SerializeField] List<Entry> m_Delegates;
        public List<Entry> triggers { get => m_Delegates ??= new List<Entry>(); set => m_Delegates = value; }
        [Obsolete("Please use triggers instead (UnityUpgradable) -> triggers", true)] public List<Entry> delegates { get => triggers; set => triggers = value; }
        void Fire(EventTriggerType id, BaseEventData d) { foreach (var e in triggers.ToArray()) if (e.eventID == id && e.callback != null) e.callback.Invoke(d); }
        public virtual void OnPointerEnter(PointerEventData eventData) => Fire(EventTriggerType.PointerEnter, eventData);
        public virtual void OnPointerExit(PointerEventData eventData) => Fire(EventTriggerType.PointerExit, eventData);
        public virtual void OnDrag(PointerEventData eventData) => Fire(EventTriggerType.Drag, eventData);
        public virtual void OnDrop(PointerEventData eventData) => Fire(EventTriggerType.Drop, eventData);
        public virtual void OnPointerDown(PointerEventData eventData) => Fire(EventTriggerType.PointerDown, eventData);
        public virtual void OnPointerUp(PointerEventData eventData) => Fire(EventTriggerType.PointerUp, eventData);
        public virtual void OnPointerClick(PointerEventData eventData) => Fire(EventTriggerType.PointerClick, eventData);
        public virtual void OnSelect(BaseEventData eventData) => Fire(EventTriggerType.Select, eventData);
        public virtual void OnDeselect(BaseEventData eventData) => Fire(EventTriggerType.Deselect, eventData);
        public virtual void OnScroll(PointerEventData eventData) => Fire(EventTriggerType.Scroll, eventData);
        public virtual void OnMove(AxisEventData eventData) => Fire(EventTriggerType.Move, eventData);
        public virtual void OnUpdateSelected(BaseEventData eventData) => Fire(EventTriggerType.UpdateSelected, eventData);
        public virtual void OnInitializePotentialDrag(PointerEventData eventData) => Fire(EventTriggerType.InitializePotentialDrag, eventData);
        public virtual void OnBeginDrag(PointerEventData eventData) => Fire(EventTriggerType.BeginDrag, eventData);
        public virtual void OnEndDrag(PointerEventData eventData) => Fire(EventTriggerType.EndDrag, eventData);
        public virtual void OnSubmit(BaseEventData eventData) => Fire(EventTriggerType.Submit, eventData);
        public virtual void OnCancel(BaseEventData eventData) => Fire(EventTriggerType.Cancel, eventData);
    }
}

namespace UnityEngine.InputSystem.UI
{
    // the Input System's UI module: same behaviour as StandaloneInputModule here
    public class InputSystemUIInputModule : UnityEngine.EventSystems.BaseInputModule
    {
        public override void Process() { }
        public float moveRepeatDelay { get; set; } = 0.5f;
        public float moveRepeatRate { get; set; } = 0.1f;
        public bool deselectOnBackgroundClick { get; set; } = true;
        public float trackedDeviceDragThresholdMultiplier { get; set; } = 2f;
        public InputActionAsset actionsAsset { get; set; }
        public void AssignDefaultActions() { }
        public void UnassignActions() { }
    }
}
