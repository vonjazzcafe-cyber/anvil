// uGUI auto layout: layout groups, LayoutElement, ContentSizeFitter, AspectRatioFitter, LayoutUtility, LayoutRebuilder.
using System;
using System.Collections.Generic;
using UnityEngine.EventSystems;

namespace UnityEngine.UI
{
    public interface ILayoutElement
    {
        void CalculateLayoutInputHorizontal(); void CalculateLayoutInputVertical();
        float minWidth { get; } float preferredWidth { get; } float flexibleWidth { get; }
        float minHeight { get; } float preferredHeight { get; } float flexibleHeight { get; }
        int layoutPriority { get; }
    }
    public interface ILayoutController { void SetLayoutHorizontal(); void SetLayoutVertical(); }
    public interface ILayoutGroup : ILayoutController { }
    public interface ILayoutSelfController : ILayoutController { }
    public interface ILayoutIgnorer { bool ignoreLayout { get; } }

    public static class LayoutUtility
    {
        public static float GetMinSize(RectTransform rect, int axis) => axis == 0 ? GetMinWidth(rect) : GetMinHeight(rect);
        public static float GetPreferredSize(RectTransform rect, int axis) => axis == 0 ? GetPreferredWidth(rect) : GetPreferredHeight(rect);
        public static float GetFlexibleSize(RectTransform rect, int axis) => axis == 0 ? GetFlexibleWidth(rect) : GetFlexibleHeight(rect);
        public static float GetMinWidth(RectTransform rect) => GetLayoutProperty(rect, e => e.minWidth, 0);
        public static float GetPreferredWidth(RectTransform rect) => Mathf.Max(GetLayoutProperty(rect, e => e.minWidth, 0), GetLayoutProperty(rect, e => e.preferredWidth, 0));
        public static float GetFlexibleWidth(RectTransform rect) => GetLayoutProperty(rect, e => e.flexibleWidth, 0);
        public static float GetMinHeight(RectTransform rect) => GetLayoutProperty(rect, e => e.minHeight, 0);
        public static float GetPreferredHeight(RectTransform rect) => Mathf.Max(GetLayoutProperty(rect, e => e.minHeight, 0), GetLayoutProperty(rect, e => e.preferredHeight, 0));
        public static float GetFlexibleHeight(RectTransform rect) => GetLayoutProperty(rect, e => e.flexibleHeight, 0);
        public static float GetLayoutProperty(RectTransform rect, Func<ILayoutElement, float> property, float defaultValue) => GetLayoutProperty(rect, property, defaultValue, out _);
        public static float GetLayoutProperty(RectTransform rect, Func<ILayoutElement, float> property, float defaultValue, out ILayoutElement source)
        {
            source = null;
            if (rect == null) return 0;
            float min = defaultValue; int maxPriority = int.MinValue;
            foreach (var c in rect.gameObject.m_Components)
            {
                if (!(c is ILayoutElement le) || c.m_Destroyed) continue;
                if (c is Behaviour b && !b.isActiveAndEnabled) continue;
                int priority = le.layoutPriority;
                if (priority < maxPriority) continue;
                float prop = property(le);
                if (prop < 0) continue;
                if (priority > maxPriority) { min = prop; maxPriority = priority; source = le; }
                else if (prop > min) { min = prop; source = le; }
            }
            return min;
        }
    }

    public class LayoutRebuilder : ICanvasElement
    {
        RectTransform m_ToRebuild;
        public Transform transform => m_ToRebuild;
        public bool IsDestroyed() => m_ToRebuild == null;
        public void Rebuild(CanvasUpdate executing) { if (executing == CanvasUpdate.Layout) ForceRebuildLayoutImmediate(m_ToRebuild); }
        public void LayoutComplete() { }
        public void GraphicUpdateComplete() { }
        public static void ForceRebuildLayoutImmediate(RectTransform layoutRoot) { if (layoutRoot != null) UIRuntime.LayoutSubtree(layoutRoot); }
        public static void MarkLayoutForRebuild(RectTransform rect) => UIRuntime.MarkLayoutDirty();
    }

    [AddComponentMenu("Layout/Layout Element", 140)]
    [RequireComponent(typeof(RectTransform))]
    [ExecuteAlways]
    public class LayoutElement : UIBehaviour, ILayoutElement, ILayoutIgnorer
    {
        [SerializeField] bool m_IgnoreLayout;
        [SerializeField] float m_MinWidth = -1, m_MinHeight = -1, m_PreferredWidth = -1, m_PreferredHeight = -1, m_FlexibleWidth = -1, m_FlexibleHeight = -1;
        [SerializeField] int m_LayoutPriority = 1;
        public virtual bool ignoreLayout { get => m_IgnoreLayout; set { m_IgnoreLayout = value; SetDirty(); } }
        public virtual void CalculateLayoutInputHorizontal() { }
        public virtual void CalculateLayoutInputVertical() { }
        public virtual float minWidth { get => m_MinWidth; set { m_MinWidth = value; SetDirty(); } }
        public virtual float minHeight { get => m_MinHeight; set { m_MinHeight = value; SetDirty(); } }
        public virtual float preferredWidth { get => m_PreferredWidth; set { m_PreferredWidth = value; SetDirty(); } }
        public virtual float preferredHeight { get => m_PreferredHeight; set { m_PreferredHeight = value; SetDirty(); } }
        public virtual float flexibleWidth { get => m_FlexibleWidth; set { m_FlexibleWidth = value; SetDirty(); } }
        public virtual float flexibleHeight { get => m_FlexibleHeight; set { m_FlexibleHeight = value; SetDirty(); } }
        public virtual int layoutPriority { get => m_LayoutPriority; set { m_LayoutPriority = value; SetDirty(); } }
        protected LayoutElement() { }
        protected void SetDirty() => UIRuntime.MarkLayoutDirty();
    }

    [DisallowMultipleComponent]
    [ExecuteAlways]
    [RequireComponent(typeof(RectTransform))]
    public abstract class LayoutGroup : UIBehaviour, ILayoutElement, ILayoutGroup
    {
        [SerializeField] protected RectOffset m_Padding = new RectOffset();
        [SerializeField] protected TextAnchor m_ChildAlignment = TextAnchor.UpperLeft;
        public RectOffset padding { get => m_Padding; set { m_Padding = value; SetDirty(); } }
        public TextAnchor childAlignment { get => m_ChildAlignment; set { m_ChildAlignment = value; SetDirty(); } }
        protected RectTransform rectTransform => (RectTransform)transform;
        protected List<RectTransform> m_RectChildren = new List<RectTransform>();
        protected List<RectTransform> rectChildren => m_RectChildren;
        Vector2 m_TotalMinSize, m_TotalPreferredSize, m_TotalFlexibleSize;
        public virtual void CalculateLayoutInputHorizontal()
        {
            m_RectChildren.Clear();
            foreach (Transform t in rectTransform)
            {
                if (!(t is RectTransform rect) || !rect.gameObject.activeInHierarchy) continue;
                bool ignore = false;
                foreach (var c in rect.gameObject.m_Components) if (c is ILayoutIgnorer li && (!(c is Behaviour b) || b.isActiveAndEnabled) && li.ignoreLayout) { ignore = true; break; }
                if (!ignore) m_RectChildren.Add(rect);
            }
        }
        public abstract void CalculateLayoutInputVertical();
        public virtual float minWidth => GetTotalMinSize(0);
        public virtual float preferredWidth => GetTotalPreferredSize(0);
        public virtual float flexibleWidth => GetTotalFlexibleSize(0);
        public virtual float minHeight => GetTotalMinSize(1);
        public virtual float preferredHeight => GetTotalPreferredSize(1);
        public virtual float flexibleHeight => GetTotalFlexibleSize(1);
        public virtual int layoutPriority => 0;
        public abstract void SetLayoutHorizontal();
        public abstract void SetLayoutVertical();
        protected LayoutGroup() { m_Padding ??= new RectOffset(); }
        protected override void OnEnable() { SetDirty(); }
        protected override void OnDisable() { SetDirty(); }
        protected float GetTotalMinSize(int axis) => m_TotalMinSize[axis];
        protected float GetTotalPreferredSize(int axis) => m_TotalPreferredSize[axis];
        protected float GetTotalFlexibleSize(int axis) => m_TotalFlexibleSize[axis];
        protected float GetStartOffset(int axis, float requiredSpaceWithoutPadding)
        {
            float requiredSpace = requiredSpaceWithoutPadding + (axis == 0 ? padding.horizontal : padding.vertical);
            float availableSpace = rectTransform.rect.size[axis];
            float surplusSpace = availableSpace - requiredSpace;
            float alignmentOnAxis = GetAlignmentOnAxis(axis);
            return (axis == 0 ? padding.left : padding.top) + surplusSpace * alignmentOnAxis;
        }
        protected float GetAlignmentOnAxis(int axis) => axis == 0 ? ((int)childAlignment % 3) * 0.5f : ((int)childAlignment / 3) * 0.5f;
        protected void SetLayoutInputForAxis(float totalMin, float totalPreferred, float totalFlexible, int axis)
        {
            m_TotalMinSize[axis] = totalMin; m_TotalPreferredSize[axis] = totalPreferred; m_TotalFlexibleSize[axis] = totalFlexible;
        }
        protected void SetChildAlongAxis(RectTransform rect, int axis, float pos) { if (rect == null) return; SetChildAlongAxisWithScale(rect, axis, pos, 1.0f); }
        protected void SetChildAlongAxisWithScale(RectTransform rect, int axis, float pos, float scaleFactor)
        {
            if (rect == null) return;
            rect.SetInsetAndSizeFromParentEdge(axis == 0 ? RectTransform.Edge.Left : RectTransform.Edge.Top, pos, rect.sizeDelta[axis] * scaleFactor);
        }
        protected void SetChildAlongAxis(RectTransform rect, int axis, float pos, float size) { if (rect == null) return; SetChildAlongAxisWithScale(rect, axis, pos, size, 1.0f); }
        protected void SetChildAlongAxisWithScale(RectTransform rect, int axis, float pos, float size, float scaleFactor)
        {
            if (rect == null) return;
            rect.SetInsetAndSizeFromParentEdge(axis == 0 ? RectTransform.Edge.Left : RectTransform.Edge.Top, pos, size * scaleFactor);
        }
        protected bool isRootLayoutGroup { get { var p = transform.parent; return p == null || p.GetComponent<ILayoutGroup>() == null; } }
        protected override void OnRectTransformDimensionsChange() { SetDirty(); }
        protected virtual void OnTransformChildrenChanged() { SetDirty(); }
        protected void SetProperty<T>(ref T currentValue, T newValue) { if ((currentValue == null && newValue == null) || (currentValue != null && currentValue.Equals(newValue))) return; currentValue = newValue; SetDirty(); }
        protected void SetDirty() => UIRuntime.MarkLayoutDirty();
    }

    public abstract class HorizontalOrVerticalLayoutGroup : LayoutGroup
    {
        [SerializeField] protected float m_Spacing = 0;
        [SerializeField] protected bool m_ChildForceExpandWidth = true, m_ChildForceExpandHeight = true;
        [SerializeField] protected bool m_ChildControlWidth = true, m_ChildControlHeight = true;
        [SerializeField] protected bool m_ChildScaleWidth = false, m_ChildScaleHeight = false;
        [SerializeField] protected bool m_ReverseArrangement = false;
        public float spacing { get => m_Spacing; set => SetProperty(ref m_Spacing, value); }
        public bool childForceExpandWidth { get => m_ChildForceExpandWidth; set => SetProperty(ref m_ChildForceExpandWidth, value); }
        public bool childForceExpandHeight { get => m_ChildForceExpandHeight; set => SetProperty(ref m_ChildForceExpandHeight, value); }
        public bool childControlWidth { get => m_ChildControlWidth; set => SetProperty(ref m_ChildControlWidth, value); }
        public bool childControlHeight { get => m_ChildControlHeight; set => SetProperty(ref m_ChildControlHeight, value); }
        public bool childScaleWidth { get => m_ChildScaleWidth; set => SetProperty(ref m_ChildScaleWidth, value); }
        public bool childScaleHeight { get => m_ChildScaleHeight; set => SetProperty(ref m_ChildScaleHeight, value); }
        public bool reverseArrangement { get => m_ReverseArrangement; set => SetProperty(ref m_ReverseArrangement, value); }
        protected void CalcAlongAxis(int axis, bool isVertical)
        {
            float combinedPadding = axis == 0 ? padding.horizontal : padding.vertical;
            bool controlSize = axis == 0 ? m_ChildControlWidth : m_ChildControlHeight;
            bool useScale = axis == 0 ? m_ChildScaleWidth : m_ChildScaleHeight;
            bool childForceExpandSize = axis == 0 ? m_ChildForceExpandWidth : m_ChildForceExpandHeight;
            float totalMin = combinedPadding, totalPreferred = combinedPadding, totalFlexible = 0;
            bool alongOtherAxis = isVertical ^ (axis == 1);
            int count = reverseArrangement ? rectChildren.Count - 1 : 0, end = reverseArrangement ? 0 : rectChildren.Count, inc = reverseArrangement ? -1 : 1;
            for (int i = count; reverseArrangement ? i >= end : i < end; i += inc)
            {
                var child = rectChildren[i];
                GetChildSizes(child, axis, controlSize, childForceExpandSize, out var min, out var preferred, out var flexible);
                if (useScale) { float s = child.localScale[axis]; min *= s; preferred *= s; flexible *= s; }
                if (alongOtherAxis) { totalMin = Mathf.Max(min + combinedPadding, totalMin); totalPreferred = Mathf.Max(preferred + combinedPadding, totalPreferred); totalFlexible = Mathf.Max(flexible, totalFlexible); }
                else { totalMin += min + spacing; totalPreferred += preferred + spacing; totalFlexible += flexible; }
            }
            if (!alongOtherAxis && rectChildren.Count > 0) { totalMin -= spacing; totalPreferred -= spacing; }
            totalPreferred = Mathf.Max(totalMin, totalPreferred);
            SetLayoutInputForAxis(totalMin, totalPreferred, totalFlexible, axis);
        }
        protected void SetChildrenAlongAxis(int axis, bool isVertical)
        {
            float size = rectTransform.rect.size[axis];
            bool controlSize = axis == 0 ? m_ChildControlWidth : m_ChildControlHeight;
            bool useScale = axis == 0 ? m_ChildScaleWidth : m_ChildScaleHeight;
            bool childForceExpandSize = axis == 0 ? m_ChildForceExpandWidth : m_ChildForceExpandHeight;
            float alignmentOnAxis = GetAlignmentOnAxis(axis);
            bool alongOtherAxis = isVertical ^ (axis == 1);
            int startIndex = m_ReverseArrangement ? rectChildren.Count - 1 : 0, endIndex = m_ReverseArrangement ? 0 : rectChildren.Count, increment = m_ReverseArrangement ? -1 : 1;
            if (alongOtherAxis)
            {
                float innerSize = size - (axis == 0 ? padding.horizontal : padding.vertical);
                for (int i = startIndex; m_ReverseArrangement ? i >= endIndex : i < endIndex; i += increment)
                {
                    var child = rectChildren[i];
                    GetChildSizes(child, axis, controlSize, childForceExpandSize, out var min, out var preferred, out var flexible);
                    float scaleFactor = useScale ? child.localScale[axis] : 1f;
                    float requiredSpace = Mathf.Clamp(innerSize, min, flexible > 0 ? size : preferred);
                    float startOffset = GetStartOffset(axis, requiredSpace * scaleFactor);
                    if (controlSize) SetChildAlongAxisWithScale(child, axis, startOffset, requiredSpace, scaleFactor);
                    else { float offsetInCell = (requiredSpace - child.sizeDelta[axis]) * alignmentOnAxis; SetChildAlongAxisWithScale(child, axis, startOffset + offsetInCell, scaleFactor); }
                }
            }
            else
            {
                float pos = axis == 0 ? padding.left : padding.top;
                float itemFlexibleMultiplier = 0;
                float surplusSpace = size - GetTotalPreferredSize(axis);
                if (surplusSpace > 0)
                {
                    if (GetTotalFlexibleSize(axis) == 0) pos = GetStartOffset(axis, GetTotalPreferredSize(axis) - (axis == 0 ? padding.horizontal : padding.vertical));
                    else if (GetTotalFlexibleSize(axis) > 0) itemFlexibleMultiplier = surplusSpace / GetTotalFlexibleSize(axis);
                }
                float minMaxLerp = 0;
                if (GetTotalMinSize(axis) != GetTotalPreferredSize(axis)) minMaxLerp = Mathf.Clamp01((size - GetTotalMinSize(axis)) / (GetTotalPreferredSize(axis) - GetTotalMinSize(axis)));
                for (int i = startIndex; m_ReverseArrangement ? i >= endIndex : i < endIndex; i += increment)
                {
                    var child = rectChildren[i];
                    GetChildSizes(child, axis, controlSize, childForceExpandSize, out var min, out var preferred, out var flexible);
                    float scaleFactor = useScale ? child.localScale[axis] : 1f;
                    float childSize = Mathf.Lerp(min, preferred, minMaxLerp);
                    childSize += flexible * itemFlexibleMultiplier;
                    if (controlSize) SetChildAlongAxisWithScale(child, axis, pos, childSize, scaleFactor);
                    else { float offsetInCell = (childSize - child.sizeDelta[axis]) * alignmentOnAxis; SetChildAlongAxisWithScale(child, axis, pos + offsetInCell, scaleFactor); }
                    pos += childSize * scaleFactor + spacing;
                }
            }
        }
        void GetChildSizes(RectTransform child, int axis, bool controlSize, bool childForceExpand, out float min, out float preferred, out float flexible)
        {
            if (!controlSize) { min = child.sizeDelta[axis]; preferred = min; flexible = 0; }
            else { min = LayoutUtility.GetMinSize(child, axis); preferred = LayoutUtility.GetPreferredSize(child, axis); flexible = LayoutUtility.GetFlexibleSize(child, axis); }
            if (childForceExpand) flexible = Mathf.Max(flexible, 1);
        }
    }

    [AddComponentMenu("Layout/Horizontal Layout Group", 150)]
    public class HorizontalLayoutGroup : HorizontalOrVerticalLayoutGroup
    {
        protected HorizontalLayoutGroup() { }
        public override void CalculateLayoutInputHorizontal() { base.CalculateLayoutInputHorizontal(); CalcAlongAxis(0, false); }
        public override void CalculateLayoutInputVertical() { CalcAlongAxis(1, false); }
        public override void SetLayoutHorizontal() { SetChildrenAlongAxis(0, false); }
        public override void SetLayoutVertical() { SetChildrenAlongAxis(1, false); }
    }
    [AddComponentMenu("Layout/Vertical Layout Group", 151)]
    public class VerticalLayoutGroup : HorizontalOrVerticalLayoutGroup
    {
        protected VerticalLayoutGroup() { }
        public override void CalculateLayoutInputHorizontal() { base.CalculateLayoutInputHorizontal(); CalcAlongAxis(0, true); }
        public override void CalculateLayoutInputVertical() { CalcAlongAxis(1, true); }
        public override void SetLayoutHorizontal() { SetChildrenAlongAxis(0, true); }
        public override void SetLayoutVertical() { SetChildrenAlongAxis(1, true); }
    }

    [AddComponentMenu("Layout/Grid Layout Group", 152)]
    public class GridLayoutGroup : LayoutGroup
    {
        public enum Corner { UpperLeft = 0, UpperRight = 1, LowerLeft = 2, LowerRight = 3 }
        public enum Axis { Horizontal = 0, Vertical = 1 }
        public enum Constraint { Flexible = 0, FixedColumnCount = 1, FixedRowCount = 2 }
        [SerializeField] protected Corner m_StartCorner = Corner.UpperLeft;
        [SerializeField] protected Axis m_StartAxis = Axis.Horizontal;
        [SerializeField] protected Vector2 m_CellSize = new Vector2(100, 100);
        [SerializeField] protected Vector2 m_Spacing = Vector2.zero;
        [SerializeField] protected Constraint m_Constraint = Constraint.Flexible;
        [SerializeField] protected int m_ConstraintCount = 2;
        public Corner startCorner { get => m_StartCorner; set => SetProperty(ref m_StartCorner, value); }
        public Axis startAxis { get => m_StartAxis; set => SetProperty(ref m_StartAxis, value); }
        public Vector2 cellSize { get => m_CellSize; set => SetProperty(ref m_CellSize, value); }
        public Vector2 spacing { get => m_Spacing; set => SetProperty(ref m_Spacing, value); }
        public Constraint constraint { get => m_Constraint; set => SetProperty(ref m_Constraint, value); }
        public int constraintCount { get => m_ConstraintCount; set => SetProperty(ref m_ConstraintCount, Mathf.Max(1, value)); }
        protected GridLayoutGroup() { }
        public override void CalculateLayoutInputHorizontal()
        {
            base.CalculateLayoutInputHorizontal();
            int minColumns, preferredColumns;
            if (m_Constraint == Constraint.FixedColumnCount) minColumns = preferredColumns = m_ConstraintCount;
            else if (m_Constraint == Constraint.FixedRowCount) minColumns = preferredColumns = Mathf.CeilToInt(rectChildren.Count / (float)m_ConstraintCount - 0.001f);
            else { minColumns = 1; preferredColumns = Mathf.CeilToInt(Mathf.Sqrt(rectChildren.Count)); }
            SetLayoutInputForAxis(padding.horizontal + (cellSize.x + spacing.x) * minColumns - spacing.x, padding.horizontal + (cellSize.x + spacing.x) * preferredColumns - spacing.x, -1, 0);
        }
        public override void CalculateLayoutInputVertical()
        {
            int minRows;
            if (m_Constraint == Constraint.FixedColumnCount) minRows = Mathf.CeilToInt(rectChildren.Count / (float)m_ConstraintCount - 0.001f);
            else if (m_Constraint == Constraint.FixedRowCount) minRows = m_ConstraintCount;
            else
            {
                float width = rectTransform.rect.size.x;
                int cellCountX = Mathf.Max(1, Mathf.FloorToInt((width - padding.horizontal + spacing.x + 0.001f) / (cellSize.x + spacing.x)));
                minRows = Mathf.CeilToInt(rectChildren.Count / (float)cellCountX);
            }
            float minSpace = padding.vertical + (cellSize.y + spacing.y) * minRows - spacing.y;
            SetLayoutInputForAxis(minSpace, minSpace, -1, 1);
        }
        public override void SetLayoutHorizontal() => SetCellsAlongAxis(0);
        public override void SetLayoutVertical() => SetCellsAlongAxis(1);
        void SetCellsAlongAxis(int axis)
        {
            int rectChildrenCount = rectChildren.Count;
            if (axis == 0)
            {
                foreach (var rect in rectChildren) { rect.anchorMin = Vector2.up; rect.anchorMax = Vector2.up; rect.sizeDelta = cellSize; }
                return;
            }
            float width = rectTransform.rect.size.x, height = rectTransform.rect.size.y;
            int cellCountX = 1, cellCountY = 1;
            if (m_Constraint == Constraint.FixedColumnCount) { cellCountX = m_ConstraintCount; if (rectChildrenCount > cellCountX) cellCountY = rectChildrenCount / cellCountX + (rectChildrenCount % cellCountX > 0 ? 1 : 0); }
            else if (m_Constraint == Constraint.FixedRowCount) { cellCountY = m_ConstraintCount; if (rectChildrenCount > cellCountY) cellCountX = rectChildrenCount / cellCountY + (rectChildrenCount % cellCountY > 0 ? 1 : 0); }
            else
            {
                cellCountX = cellSize.x + spacing.x <= 0 ? int.MaxValue : Mathf.Max(1, Mathf.FloorToInt((width - padding.horizontal + spacing.x + 0.001f) / (cellSize.x + spacing.x)));
                cellCountY = cellSize.y + spacing.y <= 0 ? int.MaxValue : Mathf.Max(1, Mathf.FloorToInt((height - padding.vertical + spacing.y + 0.001f) / (cellSize.y + spacing.y)));
            }
            int cornerX = (int)startCorner % 2, cornerY = (int)startCorner / 2;
            int cellsPerMainAxis, actualCellCountX, actualCellCountY;
            if (startAxis == Axis.Horizontal) { cellsPerMainAxis = cellCountX; actualCellCountX = Mathf.Clamp(cellCountX, 1, rectChildrenCount); actualCellCountY = Mathf.Clamp(cellCountY, 1, Mathf.CeilToInt(rectChildrenCount / (float)cellsPerMainAxis)); }
            else { cellsPerMainAxis = cellCountY; actualCellCountY = Mathf.Clamp(cellCountY, 1, rectChildrenCount); actualCellCountX = Mathf.Clamp(cellCountX, 1, Mathf.CeilToInt(rectChildrenCount / (float)cellsPerMainAxis)); }
            var requiredSpace = new Vector2(actualCellCountX * cellSize.x + (actualCellCountX - 1) * spacing.x, actualCellCountY * cellSize.y + (actualCellCountY - 1) * spacing.y);
            var startOffset = new Vector2(GetStartOffset(0, requiredSpace.x), GetStartOffset(1, requiredSpace.y));
            for (int i = 0; i < rectChildrenCount; i++)
            {
                int positionX, positionY;
                if (startAxis == Axis.Horizontal) { positionX = i % cellsPerMainAxis; positionY = i / cellsPerMainAxis; }
                else { positionX = i / cellsPerMainAxis; positionY = i % cellsPerMainAxis; }
                if (cornerX == 1) positionX = actualCellCountX - 1 - positionX;
                if (cornerY == 1) positionY = actualCellCountY - 1 - positionY;
                SetChildAlongAxis(rectChildren[i], 0, startOffset.x + (cellSize[0] + spacing[0]) * positionX, cellSize[0]);
                SetChildAlongAxis(rectChildren[i], 1, startOffset.y + (cellSize[1] + spacing[1]) * positionY, cellSize[1]);
            }
        }
    }

    [AddComponentMenu("Layout/Content Size Fitter", 141)]
    [ExecuteAlways]
    [RequireComponent(typeof(RectTransform))]
    public class ContentSizeFitter : UIBehaviour, ILayoutSelfController
    {
        public enum FitMode { Unconstrained = 0, MinSize = 1, PreferredSize = 2 }
        [SerializeField] protected FitMode m_HorizontalFit = FitMode.Unconstrained;
        [SerializeField] protected FitMode m_VerticalFit = FitMode.Unconstrained;
        public FitMode horizontalFit { get => m_HorizontalFit; set { m_HorizontalFit = value; SetDirty(); } }
        public FitMode verticalFit { get => m_VerticalFit; set { m_VerticalFit = value; SetDirty(); } }
        protected ContentSizeFitter() { }
        RectTransform rectTransform => (RectTransform)transform;
        void HandleSelfFittingAlongAxis(int axis)
        {
            var fitting = axis == 0 ? horizontalFit : verticalFit;
            if (fitting == FitMode.Unconstrained) return;
            rectTransform.SetSizeWithCurrentAnchors((RectTransform.Axis)axis, fitting == FitMode.MinSize ? LayoutUtility.GetMinSize(rectTransform, axis) : LayoutUtility.GetPreferredSize(rectTransform, axis));
        }
        public virtual void SetLayoutHorizontal() => HandleSelfFittingAlongAxis(0);
        public virtual void SetLayoutVertical() => HandleSelfFittingAlongAxis(1);
        protected void SetDirty() => UIRuntime.MarkLayoutDirty();
    }

    [AddComponentMenu("Layout/Aspect Ratio Fitter", 142)]
    [ExecuteAlways]
    [RequireComponent(typeof(RectTransform))]
    [DisallowMultipleComponent]
    public class AspectRatioFitter : UIBehaviour, ILayoutSelfController
    {
        public enum AspectMode { None = 0, WidthControlsHeight = 1, HeightControlsWidth = 2, FitInParent = 3, EnvelopeParent = 4 }
        [SerializeField] AspectMode m_AspectMode = AspectMode.None;
        [SerializeField] float m_AspectRatio = 1;
        public AspectMode aspectMode { get => m_AspectMode; set => m_AspectMode = value; }
        public float aspectRatio { get => m_AspectRatio; set => m_AspectRatio = value; }
        protected AspectRatioFitter() { }
        RectTransform rectTransform => (RectTransform)transform;
        public virtual void SetLayoutHorizontal() { }
        public virtual void SetLayoutVertical() { }
        public bool IsComponentValidOnObject() => true;
        public bool IsAspectModeValid() => true;
        internal void Apply()
        {
            var rt = rectTransform;
            switch (m_AspectMode)
            {
                case AspectMode.HeightControlsWidth: rt.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, rt.rect.height * m_AspectRatio); break;
                case AspectMode.WidthControlsHeight: rt.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, rt.rect.width / m_AspectRatio); break;
                case AspectMode.FitInParent:
                case AspectMode.EnvelopeParent:
                    {
                        var p = rt.parent as RectTransform; if (p == null) break;
                        var ps = p.rect.size; var size = Vector2.zero;
                        if ((ps.y * m_AspectRatio < ps.x) ^ (m_AspectMode == AspectMode.FitInParent)) size = new Vector2(ps.x, ps.x / m_AspectRatio); else size = new Vector2(ps.y * m_AspectRatio, ps.y);
                        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.anchoredPosition = Vector2.zero;
                        rt.sizeDelta = size - ps;
                        break;
                    }
            }
        }
        protected void SetDirty() => UIRuntime.MarkLayoutDirty();
    }
}
