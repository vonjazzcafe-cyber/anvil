// Runs uGUI each frame: canvas scaling, auto layout, drawing (as overlay commands for the Game view) and raycasts.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEngine.EventSystems;
using Anvil;

namespace UnityEngine.UI
{
    internal sealed class UIDraw
    {
        internal float screenH;
        internal Canvas canvas; internal GraphicRaycaster raycaster; internal Camera cam; internal bool world;
        internal float alpha = 1f;
        internal Rect? clip;
        internal static string F(float v) => v.ToString("0.####", CultureInfo.InvariantCulture);
        internal static string Hex(Color c) { Color32 k = c; return "#" + k.r.ToString("x2") + k.g.ToString("x2") + k.b.ToString("x2") + k.a.ToString("x2"); }

        // the rect's four corners in screen pixels (origin bottom-left), Unity order: BL, TL, TR, BR
        internal bool Corners(RectTransform rt, Rect r, Vector3[] outC)
        {
            var m = rt.localToWorldMatrix;
            outC[0] = m.MultiplyPoint(new Vector3(r.xMin, r.yMin)); outC[1] = m.MultiplyPoint(new Vector3(r.xMin, r.yMax));
            outC[2] = m.MultiplyPoint(new Vector3(r.xMax, r.yMax)); outC[3] = m.MultiplyPoint(new Vector3(r.xMax, r.yMin));
            if (world)
            {
                if (cam == null) return false;
                for (int i = 0; i < 4; i++) { var s = cam.WorldToScreenPoint(outC[i]); if (s.z <= cam.nearClipPlane * 0.5f) return false; outC[i] = s; }
            }
            return true;
        }
        readonly Vector3[] m_C = new Vector3[4];
        // GUI command geometry (top-left origin) from screen corners
        bool Geometry(RectTransform rt, Rect r, out Rect gr, out float rot, out float pxScale)
        {
            gr = default; rot = 0; pxScale = 1;
            if (!Corners(rt, r, m_C)) return false;
            var bl = m_C[0]; var tl = m_C[1]; var br = m_C[3]; var tr = m_C[2];
            float w = Vector2.Distance(bl, br), h = Vector2.Distance(bl, tl);
            var c = (bl + tr) * 0.5f;
            float ang = Mathf.Atan2(br.y - bl.y, br.x - bl.x) * Mathf.Rad2Deg;
            // mirrored (negative scale) rects keep their size; Unity would show them flipped
            if (Mathf.Abs(ang) < 0.01f) ang = 0;
            rot = -ang;
            gr = new Rect(c.x - w * 0.5f, screenH - c.y - h * 0.5f, w, h);
            pxScale = r.height > 1e-4f ? h / r.height : (r.width > 1e-4f ? w / r.width : rt.lossyScale.y);
            if (!world && r.height <= 1e-4f && r.width <= 1e-4f) pxScale = Mathf.Abs(rt.lossyScale.y);
            return true;
        }
        internal void Quad(Graphic g, Texture tex, int scaleMode, string extra)
        {
            var rt = g.rectTransform; var r = rt.rect;
            if (!Geometry(rt, r, out var gr, out var rot, out var px)) return;
            var col = g.RenderColor(alpha);
            int texRef = 0;
            if (tex is Texture2D t2) { if (t2.UniformColor(out var uc)) col *= uc; else texRef = RenderSync.TextureRef(t2); }
            else if (tex != null) texRef = RenderSync.TextureRef(tex);
            AddHit(g, rt, r);
            if (col.a <= 0.001f) return;
            GUI.cmds.Add(new GuiCmd { kind = 10, rect = gr, rot = rot, text = "", bgColor = col, textColor = col, tex = texRef, value = scaleMode, max = px, extra = extra, pad = s_NoPad });
        }
        internal void Text(Graphic g, string text, float fontSize, int style, int align, bool wrap, bool rich, string font, string extra)
        {
            var rt = g.rectTransform; var r = rt.rect;
            if (!Geometry(rt, r, out var gr, out var rot, out var px)) return;
            AddHit(g, rt, r);
            var col = g.RenderColor(alpha);
            if (col.a <= 0.001f || string.IsNullOrEmpty(text)) return;
            GUI.cmds.Add(new GuiCmd { kind = 11, rect = gr, rot = rot, text = text, fontSize = fontSize * px, fontStyle = (FontStyle)style, align = (TextAnchor)align, textColor = col, bgColor = default, wrap = wrap, rich = rich, font = font, extra = string.IsNullOrEmpty(extra) ? null : extra, value = px, pad = s_NoPad });
        }
        // text with a TMP-style alignment string and margins (already in local units)
        internal void TextBox(Graphic g, Rect localRect, string text, float fontSize, int style, int align, bool wrap, bool rich, string font, string extra, Color col)
        {
            var rt = g.rectTransform;
            if (!Geometry(rt, localRect, out var gr, out var rot, out var px)) return;
            col.a *= alpha;
            if (col.a <= 0.001f || string.IsNullOrEmpty(text)) return;
            GUI.cmds.Add(new GuiCmd { kind = 11, rect = gr, rot = rot, text = text, fontSize = fontSize * px, fontStyle = (FontStyle)style, align = (TextAnchor)align, textColor = col, wrap = wrap, rich = rich, font = font, extra = string.IsNullOrEmpty(extra) ? null : extra, value = px, pad = s_NoPad });
        }
        internal void HitOnly(Graphic g) { var rt = g.rectTransform; AddHit(g, rt, rt.rect); }
        // Graphic subclasses that build their own mesh (OnPopulateMesh): drawn as triangles
        internal void CustomMesh(Graphic g)
        {
            var vh = new VertexHelper();
            try { g.PopulateForDraw(vh); } catch (Exception e) { Debug.LogException(e); return; }
            foreach (var c in g.gameObject.m_Components) if (c is IMeshModifier mm && c is Behaviour b && b.isActiveAndEnabled) { try { mm.ModifyMesh(vh); } catch (Exception e) { Debug.LogException(e); } }
            var rt = g.rectTransform;
            AddHit(g, rt, rt.rect);
            if (vh.m_Indices.Count == 0) return;
            var m = rt.localToWorldMatrix; var tint = g.RenderColor(alpha) * new Color(1, 1, 1, 1);
            var crc = g.GetComponent<CanvasRenderer>(); Color crTint = crc != null ? crc.m_Color : Color.white; float crA = crc != null ? crc.m_Alpha : 1f;
            var sb = new StringBuilder();
            float minX = float.MaxValue, minY = float.MaxValue, maxX = float.MinValue, maxY = float.MinValue;
            var pts = new Vector2[vh.m_Verts.Count];
            for (int i = 0; i < pts.Length; i++)
            {
                var wp = m.MultiplyPoint(vh.m_Verts[i].position);
                if (world) { if (cam == null) return; wp = cam.WorldToScreenPoint(wp); }
                pts[i] = new Vector2(wp.x, screenH - wp.y);
                minX = Mathf.Min(minX, pts[i].x); minY = Mathf.Min(minY, pts[i].y); maxX = Mathf.Max(maxX, pts[i].x); maxY = Mathf.Max(maxY, pts[i].y);
            }
            for (int t = 0; t + 2 < vh.m_Indices.Count && t < 3000; t += 3)
            {
                int a = vh.m_Indices[t], b = vh.m_Indices[t + 1], c = vh.m_Indices[t + 2];
                if (a >= pts.Length || b >= pts.Length || c >= pts.Length) continue;
                Color ca = vh.m_Verts[a].color, cb = vh.m_Verts[b].color, cc = vh.m_Verts[c].color;
                var col = new Color((ca.r + cb.r + cc.r) / 3, (ca.g + cb.g + cc.g) / 3, (ca.b + cb.b + cc.b) / 3, (ca.a + cb.a + cc.a) / 3) * crTint;
                col.a *= crA * alpha;
                sb.Append(F(pts[a].x - minX)).Append(',').Append(F(pts[a].y - minY)).Append(' ').Append(F(pts[b].x - minX)).Append(',').Append(F(pts[b].y - minY)).Append(' ').Append(F(pts[c].x - minX)).Append(',').Append(F(pts[c].y - minY)).Append('|').Append(Hex(col)).Append(';');
            }
            GUI.cmds.Add(new GuiCmd { kind = 12, rect = new Rect(minX, minY, Mathf.Max(1, maxX - minX), Mathf.Max(1, maxY - minY)), text = sb.ToString(), pad = s_NoPad });
        }
        static readonly RectOffset s_NoPad = new RectOffset();
        void AddHit(Graphic g, RectTransform rt, Rect r)
        {
            if (!g.raycastTarget) return;
            var c = new Vector3[4];
            if (!Corners(rt, r, c)) return;
            var pad = g.raycastPadding;
            UIRuntime.s_Hits.Add(new UIRuntime.Hit { g = g, c0 = c[0], c1 = c[1], c2 = c[2], c3 = c[3], clip = clip, raycaster = raycaster, cam = cam });
        }
        internal Rect? ScreenRect(RectTransform rt, Vector4 padding)
        {
            var r = rt.rect;
            r = new Rect(r.x + padding.x, r.y + padding.y, r.width - padding.x - padding.z, r.height - padding.y - padding.w);
            var c = new Vector3[4];
            if (!Corners(rt, r, c)) return null;
            float x0 = Mathf.Min(Mathf.Min(c[0].x, c[1].x), Mathf.Min(c[2].x, c[3].x)), x1 = Mathf.Max(Mathf.Max(c[0].x, c[1].x), Mathf.Max(c[2].x, c[3].x));
            float y0 = Mathf.Min(Mathf.Min(c[0].y, c[1].y), Mathf.Min(c[2].y, c[3].y)), y1 = Mathf.Max(Mathf.Max(c[0].y, c[1].y), Mathf.Max(c[2].y, c[3].y));
            return new Rect(x0, y0, x1 - x0, y1 - y0);
        }
    }

    internal static class UIRuntime
    {
        internal struct Hit { public Graphic g; public Vector3 c0, c1, c2, c3; public Rect? clip; public GraphicRaycaster raycaster; public Camera cam; }
        internal static readonly List<Hit> s_Hits = new List<Hit>();
        static bool s_LayoutDirty = true;
        internal static IDropdownPopup popupOwner;
        static readonly List<Rect> s_PopupItems = new List<Rect>(); static int s_PopupHover = -1; static int s_PopupOpenedFrame;
        internal static void MarkLayoutDirty() => s_LayoutDirty = true;
        internal static void ResetStatics() { s_Hits.Clear(); popupOwner = null; s_PopupItems.Clear(); s_LayoutDirty = true; EventSystem.ResetStatics(); Selectable.ResetStatics(); }

        static readonly Dictionary<Type, bool> s_Overrides = new Dictionary<Type, bool>();
        internal static bool OverridesPopulate(Type t)
        {
            if (s_Overrides.TryGetValue(t, out var r)) return r;
            var m = t.GetMethod("OnPopulateMesh", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public, null, new[] { typeof(VertexHelper) }, null);
            r = m != null && m.DeclaringType != typeof(Graphic) && m.DeclaringType.Assembly != typeof(Graphic).Assembly;
            s_Overrides[t] = r;
            return r;
        }

        internal static Camera CameraFor(RectTransform rt)
        {
            if (rt == null) return null;
            var c = rt.GetComponentInParent<Canvas>();
            if (c == null) return Camera.main;
            c = c.rootCanvas;
            if (c.renderMode == RenderMode.WorldSpace) return c.worldCamera != null ? c.worldCamera : Camera.main;
            return null; // overlay and screen-space camera canvases are handled in screen space here
        }

        static List<Canvas> RootCanvases()
        {
            var list = new List<Canvas>();
            foreach (var c in World.FindObjectsOfType<Canvas>(false)) if (c.isActiveAndEnabled && c.isRootCanvas) list.Add(c);
            return list;
        }

        // ---------- layout ----------
        internal static void PrepareCanvases(List<Canvas> roots)
        {
            float W = Screen.width, H = Screen.height;
            foreach (var cv in roots)
            {
                var rt = cv.transform as RectTransform; if (rt == null) continue;
                var scaler = cv.GetComponent<CanvasScaler>();
                if (scaler != null && scaler.isActiveAndEnabled && cv.renderMode != RenderMode.WorldSpace) cv.scaleFactor = scaler.ComputeScale();
                if (cv.renderMode == RenderMode.WorldSpace) continue;
                float s = cv.scaleFactor;
                rt.m_AnchorMin = Vector2.zero; rt.m_AnchorMax = Vector2.zero; rt.m_Pivot = new Vector2(0.5f, 0.5f);
                rt.m_SizeDelta = new Vector2(W / s, H / s);
                rt.m_AnchoredPosition = new Vector2(W * 0.5f, H * 0.5f);
                var lp = new Vector3(W * 0.5f, H * 0.5f, 0);
                if (rt.m_LocalPosition != lp || rt.m_LocalScale != new Vector3(s, s, s) || rt.m_LocalRotation != Quaternion.identity)
                {
                    rt.m_LocalPosition = lp; rt.m_LocalScale = new Vector3(s, s, s); rt.m_LocalRotation = Quaternion.identity; rt.MarkDirty();
                }
                rt.m_SyncedLP = new Vector2(lp.x, lp.y);
            }
        }
        internal static void LayoutAll()
        {
            var roots = RootCanvases();
            PrepareCanvases(roots);
            foreach (var cv in roots) if (cv.transform is RectTransform rt) LayoutSubtree(rt);
        }
        static readonly List<Component> s_Tmp = new List<Component>();
        internal static void LayoutSubtree(RectTransform root)
        {
            root.SyncTree();
            bool any = false;
            Walk(root, t => { foreach (var c in t.gameObject.m_Components) if (c is ILayoutController || c is AspectRatioFitter) { any = true; return; } });
            if (any)
            {
                for (int axis = 0; axis < 2; axis++)
                {
                    PostOrder(root, t =>
                    {
                        foreach (var c in t.gameObject.m_Components.ToArray())
                            if (c is ILayoutElement le && Live(c)) { try { if (axis == 0) le.CalculateLayoutInputHorizontal(); else le.CalculateLayoutInputVertical(); } catch (Exception e) { Debug.LogException(e); } }
                    });
                    Walk(root, t =>
                    {
                        foreach (var c in t.gameObject.m_Components.ToArray())
                        {
                            if (!Live(c)) continue;
                            if (c is AspectRatioFitter arf) { if (axis == 0) arf.Apply(); continue; }
                            if (c is ILayoutSelfController sc) { try { if (axis == 0) sc.SetLayoutHorizontal(); else sc.SetLayoutVertical(); } catch (Exception e) { Debug.LogException(e); } }
                        }
                        foreach (var c in t.gameObject.m_Components.ToArray())
                        {
                            if (!Live(c) || c is ILayoutSelfController) continue;
                            if (c is ILayoutController lc) { try { if (axis == 0) lc.SetLayoutHorizontal(); else lc.SetLayoutVertical(); } catch (Exception e) { Debug.LogException(e); } }
                        }
                    });
                }
                root.SyncTree();
            }
        }
        static bool Live(Component c) => !c.m_Destroyed && (!(c is Behaviour b) || b.isActiveAndEnabled);
        static void Walk(Transform t, Action<Transform> f) { if (!t.gameObject.m_ActiveSelf) return; f(t); foreach (var ch in t.m_Children.ToArray()) Walk(ch, f); }
        static void PostOrder(Transform t, Action<Transform> f) { if (!t.gameObject.m_ActiveSelf) return; foreach (var ch in t.m_Children.ToArray()) PostOrder(ch, f); f(t); }

        // ---------- frame ----------
        internal static void Render()
        {
            s_Hits.Clear();
            var roots = RootCanvases();
            if (roots.Count == 0) { Draw3DText(); if (popupOwner != null) ClosePopup(); return; }
            PrepareCanvases(roots);
            foreach (var cv in roots) if (cv.transform is RectTransform rt) LayoutSubtree(rt);
            try { Canvas.FireWillRender(); } catch (Exception e) { Debug.LogException(e); }
            Draw3DText();
            var ordered = roots.OrderBy(c => c.renderMode == RenderMode.ScreenSpaceOverlay ? 1 : 0).ThenBy(c => c.sortingOrder).ToList();
            foreach (var cv in ordered) DrawCanvas(cv);
            DrawPopup();
        }
        static void DrawCanvas(Canvas cv)
        {
            var d = new UIDraw { screenH = Screen.height, canvas = cv, raycaster = cv.GetComponent<GraphicRaycaster>(), world = cv.renderMode == RenderMode.WorldSpace };
            if (d.raycaster != null && !d.raycaster.isActiveAndEnabled) d.raycaster = null;
            if (d.world) d.cam = cv.worldCamera != null ? cv.worldCamera : Camera.main;
            DrawNode(cv.transform, d, 1f, true);
        }
        static void DrawNode(Transform t, UIDraw d, float alpha, bool isRoot)
        {
            var go = t.gameObject;
            if (!go.m_ActiveSelf) return;
            Graphic g = null; Mask mask = null; RectMask2D rmask = null; bool hiddenCanvas = false;
            foreach (var c in go.m_Components)
            {
                if (c.m_Destroyed) continue;
                switch (c)
                {
                    case CanvasGroup cg when cg.m_Enabled: alpha = cg.ignoreParentGroups ? cg.alpha : alpha * cg.alpha; break;
                    case Graphic gr: if (g == null) g = gr; break;
                    case Mask m when m.m_Enabled: mask = m; break;
                    case RectMask2D rm when rm.m_Enabled: rmask = rm; break;
                    case Canvas cv when !isRoot && !cv.m_Enabled: hiddenCanvas = true; break;
                    case Selectable s when s.m_Enabled: s.RefreshGroups(); break;
                }
            }
            if (hiddenCanvas) return;
            var prevAlpha = d.alpha; d.alpha = alpha;
            if (g != null && g.m_Enabled)
            {
                g.StepFades();
                if (mask != null && !mask.showMaskGraphic) d.HitOnly(g);
                else { try { g.Draw(d); } catch (Exception e) { Debug.LogException(e); } }
            }
            var prevClip = d.clip; bool pushed = false;
            if ((mask != null && g != null) || rmask != null)
            {
                var sr = d.ScreenRect((RectTransform)t, rmask != null ? rmask.padding : Vector4.zero);
                if (sr.HasValue)
                {
                    var r = sr.Value;
                    if (d.clip.HasValue) { var p = d.clip.Value; float x0 = Mathf.Max(p.xMin, r.xMin), y0 = Mathf.Max(p.yMin, r.yMin), x1 = Mathf.Min(p.xMax, r.xMax), y1 = Mathf.Min(p.yMax, r.yMax); r = new Rect(x0, y0, Mathf.Max(0, x1 - x0), Mathf.Max(0, y1 - y0)); }
                    d.clip = r; pushed = true;
                    GUI.cmds.Add(new GuiCmd { kind = 8, rect = new Rect(r.x, d.screenH - r.yMax, r.width, r.height), text = "", pad = new RectOffset() });
                }
            }
            foreach (var ch in t.m_Children.ToArray()) DrawNode(ch, d, alpha, false);
            if (pushed) { GUI.cmds.Add(new GuiCmd { kind = 9, text = "", pad = new RectOffset() }); d.clip = prevClip; }
            d.alpha = prevAlpha;
        }
        // TextMeshPro (3D) objects: drawn at their projected position
        static bool Draw3DText()
        {
            var all = World.FindObjectsOfType<TMPro.TextMeshPro>(false);
            if (all.Length == 0) return false;
            var cam = Camera.main; if (cam == null) return true;
            var d = new UIDraw { screenH = Screen.height, world = true, cam = cam };
            foreach (var t in all) { if (!t.isActiveAndEnabled) continue; (t.transform as RectTransform)?.SyncUp(); try { t.Draw(d); } catch (Exception e) { Debug.LogException(e); } }
            return true;
        }

        // ---------- raycasts ----------
        static bool InQuad(Vector2 p, in Hit h)
        {
            // point in convex quad (either winding)
            Vector2 a = h.c0, b = h.c1, c = h.c2, e = h.c3;
            float s1 = Cross(b - a, p - a), s2 = Cross(c - b, p - b), s3 = Cross(e - c, p - c), s4 = Cross(a - e, p - e);
            bool neg = s1 < 0 || s2 < 0 || s3 < 0 || s4 < 0, pos = s1 > 0 || s2 > 0 || s3 > 0 || s4 > 0;
            return !(neg && pos);
        }
        static float Cross(Vector2 a, Vector2 b) => a.x * b.y - a.y * b.x;
        internal static void RaycastUI(PointerEventData e, List<RaycastResult> results) => RaycastCanvas(null, e, results);
        internal static void RaycastCanvas(GraphicRaycaster only, PointerEventData e, List<RaycastResult> results)
        {
            var p = e.position;
            for (int i = s_Hits.Count - 1; i >= 0; i--)
            {
                var h = s_Hits[i];
                if (h.raycaster == null || (only != null && h.raycaster != only)) continue;
                if (h.g == null || h.g.m_Destroyed || !h.g.isActiveAndEnabled || !h.g.raycastTarget) continue;
                if (h.clip.HasValue && !h.clip.Value.Contains(p)) continue;
                if (!InQuad(p, h)) continue;
                if (!h.g.Raycast(p, h.cam)) continue;
                results.Add(new RaycastResult { gameObject = h.g.gameObject, module = h.raycaster, distance = 0, screenPosition = p, index = results.Count, depth = i, sortingOrder = h.raycaster.GetComponent<Canvas>()?.sortingOrder ?? 0 });
            }
        }

        // ---------- dropdown popup ----------
        internal static void OpenPopup(IDropdownPopup d) { popupOwner = d; s_PopupOpenedFrame = Time.frameCount; s_PopupHover = d.Current; }
        internal static void ClosePopup() { popupOwner = null; s_PopupItems.Clear(); }
        static void DrawPopup()
        {
            s_PopupItems.Clear();
            var p = popupOwner; if (p == null) return;
            var owner = p.Owner;
            if (owner == null || owner.m_Destroyed || !owner.gameObject.activeInHierarchy) { ClosePopup(); return; }
            var rt = p.Rect; var cv = rt.GetComponentInParent<Canvas>(); if (cv == null) { ClosePopup(); return; }
            var d = new UIDraw { screenH = Screen.height, canvas = cv.rootCanvas, world = cv.rootCanvas.renderMode == RenderMode.WorldSpace };
            if (d.world) d.cam = cv.rootCanvas.worldCamera != null ? cv.rootCanvas.worldCamera : Camera.main;
            var sr = d.ScreenRect(rt, Vector4.zero); if (!sr.HasValue) return;
            var r = sr.Value; float H = Screen.height;
            float itemH = Mathf.Max(18, r.height * 0.9f);
            int n = p.Count; float total = n * itemH + 6;
            float top = r.yMin - 2; // screen coords, bottom-left origin: list goes downwards
            if (top - total < 0 && r.yMax + total < H) top = r.yMax + total + 2;
            float fs = 14;
            if (p.Caption is Text tx) fs = tx.fontSize * (r.height / Mathf.Max(1, rt.rect.height));
            else if (p.Caption is TMPro.TMP_Text tt) fs = tt.fontSize * (r.height / Mathf.Max(1, rt.rect.height));
            GUI.cmds.Add(new GuiCmd { kind = 10, rect = new Rect(r.x, H - top, r.width, total), bgColor = new Color(1, 1, 1, 1), extra = "sd=1", pad = new RectOffset() });
            for (int i = 0; i < n; i++)
            {
                var ir = new Rect(r.x + 3, top - 3 - (i + 1) * itemH, r.width - 6, itemH);
                s_PopupItems.Add(ir);
                var gr = new Rect(ir.x, H - ir.yMax, ir.width, ir.height);
                if (i == s_PopupHover) GUI.cmds.Add(new GuiCmd { kind = 10, rect = gr, bgColor = new Color(0.78f, 0.86f, 1f, 1f), pad = new RectOffset() });
                string label = (i == p.Current ? "✓ " : "   ") + (p.Label(i) ?? "");
                GUI.cmds.Add(new GuiCmd { kind = 11, rect = new Rect(gr.x + 6, gr.y, gr.width - 8, gr.height), text = label, fontSize = fs, align = TextAnchor.MiddleLeft, textColor = new Color(0.2f, 0.2f, 0.2f, 1), pad = new RectOffset() });
            }
        }
        // the open dropdown list eats pointer input like Unity's blocker
        internal static bool HandlePopupInput(Vector2 pos)
        {
            var p = popupOwner; if (p == null) return false;
            s_PopupHover = -1;
            for (int i = 0; i < s_PopupItems.Count; i++) if (s_PopupItems[i].Contains(pos)) s_PopupHover = i;
            if (InputState.downThisFrame.Contains("Escape")) { ClosePopup(); return true; }
            if (Time.frameCount == s_PopupOpenedFrame) return true;
            if (InputState.mouseDownThisFrame[0])
            {
                if (s_PopupHover >= 0) { int i = s_PopupHover; ClosePopup(); try { p.Choose(i); } catch (Exception e) { Debug.LogException(e); } }
                else ClosePopup();
                return true;
            }
            return true;
        }
        internal static Component popupOwnerComponent => popupOwner?.Owner;

        // ---------- edit-mode preview (Game view while not playing) ----------
        static ProjectAssets s_PreviewAssets;
        static ProjectAssets Rebuild(ProjectAssets old, string path, (int, int, bool) meta)
        {
            // texture metadata changed (re-imported image): start a fresh set, keeping the other entries
            var n = new ProjectAssets();
            foreach (var kv in old.textureMeta) n.textureMeta[kv.Key] = kv.Value;
            n.textureMeta[path] = meta;
            return n;
        }
        internal static string Preview(string sceneJson, int w, int h)
        {
            if (World.isPlaying) return "[]";
            int ow = Screen.s_Width, oh = Screen.s_Height;
            Screen.s_Width = Math.Max(1, w); Screen.s_Height = Math.Max(1, h);
            try
            {
                World.ClearScene();
                ResetStatics();
                using var doc = System.Text.Json.JsonDocument.Parse(sceneJson);
                int logCount = Debug.s_Entries.Count;
                s_PreviewAssets ??= new ProjectAssets();
                if (doc.RootElement.TryGetProperty("textures", out var texs) && texs.ValueKind == System.Text.Json.JsonValueKind.Object)
                    foreach (var tx in texs.EnumerateObject())
                    {
                        var meta = (tx.Value.TryGetProperty("w", out var tw) ? tw.GetInt32() : 1, tx.Value.TryGetProperty("h", out var th) ? th.GetInt32() : 1, true);
                        if (!s_PreviewAssets.textureMeta.TryGetValue(tx.Name, out var old) || old != meta) { s_PreviewAssets = Rebuild(s_PreviewAssets, tx.Name, meta); }
                    }
                SceneLoader.BuildObjects(doc.RootElement, s_PreviewAssets, out var byId);
                var sceneIds = new Dictionary<GameObject, int>(); foreach (var kv in byId) sceneIds[kv.Value] = kv.Key;
                if (Debug.s_Entries.Count > logCount) Debug.s_Entries.RemoveRange(logCount, Debug.s_Entries.Count - logCount);
                // refresh visuals that depend on values (slider fill, toggle mark, dropdown caption...)
                foreach (var go in World.SceneObjects().ToArray())
                    foreach (var c in go.m_Components.ToArray()) if (c is IUIRefresh r) { try { r.UIRefresh(); } catch { } }
                GUI.cmds.Clear();
                Render();
                var json = Bridge.GuiJson();
                var rects = new StringBuilder("[");
                // object ids under the pointer can be found from the hit list (for picking in the Game view)
                foreach (var hit in s_Hits)
                {
                    if (rects.Length > 1) rects.Append(',');
                    rects.Append('[').Append(sceneIds.TryGetValue(hit.g.gameObject, out var sid) ? sid : 0).Append(',').Append(UIDraw.F(hit.c0.x)).Append(',').Append(UIDraw.F(hit.c0.y)).Append(',').Append(UIDraw.F(hit.c2.x)).Append(',').Append(UIDraw.F(hit.c2.y)).Append(']');
                }
                rects.Append(']');
                var ta = new StringBuilder("[");
                foreach (var (uid, path) in RenderSync.textureAssetUploads) { if (ta.Length > 1) ta.Append(','); ta.Append('[').Append(uid).Append(',').Append(System.Text.Json.JsonSerializer.Serialize(path)).Append(']'); }
                ta.Append(']'); RenderSync.textureAssetUploads.Clear();
                return "{\"gui\":" + json + ",\"hits\":" + rects + ",\"texAssets\":" + ta + "}";
            }
            catch (Exception e) { return "{\"error\":" + System.Text.Json.JsonSerializer.Serialize(e.Message) + "}"; }
            finally
            {
                World.ClearScene(); ResetStatics(); GUI.cmds.Clear();
                Screen.s_Width = ow; Screen.s_Height = oh;
            }
        }
    }
}
