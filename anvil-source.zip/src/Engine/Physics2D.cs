// Anvil — Unity's 2D physics API (Rigidbody2D, Collider2D family, Joint2D family, Effector2D family, Physics2D
// queries and callbacks). The simulation runs in editor/js/runtime/physics2d.js (Box2D, like Unity);
// Anvil.Physics2DWorld keeps the two sides in sync.
using System;
using System.Collections.Generic;
using System.Linq;
using Anvil;

namespace UnityEngine
{
    public enum RigidbodyType2D { Dynamic = 0, Kinematic = 1, Static = 2 }
    public enum ForceMode2D { Force = 0, Impulse = 1 }
    public enum CapsuleDirection2D { Vertical = 0, Horizontal = 1 }
    public enum CollisionDetectionMode2D { [Obsolete("Enum member CollisionDetectionMode2D.None has been deprecated. Use CollisionDetectionMode2D.Discrete instead (UnityUpgradable) -> Discrete", true)] None = 0, Discrete = 0, Continuous = 1 }
    public enum RigidbodySleepMode2D { NeverSleep = 0, StartAwake = 1, StartAsleep = 2 }
    public enum RigidbodyInterpolation2D { None = 0, Interpolate = 1, Extrapolate = 2 }
    [Flags] public enum RigidbodyConstraints2D { None = 0, FreezePositionX = 1, FreezePositionY = 2, FreezeRotation = 4, FreezePosition = 3, FreezeAll = 7 }
    public enum JointLimitState2D { Inactive = 0, LowerLimit = 1, UpperLimit = 2, EqualLimits = 3 }
    public enum SimulationMode2D { FixedUpdate = 0, Update = 1, Script = 2 }
    public enum EffectorSelection2D { Rigidbody = 0, Collider = 1 }
    public enum EffectorForceMode2D { Constant = 0, InverseLinear = 1, InverseSquared = 2 }
    public enum JointBreakAction2D { Ignore = 0, CallbackOnly = 1, Disable = 2, Destroy = 3 }

    public class PhysicsMaterial2D : Object
    {
        float m_Friction = 0.4f, m_Bounciness;
        internal int m_Version;
        public PhysicsMaterial2D() { m_Name = ""; }
        public PhysicsMaterial2D(string name) { m_Name = name; }
        public float friction { get => m_Friction; set { m_Friction = value; m_Version++; } }
        public float bounciness { get => m_Bounciness; set { m_Bounciness = value; m_Version++; } }
    }

    public struct JointMotor2D { public float motorSpeed { get; set; } public float maxMotorTorque { get; set; } }
    public struct JointAngleLimits2D { public float min { get; set; } public float max { get; set; } }
    public struct JointTranslationLimits2D { public float min { get; set; } public float max { get; set; } }
    public struct JointSuspension2D { public float dampingRatio { get; set; } public float frequency { get; set; } public float angle { get; set; } }

    // ---------------------------------------------------------------- Rigidbody2D
    public sealed class Rigidbody2D : Component
    {
        internal RigidbodyType2D m_BodyType;
        internal bool m_Simulated = true, m_AutoMass, m_FullKinematic, m_HasCom, m_HasInertia;
        internal float m_Mass = 1, m_LinDamp, m_AngDamp = 0.05f, m_GravityScale = 1, m_Inertia = 1;
        internal Vector2 m_Com;
        internal RigidbodyConstraints2D m_Constraints;
        internal CollisionDetectionMode2D m_CDM;
        internal RigidbodySleepMode2D m_SleepMode = RigidbodySleepMode2D.StartAwake;
        internal RigidbodyInterpolation2D m_Interp;
        internal PhysicsMaterial2D m_Material;
        internal LayerMask m_Exclude, m_Include = -1;

        // physics-side state
        internal int handle = -1;
        internal Vector2 s_Pos, s_Vel, s_WorldCom, s_LocalCom; internal float s_Angle, s_AngVel, s_Mass = 1, s_Inertia = 1;
        internal bool s_Awake = true, s_HasState;
        internal Vector3 lastPos; internal Quaternion lastRot; internal bool hasLast;
        internal bool propsDirty = true, pendingVel, pendingAngVel, pendingWake, pendingSleep, pendingTeleport;
        internal Vector2? pendingPos; internal float? pendingAngle; internal Vector2? movePos; internal float? moveAngle;
        internal readonly List<double> pendingForces = new List<double>();
        internal Vector2 m_TotalForce; internal float m_TotalTorque;
        internal int depth;

        void Dirty() { propsDirty = true; }
        public RigidbodyType2D bodyType { get => m_BodyType; set { if (m_BodyType != value) { m_BodyType = value; Dirty(); Physics2DWorld.MarkDirty(); } } }
        public bool isKinematic { get => m_BodyType == RigidbodyType2D.Kinematic; set => bodyType = value ? RigidbodyType2D.Kinematic : RigidbodyType2D.Dynamic; }
        public bool simulated { get => m_Simulated; set { if (m_Simulated != value) { m_Simulated = value; Dirty(); Physics2DWorld.MarkDirty(); } } }
        public bool useAutoMass { get => m_AutoMass; set { m_AutoMass = value; Dirty(); } }
        public float mass
        {
            get => m_AutoMass && s_HasState ? s_Mass : m_Mass;
            set { if (value <= 0) { Debug.LogWarning("Mass must be greater than zero."); value = 0.0001f; } m_Mass = value; Dirty(); }
        }
        public float linearDamping { get => m_LinDamp; set { m_LinDamp = Math.Max(0, value); Dirty(); } }
        public float angularDamping { get => m_AngDamp; set { m_AngDamp = Math.Max(0, value); Dirty(); } }
        [Obsolete("drag has been renamed to linearDamping")] public float drag { get => linearDamping; set => linearDamping = value; }
        [Obsolete("angularDrag has been renamed to angularDamping")] public float angularDrag { get => angularDamping; set => angularDamping = value; }
        public float gravityScale { get => m_GravityScale; set { m_GravityScale = value; Dirty(); } }
        public RigidbodyConstraints2D constraints { get => m_Constraints; set { m_Constraints = value; Dirty(); } }
        public bool freezeRotation { get => (m_Constraints & RigidbodyConstraints2D.FreezeRotation) != 0; set => constraints = value ? m_Constraints | RigidbodyConstraints2D.FreezeRotation : m_Constraints & ~RigidbodyConstraints2D.FreezeRotation; }
        public CollisionDetectionMode2D collisionDetectionMode { get => m_CDM; set { m_CDM = value; Dirty(); } }
        public RigidbodySleepMode2D sleepMode { get => m_SleepMode; set { m_SleepMode = value; Dirty(); } }
        public RigidbodyInterpolation2D interpolation { get => m_Interp; set => m_Interp = value; }
        public bool useFullKinematicContacts { get => m_FullKinematic; set { m_FullKinematic = value; Dirty(); } }
        public PhysicsMaterial2D sharedMaterial { get => m_Material; set { m_Material = value; Physics2DWorld.MarkDirty(); } }
        public LayerMask excludeLayers { get => m_Exclude; set => m_Exclude = value; }
        public LayerMask includeLayers { get => m_Include; set => m_Include = value; }

        public Vector2 centerOfMass
        {
            get => m_HasCom ? m_Com : s_LocalCom;
            set { m_Com = value; m_HasCom = true; Dirty(); }
        }
        public Vector2 worldCenterOfMass => s_HasState ? s_WorldCom : GetRelativePoint(centerOfMass);
        public float inertia { get => m_HasInertia ? m_Inertia : s_Inertia; set { m_Inertia = value; m_HasInertia = true; Dirty(); } }

        public Vector2 linearVelocity { get => s_Vel; set { s_Vel = value; pendingVel = true; } }
        [Obsolete("velocity has been renamed to linearVelocity")] public Vector2 velocity { get => linearVelocity; set => linearVelocity = value; }
        public float linearVelocityX { get => s_Vel.x; set => linearVelocity = new Vector2(value, s_Vel.y); }
        public float linearVelocityY { get => s_Vel.y; set => linearVelocity = new Vector2(s_Vel.x, value); }
        public float angularVelocity { get => s_AngVel; set { s_AngVel = value; pendingAngVel = true; } }
        public Vector2 totalForce { get => m_TotalForce; set => m_TotalForce = value; }
        public float totalTorque { get => m_TotalTorque; set => m_TotalTorque = value; }

        public Vector2 position
        {
            get => pendingPos ?? (s_HasState ? s_Pos : (Vector2)transform.position);
            set { pendingPos = value; s_Pos = value; pendingTeleport = true; }
        }
        public float rotation
        {
            get => pendingAngle ?? (s_HasState ? s_Angle : transform.eulerAngles.z);
            set { pendingAngle = value; s_Angle = value; pendingTeleport = true; }
        }
        public void SetRotation(float angle) => rotation = angle;
        public void SetRotation(Quaternion angle) => rotation = angle.eulerAngles.z;
        public void MovePosition(Vector2 position) { movePos = position; }
        public void MoveRotation(float angle) { moveAngle = angle; }
        public void MoveRotation(Quaternion rotation) { moveAngle = rotation.eulerAngles.z; }
        public void MovePositionAndRotation(Vector2 position, float angle) { movePos = position; moveAngle = angle; }
        public void MovePositionAndRotation(Vector2 position, Quaternion rotation) { movePos = position; moveAngle = rotation.eulerAngles.z; }

        public bool IsAwake() => s_Awake && m_BodyType != RigidbodyType2D.Static;
        public bool IsSleeping() => !IsAwake();
        public void WakeUp() { pendingWake = true; pendingSleep = false; s_Awake = true; }
        public void Sleep() { pendingSleep = true; pendingWake = false; s_Awake = false; }

        static readonly double NaN = double.NaN;
        public void AddForce(Vector2 force) => AddForce(force, ForceMode2D.Force);
        public void AddForce(Vector2 force, ForceMode2D mode)
        {
            if (m_BodyType != RigidbodyType2D.Dynamic) return;
            pendingForces.AddRange(new double[] { mode == ForceMode2D.Impulse ? 16 : 17, 0, force.x, force.y, NaN, NaN });
            if (mode == ForceMode2D.Force) m_TotalForce += force;
        }
        public void AddForceX(float force, ForceMode2D mode = ForceMode2D.Force) => AddForce(new Vector2(force, 0), mode);
        public void AddForceY(float force, ForceMode2D mode = ForceMode2D.Force) => AddForce(new Vector2(0, force), mode);
        public void AddRelativeForce(Vector2 relativeForce) => AddForce(GetRelativeVector(relativeForce), ForceMode2D.Force);
        public void AddRelativeForce(Vector2 relativeForce, ForceMode2D mode) => AddForce(GetRelativeVector(relativeForce), mode);
        public void AddRelativeForceX(float force, ForceMode2D mode = ForceMode2D.Force) => AddRelativeForce(new Vector2(force, 0), mode);
        public void AddRelativeForceY(float force, ForceMode2D mode = ForceMode2D.Force) => AddRelativeForce(new Vector2(0, force), mode);
        public void AddForceAtPosition(Vector2 force, Vector2 position) => AddForceAtPosition(force, position, ForceMode2D.Force);
        public void AddForceAtPosition(Vector2 force, Vector2 position, ForceMode2D mode)
        {
            if (m_BodyType != RigidbodyType2D.Dynamic) return;
            pendingForces.AddRange(new double[] { mode == ForceMode2D.Impulse ? 16 : 17, 0, force.x, force.y, position.x, position.y });
        }
        public void AddTorque(float torque) => AddTorque(torque, ForceMode2D.Force);
        public void AddTorque(float torque, ForceMode2D mode)
        {
            if (m_BodyType != RigidbodyType2D.Dynamic) return;
            pendingForces.AddRange(new double[] { mode == ForceMode2D.Impulse ? 19 : 18, 0, torque });
            if (mode == ForceMode2D.Force) m_TotalTorque += torque;
        }

        float Rad => rotation * Mathf.Deg2Rad;
        public Vector2 GetPoint(Vector2 point) { var d = point - position; float c = Mathf.Cos(-Rad), s = Mathf.Sin(-Rad); return new Vector2(c * d.x - s * d.y, s * d.x + c * d.y); }
        public Vector2 GetRelativePoint(Vector2 relativePoint) { float c = Mathf.Cos(Rad), s = Mathf.Sin(Rad); return position + new Vector2(c * relativePoint.x - s * relativePoint.y, s * relativePoint.x + c * relativePoint.y); }
        public Vector2 GetVector(Vector2 vector) { float c = Mathf.Cos(-Rad), s = Mathf.Sin(-Rad); return new Vector2(c * vector.x - s * vector.y, s * vector.x + c * vector.y); }
        public Vector2 GetRelativeVector(Vector2 relativeVector) { float c = Mathf.Cos(Rad), s = Mathf.Sin(Rad); return new Vector2(c * relativeVector.x - s * relativeVector.y, s * relativeVector.x + c * relativeVector.y); }
        public Vector2 GetPointVelocity(Vector2 point) { var r = point - worldCenterOfMass; float w = s_AngVel * Mathf.Deg2Rad; return s_Vel + new Vector2(-w * r.y, w * r.x); }
        public Vector2 GetRelativePointVelocity(Vector2 relativePoint) => GetPointVelocity(GetRelativePoint(relativePoint));

        public int attachedColliderCount => Physics2DWorld.CollidersOf(this).Count;
        public int GetAttachedColliders(Collider2D[] results) { var l = Physics2DWorld.CollidersOf(this); int n = Math.Min(l.Count, results.Length); for (int i = 0; i < n; i++) results[i] = l[i]; return n; }
        public int GetAttachedColliders(List<Collider2D> results) { results.Clear(); results.AddRange(Physics2DWorld.CollidersOf(this)); return results.Count; }
        public bool IsTouching(Collider2D collider) => Physics2DWorld.CollidersOf(this).Any(c => Physics2DWorld.Touching(c, collider));
        public bool IsTouching(Collider2D collider, ContactFilter2D contactFilter) => Physics2DWorld.CollidersOf(this).Any(c => Physics2DWorld.Touching(c, collider, contactFilter));
        public bool IsTouching(ContactFilter2D contactFilter) => Physics2DWorld.CollidersOf(this).Any(c => Physics2DWorld.TouchingAny(c, contactFilter));
        public bool IsTouchingLayers() => IsTouchingLayers(Physics2D.AllLayers);
        public bool IsTouchingLayers(int layerMask) => Physics2DWorld.CollidersOf(this).Any(c => Physics2DWorld.TouchingLayers(c, layerMask));
        public bool OverlapPoint(Vector2 point) => Physics2DWorld.CollidersOf(this).Any(c => c.OverlapPoint(point));
        public ColliderDistance2D Distance(Collider2D collider)
        {
            ColliderDistance2D best = default; bool any = false;
            foreach (var c in Physics2DWorld.CollidersOf(this)) { var d = Physics2D.Distance(c, collider); if (d.isValid && (!any || d.distance < best.distance)) { best = d; any = true; } }
            return best;
        }
        public Vector2 ClosestPoint(Vector2 position)
        {
            Vector2 best = position; float bd = float.PositiveInfinity;
            foreach (var c in Physics2DWorld.CollidersOf(this)) { var p = c.ClosestPoint(position); float d = (p - position).sqrMagnitude; if (d < bd) { bd = d; best = p; } }
            return best;
        }
        public int GetContacts(ContactPoint2D[] contacts) => Physics2DWorld.GetContacts(Physics2DWorld.CollidersOf(this), contacts, null, new ContactFilter2D().NoFilter());
        public int GetContacts(List<ContactPoint2D> contacts) => Physics2DWorld.GetContacts(Physics2DWorld.CollidersOf(this), null, contacts, new ContactFilter2D().NoFilter());
        public int GetContacts(ContactFilter2D contactFilter, ContactPoint2D[] contacts) => Physics2DWorld.GetContacts(Physics2DWorld.CollidersOf(this), contacts, null, contactFilter);
        public int GetContacts(Collider2D[] colliders) => Physics2DWorld.GetContactColliders(Physics2DWorld.CollidersOf(this), colliders, null, new ContactFilter2D().NoFilter());
        public int GetContacts(List<Collider2D> colliders) => Physics2DWorld.GetContactColliders(Physics2DWorld.CollidersOf(this), null, colliders, new ContactFilter2D().NoFilter());
        public int Cast(Vector2 direction, RaycastHit2D[] results) => Cast(direction, results, float.PositiveInfinity);
        public int Cast(Vector2 direction, RaycastHit2D[] results, float distance)
        {
            var all = new List<RaycastHit2D>();
            foreach (var c in Physics2DWorld.CollidersOf(this)) all.AddRange(c.CastAll(direction, distance, true));
            all.Sort((a, b) => a.distance.CompareTo(b.distance));
            var dedup = new List<RaycastHit2D>(); foreach (var h in all) if (!dedup.Any(x => x.collider == h.collider)) dedup.Add(h);
            int n = Math.Min(dedup.Count, results.Length); for (int i = 0; i < n; i++) results[i] = dedup[i]; return n;
        }
        public int Cast(Vector2 direction, List<RaycastHit2D> results, float distance = float.PositiveInfinity)
        {
            var arr = new RaycastHit2D[64]; int n = Cast(direction, arr, distance); results.Clear(); for (int i = 0; i < n; i++) results.Add(arr[i]); return n;
        }

        internal override void OnAddedInternal() => Physics2DWorld.MarkDirty();
        internal override void OnRemovedInternal() => Physics2DWorld.MarkDirty();
        internal override void OnActiveChangedInternal(bool active) => Physics2DWorld.MarkDirty();
    }

    // ---------------------------------------------------------------- colliders
    public class Collider2D : Behaviour
    {
        internal bool m_IsTrigger, m_UsedByEffector, m_UsedByComposite;
        internal Vector2 m_Offset;
        internal float m_Density = 1;
        internal PhysicsMaterial2D m_Material;
        internal int shapeVersion = 1;
        internal int handle = -1, bodyHandle = -1, staticBody = -1;
        internal Rigidbody2D owner;
        internal string builtSig; internal Vector3 lastPos; internal Quaternion lastRot;
        internal int effectorSig;

        public bool isTrigger { get => m_IsTrigger; set { if (m_IsTrigger != value) { m_IsTrigger = value; shapeVersion++; } } }
        public Vector2 offset { get => m_Offset; set { m_Offset = value; shapeVersion++; } }
        public float density { get => m_Density; set { m_Density = value; shapeVersion++; } }
        public bool usedByEffector { get => m_UsedByEffector; set { m_UsedByEffector = value; shapeVersion++; } }
        public bool usedByComposite { get => m_UsedByComposite; set => m_UsedByComposite = value; }
        public CompositeCollider2D composite => null;
        public PhysicsMaterial2D sharedMaterial { get => m_Material; set { m_Material = value; shapeVersion++; } }
        public float friction => (m_Material ?? attachedRigidbody?.m_Material)?.friction ?? 0.4f;
        public float bounciness => (m_Material ?? attachedRigidbody?.m_Material)?.bounciness ?? 0f;
        public Rigidbody2D attachedRigidbody => Physics2DWorld.FindOwner(this);
        public int shapeCount => 1;
        public LayerMask callbackLayers { get; set; } = -1;
        public LayerMask contactCaptureLayers { get; set; } = -1;
        public LayerMask forceSendLayers { get; set; } = -1;
        public LayerMask forceReceiveLayers { get; set; } = -1;
        public LayerMask excludeLayers { get; set; }
        public LayerMask includeLayers { get; set; }
        public int layerOverridePriority { get; set; }
        public ColliderErrorState2D errorState => ColliderErrorState2D.None;
        public Bounds bounds => Physics2DWorld.BoundsOf(this);

        public bool IsTouching(Collider2D collider) => Physics2DWorld.Touching(this, collider);
        public bool IsTouching(Collider2D collider, ContactFilter2D contactFilter) => Physics2DWorld.Touching(this, collider, contactFilter);
        public bool IsTouching(ContactFilter2D contactFilter) => Physics2DWorld.TouchingAny(this, contactFilter);
        public bool IsTouchingLayers() => IsTouchingLayers(Physics2D.AllLayers);
        public bool IsTouchingLayers(int layerMask) => Physics2DWorld.TouchingLayers(this, layerMask);
        public bool OverlapPoint(Vector2 point) => Physics2DWorld.OverlapPointSelf(this, point);
        public Vector2 ClosestPoint(Vector2 position) => Physics2DWorld.ClosestPoint(this, position);
        public ColliderDistance2D Distance(Collider2D collider) => Physics2D.Distance(this, collider);
        public int Overlap(ContactFilter2D contactFilter, Collider2D[] results) => Physics2D.OverlapCollider(this, contactFilter, results);
        public int Overlap(ContactFilter2D contactFilter, List<Collider2D> results) => Physics2D.OverlapCollider(this, contactFilter, results);
        public int Overlap(Collider2D[] results) => Physics2D.OverlapCollider(this, new ContactFilter2D().NoFilter(), results);
        public int Overlap(List<Collider2D> results) => Physics2D.OverlapCollider(this, new ContactFilter2D().NoFilter(), results);
        public int GetContacts(ContactPoint2D[] contacts) => Physics2DWorld.GetContacts(new List<Collider2D> { this }, contacts, null, new ContactFilter2D().NoFilter());
        public int GetContacts(List<ContactPoint2D> contacts) => Physics2DWorld.GetContacts(new List<Collider2D> { this }, null, contacts, new ContactFilter2D().NoFilter());
        public int GetContacts(ContactFilter2D contactFilter, ContactPoint2D[] contacts) => Physics2DWorld.GetContacts(new List<Collider2D> { this }, contacts, null, contactFilter);
        public int GetContacts(Collider2D[] colliders) => Physics2DWorld.GetContactColliders(new List<Collider2D> { this }, colliders, null, new ContactFilter2D().NoFilter());
        public int GetContacts(List<Collider2D> colliders) => Physics2DWorld.GetContactColliders(new List<Collider2D> { this }, null, colliders, new ContactFilter2D().NoFilter());

        public int Raycast(Vector2 direction, RaycastHit2D[] results) => Raycast(direction, results, float.PositiveInfinity, Physics2D.AllLayers);
        public int Raycast(Vector2 direction, RaycastHit2D[] results, float distance) => Raycast(direction, results, distance, Physics2D.AllLayers);
        public int Raycast(Vector2 direction, RaycastHit2D[] results, float distance, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
        {
            var origin = (Vector2)transform.TransformPoint(m_Offset);
            var hits = Physics2D.RaycastAll(origin, direction, distance, layerMask, minDepth, maxDepth).Where(h => h.collider != this).ToArray();
            int n = Math.Min(hits.Length, results.Length); for (int i = 0; i < n; i++) results[i] = hits[i]; return n;
        }
        public int Cast(Vector2 direction, RaycastHit2D[] results) => Cast(direction, results, float.PositiveInfinity, true);
        public int Cast(Vector2 direction, RaycastHit2D[] results, float distance) => Cast(direction, results, distance, true);
        public int Cast(Vector2 direction, RaycastHit2D[] results, float distance, bool ignoreSiblingColliders)
        {
            var hits = CastAll(direction, distance, ignoreSiblingColliders);
            int n = Math.Min(hits.Count, results.Length); for (int i = 0; i < n; i++) results[i] = hits[i]; return n;
        }
        public int Cast(Vector2 direction, List<RaycastHit2D> results, float distance = float.PositiveInfinity, bool ignoreSiblingColliders = true)
        {
            results.Clear(); results.AddRange(CastAll(direction, distance, ignoreSiblingColliders)); return results.Count;
        }
        public int Cast(Vector2 direction, ContactFilter2D contactFilter, RaycastHit2D[] results, float distance = float.PositiveInfinity, bool ignoreSiblingColliders = true)
        {
            var hits = CastAll(direction, distance, ignoreSiblingColliders).Where(h => contactFilter.Passes(h.collider, h.normal)).ToList();
            int n = Math.Min(hits.Count, results.Length); for (int i = 0; i < n; i++) results[i] = hits[i]; return n;
        }
        internal List<RaycastHit2D> CastAll(Vector2 direction, float distance, bool ignoreSiblings)
        {
            var self = attachedRigidbody;
            var hits = CastShape(direction, distance);
            return hits.Where(h => h.collider != this && !(ignoreSiblings && self != null && h.collider.attachedRigidbody == self)).ToList();
        }
        // the cast is done with this collider's shape in world space
        internal virtual List<RaycastHit2D> CastShape(Vector2 direction, float distance)
        {
            var b = bounds;
            return Physics2D.BoxCastAll(b.center, b.size, 0, direction, distance, Physics2D.AllLayers).ToList();
        }
        internal virtual void BuildShape(Func<Vector2, Vector2> toBody, Vector2 scale, List<double> data, out int kind) { kind = 3; data.Add(0); }

        internal override void OnAddedInternal() => Physics2DWorld.MarkDirty();
        internal override void OnRemovedInternal() => Physics2DWorld.MarkDirty();
        internal override void OnActiveChangedInternal(bool active) => Physics2DWorld.MarkDirty();
        internal static float MaxAbs(Vector2 s) => Math.Max(Math.Abs(s.x), Math.Abs(s.y));
        internal float WorldAngle() => transform.eulerAngles.z;
    }
    public enum ColliderErrorState2D { None = 0, NoShapes = 1, RemovedShapes = 2 }

    public sealed class BoxCollider2D : Collider2D
    {
        internal Vector2 m_Size = Vector2.one; internal float m_EdgeRadius;
        public Vector2 size { get => m_Size; set { m_Size = value; shapeVersion++; } }
        public float edgeRadius { get => m_EdgeRadius; set { m_EdgeRadius = Math.Max(0, value); shapeVersion++; } }
        public bool autoTiling { get; set; }
        internal override void BuildShape(Func<Vector2, Vector2> toBody, Vector2 scale, List<double> data, out int kind)
        {
            kind = 3;
            float hx = m_Size.x / 2 + m_EdgeRadius, hy = m_Size.y / 2 + m_EdgeRadius;
            data.Add(1); data.Add(4);
            foreach (var p in new[] { new Vector2(-hx, -hy), new Vector2(hx, -hy), new Vector2(hx, hy), new Vector2(-hx, hy) }) { var q = toBody(p + m_Offset); data.Add(q.x); data.Add(q.y); }
        }
        internal override List<RaycastHit2D> CastShape(Vector2 direction, float distance)
        {
            var s = (Vector2)transform.lossyScale;
            return Physics2D.BoxCastAll(transform.TransformPoint(m_Offset), new Vector2(Math.Abs(m_Size.x * s.x) + 2 * m_EdgeRadius, Math.Abs(m_Size.y * s.y) + 2 * m_EdgeRadius), WorldAngle(), direction, distance, Physics2D.AllLayers).ToList();
        }
    }
    public sealed class CircleCollider2D : Collider2D
    {
        internal float m_Radius = 0.5f;
        public float radius { get => m_Radius; set { m_Radius = Math.Max(0.0001f, value); shapeVersion++; } }
        internal override void BuildShape(Func<Vector2, Vector2> toBody, Vector2 scale, List<double> data, out int kind)
        {
            kind = 1; var c = toBody(m_Offset);
            data.Add(c.x); data.Add(c.y); data.Add(m_Radius * MaxAbs(scale));
        }
        internal override List<RaycastHit2D> CastShape(Vector2 direction, float distance)
            => Physics2D.CircleCastAll(transform.TransformPoint(m_Offset), m_Radius * MaxAbs(transform.lossyScale), direction, distance, Physics2D.AllLayers).ToList();
    }
    public sealed class CapsuleCollider2D : Collider2D
    {
        internal Vector2 m_Size = new Vector2(0.5f, 1f); internal CapsuleDirection2D m_Direction = CapsuleDirection2D.Vertical;
        public Vector2 size { get => m_Size; set { m_Size = value; shapeVersion++; } }
        public CapsuleDirection2D direction { get => m_Direction; set { m_Direction = value; shapeVersion++; } }
        internal override void BuildShape(Func<Vector2, Vector2> toBody, Vector2 scale, List<double> data, out int kind)
        {
            kind = 2;
            var c = toBody(m_Offset); var ex = toBody(m_Offset + Vector2.right) - c;
            data.Add(c.x); data.Add(c.y); data.Add(Mathf.Atan2(ex.y, ex.x));
            data.Add(Math.Abs(m_Size.x * scale.x)); data.Add(Math.Abs(m_Size.y * scale.y)); data.Add((int)m_Direction);
        }
        internal override List<RaycastHit2D> CastShape(Vector2 direction, float distance)
        {
            var s = (Vector2)transform.lossyScale;
            return Physics2D.CapsuleCastAll(transform.TransformPoint(m_Offset), new Vector2(Math.Abs(m_Size.x * s.x), Math.Abs(m_Size.y * s.y)), m_Direction, WorldAngle(), direction, distance, Physics2D.AllLayers).ToList();
        }
    }
    public sealed class PolygonCollider2D : Collider2D
    {
        internal List<Vector2[]> m_Paths = new List<Vector2[]> { Pentagon() };
        static Vector2[] Pentagon()
        {
            var p = new Vector2[5];
            for (int i = 0; i < 5; i++) { float a = Mathf.PI / 2 + i * 2 * Mathf.PI / 5; p[i] = new Vector2(Mathf.Cos(a) * 0.5f, Mathf.Sin(a) * 0.5f); }
            return p;
        }
        public Vector2[] points { get => m_Paths.Count > 0 ? (Vector2[])m_Paths[0].Clone() : Array.Empty<Vector2>(); set { if (m_Paths.Count == 0) m_Paths.Add(value ?? Array.Empty<Vector2>()); else m_Paths[0] = (Vector2[])(value ?? Array.Empty<Vector2>()).Clone(); shapeVersion++; } }
        public int pathCount { get => m_Paths.Count; set { while (m_Paths.Count < value) m_Paths.Add(Array.Empty<Vector2>()); if (m_Paths.Count > value) m_Paths.RemoveRange(value, m_Paths.Count - value); shapeVersion++; } }
        public bool autoTiling { get; set; }
        public bool useDelaunayMesh { get; set; }
        public Vector2[] GetPath(int index) => (Vector2[])m_Paths[index].Clone();
        public int GetPath(int index, List<Vector2> points) { points.Clear(); points.AddRange(m_Paths[index]); return points.Count; }
        public void SetPath(int index, Vector2[] points) { pathCount = Math.Max(pathCount, index + 1); m_Paths[index] = (Vector2[])points.Clone(); shapeVersion++; }
        public void SetPath(int index, List<Vector2> points) => SetPath(index, points.ToArray());
        public int GetTotalPointCount() => m_Paths.Sum(p => p.Length);
        public void CreatePrimitive(int sides) => CreatePrimitive(sides, Vector2.one, Vector2.zero);
        public void CreatePrimitive(int sides, Vector2 scale) => CreatePrimitive(sides, scale, Vector2.zero);
        public void CreatePrimitive(int sides, Vector2 scale, Vector2 offset)
        {
            if (sides < 3) { Debug.LogWarning("Cannot create a 2D polygon primitive collider with less than three sides."); return; }
            var p = new Vector2[sides];
            for (int i = 0; i < sides; i++) { float a = Mathf.PI / 2 + i * 2 * Mathf.PI / sides; p[i] = offset + new Vector2(Mathf.Cos(a) * 0.5f * scale.x, Mathf.Sin(a) * 0.5f * scale.y); }
            m_Paths = new List<Vector2[]> { p }; shapeVersion++;
        }
        internal override void BuildShape(Func<Vector2, Vector2> toBody, Vector2 scale, List<double> data, out int kind)
        {
            kind = 3; data.Add(m_Paths.Count);
            foreach (var path in m_Paths) { data.Add(path.Length); foreach (var p in path) { var q = toBody(p + m_Offset); data.Add(q.x); data.Add(q.y); } }
        }
    }
    public sealed class EdgeCollider2D : Collider2D
    {
        internal Vector2[] m_Points = { new Vector2(-0.5f, 0), new Vector2(0.5f, 0) }; internal float m_EdgeRadius;
        public Vector2[] points { get => (Vector2[])m_Points.Clone(); set { if (value == null || value.Length < 2) { Debug.LogWarning("Cannot set an EdgeCollider2D with less than two points."); return; } m_Points = (Vector2[])value.Clone(); shapeVersion++; } }
        public int GetPoints(List<Vector2> points) { points.Clear(); points.AddRange(m_Points); return points.Count; }
        public bool SetPoints(List<Vector2> points) { if (points == null || points.Count < 2) return false; m_Points = points.ToArray(); shapeVersion++; return true; }
        public float edgeRadius { get => m_EdgeRadius; set { m_EdgeRadius = Math.Max(0, value); shapeVersion++; } }
        public int edgeCount => m_Points.Length - 1;
        public int pointCount => m_Points.Length;
        public bool useAdjacentStartPoint { get; set; }
        public bool useAdjacentEndPoint { get; set; }
        public Vector2 adjacentStartPoint { get; set; }
        public Vector2 adjacentEndPoint { get; set; }
        public void Reset() { m_Points = new[] { new Vector2(-0.5f, 0), new Vector2(0.5f, 0) }; shapeVersion++; }
        internal override void BuildShape(Func<Vector2, Vector2> toBody, Vector2 scale, List<double> data, out int kind)
        {
            kind = 4; data.Add(m_Points.Length); data.Add(0);
            foreach (var p in m_Points) { var q = toBody(p + m_Offset); data.Add(q.x); data.Add(q.y); }
        }
    }
    public sealed class CompositeCollider2D : Collider2D
    {
        public enum GeometryType { Outlines = 0, Polygons = 1 }
        public enum GenerationType { Synchronous = 0, Manual = 1 }
        public GeometryType geometryType { get; set; }
        public GenerationType generationType { get; set; }
        public float vertexDistance { get; set; } = 0.0005f;
        public float edgeRadius { get; set; }
        public int pathCount => 0;
        public int pointCount => 0;
        public void GenerateGeometry() { }
    }

    // ---------------------------------------------------------------- joints
    public class Joint2D : Behaviour
    {
        internal Rigidbody2D m_ConnectedBody;
        internal bool m_EnableCollision;
        internal float m_BreakForce = float.PositiveInfinity, m_BreakTorque = float.PositiveInfinity;
        internal JointBreakAction2D m_BreakAction = JointBreakAction2D.Destroy;
        internal int handle = -1, structVersion = 1, builtVersion, paramVersion = 1, sentParams, builtA = -2, builtB = -2;
        internal Vector2 s_Force; internal float s_Torque, s_Angle, s_AngSpeed, s_Trans, s_TransSpeed;
        internal bool broken;

        protected void Rebuild() => structVersion++;
        protected void Params() => paramVersion++;
        public Rigidbody2D connectedBody { get => m_ConnectedBody; set { m_ConnectedBody = value; Rebuild(); } }
        public bool enableCollision { get => m_EnableCollision; set { m_EnableCollision = value; Rebuild(); } }
        public float breakForce { get => m_BreakForce; set => m_BreakForce = value; }
        public float breakTorque { get => m_BreakTorque; set => m_BreakTorque = value; }
        public JointBreakAction2D breakAction { get => m_BreakAction; set => m_BreakAction = value; }
        public Rigidbody2D attachedRigidbody => GetComponent<Rigidbody2D>();
        public Vector2 reactionForce => s_Force;
        public float reactionTorque => s_Torque;
        public Vector2 GetReactionForce(float timeStep) => s_Force * (Time.fixedDeltaTime / Math.Max(timeStep, 1e-6f));
        public float GetReactionTorque(float timeStep) => s_Torque * (Time.fixedDeltaTime / Math.Max(timeStep, 1e-6f));

        internal virtual int Kind => -1;
        internal virtual bool AnchorsOnGround => false;
        internal virtual void Configure(Rigidbody2D self, Vector2 worldA, Vector2 worldB) { }
        internal virtual void ParamsInto(List<double> p) { }
        internal virtual Vector2 LocalAnchor => Vector2.zero;
        internal virtual Vector2 WorldAnchorB(Rigidbody2D self) => m_ConnectedBody != null ? (Vector2)m_ConnectedBody.transform.TransformPoint(LocalAnchor) : (Vector2)self.transform.TransformPoint(LocalAnchor);
        internal static float RefAngle(Rigidbody2D self, Rigidbody2D other) => ((other != null ? other.rotation : 0f) - self.rotation) * Mathf.Deg2Rad;

        internal override void OnAddedInternal() => Physics2DWorld.MarkDirty();
        internal override void OnRemovedInternal() => Physics2DWorld.MarkDirty();
        internal override void OnActiveChangedInternal(bool active) => Physics2DWorld.MarkDirty();
    }
    public class AnchoredJoint2D : Joint2D
    {
        internal Vector2 m_Anchor, m_ConnectedAnchor; internal bool m_AutoConnected = true;
        public Vector2 anchor { get => m_Anchor; set { m_Anchor = value; Rebuild(); } }
        public Vector2 connectedAnchor { get => m_ConnectedAnchor; set { m_ConnectedAnchor = value; Rebuild(); } }
        public bool autoConfigureConnectedAnchor { get => m_AutoConnected; set { m_AutoConnected = value; Rebuild(); } }
        internal override Vector2 LocalAnchor => m_Anchor;
        internal override Vector2 WorldAnchorB(Rigidbody2D self)
        {
            var wa = (Vector2)self.transform.TransformPoint(m_Anchor);
            if (m_AutoConnected)
            {
                // like Unity: the connected anchor is set to where this anchor is right now
                m_ConnectedAnchor = m_ConnectedBody != null ? (Vector2)m_ConnectedBody.transform.InverseTransformPoint(wa) : wa;
                return wa;
            }
            return m_ConnectedBody != null ? (Vector2)m_ConnectedBody.transform.TransformPoint(m_ConnectedAnchor) : m_ConnectedAnchor;
        }
    }
    public sealed class HingeJoint2D : AnchoredJoint2D
    {
        bool m_UseMotor, m_UseLimits, m_UseConnectedAnchor; JointMotor2D m_Motor = new JointMotor2D { motorSpeed = 0, maxMotorTorque = 10000 }; JointAngleLimits2D m_Limits = new JointAngleLimits2D { min = 0, max = 359 };
        float m_Ref;
        public bool useMotor { get => m_UseMotor; set { m_UseMotor = value; Params(); } }
        public bool useLimits { get => m_UseLimits; set { m_UseLimits = value; Params(); } }
        public bool useConnectedAnchor { get => m_UseConnectedAnchor; set => m_UseConnectedAnchor = value; }
        public JointMotor2D motor { get => m_Motor; set { m_Motor = value; Params(); } }
        public JointAngleLimits2D limits { get => m_Limits; set { m_Limits = value; Params(); } }
        public float referenceAngle => m_Ref * Mathf.Rad2Deg;
        public float jointAngle => s_Angle * Mathf.Rad2Deg;
        public float jointSpeed => s_AngSpeed * Mathf.Rad2Deg;
        public JointLimitState2D limitState
        {
            get
            {
                if (!m_UseLimits) return JointLimitState2D.Inactive;
                if (Mathf.Abs(m_Limits.max - m_Limits.min) < 0.01f) return JointLimitState2D.EqualLimits;
                float a = jointAngle;
                return a <= Math.Min(m_Limits.min, m_Limits.max) + 0.5f ? JointLimitState2D.LowerLimit : a >= Math.Max(m_Limits.min, m_Limits.max) - 0.5f ? JointLimitState2D.UpperLimit : JointLimitState2D.Inactive;
            }
        }
        public float GetMotorTorque(float timeStep) => s_Torque;
        internal override int Kind => 0;
        internal override void Configure(Rigidbody2D self, Vector2 wa, Vector2 wb) { m_Ref = RefAngle(self, m_ConnectedBody); }
        internal override void ParamsInto(List<double> p)
        {
            p.Add(m_Ref); p.Add(m_UseMotor ? 1 : 0); p.Add(m_Motor.motorSpeed * Mathf.Deg2Rad); p.Add(m_Motor.maxMotorTorque);
            p.Add(m_UseLimits ? 1 : 0); p.Add(m_Limits.min * Mathf.Deg2Rad); p.Add(m_Limits.max * Mathf.Deg2Rad);
        }
    }
    public sealed class DistanceJoint2D : AnchoredJoint2D
    {
        float m_Distance = 1; bool m_AutoDistance = true, m_MaxOnly;
        public float distance { get => m_Distance; set { m_Distance = Math.Max(0.005f, value); Params(); } }
        public bool autoConfigureDistance { get => m_AutoDistance; set { m_AutoDistance = value; Rebuild(); } }
        public bool maxDistanceOnly { get => m_MaxOnly; set { m_MaxOnly = value; Rebuild(); } }
        internal override int Kind => 1;
        internal override Vector2 WorldAnchorB(Rigidbody2D self) => m_AutoConnected ? AutoB(self) : base.WorldAnchorB(self);
        Vector2 AutoB(Rigidbody2D self) { m_ConnectedAnchor = Vector2.zero; return m_ConnectedBody != null ? (Vector2)m_ConnectedBody.transform.position : (Vector2)self.transform.TransformPoint(m_Anchor); }
        internal override void Configure(Rigidbody2D self, Vector2 wa, Vector2 wb) { if (m_AutoDistance) m_Distance = Math.Max(0.005f, (wb - wa).magnitude); }
        internal override void ParamsInto(List<double> p) { p.Add(m_Distance); p.Add(m_MaxOnly ? 1 : 0); }
    }
    public sealed class SpringJoint2D : AnchoredJoint2D
    {
        float m_Distance = 1, m_Damping, m_Frequency = 1; bool m_AutoDistance = true;
        public float distance { get => m_Distance; set { m_Distance = Math.Max(0.005f, value); Params(); } }
        public bool autoConfigureDistance { get => m_AutoDistance; set { m_AutoDistance = value; Rebuild(); } }
        public float dampingRatio { get => m_Damping; set { m_Damping = Mathf.Clamp01(value); Params(); } }
        public float frequency { get => m_Frequency; set { m_Frequency = Math.Max(0, value); Params(); } }
        internal override int Kind => 2;
        internal override Vector2 WorldAnchorB(Rigidbody2D self) { if (m_AutoConnected) { m_ConnectedAnchor = Vector2.zero; return m_ConnectedBody != null ? (Vector2)m_ConnectedBody.transform.position : (Vector2)self.transform.TransformPoint(m_Anchor); } return base.WorldAnchorB(self); }
        internal override void Configure(Rigidbody2D self, Vector2 wa, Vector2 wb) { if (m_AutoDistance) m_Distance = Math.Max(0.005f, (wb - wa).magnitude); }
        internal override void ParamsInto(List<double> p) { p.Add(m_Distance); p.Add(m_Frequency); p.Add(m_Damping); }
    }
    public sealed class FixedJoint2D : AnchoredJoint2D
    {
        float m_Damping, m_Frequency, m_Ref;
        public float dampingRatio { get => m_Damping; set { m_Damping = Mathf.Clamp01(value); Params(); } }
        public float frequency { get => m_Frequency; set { m_Frequency = Math.Max(0, value); Params(); } }
        public float referenceAngle => m_Ref * Mathf.Rad2Deg;
        internal override int Kind => 3;
        internal override void Configure(Rigidbody2D self, Vector2 wa, Vector2 wb) { m_Ref = RefAngle(self, m_ConnectedBody); }
        internal override void ParamsInto(List<double> p) { p.Add(m_Frequency); p.Add(m_Damping); p.Add(m_Ref); }
    }
    public sealed class SliderJoint2D : AnchoredJoint2D
    {
        float m_Angle, m_Ref; bool m_AutoAngle = true, m_UseMotor, m_UseLimits;
        JointMotor2D m_Motor = new JointMotor2D { motorSpeed = 0, maxMotorTorque = 10000 }; JointTranslationLimits2D m_Limits = new JointTranslationLimits2D { min = 0, max = 0 };
        public float angle { get => m_Angle; set { m_Angle = value; Rebuild(); } }
        public bool autoConfigureAngle { get => m_AutoAngle; set { m_AutoAngle = value; Rebuild(); } }
        public bool useMotor { get => m_UseMotor; set { m_UseMotor = value; Params(); } }
        public bool useLimits { get => m_UseLimits; set { m_UseLimits = value; Params(); } }
        public JointMotor2D motor { get => m_Motor; set { m_Motor = value; Params(); } }
        public JointTranslationLimits2D limits { get => m_Limits; set { m_Limits = value; Params(); } }
        public float referenceAngle => m_Ref * Mathf.Rad2Deg;
        public float jointTranslation => s_Trans;
        public float jointSpeed => s_TransSpeed;
        public JointLimitState2D limitState => !m_UseLimits ? JointLimitState2D.Inactive : Mathf.Abs(m_Limits.max - m_Limits.min) < 1e-4f ? JointLimitState2D.EqualLimits : s_Trans <= m_Limits.min + 0.005f ? JointLimitState2D.LowerLimit : s_Trans >= m_Limits.max - 0.005f ? JointLimitState2D.UpperLimit : JointLimitState2D.Inactive;
        public float GetMotorForce(float timeStep) => s_Force.magnitude;
        internal override int Kind => 4;
        internal override void Configure(Rigidbody2D self, Vector2 wa, Vector2 wb)
        {
            m_Ref = RefAngle(self, m_ConnectedBody);
            if (m_AutoAngle && m_ConnectedBody != null)
            {
                var d = (Vector2)m_ConnectedBody.transform.position - (Vector2)self.transform.position;
                if (d.sqrMagnitude > 1e-8f) m_Angle = Mathf.Atan2(d.y, d.x) * Mathf.Rad2Deg - self.rotation;
            }
        }
        internal override void ParamsInto(List<double> p)
        {
            p.Add(m_Angle * Mathf.Deg2Rad); p.Add(m_UseMotor ? 1 : 0); p.Add(m_Motor.motorSpeed); p.Add(m_Motor.maxMotorTorque);
            p.Add(m_UseLimits ? 1 : 0); p.Add(m_Limits.min); p.Add(m_Limits.max); p.Add(m_Ref);
        }
    }
    public sealed class WheelJoint2D : AnchoredJoint2D
    {
        JointSuspension2D m_Susp = new JointSuspension2D { dampingRatio = 0.7f, frequency = 2, angle = 90 }; bool m_UseMotor; JointMotor2D m_Motor = new JointMotor2D { motorSpeed = 0, maxMotorTorque = 10000 };
        float m_LocalAxis;
        public JointSuspension2D suspension { get => m_Susp; set { m_Susp = value; if (Math.Abs(value.angle - m_Susp.angle) > 1e-4f) Rebuild(); Params(); } }
        public bool useMotor { get => m_UseMotor; set { m_UseMotor = value; Params(); } }
        public JointMotor2D motor { get => m_Motor; set { m_Motor = value; Params(); } }
        public float jointTranslation => s_Trans;
        public float jointLinearSpeed => s_TransSpeed;
        public float jointSpeed => s_AngSpeed * Mathf.Rad2Deg;
        public float jointAngle => s_Angle * Mathf.Rad2Deg;
        public float GetMotorTorque(float timeStep) => s_Torque;
        internal override int Kind => 5;
        internal override void Configure(Rigidbody2D self, Vector2 wa, Vector2 wb) { m_LocalAxis = (m_Susp.angle - self.rotation) * Mathf.Deg2Rad; }
        internal override void ParamsInto(List<double> p)
        {
            p.Add(m_LocalAxis); p.Add(m_Susp.frequency); p.Add(m_Susp.dampingRatio);
            p.Add(m_UseMotor ? 1 : 0); p.Add(m_Motor.motorSpeed * Mathf.Deg2Rad); p.Add(m_Motor.maxMotorTorque);
        }
    }
    public sealed class RelativeJoint2D : Joint2D
    {
        float m_MaxForce = 10000, m_MaxTorque = 10000, m_Correction = 0.3f, m_AngOffset; Vector2 m_LinOffset; bool m_AutoOffset = true;
        public float maxForce { get => m_MaxForce; set { m_MaxForce = Math.Max(0, value); Params(); } }
        public float maxTorque { get => m_MaxTorque; set { m_MaxTorque = Math.Max(0, value); Params(); } }
        public float correctionScale { get => m_Correction; set { m_Correction = Mathf.Clamp01(value); Params(); } }
        public bool autoConfigureOffset { get => m_AutoOffset; set { m_AutoOffset = value; Rebuild(); } }
        public Vector2 linearOffset { get => m_LinOffset; set { m_LinOffset = value; Params(); } }
        public float angularOffset { get => m_AngOffset; set { m_AngOffset = value; Params(); } }
        public Vector2 target => m_ConnectedBody != null ? m_ConnectedBody.position : Vector2.zero;
        internal override int Kind => 6;
        internal override void Configure(Rigidbody2D self, Vector2 wa, Vector2 wb)
        {
            if (!m_AutoOffset) return;
            var other = m_ConnectedBody;
            Vector2 pb = other != null ? other.position : Vector2.zero; float ab = other != null ? other.rotation : 0;
            m_LinOffset = self.GetVector(pb - self.position); m_AngOffset = ab - self.rotation;
        }
        internal override void ParamsInto(List<double> p) { p.Add(m_MaxForce); p.Add(m_MaxTorque); p.Add(m_Correction); p.Add(m_LinOffset.x); p.Add(m_LinOffset.y); p.Add(m_AngOffset * Mathf.Deg2Rad); }
    }
    public sealed class FrictionJoint2D : AnchoredJoint2D
    {
        float m_MaxForce = 1, m_MaxTorque = 1;
        public float maxForce { get => m_MaxForce; set { m_MaxForce = Math.Max(0, value); Params(); } }
        public float maxTorque { get => m_MaxTorque; set { m_MaxTorque = Math.Max(0, value); Params(); } }
        internal override int Kind => 7;
        internal override void ParamsInto(List<double> p) { p.Add(m_MaxForce); p.Add(m_MaxTorque); }
    }
    public sealed class TargetJoint2D : Joint2D
    {
        Vector2 m_Anchor, m_Target; bool m_AutoTarget = true; float m_MaxForce = 1000, m_Damping = 1, m_Frequency = 5;
        public Vector2 anchor { get => m_Anchor; set { m_Anchor = value; Rebuild(); } }
        public Vector2 target { get => m_Target; set { m_Target = value; Params(); } }
        public bool autoConfigureTarget { get => m_AutoTarget; set { m_AutoTarget = value; Rebuild(); } }
        public float maxForce { get => m_MaxForce; set { m_MaxForce = Math.Max(0, value); Params(); } }
        public float dampingRatio { get => m_Damping; set { m_Damping = Mathf.Clamp01(value); Params(); } }
        public float frequency { get => m_Frequency; set { m_Frequency = Math.Max(0, value); Params(); } }
        internal override int Kind => 8;
        internal override bool AnchorsOnGround => true;
        internal override Vector2 LocalAnchor => m_Anchor;
        internal override Vector2 WorldAnchorB(Rigidbody2D self) => self.transform.TransformPoint(m_Anchor);
        internal override void Configure(Rigidbody2D self, Vector2 wa, Vector2 wb) { if (m_AutoTarget) m_Target = wb; }
        internal override void ParamsInto(List<double> p) { p.Add(m_Target.x); p.Add(m_Target.y); p.Add(m_MaxForce); p.Add(m_Frequency); p.Add(m_Damping); }
    }

    // ---------------------------------------------------------------- effectors
    public class Effector2D : Behaviour
    {
        bool m_UseMask = true; int m_Mask = -1;
        internal int version = 1;
        protected void Changed() => version++;
        public bool useColliderMask { get => m_UseMask; set { m_UseMask = value; Changed(); } }
        public int colliderMask { get => m_Mask; set { m_Mask = value; Changed(); } }
        internal virtual int Type => 0;
        internal virtual void ParamsInto(double[] p) { }
        internal override void OnAddedInternal() => Physics2DWorld.MarkDirty();
        internal override void OnRemovedInternal() => Physics2DWorld.MarkDirty();
        internal override void OnActiveChangedInternal(bool active) => Physics2DWorld.MarkDirty();
    }
    public sealed class PlatformEffector2D : Effector2D
    {
        bool m_OneWay = true, m_Grouping, m_SideFriction, m_SideBounce; float m_Arc = 180, m_Rot, m_SideArc = 1;
        public bool useOneWay { get => m_OneWay; set { m_OneWay = value; Changed(); } }
        public bool useOneWayGrouping { get => m_Grouping; set => m_Grouping = value; }
        public bool useSideFriction { get => m_SideFriction; set { m_SideFriction = value; Changed(); } }
        public bool useSideBounce { get => m_SideBounce; set { m_SideBounce = value; Changed(); } }
        public float surfaceArc { get => m_Arc; set { m_Arc = Mathf.Clamp(value, 0, 360); Changed(); } }
        public float sideArc { get => m_SideArc; set { m_SideArc = Mathf.Clamp(value, 0, 180); Changed(); } }
        public float rotationalOffset { get => m_Rot; set { m_Rot = value; Changed(); } }
        internal override int Type => 1;
        internal override void ParamsInto(double[] p) { p[0] = m_OneWay ? 1 : 0; p[1] = m_Arc; p[2] = m_Rot; p[3] = m_SideFriction ? 1 : 0; p[4] = m_SideBounce ? 1 : 0; p[5] = m_SideArc; }
    }
    public sealed class SurfaceEffector2D : Effector2D
    {
        float m_Speed, m_Var, m_ForceScale = 0.1f; bool m_UseContactForce, m_UseFriction, m_UseBounce;
        public float speed { get => m_Speed; set { m_Speed = value; Changed(); } }
        public float speedVariation { get => m_Var; set { m_Var = value; Changed(); } }
        public float forceScale { get => m_ForceScale; set { m_ForceScale = Mathf.Clamp01(value); Changed(); } }
        public bool useContactForce { get => m_UseContactForce; set => m_UseContactForce = value; }
        public bool useFriction { get => m_UseFriction; set { m_UseFriction = value; Changed(); } }
        public bool useBounce { get => m_UseBounce; set { m_UseBounce = value; Changed(); } }
        internal override int Type => 2;
        internal override void ParamsInto(double[] p) { p[0] = m_Speed; p[1] = m_Var; p[2] = m_UseFriction ? 1 : 0; p[3] = m_UseBounce ? 1 : 0; }
    }
    public sealed class AreaEffector2D : Effector2D
    {
        float m_Angle, m_Mag, m_Var, m_Drag, m_AngDrag; bool m_Global; EffectorSelection2D m_Target;
        public float forceAngle { get => m_Angle; set { m_Angle = value; Changed(); } }
        public bool useGlobalAngle { get => m_Global; set { m_Global = value; Changed(); } }
        public float forceMagnitude { get => m_Mag; set { m_Mag = value; Changed(); } }
        public float forceVariation { get => m_Var; set { m_Var = value; Changed(); } }
        public float linearDamping { get => m_Drag; set { m_Drag = value; Changed(); } }
        public float angularDamping { get => m_AngDrag; set { m_AngDrag = value; Changed(); } }
        [Obsolete("drag has been renamed to linearDamping")] public float drag { get => linearDamping; set => linearDamping = value; }
        [Obsolete("angularDrag has been renamed to angularDamping")] public float angularDrag { get => angularDamping; set => angularDamping = value; }
        public EffectorSelection2D forceTarget { get => m_Target; set { m_Target = value; Changed(); } }
        internal override int Type => 3;
        internal override void ParamsInto(double[] p) { p[0] = m_Angle; p[1] = m_Global ? 1 : 0; p[2] = m_Mag; p[3] = m_Var; p[4] = (int)m_Target; p[5] = m_Drag; p[6] = m_AngDrag; p[7] = 0; }
    }
    public sealed class PointEffector2D : Effector2D
    {
        float m_Mag, m_Var, m_DistScale = 1, m_Drag, m_AngDrag; EffectorSelection2D m_Source, m_Target; EffectorForceMode2D m_Mode;
        public float forceMagnitude { get => m_Mag; set { m_Mag = value; Changed(); } }
        public float forceVariation { get => m_Var; set { m_Var = value; Changed(); } }
        public float distanceScale { get => m_DistScale; set { m_DistScale = value; Changed(); } }
        public float linearDamping { get => m_Drag; set { m_Drag = value; Changed(); } }
        public float angularDamping { get => m_AngDrag; set { m_AngDrag = value; Changed(); } }
        [Obsolete("drag has been renamed to linearDamping")] public float drag { get => linearDamping; set => linearDamping = value; }
        [Obsolete("angularDrag has been renamed to angularDamping")] public float angularDrag { get => angularDamping; set => angularDamping = value; }
        public EffectorSelection2D forceSource { get => m_Source; set { m_Source = value; Changed(); } }
        public EffectorSelection2D forceTarget { get => m_Target; set { m_Target = value; Changed(); } }
        public EffectorForceMode2D forceMode { get => m_Mode; set { m_Mode = value; Changed(); } }
        internal override int Type => 4;
        internal override void ParamsInto(double[] p) { p[0] = m_Mag; p[1] = m_Var; p[2] = m_DistScale; p[3] = (int)m_Source; p[4] = (int)m_Target; p[5] = (int)m_Mode; p[6] = m_Drag; p[7] = m_AngDrag; }
    }

    // ---------------------------------------------------------------- results
    public struct RaycastHit2D
    {
        internal Vector2 m_Centroid, m_Point, m_Normal; internal float m_Distance, m_Fraction; internal Collider2D m_Collider;
        public Vector2 centroid { get => m_Centroid; set => m_Centroid = value; }
        public Vector2 point { get => m_Point; set => m_Point = value; }
        public Vector2 normal { get => m_Normal; set => m_Normal = value; }
        public float distance { get => m_Distance; set => m_Distance = value; }
        public float fraction { get => m_Fraction; set => m_Fraction = value; }
        public Collider2D collider => m_Collider;
        public Rigidbody2D rigidbody => m_Collider != null ? m_Collider.attachedRigidbody : null;
        public Transform transform => rigidbody != null ? rigidbody.transform : m_Collider != null ? m_Collider.transform : null;
        public static implicit operator bool(RaycastHit2D hit) => hit.m_Collider != null;
        public int CompareTo(RaycastHit2D other) => m_Collider == null ? 1 : other.m_Collider == null ? -1 : m_Fraction.CompareTo(other.m_Fraction);
    }
    public struct ContactPoint2D
    {
        internal Vector2 m_Point, m_Normal, m_RelVel; internal float m_Separation, m_NormalImpulse, m_TangentImpulse;
        internal Collider2D m_Collider, m_OtherCollider;
        public Vector2 point => m_Point;
        public Vector2 normal => m_Normal;
        public float separation => m_Separation;
        public float normalImpulse => m_NormalImpulse;
        public float tangentImpulse => m_TangentImpulse;
        public Vector2 relativeVelocity => m_RelVel;
        public Collider2D collider => m_Collider;
        public Collider2D otherCollider => m_OtherCollider;
        public Rigidbody2D rigidbody => m_Collider != null ? m_Collider.attachedRigidbody : null;
        public Rigidbody2D otherRigidbody => m_OtherCollider != null ? m_OtherCollider.attachedRigidbody : null;
        public bool enabled => true;
    }
    public class Collision2D
    {
        internal Collider2D m_Collider, m_OtherCollider; internal Vector2 m_RelVel; internal ContactPoint2D[] m_Contacts = Array.Empty<ContactPoint2D>();
        public Collider2D collider => m_Collider;
        public Collider2D otherCollider => m_OtherCollider;
        public Rigidbody2D rigidbody => m_Collider != null ? m_Collider.attachedRigidbody : null;
        public Rigidbody2D otherRigidbody => m_OtherCollider != null ? m_OtherCollider.attachedRigidbody : null;
        public Transform transform => rigidbody != null ? rigidbody.transform : m_Collider?.transform;
        public GameObject gameObject => m_Collider?.gameObject;
        public Vector2 relativeVelocity => m_RelVel;
        public bool enabled => true;
        public int contactCount => m_Contacts.Length;
        public ContactPoint2D[] contacts => m_Contacts;
        public ContactPoint2D GetContact(int index) => m_Contacts[index];
        public int GetContacts(ContactPoint2D[] contacts) { int n = Math.Min(contacts.Length, m_Contacts.Length); Array.Copy(m_Contacts, contacts, n); return n; }
        public int GetContacts(List<ContactPoint2D> contacts) { contacts.Clear(); contacts.AddRange(m_Contacts); return m_Contacts.Length; }
    }
    public struct ColliderDistance2D
    {
        internal Vector2 m_PointA, m_PointB, m_Normal; internal float m_Distance; internal bool m_Valid;
        public Vector2 pointA { get => m_PointA; set => m_PointA = value; }
        public Vector2 pointB { get => m_PointB; set => m_PointB = value; }
        public Vector2 normal => m_Normal;
        public float distance { get => m_Distance; set => m_Distance = value; }
        public bool isOverlapped => m_Distance < 0;
        public bool isValid { get => m_Valid; set => m_Valid = value; }
    }
    public struct ContactFilter2D
    {
        public bool useTriggers, useLayerMask, useDepth, useOutsideDepth, useNormalAngle, useOutsideNormalAngle;
        public LayerMask layerMask;
        public float minDepth, maxDepth, minNormalAngle, maxNormalAngle;
        public const float NormalAngleUpperLimit = 359.9999f;
        public bool isFiltering => !useTriggers || useLayerMask || useDepth || useNormalAngle;
        public ContactFilter2D NoFilter()
        {
            useTriggers = true; useLayerMask = false; layerMask = -1; useDepth = false; useOutsideDepth = false; minDepth = float.NegativeInfinity; maxDepth = float.PositiveInfinity;
            useNormalAngle = false; useOutsideNormalAngle = false; minNormalAngle = 0; maxNormalAngle = NormalAngleUpperLimit;
            return this;
        }
        public void SetLayerMask(LayerMask layerMask) { this.layerMask = layerMask; useLayerMask = true; }
        public void ClearLayerMask() { useLayerMask = false; }
        public void SetDepth(float minDepth, float maxDepth) { this.minDepth = minDepth; this.maxDepth = maxDepth; useDepth = true; }
        public void ClearDepth() { useDepth = false; minDepth = float.NegativeInfinity; maxDepth = float.PositiveInfinity; }
        public void SetNormalAngle(float minNormalAngle, float maxNormalAngle) { this.minNormalAngle = minNormalAngle; this.maxNormalAngle = maxNormalAngle; useNormalAngle = true; }
        public void ClearNormalAngle() { useNormalAngle = false; minNormalAngle = 0; maxNormalAngle = NormalAngleUpperLimit; }
        public bool IsFilteringTrigger(Collider2D collider) => !useTriggers && collider != null && collider.isTrigger;
        public bool IsFilteringLayerMask(GameObject obj) => useLayerMask && obj != null && (layerMask.value & (1 << obj.layer)) == 0;
        public bool IsFilteringDepth(GameObject obj)
        {
            if (!useDepth || obj == null) return false;
            float z = obj.transform.position.z, lo = Math.Min(minDepth, maxDepth), hi = Math.Max(minDepth, maxDepth);
            bool inside = z >= lo && z <= hi;
            return useOutsideDepth ? inside : !inside;
        }
        public bool IsFilteringNormalAngle(Vector2 normal) => IsFilteringNormalAngle(Mathf.Atan2(normal.y, normal.x) * Mathf.Rad2Deg);
        public bool IsFilteringNormalAngle(float angle)
        {
            if (!useNormalAngle) return false;
            float a = Mathf.Repeat(angle, 360), lo = Mathf.Repeat(minNormalAngle, 360), hi = Mathf.Repeat(maxNormalAngle, 360);
            bool inside = lo <= hi ? a >= lo && a <= hi : a >= lo || a <= hi;
            return useOutsideNormalAngle ? inside : !inside;
        }
        internal bool Passes(Collider2D c, Vector2? normal = null)
        {
            if (c == null) return false;
            if (IsFilteringTrigger(c) || IsFilteringLayerMask(c.gameObject) || IsFilteringDepth(c.gameObject)) return false;
            if (normal.HasValue && IsFilteringNormalAngle(normal.Value)) return false;
            return true;
        }
        internal int Mask => useLayerMask ? layerMask.value : -1;
    }

    // ---------------------------------------------------------------- Physics2D
    public static class Physics2D
    {
        public const int IgnoreRaycastLayer = 4;
        public const int DefaultRaycastLayers = -5;
        public const int AllLayers = -1;
        static Vector2 s_Gravity = new Vector2(0, -9.81f);
        public static Vector2 gravity { get => s_Gravity; set { s_Gravity = value; Physics2DWorld.settingsDirty = true; } }
        static int s_VelIt = 8, s_PosIt = 3; static float s_Bounce = 1;
        public static int velocityIterations { get => s_VelIt; set { s_VelIt = Math.Max(1, value); Physics2DWorld.settingsDirty = true; } }
        public static int positionIterations { get => s_PosIt; set { s_PosIt = Math.Max(1, value); Physics2DWorld.settingsDirty = true; } }
        public static float bounceThreshold { get => s_Bounce; set { s_Bounce = Math.Max(0.0001f, value); Physics2DWorld.settingsDirty = true; } }
        public static bool queriesHitTriggers { get; set; } = true;
        public static bool queriesStartInColliders { get; set; } = true;
        public static bool callbacksOnDisable { get; set; } = true;
        public static bool reuseCollisionCallbacks { get; set; } = true;
        public static bool autoSyncTransforms { get; set; }
        public static SimulationMode2D simulationMode { get; set; } = SimulationMode2D.FixedUpdate;
        public static float defaultContactOffset { get; set; } = 0.01f;
        public static float maxLinearCorrection { get; set; } = 0.2f;
        public static float maxAngularCorrection { get; set; } = 8f;
        public static float maxTranslationSpeed { get; set; } = 100f;
        public static float maxRotationSpeed { get; set; } = 360f;
        public static float baumgarteScale { get; set; } = 0.2f;
        public static float baumgarteTOIScale { get; set; } = 0.75f;
        public static float timeToSleep { get; set; } = 0.5f;
        public static float linearSleepTolerance { get; set; } = 0.01f;
        public static float angularSleepTolerance { get; set; } = 2f;
        internal static readonly int[] s_LayerMasks = Enumerable.Repeat(-1, 32).ToArray();

        public static bool Simulate(float deltaTime) { Physics2DWorld.Step(deltaTime); return true; }
        public static bool Simulate(float deltaTime, int simulationLayers) => Simulate(deltaTime);
        public static void SyncTransforms() => Physics2DWorld.SyncForQuery();

        // ---- collision matrix and ignore pairs
        public static void IgnoreCollision(Collider2D collider1, Collider2D collider2) => IgnoreCollision(collider1, collider2, true);
        public static void IgnoreCollision(Collider2D collider1, Collider2D collider2, bool ignore)
        {
            if (collider1 == null || collider2 == null) { Debug.LogError("Cannot IgnoreCollision as a Collider2D is null."); return; }
            Physics2DWorld.SetIgnore(collider1, collider2, ignore);
        }
        public static bool GetIgnoreCollision(Collider2D collider1, Collider2D collider2) => Physics2DWorld.IsIgnored(collider1, collider2);
        public static void IgnoreLayerCollision(int layer1, int layer2) => IgnoreLayerCollision(layer1, layer2, true);
        public static void IgnoreLayerCollision(int layer1, int layer2, bool ignore)
        {
            if (layer1 < 0 || layer1 > 31 || layer2 < 0 || layer2 > 31) { Debug.LogError("Layer numbers must be between 0 and 31."); return; }
            if (ignore) { s_LayerMasks[layer1] &= ~(1 << layer2); s_LayerMasks[layer2] &= ~(1 << layer1); }
            else { s_LayerMasks[layer1] |= 1 << layer2; s_LayerMasks[layer2] |= 1 << layer1; }
            Physics2DWorld.layersDirty = true;
        }
        public static bool GetIgnoreLayerCollision(int layer1, int layer2) => (s_LayerMasks[layer1] & (1 << layer2)) == 0;
        public static int GetLayerCollisionMask(int layer) => s_LayerMasks[layer];
        public static void SetLayerCollisionMask(int layer, int layerMask) { s_LayerMasks[layer] = layerMask; Physics2DWorld.layersDirty = true; }

        // ---- touching / distance
        public static bool IsTouching(Collider2D collider1, Collider2D collider2) => Physics2DWorld.Touching(collider1, collider2);
        public static bool IsTouching(Collider2D collider1, Collider2D collider2, ContactFilter2D contactFilter) => Physics2DWorld.Touching(collider1, collider2, contactFilter);
        public static bool IsTouching(Collider2D collider, ContactFilter2D contactFilter) => Physics2DWorld.TouchingAny(collider, contactFilter);
        public static bool IsTouchingLayers(Collider2D collider) => IsTouchingLayers(collider, AllLayers);
        public static bool IsTouchingLayers(Collider2D collider, int layerMask) => Physics2DWorld.TouchingLayers(collider, layerMask);
        public static ColliderDistance2D Distance(Collider2D colliderA, Collider2D colliderB) => Physics2DWorld.Distance(colliderA, colliderB);
        public static Vector2 ClosestPoint(Vector2 position, Collider2D collider) => collider.ClosestPoint(position);
        public static Vector2 ClosestPoint(Vector2 position, Rigidbody2D rigidbody) => rigidbody.ClosestPoint(position);
        public static int GetContacts(Collider2D collider, ContactPoint2D[] contacts) => collider.GetContacts(contacts);
        public static int GetContacts(Collider2D collider, List<ContactPoint2D> contacts) => collider.GetContacts(contacts);
        public static int GetContacts(Collider2D collider, ContactFilter2D contactFilter, ContactPoint2D[] contacts) => collider.GetContacts(contactFilter, contacts);
        public static int GetContacts(Collider2D collider, Collider2D[] colliders) => collider.GetContacts(colliders);
        public static int GetContacts(Rigidbody2D rigidbody, ContactPoint2D[] contacts) => rigidbody.GetContacts(contacts);
        public static int GetContacts(Rigidbody2D rigidbody, List<ContactPoint2D> contacts) => rigidbody.GetContacts(contacts);

        // ---- helpers
        static ContactFilter2D Legacy(int layerMask, float minDepth, float maxDepth)
        {
            var f = new ContactFilter2D().NoFilter();
            f.useTriggers = queriesHitTriggers; f.SetLayerMask(layerMask);
            if (!float.IsNegativeInfinity(minDepth) || !float.IsPositiveInfinity(maxDepth)) f.SetDepth(minDepth, maxDepth);
            return f;
        }
        static RaycastHit2D First(RaycastHit2D[] hits) => hits.Length > 0 ? hits[0] : default;
        static int Fill(RaycastHit2D[] all, RaycastHit2D[] results) { int n = Math.Min(all.Length, results.Length); Array.Copy(all, results, n); return n; }
        static int Fill(RaycastHit2D[] all, List<RaycastHit2D> results) { results.Clear(); results.AddRange(all); return all.Length; }
        static int Fill(Collider2D[] all, Collider2D[] results) { int n = Math.Min(all.Length, results.Length); Array.Copy(all, results, n); return n; }
        static int Fill(Collider2D[] all, List<Collider2D> results) { results.Clear(); results.AddRange(all); return all.Length; }

        // ---- raycasts
        public static RaycastHit2D Raycast(Vector2 origin, Vector2 direction) => Raycast(origin, direction, float.PositiveInfinity, DefaultRaycastLayers);
        public static RaycastHit2D Raycast(Vector2 origin, Vector2 direction, float distance) => Raycast(origin, direction, distance, DefaultRaycastLayers);
        public static RaycastHit2D Raycast(Vector2 origin, Vector2 direction, float distance, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => First(Physics2DWorld.Ray(origin, direction, distance, Legacy(layerMask, minDepth, maxDepth), true));
        public static int Raycast(Vector2 origin, Vector2 direction, ContactFilter2D contactFilter, RaycastHit2D[] results, float distance = float.PositiveInfinity) => Fill(Physics2DWorld.Ray(origin, direction, distance, contactFilter, false), results);
        public static int Raycast(Vector2 origin, Vector2 direction, ContactFilter2D contactFilter, List<RaycastHit2D> results, float distance = float.PositiveInfinity) => Fill(Physics2DWorld.Ray(origin, direction, distance, contactFilter, false), results);
        public static RaycastHit2D[] RaycastAll(Vector2 origin, Vector2 direction) => RaycastAll(origin, direction, float.PositiveInfinity, DefaultRaycastLayers);
        public static RaycastHit2D[] RaycastAll(Vector2 origin, Vector2 direction, float distance) => RaycastAll(origin, direction, distance, DefaultRaycastLayers);
        public static RaycastHit2D[] RaycastAll(Vector2 origin, Vector2 direction, float distance, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => Physics2DWorld.Ray(origin, direction, distance, Legacy(layerMask, minDepth, maxDepth), false);
        public static int RaycastNonAlloc(Vector2 origin, Vector2 direction, RaycastHit2D[] results, float distance = float.PositiveInfinity, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => Fill(RaycastAll(origin, direction, distance, layerMask, minDepth, maxDepth), results);
        public static RaycastHit2D Linecast(Vector2 start, Vector2 end) => Linecast(start, end, DefaultRaycastLayers);
        public static RaycastHit2D Linecast(Vector2 start, Vector2 end, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => Raycast(start, end - start, (end - start).magnitude, layerMask, minDepth, maxDepth);
        public static int Linecast(Vector2 start, Vector2 end, ContactFilter2D contactFilter, RaycastHit2D[] results) => Raycast(start, end - start, contactFilter, results, (end - start).magnitude);
        public static int Linecast(Vector2 start, Vector2 end, ContactFilter2D contactFilter, List<RaycastHit2D> results) => Raycast(start, end - start, contactFilter, results, (end - start).magnitude);
        public static RaycastHit2D[] LinecastAll(Vector2 start, Vector2 end, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => RaycastAll(start, end - start, (end - start).magnitude, layerMask, minDepth, maxDepth);
        public static int LinecastNonAlloc(Vector2 start, Vector2 end, RaycastHit2D[] results, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => Fill(LinecastAll(start, end, layerMask, minDepth, maxDepth), results);

        // ---- shape casts (kind: 0 circle, 1 box, 2 capsule)
        static double[] Circ(Vector2 o, float r) => new double[] { o.x, o.y, r, 0, 0, 0 };
        static double[] BoxD(Vector2 o, Vector2 s, float a) => new double[] { o.x, o.y, s.x, s.y, a, 0 };
        static double[] Cap(Vector2 o, Vector2 s, CapsuleDirection2D d, float a) => new double[] { o.x, o.y, s.x, s.y, a, (int)d };
        public static RaycastHit2D CircleCast(Vector2 origin, float radius, Vector2 direction) => CircleCast(origin, radius, direction, float.PositiveInfinity, DefaultRaycastLayers);
        public static RaycastHit2D CircleCast(Vector2 origin, float radius, Vector2 direction, float distance) => CircleCast(origin, radius, direction, distance, DefaultRaycastLayers);
        public static RaycastHit2D CircleCast(Vector2 origin, float radius, Vector2 direction, float distance, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => First(Physics2DWorld.Cast(0, Circ(origin, radius), origin, direction, distance, Legacy(layerMask, minDepth, maxDepth)));
        public static int CircleCast(Vector2 origin, float radius, Vector2 direction, ContactFilter2D contactFilter, RaycastHit2D[] results, float distance = float.PositiveInfinity) => Fill(Physics2DWorld.Cast(0, Circ(origin, radius), origin, direction, distance, contactFilter), results);
        public static int CircleCast(Vector2 origin, float radius, Vector2 direction, ContactFilter2D contactFilter, List<RaycastHit2D> results, float distance = float.PositiveInfinity) => Fill(Physics2DWorld.Cast(0, Circ(origin, radius), origin, direction, distance, contactFilter), results);
        public static RaycastHit2D[] CircleCastAll(Vector2 origin, float radius, Vector2 direction, float distance = float.PositiveInfinity, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => Physics2DWorld.Cast(0, Circ(origin, radius), origin, direction, distance, Legacy(layerMask, minDepth, maxDepth));
        public static int CircleCastNonAlloc(Vector2 origin, float radius, Vector2 direction, RaycastHit2D[] results, float distance = float.PositiveInfinity, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => Fill(CircleCastAll(origin, radius, direction, distance, layerMask, minDepth, maxDepth), results);
        public static RaycastHit2D BoxCast(Vector2 origin, Vector2 size, float angle, Vector2 direction) => BoxCast(origin, size, angle, direction, float.PositiveInfinity, DefaultRaycastLayers);
        public static RaycastHit2D BoxCast(Vector2 origin, Vector2 size, float angle, Vector2 direction, float distance) => BoxCast(origin, size, angle, direction, distance, DefaultRaycastLayers);
        public static RaycastHit2D BoxCast(Vector2 origin, Vector2 size, float angle, Vector2 direction, float distance, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => First(Physics2DWorld.Cast(1, BoxD(origin, size, angle), origin, direction, distance, Legacy(layerMask, minDepth, maxDepth)));
        public static int BoxCast(Vector2 origin, Vector2 size, float angle, Vector2 direction, ContactFilter2D contactFilter, RaycastHit2D[] results, float distance = float.PositiveInfinity) => Fill(Physics2DWorld.Cast(1, BoxD(origin, size, angle), origin, direction, distance, contactFilter), results);
        public static int BoxCast(Vector2 origin, Vector2 size, float angle, Vector2 direction, ContactFilter2D contactFilter, List<RaycastHit2D> results, float distance = float.PositiveInfinity) => Fill(Physics2DWorld.Cast(1, BoxD(origin, size, angle), origin, direction, distance, contactFilter), results);
        public static RaycastHit2D[] BoxCastAll(Vector2 origin, Vector2 size, float angle, Vector2 direction, float distance = float.PositiveInfinity, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => Physics2DWorld.Cast(1, BoxD(origin, size, angle), origin, direction, distance, Legacy(layerMask, minDepth, maxDepth));
        public static int BoxCastNonAlloc(Vector2 origin, Vector2 size, float angle, Vector2 direction, RaycastHit2D[] results, float distance = float.PositiveInfinity, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => Fill(BoxCastAll(origin, size, angle, direction, distance, layerMask, minDepth, maxDepth), results);
        public static RaycastHit2D CapsuleCast(Vector2 origin, Vector2 size, CapsuleDirection2D capsuleDirection, float angle, Vector2 direction) => CapsuleCast(origin, size, capsuleDirection, angle, direction, float.PositiveInfinity, DefaultRaycastLayers);
        public static RaycastHit2D CapsuleCast(Vector2 origin, Vector2 size, CapsuleDirection2D capsuleDirection, float angle, Vector2 direction, float distance) => CapsuleCast(origin, size, capsuleDirection, angle, direction, distance, DefaultRaycastLayers);
        public static RaycastHit2D CapsuleCast(Vector2 origin, Vector2 size, CapsuleDirection2D capsuleDirection, float angle, Vector2 direction, float distance, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => First(Physics2DWorld.Cast(2, Cap(origin, size, capsuleDirection, angle), origin, direction, distance, Legacy(layerMask, minDepth, maxDepth)));
        public static int CapsuleCast(Vector2 origin, Vector2 size, CapsuleDirection2D capsuleDirection, float angle, Vector2 direction, ContactFilter2D contactFilter, RaycastHit2D[] results, float distance = float.PositiveInfinity) => Fill(Physics2DWorld.Cast(2, Cap(origin, size, capsuleDirection, angle), origin, direction, distance, contactFilter), results);
        public static RaycastHit2D[] CapsuleCastAll(Vector2 origin, Vector2 size, CapsuleDirection2D capsuleDirection, float angle, Vector2 direction, float distance = float.PositiveInfinity, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => Physics2DWorld.Cast(2, Cap(origin, size, capsuleDirection, angle), origin, direction, distance, Legacy(layerMask, minDepth, maxDepth));
        public static int CapsuleCastNonAlloc(Vector2 origin, Vector2 size, CapsuleDirection2D capsuleDirection, float angle, Vector2 direction, RaycastHit2D[] results, float distance = float.PositiveInfinity, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity)
            => Fill(CapsuleCastAll(origin, size, capsuleDirection, angle, direction, distance, layerMask, minDepth, maxDepth), results);

        // ---- 3D ray against the 2D world (clicking on 2D objects)
        public static RaycastHit2D GetRayIntersection(Ray ray) => GetRayIntersection(ray, float.PositiveInfinity, DefaultRaycastLayers);
        public static RaycastHit2D GetRayIntersection(Ray ray, float distance) => GetRayIntersection(ray, distance, DefaultRaycastLayers);
        public static RaycastHit2D GetRayIntersection(Ray ray, float distance, int layerMask) { var a = GetRayIntersectionAll(ray, distance, layerMask); return a.Length > 0 ? a[0] : default; }
        public static RaycastHit2D[] GetRayIntersectionAll(Ray ray, float distance = float.PositiveInfinity, int layerMask = DefaultRaycastLayers)
        {
            var res = new List<RaycastHit2D>();
            var dir = ray.direction;
            foreach (var c in OverlapAllAlongRay(ray, distance, layerMask))
            {
                float z = c.transform.position.z;
                float t = Math.Abs(dir.z) > 1e-6f ? (z - ray.origin.z) / dir.z : 0;
                if (t < 0 || t > distance) continue;
                var p = ray.origin + dir * t;
                if (!c.OverlapPoint(p)) continue;
                res.Add(new RaycastHit2D { m_Collider = c, m_Point = p, m_Centroid = p, m_Normal = -(Vector2)dir, m_Distance = t, m_Fraction = float.IsInfinity(distance) ? 0 : t / distance });
            }
            res.Sort((a, b) => a.distance.CompareTo(b.distance));
            return res.ToArray();
        }
        public static int GetRayIntersectionNonAlloc(Ray ray, RaycastHit2D[] results, float distance = float.PositiveInfinity, int layerMask = DefaultRaycastLayers) => Fill(GetRayIntersectionAll(ray, distance, layerMask), results);
        static IEnumerable<Collider2D> OverlapAllAlongRay(Ray ray, float distance, int layerMask)
        {
            var seen = new HashSet<Collider2D>();
            foreach (var c in Physics2DWorld.AllColliders()) if (c.isActiveAndEnabled && (layerMask & (1 << c.gameObject.layer)) != 0 && (queriesHitTriggers || !c.isTrigger) && seen.Add(c)) yield return c;
        }

        // ---- overlaps
        public static Collider2D OverlapPoint(Vector2 point) => OverlapPoint(point, DefaultRaycastLayers);
        public static Collider2D OverlapPoint(Vector2 point, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) { var a = OverlapPointAll(point, layerMask, minDepth, maxDepth); return a.Length > 0 ? a[0] : null; }
        public static Collider2D[] OverlapPointAll(Vector2 point, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => Physics2DWorld.OverlapPoint(point, Legacy(layerMask, minDepth, maxDepth));
        public static int OverlapPoint(Vector2 point, ContactFilter2D contactFilter, Collider2D[] results) => Fill(Physics2DWorld.OverlapPoint(point, contactFilter), results);
        public static int OverlapPoint(Vector2 point, ContactFilter2D contactFilter, List<Collider2D> results) => Fill(Physics2DWorld.OverlapPoint(point, contactFilter), results);
        public static int OverlapPointNonAlloc(Vector2 point, Collider2D[] results, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => Fill(OverlapPointAll(point, layerMask, minDepth, maxDepth), results);

        public static Collider2D OverlapCircle(Vector2 point, float radius) => OverlapCircle(point, radius, DefaultRaycastLayers);
        public static Collider2D OverlapCircle(Vector2 point, float radius, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) { var a = OverlapCircleAll(point, radius, layerMask, minDepth, maxDepth); return a.Length > 0 ? a[0] : null; }
        public static Collider2D[] OverlapCircleAll(Vector2 point, float radius, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => Physics2DWorld.Overlap(0, Circ(point, radius), Legacy(layerMask, minDepth, maxDepth));
        public static int OverlapCircle(Vector2 point, float radius, ContactFilter2D contactFilter, Collider2D[] results) => Fill(Physics2DWorld.Overlap(0, Circ(point, radius), contactFilter), results);
        public static int OverlapCircle(Vector2 point, float radius, ContactFilter2D contactFilter, List<Collider2D> results) => Fill(Physics2DWorld.Overlap(0, Circ(point, radius), contactFilter), results);
        public static int OverlapCircleNonAlloc(Vector2 point, float radius, Collider2D[] results, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => Fill(OverlapCircleAll(point, radius, layerMask, minDepth, maxDepth), results);

        public static Collider2D OverlapBox(Vector2 point, Vector2 size, float angle) => OverlapBox(point, size, angle, DefaultRaycastLayers);
        public static Collider2D OverlapBox(Vector2 point, Vector2 size, float angle, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) { var a = OverlapBoxAll(point, size, angle, layerMask, minDepth, maxDepth); return a.Length > 0 ? a[0] : null; }
        public static Collider2D[] OverlapBoxAll(Vector2 point, Vector2 size, float angle, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => Physics2DWorld.Overlap(1, BoxD(point, size, angle), Legacy(layerMask, minDepth, maxDepth));
        public static int OverlapBox(Vector2 point, Vector2 size, float angle, ContactFilter2D contactFilter, Collider2D[] results) => Fill(Physics2DWorld.Overlap(1, BoxD(point, size, angle), contactFilter), results);
        public static int OverlapBox(Vector2 point, Vector2 size, float angle, ContactFilter2D contactFilter, List<Collider2D> results) => Fill(Physics2DWorld.Overlap(1, BoxD(point, size, angle), contactFilter), results);
        public static int OverlapBoxNonAlloc(Vector2 point, Vector2 size, float angle, Collider2D[] results, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => Fill(OverlapBoxAll(point, size, angle, layerMask, minDepth, maxDepth), results);

        static double[] Area(Vector2 a, Vector2 b) => new double[] { Math.Min(a.x, b.x), Math.Min(a.y, b.y), Math.Max(a.x, b.x), Math.Max(a.y, b.y), 0, 0 };
        public static Collider2D OverlapArea(Vector2 pointA, Vector2 pointB) => OverlapArea(pointA, pointB, DefaultRaycastLayers);
        public static Collider2D OverlapArea(Vector2 pointA, Vector2 pointB, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) { var a = OverlapAreaAll(pointA, pointB, layerMask, minDepth, maxDepth); return a.Length > 0 ? a[0] : null; }
        public static Collider2D[] OverlapAreaAll(Vector2 pointA, Vector2 pointB, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => Physics2DWorld.Overlap(3, Area(pointA, pointB), Legacy(layerMask, minDepth, maxDepth));
        public static int OverlapArea(Vector2 pointA, Vector2 pointB, ContactFilter2D contactFilter, Collider2D[] results) => Fill(Physics2DWorld.Overlap(3, Area(pointA, pointB), contactFilter), results);
        public static int OverlapArea(Vector2 pointA, Vector2 pointB, ContactFilter2D contactFilter, List<Collider2D> results) => Fill(Physics2DWorld.Overlap(3, Area(pointA, pointB), contactFilter), results);
        public static int OverlapAreaNonAlloc(Vector2 pointA, Vector2 pointB, Collider2D[] results, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => Fill(OverlapAreaAll(pointA, pointB, layerMask, minDepth, maxDepth), results);

        public static Collider2D OverlapCapsule(Vector2 point, Vector2 size, CapsuleDirection2D direction, float angle) => OverlapCapsule(point, size, direction, angle, DefaultRaycastLayers);
        public static Collider2D OverlapCapsule(Vector2 point, Vector2 size, CapsuleDirection2D direction, float angle, int layerMask, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) { var a = OverlapCapsuleAll(point, size, direction, angle, layerMask, minDepth, maxDepth); return a.Length > 0 ? a[0] : null; }
        public static Collider2D[] OverlapCapsuleAll(Vector2 point, Vector2 size, CapsuleDirection2D direction, float angle, int layerMask = DefaultRaycastLayers, float minDepth = float.NegativeInfinity, float maxDepth = float.PositiveInfinity) => Physics2DWorld.Overlap(2, Cap(point, size, direction, angle), Legacy(layerMask, minDepth, maxDepth));
        public static int OverlapCapsule(Vector2 point, Vector2 size, CapsuleDirection2D direction, float angle, ContactFilter2D contactFilter, Collider2D[] results) => Fill(Physics2DWorld.Overlap(2, Cap(point, size, direction, angle), contactFilter), results);
        public static int OverlapCapsule(Vector2 point, Vector2 size, CapsuleDirection2D direction, float angle, ContactFilter2D contactFilter, List<Collider2D> results) => Fill(Physics2DWorld.Overlap(2, Cap(point, size, direction, angle), contactFilter), results);

        public static int OverlapCollider(Collider2D collider, ContactFilter2D contactFilter, Collider2D[] results) => Fill(Physics2DWorld.OverlapCollider(collider, contactFilter), results);
        public static int OverlapCollider(Collider2D collider, ContactFilter2D contactFilter, List<Collider2D> results) => Fill(Physics2DWorld.OverlapCollider(collider, contactFilter), results);
        public static int OverlapCollider(Collider2D collider, List<Collider2D> results) => Fill(Physics2DWorld.OverlapCollider(collider, new ContactFilter2D().NoFilter()), results);
    }
}
