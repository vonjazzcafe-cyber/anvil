// uGUI controls: Selectable, Button, Toggle, ToggleGroup, Slider, Scrollbar, ScrollRect, InputField, Dropdown.
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using Anvil;

namespace UnityEngine.UI
{
    [Serializable]
    public struct ColorBlock : IEquatable<ColorBlock>
    {
        [SerializeField] Color m_NormalColor, m_HighlightedColor, m_PressedColor, m_SelectedColor, m_DisabledColor;
        [Range(1, 5)] [SerializeField] float m_ColorMultiplier;
        [SerializeField] float m_FadeDuration;
        public Color normalColor { get => m_NormalColor; set => m_NormalColor = value; }
        public Color highlightedColor { get => m_HighlightedColor; set => m_HighlightedColor = value; }
        public Color pressedColor { get => m_PressedColor; set => m_PressedColor = value; }
        public Color selectedColor { get => m_SelectedColor; set => m_SelectedColor = value; }
        public Color disabledColor { get => m_DisabledColor; set => m_DisabledColor = value; }
        public float colorMultiplier { get => m_ColorMultiplier; set => m_ColorMultiplier = value; }
        public float fadeDuration { get => m_FadeDuration; set => m_FadeDuration = value; }
        public static ColorBlock defaultColorBlock = new ColorBlock
        {
            m_NormalColor = new Color32(255, 255, 255, 255), m_HighlightedColor = new Color32(245, 245, 245, 255), m_PressedColor = new Color32(200, 200, 200, 255),
            m_SelectedColor = new Color32(245, 245, 245, 255), m_DisabledColor = new Color32(200, 200, 200, 128), m_ColorMultiplier = 1f, m_FadeDuration = 0.1f,
        };
        public bool Equals(ColorBlock o) => normalColor == o.normalColor && highlightedColor == o.highlightedColor && pressedColor == o.pressedColor && selectedColor == o.selectedColor && disabledColor == o.disabledColor && colorMultiplier == o.colorMultiplier && fadeDuration == o.fadeDuration;
        public override bool Equals(object obj) => obj is ColorBlock b && Equals(b);
        public static bool operator ==(ColorBlock a, ColorBlock b) => a.Equals(b);
        public static bool operator !=(ColorBlock a, ColorBlock b) => !a.Equals(b);
        public override int GetHashCode() => normalColor.GetHashCode();
    }
    [Serializable]
    public struct SpriteState : IEquatable<SpriteState>
    {
        [SerializeField] Sprite m_HighlightedSprite, m_PressedSprite, m_SelectedSprite, m_DisabledSprite;
        public Sprite highlightedSprite { get => m_HighlightedSprite; set => m_HighlightedSprite = value; }
        public Sprite pressedSprite { get => m_PressedSprite; set => m_PressedSprite = value; }
        public Sprite selectedSprite { get => m_SelectedSprite; set => m_SelectedSprite = value; }
        public Sprite disabledSprite { get => m_DisabledSprite; set => m_DisabledSprite = value; }
        public bool Equals(SpriteState o) => highlightedSprite == o.highlightedSprite && pressedSprite == o.pressedSprite && selectedSprite == o.selectedSprite && disabledSprite == o.disabledSprite;
    }
    [Serializable]
    public class AnimationTriggers
    {
        [SerializeField] string m_NormalTrigger = "Normal", m_HighlightedTrigger = "Highlighted", m_PressedTrigger = "Pressed", m_SelectedTrigger = "Selected", m_DisabledTrigger = "Disabled";
        public string normalTrigger { get => m_NormalTrigger; set => m_NormalTrigger = value; }
        public string highlightedTrigger { get => m_HighlightedTrigger; set => m_HighlightedTrigger = value; }
        public string pressedTrigger { get => m_PressedTrigger; set => m_PressedTrigger = value; }
        public string selectedTrigger { get => m_SelectedTrigger; set => m_SelectedTrigger = value; }
        public string disabledTrigger { get => m_DisabledTrigger; set => m_DisabledTrigger = value; }
    }
    [Serializable]
    public struct Navigation : IEquatable<Navigation>
    {
        [Flags] public enum Mode { None = 0, Horizontal = 1, Vertical = 2, Automatic = 3, Explicit = 4 }
        [SerializeField] Mode m_Mode; [SerializeField] bool m_WrapAround;
        [SerializeField] Selectable m_SelectOnUp, m_SelectOnDown, m_SelectOnLeft, m_SelectOnRight;
        public Mode mode { get => m_Mode; set => m_Mode = value; }
        public bool wrapAround { get => m_WrapAround; set => m_WrapAround = value; }
        public Selectable selectOnUp { get => m_SelectOnUp; set => m_SelectOnUp = value; }
        public Selectable selectOnDown { get => m_SelectOnDown; set => m_SelectOnDown = value; }
        public Selectable selectOnLeft { get => m_SelectOnLeft; set => m_SelectOnLeft = value; }
        public Selectable selectOnRight { get => m_SelectOnRight; set => m_SelectOnRight = value; }
        public static Navigation defaultNavigation => new Navigation { m_Mode = Mode.Automatic, m_WrapAround = false };
        public bool Equals(Navigation o) => mode == o.mode && selectOnUp == o.selectOnUp && selectOnDown == o.selectOnDown && selectOnLeft == o.selectOnLeft && selectOnRight == o.selectOnRight;
    }

    [AddComponentMenu("UI/Selectable", 35)]
    [ExecuteAlways]
    [SelectionBase]
    [DisallowMultipleComponent]
    public class Selectable : UIBehaviour, IMoveHandler, IPointerDownHandler, IPointerUpHandler, IPointerEnterHandler, IPointerExitHandler, ISelectHandler, IDeselectHandler, IUIRefresh
    {
        public enum Transition { None = 0, ColorTint = 1, SpriteSwap = 2, Animation = 3 }
        protected enum SelectionState { Normal = 0, Highlighted = 1, Pressed = 2, Selected = 3, Disabled = 4 }
        protected static Selectable[] s_Selectables = new Selectable[10];
        protected static int s_SelectableCount;
        static readonly List<Selectable> s_All = new List<Selectable>();
        internal static void ResetStatics() { s_All.Clear(); s_SelectableCount = 0; }
        public static Selectable[] allSelectablesArray => s_All.ToArray();
        public static int allSelectableCount => s_All.Count;
        [Obsolete("Replaced with allSelectablesArray to have better performance when disabling a element", false)] public static List<Selectable> allSelectables => new List<Selectable>(s_All);
        public static int AllSelectablesNoAlloc(Selectable[] selectables) { int n = Mathf.Min(selectables.Length, s_All.Count); for (int i = 0; i < n; i++) selectables[i] = s_All[i]; return n; }

        [SerializeField] Navigation m_Navigation = Navigation.defaultNavigation;
        [SerializeField] Transition m_Transition = Transition.ColorTint;
        [SerializeField] ColorBlock m_Colors = ColorBlock.defaultColorBlock;
        [SerializeField] SpriteState m_SpriteState;
        [SerializeField] AnimationTriggers m_AnimationTriggers = new AnimationTriggers();
        [SerializeField] bool m_Interactable = true;
        [SerializeField] Graphic m_TargetGraphic;
        bool m_GroupsAllowInteraction = true;
        bool isPointerInside, isPointerDown, hasSelection;
        public Navigation navigation { get => m_Navigation; set => m_Navigation = value; }
        public Transition transition { get => m_Transition; set { m_Transition = value; OnSetProperty(); } }
        public ColorBlock colors { get => m_Colors; set { m_Colors = value; OnSetProperty(); } }
        public SpriteState spriteState { get => m_SpriteState; set { m_SpriteState = value; OnSetProperty(); } }
        public AnimationTriggers animationTriggers { get => m_AnimationTriggers; set { m_AnimationTriggers = value; OnSetProperty(); } }
        public Graphic targetGraphic { get => m_TargetGraphic; set { m_TargetGraphic = value; OnSetProperty(); } }
        public bool interactable
        {
            get => m_Interactable;
            set
            {
                m_Interactable = value;
                if (!m_Interactable && EventSystem.current != null && EventSystem.current.currentSelectedGameObject == gameObject) EventSystem.current.SetSelectedGameObject(null);
                OnSetProperty();
            }
        }
        public Image image { get => m_TargetGraphic as Image; set => m_TargetGraphic = value; }
        public Animator animator => GetComponent<Animator>();
        protected Selectable() { }
        protected override void Awake() { if (m_TargetGraphic == null) m_TargetGraphic = GetComponent<Graphic>(); }
        protected override void OnCanvasGroupChanged() { OnSetProperty(); }
        public virtual bool IsInteractable() => m_GroupsAllowInteraction && m_Interactable;
        bool GroupsAllow()
        {
            for (var t = transform; t != null; t = t.parent)
            {
                var g = t.GetComponent<CanvasGroup>();
                if (g != null && g.enabled) { if (!g.interactable) return false; if (g.ignoreParentGroups) break; }
            }
            return true;
        }
        protected override void OnEnable()
        {
            if (!s_All.Contains(this)) s_All.Add(this);
            s_SelectableCount = s_All.Count;
            if (EventSystem.current != null && EventSystem.current.currentSelectedGameObject == gameObject) hasSelection = true;
            isPointerDown = false;
            DoStateTransition(currentSelectionState, true);
        }
        protected override void OnDisable()
        {
            s_All.Remove(this); s_SelectableCount = s_All.Count;
            isPointerInside = isPointerDown = hasSelection = false;
            InstantClearState();
        }
        protected override void OnTransformParentChanged() { OnSetProperty(); }
        void OnSetProperty() { if (isActiveAndEnabled) DoStateTransition(currentSelectionState, false); else UIRefresh(); }
        public virtual void UIRefresh() { DoStateTransition(SelectionState.Normal, true); }
        protected SelectionState currentSelectionState
        {
            get
            {
                if (!IsInteractable()) return SelectionState.Disabled;
                if (isPointerDown) return SelectionState.Pressed;
                if (hasSelection) return SelectionState.Selected;
                if (isPointerInside) return SelectionState.Highlighted;
                return SelectionState.Normal;
            }
        }
        // called every frame by UIRuntime: CanvasGroup interactable changes
        internal void RefreshGroups()
        {
            bool g = GroupsAllow();
            if (g != m_GroupsAllowInteraction) { m_GroupsAllowInteraction = g; DoStateTransition(currentSelectionState, false); }
        }
        protected virtual void InstantClearState()
        {
            switch (m_Transition)
            {
                case Transition.ColorTint: StartColorTween(Color.white, true); break;
                case Transition.SpriteSwap: DoSpriteSwap(null); break;
            }
        }
        protected virtual void DoStateTransition(SelectionState state, bool instant)
        {
            if (!gameObject.activeInHierarchy && !instant) return;
            Color tint; Sprite sprite;
            switch (state)
            {
                case SelectionState.Highlighted: tint = m_Colors.highlightedColor; sprite = m_SpriteState.highlightedSprite; break;
                case SelectionState.Pressed: tint = m_Colors.pressedColor; sprite = m_SpriteState.pressedSprite; break;
                case SelectionState.Selected: tint = m_Colors.selectedColor; sprite = m_SpriteState.selectedSprite; break;
                case SelectionState.Disabled: tint = m_Colors.disabledColor; sprite = m_SpriteState.disabledSprite; break;
                default: tint = m_Colors.normalColor; sprite = null; break;
            }
            switch (m_Transition)
            {
                case Transition.ColorTint: StartColorTween(tint * m_Colors.colorMultiplier, instant); break;
                case Transition.SpriteSwap: DoSpriteSwap(sprite); break;
                case Transition.Animation:
                    {
                        var a = animator; if (a == null || !a.isActiveAndEnabled) break;
                        string trig = state switch { SelectionState.Highlighted => m_AnimationTriggers.highlightedTrigger, SelectionState.Pressed => m_AnimationTriggers.pressedTrigger, SelectionState.Selected => m_AnimationTriggers.selectedTrigger, SelectionState.Disabled => m_AnimationTriggers.disabledTrigger, _ => m_AnimationTriggers.normalTrigger };
                        try { a.SetTrigger(trig); } catch { }
                        break;
                    }
            }
        }
        void StartColorTween(Color targetColor, bool instant) { if (m_TargetGraphic != null) m_TargetGraphic.CrossFadeColor(targetColor, instant ? 0f : m_Colors.fadeDuration, true, true); }
        void DoSpriteSwap(Sprite newSprite) { if (image != null) image.overrideSprite = newSprite; }

        // navigation
        public Selectable FindSelectable(Vector3 dir)
        {
            dir = dir.normalized;
            var localDir = Quaternion.Inverse(transform.rotation) * dir;
            var pos = transform.TransformPoint(GetPointOnRectEdge(transform as RectTransform, localDir));
            float maxScore = Mathf.NegativeInfinity; Selectable best = null;
            foreach (var sel in s_All)
            {
                if (sel == this || !sel.IsInteractable() || sel.navigation.mode == Navigation.Mode.None) continue;
                var selRect = sel.transform as RectTransform;
                var center = selRect != null ? (Vector3)selRect.rect.center : Vector3.zero;
                var myVector = sel.transform.TransformPoint(center) - pos;
                float dot = Vector3.Dot(dir, myVector);
                if (dot <= 0) continue;
                float score = dot / myVector.sqrMagnitude;
                if (score > maxScore) { maxScore = score; best = sel; }
            }
            return best;
        }
        static Vector3 GetPointOnRectEdge(RectTransform rect, Vector2 dir)
        {
            if (rect == null) return Vector3.zero;
            if (dir != Vector2.zero) dir /= Mathf.Max(Mathf.Abs(dir.x), Mathf.Abs(dir.y));
            dir = rect.rect.center + Vector2.Scale(rect.rect.size, dir * 0.5f);
            return dir;
        }
        void Navigate(AxisEventData eventData, Selectable sel) { if (sel != null && sel.IsActive()) eventData.selectedObject = sel.gameObject; }
        public virtual Selectable FindSelectableOnLeft() => m_Navigation.mode == Navigation.Mode.Explicit ? m_Navigation.selectOnLeft : (m_Navigation.mode & Navigation.Mode.Horizontal) != 0 ? FindSelectable(transform.rotation * Vector3.left) : null;
        public virtual Selectable FindSelectableOnRight() => m_Navigation.mode == Navigation.Mode.Explicit ? m_Navigation.selectOnRight : (m_Navigation.mode & Navigation.Mode.Horizontal) != 0 ? FindSelectable(transform.rotation * Vector3.right) : null;
        public virtual Selectable FindSelectableOnUp() => m_Navigation.mode == Navigation.Mode.Explicit ? m_Navigation.selectOnUp : (m_Navigation.mode & Navigation.Mode.Vertical) != 0 ? FindSelectable(transform.rotation * Vector3.up) : null;
        public virtual Selectable FindSelectableOnDown() => m_Navigation.mode == Navigation.Mode.Explicit ? m_Navigation.selectOnDown : (m_Navigation.mode & Navigation.Mode.Vertical) != 0 ? FindSelectable(transform.rotation * Vector3.down) : null;
        public virtual void OnMove(AxisEventData eventData)
        {
            switch (eventData.moveDir)
            {
                case MoveDirection.Right: Navigate(eventData, FindSelectableOnRight()); break;
                case MoveDirection.Up: Navigate(eventData, FindSelectableOnUp()); break;
                case MoveDirection.Left: Navigate(eventData, FindSelectableOnLeft()); break;
                case MoveDirection.Down: Navigate(eventData, FindSelectableOnDown()); break;
            }
        }
        protected bool IsHighlighted() => IsActive() && IsInteractable() && isPointerInside && !isPointerDown && !hasSelection;
        protected bool IsPressed() => IsActive() && IsInteractable() && isPointerDown;
        void EvaluateAndTransitionToSelectionState() { if (IsActive() && IsInteractable()) DoStateTransition(currentSelectionState, false); }
        public virtual void OnPointerDown(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left) return;
            if (IsInteractable() && navigation.mode != Navigation.Mode.None && EventSystem.current != null) EventSystem.current.SetSelectedGameObject(gameObject, eventData);
            isPointerDown = true; EvaluateAndTransitionToSelectionState();
        }
        public virtual void OnPointerUp(PointerEventData eventData) { if (eventData.button != PointerEventData.InputButton.Left) return; isPointerDown = false; EvaluateAndTransitionToSelectionState(); }
        public virtual void OnPointerEnter(PointerEventData eventData) { isPointerInside = true; EvaluateAndTransitionToSelectionState(); }
        public virtual void OnPointerExit(PointerEventData eventData) { isPointerInside = false; EvaluateAndTransitionToSelectionState(); }
        public virtual void OnSelect(BaseEventData eventData) { hasSelection = true; EvaluateAndTransitionToSelectionState(); }
        public virtual void OnDeselect(BaseEventData eventData) { hasSelection = false; EvaluateAndTransitionToSelectionState(); }
        public virtual void Select()
        {
            if (EventSystem.current == null || EventSystem.current.alreadySelecting) return;
            EventSystem.current.SetSelectedGameObject(gameObject);
        }
    }

    [AddComponentMenu("UI/Button", 30)]
    public class Button : Selectable, IPointerClickHandler, ISubmitHandler
    {
        [Serializable] public class ButtonClickedEvent : UnityEvent { }
        [SerializeField] ButtonClickedEvent m_OnClick = new ButtonClickedEvent();
        protected Button() { }
        public ButtonClickedEvent onClick { get => m_OnClick; set => m_OnClick = value; }
        void Press() { if (!IsActive() || !IsInteractable()) return; m_OnClick.Invoke(); }
        public virtual void OnPointerClick(PointerEventData eventData) { if (eventData.button != PointerEventData.InputButton.Left) return; Press(); }
        public virtual void OnSubmit(BaseEventData eventData)
        {
            Press();
            if (!IsActive() || !IsInteractable()) return;
            DoStateTransition(SelectionState.Pressed, false);
            StartCoroutine(OnFinishSubmit());
        }
        System.Collections.IEnumerator OnFinishSubmit()
        {
            float fade = colors.fadeDuration, elapsed = 0f;
            while (elapsed < fade) { elapsed += Time.unscaledDeltaTime; yield return null; }
            DoStateTransition(currentSelectionState, false);
        }
    }

    [AddComponentMenu("UI/Toggle", 31)]
    [RequireComponent(typeof(RectTransform))]
    public class Toggle : Selectable, IPointerClickHandler, ISubmitHandler, ICanvasElement
    {
        public enum ToggleTransition { None = 0, Fade = 1 }
        [Serializable] public class ToggleEvent : UnityEvent<bool> { }
        public ToggleTransition toggleTransition = ToggleTransition.Fade;
        public Graphic graphic;
        [SerializeField] ToggleGroup m_Group;
        public ToggleEvent onValueChanged = new ToggleEvent();
        [SerializeField] bool m_IsOn;
        protected Toggle() { }
        public ToggleGroup group
        {
            get => m_Group;
            set { SetToggleGroup(value, true); PlayEffect(true); }
        }
        public bool isOn { get => m_IsOn; set => Set(value); }
        public void SetIsOnWithoutNotify(bool value) => Set(value, false);
        public virtual void Rebuild(CanvasUpdate executing) { }
        public virtual void LayoutComplete() { }
        public virtual void GraphicUpdateComplete() { }
        protected override void OnEnable() { base.OnEnable(); SetToggleGroup(m_Group, false); PlayEffect(true); }
        protected override void OnDisable() { SetToggleGroup(null, false); base.OnDisable(); }
        protected override void Start() { PlayEffect(true); }
        public override void UIRefresh() { base.UIRefresh(); PlayEffect(true); }
        protected override void OnDidApplyAnimationProperties() { PlayEffect(true); }
        void SetToggleGroup(ToggleGroup newGroup, bool setMemberValue)
        {
            if (m_Group != null) m_Group.UnregisterToggle(this);
            if (setMemberValue) m_Group = newGroup;
            if (newGroup != null && IsActive()) newGroup.RegisterToggle(this);
            if (newGroup != null && isOn && IsActive()) newGroup.NotifyToggleOn(this);
        }
        void Set(bool value, bool sendCallback = true)
        {
            if (m_IsOn == value) return;
            m_IsOn = value;
            if (m_Group != null && m_Group.isActiveAndEnabled && IsActive())
            {
                if (m_IsOn || (!m_Group.AnyTogglesOn() && !m_Group.allowSwitchOff)) { m_IsOn = true; m_Group.NotifyToggleOn(this, sendCallback); }
            }
            PlayEffect(toggleTransition == ToggleTransition.None);
            if (sendCallback) onValueChanged.Invoke(m_IsOn);
        }
        void PlayEffect(bool instant)
        {
            if (graphic == null) return;
            graphic.CrossFadeAlpha(m_IsOn ? 1f : 0f, instant ? 0f : 0.1f, true);
        }
        void InternalToggle() { if (!IsActive() || !IsInteractable()) return; isOn = !isOn; }
        public virtual void OnPointerClick(PointerEventData eventData) { if (eventData.button != PointerEventData.InputButton.Left) return; InternalToggle(); }
        public virtual void OnSubmit(BaseEventData eventData) => InternalToggle();
    }

    [AddComponentMenu("UI/Toggle Group", 32)]
    [DisallowMultipleComponent]
    public class ToggleGroup : UIBehaviour
    {
        [SerializeField] bool m_AllowSwitchOff;
        protected List<Toggle> m_Toggles = new List<Toggle>();
        public bool allowSwitchOff { get => m_AllowSwitchOff; set => m_AllowSwitchOff = value; }
        protected ToggleGroup() { }
        protected override void Start() { EnsureValidState(); base.Start(); }
        protected override void OnEnable() { EnsureValidState(); base.OnEnable(); }
        void ValidateToggleIsInGroup(Toggle toggle) { if (toggle == null || !m_Toggles.Contains(toggle)) throw new ArgumentException(string.Format("Toggle {0} is not part of ToggleGroup {1}", toggle, this)); }
        public void NotifyToggleOn(Toggle toggle, bool sendCallback = true)
        {
            ValidateToggleIsInGroup(toggle);
            foreach (var t in m_Toggles.ToArray()) { if (t == toggle) continue; if (sendCallback) t.isOn = false; else t.SetIsOnWithoutNotify(false); }
        }
        public void UnregisterToggle(Toggle toggle) { m_Toggles.Remove(toggle); }
        public void RegisterToggle(Toggle toggle) { if (!m_Toggles.Contains(toggle)) m_Toggles.Add(toggle); }
        public void EnsureValidState()
        {
            if (!allowSwitchOff && !AnyTogglesOn() && m_Toggles.Count != 0) { m_Toggles[0].isOn = true; NotifyToggleOn(m_Toggles[0]); }
            var active = ActiveToggles().ToList();
            if (active.Count > 1) { var first = GetFirstActiveToggle(); foreach (var t in active) if (t != first) t.isOn = false; }
        }
        public bool AnyTogglesOn() => m_Toggles.Find(x => x.isOn) != null;
        public IEnumerable<Toggle> ActiveToggles() => m_Toggles.Where(x => x.isOn);
        public Toggle GetFirstActiveToggle() => ActiveToggles().FirstOrDefault();
        public void SetAllTogglesOff(bool sendCallback = true)
        {
            bool old = m_AllowSwitchOff; m_AllowSwitchOff = true;
            foreach (var t in m_Toggles.ToArray()) { if (sendCallback) t.isOn = false; else t.SetIsOnWithoutNotify(false); }
            m_AllowSwitchOff = old;
        }
    }

    [AddComponentMenu("UI/Slider", 34)]
    [ExecuteAlways]
    [RequireComponent(typeof(RectTransform))]
    public class Slider : Selectable, IDragHandler, IInitializePotentialDragHandler, ICanvasElement
    {
        public enum Direction { LeftToRight = 0, RightToLeft = 1, BottomToTop = 2, TopToBottom = 3 }
        [Serializable] public class SliderEvent : UnityEvent<float> { }
        [SerializeField] RectTransform m_FillRect, m_HandleRect;
        [SerializeField] Direction m_Direction = Direction.LeftToRight;
        [SerializeField] float m_MinValue = 0, m_MaxValue = 1;
        [SerializeField] bool m_WholeNumbers;
        [SerializeField] protected float m_Value;
        [SerializeField] SliderEvent m_OnValueChanged = new SliderEvent();
        Vector2 m_Offset = Vector2.zero;
        protected Slider() { }
        public RectTransform fillRect { get => m_FillRect; set { m_FillRect = value; UpdateVisuals(); } }
        public RectTransform handleRect { get => m_HandleRect; set { m_HandleRect = value; UpdateVisuals(); } }
        public Direction direction { get => m_Direction; set { m_Direction = value; UpdateVisuals(); } }
        public float minValue { get => m_MinValue; set { m_MinValue = value; Set(m_Value); UpdateVisuals(); } }
        public float maxValue { get => m_MaxValue; set { m_MaxValue = value; Set(m_Value); UpdateVisuals(); } }
        public bool wholeNumbers { get => m_WholeNumbers; set { m_WholeNumbers = value; Set(m_Value); UpdateVisuals(); } }
        public virtual float value { get => m_WholeNumbers ? Mathf.Round(m_Value) : m_Value; set => Set(value); }
        public virtual void SetValueWithoutNotify(float input) => Set(input, false);
        public float normalizedValue
        {
            get => Mathf.Approximately(minValue, maxValue) ? 0 : Mathf.InverseLerp(minValue, maxValue, value);
            set => this.value = Mathf.Lerp(minValue, maxValue, value);
        }
        public SliderEvent onValueChanged { get => m_OnValueChanged; set => m_OnValueChanged = value; }
        protected virtual float stepSize => wholeNumbers ? 1 : (maxValue - minValue) * 0.1f;
        public virtual void Rebuild(CanvasUpdate executing) { }
        public virtual void LayoutComplete() { }
        public virtual void GraphicUpdateComplete() { }
        protected override void OnEnable() { base.OnEnable(); Set(m_Value, false); UpdateVisuals(); }
        public override void UIRefresh() { base.UIRefresh(); UpdateVisuals(); }
        protected override void OnRectTransformDimensionsChange() { UpdateVisuals(); }
        float ClampValue(float input) { float v = Mathf.Clamp(input, minValue, maxValue); if (wholeNumbers) v = Mathf.Round(v); return v; }
        protected virtual void Set(float input, bool sendCallback = true)
        {
            float v = ClampValue(input);
            if (m_Value == v) return;
            m_Value = v;
            UpdateVisuals();
            if (sendCallback) m_OnValueChanged.Invoke(v);
        }
        int axis => (m_Direction == Direction.LeftToRight || m_Direction == Direction.RightToLeft) ? 0 : 1;
        bool reverseValue => m_Direction == Direction.RightToLeft || m_Direction == Direction.TopToBottom;
        void UpdateVisuals()
        {
            if (m_FillRect != null)
            {
                var fillImage = m_FillRect.GetComponent<Image>();
                Vector2 anchorMin = Vector2.zero, anchorMax = Vector2.one;
                if (fillImage != null && fillImage.type == Image.Type.Filled) fillImage.fillAmount = normalizedValue;
                else if (reverseValue) anchorMin[axis] = 1 - normalizedValue;
                else anchorMax[axis] = normalizedValue;
                m_FillRect.anchorMin = anchorMin; m_FillRect.anchorMax = anchorMax;
            }
            if (m_HandleRect != null)
            {
                Vector2 anchorMin = Vector2.zero, anchorMax = Vector2.one;
                anchorMin[axis] = anchorMax[axis] = reverseValue ? (1 - normalizedValue) : normalizedValue;
                m_HandleRect.anchorMin = anchorMin; m_HandleRect.anchorMax = anchorMax;
            }
        }
        RectTransform ClickRect => m_HandleRect != null && m_HandleRect.parent is RectTransform hp ? hp : (m_FillRect != null && m_FillRect.parent is RectTransform fp ? fp : null);
        void UpdateDrag(PointerEventData eventData, Camera cam)
        {
            var clickRect = ClickRect;
            if (clickRect == null || clickRect.rect.size[axis] <= 0) return;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(clickRect, eventData.position, cam, out var localCursor)) return;
            localCursor -= clickRect.rect.position;
            float val = Mathf.Clamp01((localCursor - m_Offset)[axis] / clickRect.rect.size[axis]);
            normalizedValue = reverseValue ? 1f - val : val;
        }
        bool MayDrag(PointerEventData eventData) => IsActive() && IsInteractable() && eventData.button == PointerEventData.InputButton.Left;
        public override void OnPointerDown(PointerEventData eventData)
        {
            if (!MayDrag(eventData)) return;
            base.OnPointerDown(eventData);
            m_Offset = Vector2.zero;
            var cam = UIRuntime.CameraFor(transform as RectTransform);
            if (m_HandleRect != null && RectTransformUtility.RectangleContainsScreenPoint(m_HandleRect, eventData.position, cam))
            {
                if (RectTransformUtility.ScreenPointToLocalPointInRectangle(m_HandleRect, eventData.position, cam, out var localMousePos)) m_Offset = localMousePos;
            }
            else UpdateDrag(eventData, cam);
        }
        public virtual void OnDrag(PointerEventData eventData) { if (!MayDrag(eventData)) return; UpdateDrag(eventData, UIRuntime.CameraFor(transform as RectTransform)); }
        public override void OnMove(AxisEventData eventData)
        {
            if (!IsActive() || !IsInteractable()) { base.OnMove(eventData); return; }
            switch (eventData.moveDir)
            {
                case MoveDirection.Left: if (axis == 0 && FindSelectableOnLeft() == null) Set(reverseValue ? value + stepSize : value - stepSize); else base.OnMove(eventData); break;
                case MoveDirection.Right: if (axis == 0 && FindSelectableOnRight() == null) Set(reverseValue ? value - stepSize : value + stepSize); else base.OnMove(eventData); break;
                case MoveDirection.Up: if (axis == 1 && FindSelectableOnUp() == null) Set(reverseValue ? value - stepSize : value + stepSize); else base.OnMove(eventData); break;
                case MoveDirection.Down: if (axis == 1 && FindSelectableOnDown() == null) Set(reverseValue ? value + stepSize : value - stepSize); else base.OnMove(eventData); break;
            }
        }
        public override Selectable FindSelectableOnLeft() => navigation.mode == Navigation.Mode.Automatic && axis == 0 ? null : base.FindSelectableOnLeft();
        public override Selectable FindSelectableOnRight() => navigation.mode == Navigation.Mode.Automatic && axis == 0 ? null : base.FindSelectableOnRight();
        public override Selectable FindSelectableOnUp() => navigation.mode == Navigation.Mode.Automatic && axis == 1 ? null : base.FindSelectableOnUp();
        public override Selectable FindSelectableOnDown() => navigation.mode == Navigation.Mode.Automatic && axis == 1 ? null : base.FindSelectableOnDown();
        public virtual void OnInitializePotentialDrag(PointerEventData eventData) { eventData.useDragThreshold = false; }
        public void SetDirection(Direction direction, bool includeRectLayouts)
        {
            int oldAxis = axis; bool oldReverse = reverseValue;
            this.direction = direction;
            if (!includeRectLayouts) return;
            if (axis != oldAxis) RectTransformUtility.FlipLayoutAxes(transform as RectTransform, true, true);
            if (reverseValue != oldReverse) RectTransformUtility.FlipLayoutOnAxis(transform as RectTransform, axis, true, true);
        }
    }

    [AddComponentMenu("UI/Scrollbar", 36)]
    [ExecuteAlways]
    [RequireComponent(typeof(RectTransform))]
    public class Scrollbar : Selectable, IBeginDragHandler, IDragHandler, IInitializePotentialDragHandler, ICanvasElement
    {
        public enum Direction { LeftToRight = 0, RightToLeft = 1, BottomToTop = 2, TopToBottom = 3 }
        [Serializable] public class ScrollEvent : UnityEvent<float> { }
        [SerializeField] RectTransform m_HandleRect;
        [SerializeField] Direction m_Direction = Direction.LeftToRight;
        [Range(0f, 1f)] [SerializeField] float m_Value;
        [Range(0f, 1f)] [SerializeField] float m_Size = 0.2f;
        [Range(0, 11)] [SerializeField] int m_NumberOfSteps;
        [SerializeField] ScrollEvent m_OnValueChanged = new ScrollEvent();
        Vector2 m_Offset;
        protected Scrollbar() { }
        public RectTransform handleRect { get => m_HandleRect; set { m_HandleRect = value; UpdateVisuals(); } }
        public Direction direction { get => m_Direction; set { m_Direction = value; UpdateVisuals(); } }
        public float value { get { float v = m_Value; if (m_NumberOfSteps > 1) v = Mathf.Round(v * (m_NumberOfSteps - 1)) / (m_NumberOfSteps - 1); return v; } set => Set(value); }
        public virtual void SetValueWithoutNotify(float input) => Set(input, false);
        public float size { get => m_Size; set { m_Size = Mathf.Clamp01(value); UpdateVisuals(); } }
        public int numberOfSteps { get => m_NumberOfSteps; set { m_NumberOfSteps = value; Set(m_Value); UpdateVisuals(); } }
        public ScrollEvent onValueChanged { get => m_OnValueChanged; set => m_OnValueChanged = value; }
        float stepSize => m_NumberOfSteps > 1 ? 1f / (m_NumberOfSteps - 1) : 0.1f;
        public virtual void Rebuild(CanvasUpdate executing) { }
        public virtual void LayoutComplete() { }
        public virtual void GraphicUpdateComplete() { }
        protected override void OnEnable() { base.OnEnable(); Set(m_Value, false); UpdateVisuals(); }
        public override void UIRefresh() { base.UIRefresh(); UpdateVisuals(); }
        void Set(float input, bool sendCallback = true)
        {
            float old = m_Value; m_Value = Mathf.Clamp01(input);
            if (old == value) return;
            UpdateVisuals();
            if (sendCallback) m_OnValueChanged.Invoke(value);
        }
        int axis => (m_Direction == Direction.LeftToRight || m_Direction == Direction.RightToLeft) ? 0 : 1;
        bool reverseValue => m_Direction == Direction.RightToLeft || m_Direction == Direction.TopToBottom;
        void UpdateVisuals()
        {
            if (m_HandleRect == null) return;
            Vector2 anchorMin = Vector2.zero, anchorMax = Vector2.one;
            float movement = Mathf.Clamp01(value) * (1 - size);
            if (reverseValue) { anchorMin[axis] = 1 - movement - size; anchorMax[axis] = 1 - movement; }
            else { anchorMin[axis] = movement; anchorMax[axis] = movement + size; }
            m_HandleRect.anchorMin = anchorMin; m_HandleRect.anchorMax = anchorMax;
        }
        RectTransform Container => m_HandleRect != null ? m_HandleRect.parent as RectTransform : null;
        void UpdateDrag(PointerEventData eventData)
        {
            var c = Container; if (c == null) return;
            var cam = UIRuntime.CameraFor(c);
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(c, eventData.position, cam, out var local)) return;
            var handleCorner = local - m_Offset - c.rect.position - (m_HandleRect.rect.size - m_HandleRect.sizeDelta) * 0.5f;
            float parentSize = axis == 0 ? c.rect.width : c.rect.height;
            float remaining = parentSize * (1 - size);
            if (remaining <= 0) return;
            float v = (axis == 0 ? handleCorner.x : handleCorner.y) / remaining;
            Set(reverseValue ? 1f - v : v);
        }
        bool MayDrag(PointerEventData e) => IsActive() && IsInteractable() && e.button == PointerEventData.InputButton.Left;
        public virtual void OnBeginDrag(PointerEventData eventData)
        {
            if (!MayDrag(eventData) || Container == null) return;
            m_Offset = Vector2.zero;
            var cam = UIRuntime.CameraFor(m_HandleRect);
            if (RectTransformUtility.RectangleContainsScreenPoint(m_HandleRect, eventData.position, cam) && RectTransformUtility.ScreenPointToLocalPointInRectangle(m_HandleRect, eventData.position, cam, out var lp)) m_Offset = lp - m_HandleRect.rect.center;
        }
        public virtual void OnDrag(PointerEventData eventData) { if (MayDrag(eventData) && Container != null) UpdateDrag(eventData); }
        public override void OnPointerDown(PointerEventData eventData)
        {
            if (!MayDrag(eventData)) return;
            base.OnPointerDown(eventData);
            var cam = UIRuntime.CameraFor(m_HandleRect);
            if (m_HandleRect != null && !RectTransformUtility.RectangleContainsScreenPoint(m_HandleRect, eventData.position, cam))
            {
                // clicking the track jumps a page towards the click
                if (RectTransformUtility.ScreenPointToLocalPointInRectangle(m_HandleRect, eventData.position, cam, out var lp))
                {
                    float d = axis == 0 ? lp.x - m_HandleRect.rect.center.x : lp.y - m_HandleRect.rect.center.y;
                    float change = Mathf.Sign(d) * Mathf.Max(size, 0.1f);
                    Set(reverseValue ? value - change : value + change);
                }
            }
        }
        public virtual void OnInitializePotentialDrag(PointerEventData eventData) { eventData.useDragThreshold = false; }
        public override void OnMove(AxisEventData eventData)
        {
            if (!IsActive() || !IsInteractable()) { base.OnMove(eventData); return; }
            switch (eventData.moveDir)
            {
                case MoveDirection.Left: if (axis == 0) Set(reverseValue ? value + stepSize : value - stepSize); else base.OnMove(eventData); break;
                case MoveDirection.Right: if (axis == 0) Set(reverseValue ? value - stepSize : value + stepSize); else base.OnMove(eventData); break;
                case MoveDirection.Up: if (axis == 1) Set(reverseValue ? value - stepSize : value + stepSize); else base.OnMove(eventData); break;
                case MoveDirection.Down: if (axis == 1) Set(reverseValue ? value + stepSize : value - stepSize); else base.OnMove(eventData); break;
            }
        }
        public void SetDirection(Direction direction, bool includeRectLayouts) { this.direction = direction; }
    }

    [AddComponentMenu("UI/Scroll Rect", 37)]
    [SelectionBase]
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [RequireComponent(typeof(RectTransform))]
    public class ScrollRect : UIBehaviour, IInitializePotentialDragHandler, IBeginDragHandler, IEndDragHandler, IDragHandler, IScrollHandler, ICanvasElement, ILayoutElement, ILayoutGroup
    {
        public enum MovementType { Unrestricted = 0, Elastic = 1, Clamped = 2 }
        public enum ScrollbarVisibility { Permanent = 0, AutoHide = 1, AutoHideAndExpandViewport = 2 }
        [Serializable] public class ScrollRectEvent : UnityEvent<Vector2> { }
        [SerializeField] RectTransform m_Content;
        [SerializeField] bool m_Horizontal = true, m_Vertical = true;
        [SerializeField] MovementType m_MovementType = MovementType.Elastic;
        [SerializeField] float m_Elasticity = 0.1f;
        [SerializeField] bool m_Inertia = true;
        [SerializeField] float m_DecelerationRate = 0.135f, m_ScrollSensitivity = 1.0f;
        [SerializeField] RectTransform m_Viewport;
        [SerializeField] Scrollbar m_HorizontalScrollbar, m_VerticalScrollbar;
        [SerializeField] ScrollbarVisibility m_HorizontalScrollbarVisibility, m_VerticalScrollbarVisibility;
        [SerializeField] float m_HorizontalScrollbarSpacing, m_VerticalScrollbarSpacing;
        [SerializeField] ScrollRectEvent m_OnValueChanged = new ScrollRectEvent();
        Vector2 m_PointerStartLocalCursor, m_ContentStartPosition, m_Velocity, m_PrevPosition;
        bool m_Dragging, m_Scrolling;
        public RectTransform content { get => m_Content; set => m_Content = value; }
        public bool horizontal { get => m_Horizontal; set => m_Horizontal = value; }
        public bool vertical { get => m_Vertical; set => m_Vertical = value; }
        public MovementType movementType { get => m_MovementType; set => m_MovementType = value; }
        public float elasticity { get => m_Elasticity; set => m_Elasticity = value; }
        public bool inertia { get => m_Inertia; set => m_Inertia = value; }
        public float decelerationRate { get => m_DecelerationRate; set => m_DecelerationRate = value; }
        public float scrollSensitivity { get => m_ScrollSensitivity; set => m_ScrollSensitivity = value; }
        public RectTransform viewport { get => m_Viewport; set => m_Viewport = value; }
        public Scrollbar horizontalScrollbar { get => m_HorizontalScrollbar; set { if (m_HorizontalScrollbar) m_HorizontalScrollbar.onValueChanged.RemoveListener(SetHorizontalNormalizedPosition); m_HorizontalScrollbar = value; if (m_HorizontalScrollbar && isActiveAndEnabled) m_HorizontalScrollbar.onValueChanged.AddListener(SetHorizontalNormalizedPosition); } }
        public Scrollbar verticalScrollbar { get => m_VerticalScrollbar; set { if (m_VerticalScrollbar) m_VerticalScrollbar.onValueChanged.RemoveListener(SetVerticalNormalizedPosition); m_VerticalScrollbar = value; if (m_VerticalScrollbar && isActiveAndEnabled) m_VerticalScrollbar.onValueChanged.AddListener(SetVerticalNormalizedPosition); } }
        public ScrollbarVisibility horizontalScrollbarVisibility { get => m_HorizontalScrollbarVisibility; set => m_HorizontalScrollbarVisibility = value; }
        public ScrollbarVisibility verticalScrollbarVisibility { get => m_VerticalScrollbarVisibility; set => m_VerticalScrollbarVisibility = value; }
        public float horizontalScrollbarSpacing { get => m_HorizontalScrollbarSpacing; set => m_HorizontalScrollbarSpacing = value; }
        public float verticalScrollbarSpacing { get => m_VerticalScrollbarSpacing; set => m_VerticalScrollbarSpacing = value; }
        public ScrollRectEvent onValueChanged { get => m_OnValueChanged; set => m_OnValueChanged = value; }
        protected RectTransform viewRect => m_Viewport != null ? m_Viewport : (RectTransform)transform;
        protected Bounds m_ContentBounds, m_ViewBounds;
        public Vector2 velocity { get => m_Velocity; set => m_Velocity = value; }
        protected ScrollRect() { }
        public virtual void Rebuild(CanvasUpdate executing) { }
        public virtual void LayoutComplete() { }
        public virtual void GraphicUpdateComplete() { }
        public virtual void CalculateLayoutInputHorizontal() { }
        public virtual void CalculateLayoutInputVertical() { }
        public virtual float minWidth => -1; public virtual float preferredWidth => -1; public virtual float flexibleWidth => -1;
        public virtual float minHeight => -1; public virtual float preferredHeight => -1; public virtual float flexibleHeight => -1;
        public virtual int layoutPriority => -1;
        public virtual void SetLayoutHorizontal() { }
        public virtual void SetLayoutVertical() { }
        protected override void OnEnable()
        {
            if (m_HorizontalScrollbar) m_HorizontalScrollbar.onValueChanged.AddListener(SetHorizontalNormalizedPosition);
            if (m_VerticalScrollbar) m_VerticalScrollbar.onValueChanged.AddListener(SetVerticalNormalizedPosition);
        }
        protected override void OnDisable()
        {
            if (m_HorizontalScrollbar) m_HorizontalScrollbar.onValueChanged.RemoveListener(SetHorizontalNormalizedPosition);
            if (m_VerticalScrollbar) m_VerticalScrollbar.onValueChanged.RemoveListener(SetVerticalNormalizedPosition);
            m_Dragging = false; m_Scrolling = false; m_Velocity = Vector2.zero;
        }
        public override bool IsActive() => base.IsActive() && m_Content != null;
        public virtual void StopMovement() { m_Velocity = Vector2.zero; }
        public virtual void OnScroll(PointerEventData data)
        {
            if (!IsActive()) return;
            UpdateBounds();
            var delta = data.scrollDelta; delta.y *= -1;
            if (vertical && !horizontal) { if (Mathf.Abs(delta.x) > Mathf.Abs(delta.y)) delta.y = delta.x; delta.x = 0; }
            if (horizontal && !vertical) { if (Mathf.Abs(delta.y) > Mathf.Abs(delta.x)) delta.x = delta.y; delta.y = 0; }
            if (data.IsScrolling()) m_Scrolling = true;
            var position = m_Content.anchoredPosition;
            position += delta * m_ScrollSensitivity;
            if (m_MovementType == MovementType.Clamped) position += CalculateOffset(position - m_Content.anchoredPosition);
            SetContentAnchoredPosition(position);
            UpdateBounds();
        }
        public virtual void OnInitializePotentialDrag(PointerEventData eventData) { if (eventData.button == PointerEventData.InputButton.Left) m_Velocity = Vector2.zero; }
        public virtual void OnBeginDrag(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left || !IsActive()) return;
            UpdateBounds();
            RectTransformUtility.ScreenPointToLocalPointInRectangle(viewRect, eventData.position, eventData.pressEventCamera, out m_PointerStartLocalCursor);
            m_ContentStartPosition = m_Content.anchoredPosition;
            m_Dragging = true;
        }
        public virtual void OnEndDrag(PointerEventData eventData) { if (eventData.button == PointerEventData.InputButton.Left) m_Dragging = false; }
        public virtual void OnDrag(PointerEventData eventData)
        {
            if (!m_Dragging || eventData.button != PointerEventData.InputButton.Left || !IsActive()) return;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(viewRect, eventData.position, eventData.pressEventCamera, out var localCursor)) return;
            UpdateBounds();
            var pointerDelta = localCursor - m_PointerStartLocalCursor;
            Vector2 position = m_ContentStartPosition + pointerDelta;
            Vector2 offset = CalculateOffset(position - m_Content.anchoredPosition);
            position += offset;
            if (m_MovementType == MovementType.Elastic)
            {
                if (offset.x != 0) position.x = position.x - RubberDelta(offset.x, m_ViewBounds.size.x);
                if (offset.y != 0) position.y = position.y - RubberDelta(offset.y, m_ViewBounds.size.y);
            }
            SetContentAnchoredPosition(position);
        }
        protected virtual void SetContentAnchoredPosition(Vector2 position)
        {
            if (!m_Horizontal) position.x = m_Content.anchoredPosition.x;
            if (!m_Vertical) position.y = m_Content.anchoredPosition.y;
            if (position != m_Content.anchoredPosition) { m_Content.anchoredPosition = position; UpdateBounds(); }
        }
        protected virtual void LateUpdate()
        {
            if (!m_Content) return;
            UpdateBounds();
            float deltaTime = Time.unscaledDeltaTime;
            Vector2 offset = CalculateOffset(Vector2.zero);
            if (deltaTime > 0.0f && !m_Dragging && (offset != Vector2.zero || m_Velocity != Vector2.zero))
            {
                Vector2 position = m_Content.anchoredPosition;
                for (int axis = 0; axis < 2; axis++)
                {
                    if (m_MovementType == MovementType.Elastic && offset[axis] != 0)
                    {
                        float speed = m_Velocity[axis];
                        float smooth = m_Elasticity;
                        if (m_Scrolling) smooth *= 3.0f;
                        position[axis] = Mathf.SmoothDamp(m_Content.anchoredPosition[axis], m_Content.anchoredPosition[axis] + offset[axis], ref speed, smooth, Mathf.Infinity, deltaTime);
                        if (Mathf.Abs(speed) < 1) speed = 0;
                        var v = m_Velocity; v[axis] = speed; m_Velocity = v;
                    }
                    else if (m_Inertia)
                    {
                        var v = m_Velocity; v[axis] *= Mathf.Pow(m_DecelerationRate, deltaTime); if (Mathf.Abs(v[axis]) < 1) v[axis] = 0; m_Velocity = v;
                        position[axis] += m_Velocity[axis] * deltaTime;
                    }
                    else { var v = m_Velocity; v[axis] = 0; m_Velocity = v; }
                }
                if (m_MovementType == MovementType.Clamped) { offset = CalculateOffset(position - m_Content.anchoredPosition); position += offset; }
                SetContentAnchoredPosition(position);
            }
            if (m_Dragging && m_Inertia)
            {
                Vector3 newVelocity = (m_Content.anchoredPosition - m_PrevPosition) / Mathf.Max(deltaTime, 1e-4f);
                m_Velocity = Vector3.Lerp(m_Velocity, newVelocity, deltaTime * 10);
            }
            if (m_ViewBounds != m_PrevViewBounds || m_ContentBounds != m_PrevContentBounds || m_Content.anchoredPosition != m_PrevPosition)
            {
                UpdateScrollbars(offset);
                m_OnValueChanged.Invoke(normalizedPosition);
                m_PrevPosition = m_Content.anchoredPosition; m_PrevViewBounds = m_ViewBounds; m_PrevContentBounds = m_ContentBounds;
            }
            UpdateScrollbarVisibility();
            m_Scrolling = false;
        }
        Bounds m_PrevViewBounds, m_PrevContentBounds;
        void UpdateScrollbars(Vector2 offset)
        {
            if (m_HorizontalScrollbar)
            {
                m_HorizontalScrollbar.size = m_ContentBounds.size.x > 0 ? Mathf.Clamp01((m_ViewBounds.size.x - Mathf.Abs(offset.x)) / m_ContentBounds.size.x) : 1;
                m_HorizontalScrollbar.SetValueWithoutNotify(horizontalNormalizedPosition);
            }
            if (m_VerticalScrollbar)
            {
                m_VerticalScrollbar.size = m_ContentBounds.size.y > 0 ? Mathf.Clamp01((m_ViewBounds.size.y - Mathf.Abs(offset.y)) / m_ContentBounds.size.y) : 1;
                m_VerticalScrollbar.SetValueWithoutNotify(verticalNormalizedPosition);
            }
        }
        void UpdateScrollbarVisibility()
        {
            if (m_VerticalScrollbar && m_VerticalScrollbarVisibility != ScrollbarVisibility.Permanent) { bool need = m_ContentBounds.size.y > m_ViewBounds.size.y + 0.01f; if (m_VerticalScrollbar.gameObject.activeSelf != need) m_VerticalScrollbar.gameObject.SetActive(need); }
            if (m_HorizontalScrollbar && m_HorizontalScrollbarVisibility != ScrollbarVisibility.Permanent) { bool need = m_ContentBounds.size.x > m_ViewBounds.size.x + 0.01f; if (m_HorizontalScrollbar.gameObject.activeSelf != need) m_HorizontalScrollbar.gameObject.SetActive(need); }
        }
        public Vector2 normalizedPosition { get => new Vector2(horizontalNormalizedPosition, verticalNormalizedPosition); set { SetNormalizedPosition(value.x, 0); SetNormalizedPosition(value.y, 1); } }
        public float horizontalNormalizedPosition
        {
            get { UpdateBounds(); if (m_ContentBounds.size.x <= m_ViewBounds.size.x || Mathf.Approximately(m_ContentBounds.size.x, m_ViewBounds.size.x)) return (m_ViewBounds.min.x > m_ContentBounds.min.x) ? 1 : 0; return (m_ViewBounds.min.x - m_ContentBounds.min.x) / (m_ContentBounds.size.x - m_ViewBounds.size.x); }
            set => SetNormalizedPosition(value, 0);
        }
        public float verticalNormalizedPosition
        {
            get { UpdateBounds(); if (m_ContentBounds.size.y <= m_ViewBounds.size.y || Mathf.Approximately(m_ContentBounds.size.y, m_ViewBounds.size.y)) return (m_ViewBounds.min.y > m_ContentBounds.min.y) ? 1 : 0; return (m_ViewBounds.min.y - m_ContentBounds.min.y) / (m_ContentBounds.size.y - m_ViewBounds.size.y); }
            set => SetNormalizedPosition(value, 1);
        }
        void SetHorizontalNormalizedPosition(float value) => SetNormalizedPosition(value, 0);
        void SetVerticalNormalizedPosition(float value) => SetNormalizedPosition(value, 1);
        protected virtual void SetNormalizedPosition(float value, int axis)
        {
            if (m_Content == null) return;
            UpdateBounds();
            float hiddenLength = m_ContentBounds.size[axis] - m_ViewBounds.size[axis];
            float contentBoundsMinPosition = m_ViewBounds.min[axis] - value * hiddenLength;
            float newAnchoredPosition = m_Content.anchoredPosition[axis] + contentBoundsMinPosition - m_ContentBounds.min[axis];
            var anchoredPosition = m_Content.anchoredPosition;
            if (Mathf.Abs(anchoredPosition[axis] - newAnchoredPosition) > 0.01f)
            {
                anchoredPosition[axis] = newAnchoredPosition;
                m_Content.anchoredPosition = anchoredPosition;
                m_Velocity[axis] = 0;
                UpdateBounds();
            }
        }
        static float RubberDelta(float overStretching, float viewSize) => (1 - (1 / ((Mathf.Abs(overStretching) * 0.55f / viewSize) + 1))) * viewSize * Mathf.Sign(overStretching);
        protected void UpdateBounds()
        {
            if (m_Content == null) return;
            var vr = viewRect; vr.SyncUp(); m_Content.SyncUp();
            m_ViewBounds = new Bounds(vr.rect.center, vr.rect.size);
            var corners = new Vector3[4]; m_Content.GetWorldCorners(corners);
            var toLocal = vr.worldToLocalMatrix;
            var min = new Vector3(float.MaxValue, float.MaxValue, float.MaxValue); var max = -min;
            for (int i = 0; i < 4; i++) { var p = toLocal.MultiplyPoint3x4(corners[i]); min = Vector3.Min(min, p); max = Vector3.Max(max, p); }
            var b = new Bounds(min, Vector3.zero); b.Encapsulate(max);
            // content smaller than the view: pad it so it can't move (like Unity)
            var contentSize = b.size; var contentPos = b.center; var contentPivot = m_Content.pivot;
            var excess = m_ViewBounds.size - contentSize;
            if (excess.x > 0) { contentPos.x -= excess.x * (contentPivot.x - 0.5f); contentSize.x = m_ViewBounds.size.x; }
            if (excess.y > 0) { contentPos.y -= excess.y * (contentPivot.y - 0.5f); contentSize.y = m_ViewBounds.size.y; }
            b.size = contentSize; b.center = contentPos;
            m_ContentBounds = b;
        }
        protected Vector2 CalculateOffset(Vector2 delta)
        {
            var offset = Vector2.zero;
            if (m_MovementType == MovementType.Unrestricted) return offset;
            Vector2 min = m_ContentBounds.min, max = m_ContentBounds.max;
            if (m_Horizontal)
            {
                min.x += delta.x; max.x += delta.x;
                float maxOffset = m_ViewBounds.max.x - max.x, minOffset = m_ViewBounds.min.x - min.x;
                if (minOffset < -0.001f) offset.x = minOffset; else if (maxOffset > 0.001f) offset.x = maxOffset;
            }
            if (m_Vertical)
            {
                min.y += delta.y; max.y += delta.y;
                float maxOffset = m_ViewBounds.max.y - max.y, minOffset = m_ViewBounds.min.y - min.y;
                if (maxOffset > 0.001f) offset.y = maxOffset; else if (minOffset < -0.001f) offset.y = minOffset;
            }
            return offset;
        }
        protected void SetDirty() { }
        protected void SetDirtyCaching() { }
    }

    // ---------- text input (shared by InputField and TMP_InputField) ----------
    internal sealed class TextEditCore
    {
        internal string text = "";
        internal bool focused;
        internal float caretBlink;
        internal int characterLimit;
        internal int contentType; // 0 standard, 2 int, 3 decimal, 4 alnum, 5 name, 6 email, 7 password, 8 pin
        internal int lineType;    // 0 single, 1 multi submit, 2 multi newline
        internal bool readOnly;
        internal string originalText = "";
        // returns: 0 nothing, 1 changed, 2 submit, 3 cancel
        internal int Process(Func<string, int, char, char> validate, out bool changed)
        {
            changed = false;
            if (!focused || readOnly) return 0;
            int result = 0;
            foreach (char ch in InputState.inputString)
            {
                if (ch == '\b') { if (text.Length > 0) { text = text.Substring(0, text.Length - 1); changed = true; } continue; }
                if (ch == '\n' || ch == '\r')
                {
                    if (lineType == 2) { if (characterLimit <= 0 || text.Length < characterLimit) { text += "\n"; changed = true; } continue; }
                    result = 2; break;
                }
                if (ch < ' ') continue;
                if (characterLimit > 0 && text.Length >= characterLimit) continue;
                char c = validate != null ? validate(text, text.Length, ch) : Validate(text, ch);
                if (c == '\0') continue;
                text += c; changed = true;
            }
            if (result == 0 && InputState.downThisFrame.Contains("Escape")) result = 3;
            return result;
        }
        char Validate(string t, char ch)
        {
            switch (contentType)
            {
                case 2: if (char.IsDigit(ch) || (ch == '-' && t.Length == 0)) return ch; return '\0';
                case 3: if (char.IsDigit(ch) || (ch == '-' && t.Length == 0) || ((ch == '.' || ch == ',') && t.IndexOf('.') < 0 && t.IndexOf(',') < 0)) return ch; return '\0';
                case 4: return char.IsLetterOrDigit(ch) ? ch : '\0';
                case 5: return char.IsLetter(ch) || ch == ' ' || ch == '\'' || ch == '-' ? (t.Length == 0 || t[t.Length - 1] == ' ' ? char.ToUpper(ch) : ch) : '\0';
                case 6: return char.IsLetterOrDigit(ch) || "@.-_+!#$%&'*/=?^`{|}~".IndexOf(ch) >= 0 ? ch : '\0';
                case 8: return char.IsDigit(ch) ? ch : '\0';
                default: return ch;
            }
        }
        internal string Display(bool richCaret)
        {
            string shown = contentType == 7 || contentType == 8 ? new string('*', text.Length) : text;
            if (focused && (Time.realtimeSinceStartup % 1f) < 0.53f) shown += "|";
            return shown;
        }
    }

    [AddComponentMenu("UI/Legacy/Input Field", 103)]
    public class InputField : Selectable, IUpdateSelectedHandler, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerClickHandler, ISubmitHandler, ICancelHandler, ICanvasElement, ILayoutElement
    {
        public enum ContentType { Standard = 0, Autocorrected = 1, IntegerNumber = 2, DecimalNumber = 3, Alphanumeric = 4, Name = 5, EmailAddress = 6, Password = 7, Pin = 8, Custom = 9 }
        public enum InputType { Standard = 0, AutoCorrect = 1, Password = 2 }
        public enum CharacterValidation { None = 0, Integer = 1, Decimal = 2, Alphanumeric = 3, Name = 4, EmailAddress = 5 }
        public enum LineType { SingleLine = 0, MultiLineSubmit = 1, MultiLineNewline = 2 }
        public delegate char OnValidateInput(string text, int charIndex, char addedChar);
        [Serializable] public class SubmitEvent : UnityEvent<string> { }
        [Serializable] public class EndEditEvent : UnityEvent<string> { }
        [Serializable] public class OnChangeEvent : UnityEvent<string> { }
        [SerializeField] protected Text m_TextComponent;
        [SerializeField] protected Graphic m_Placeholder;
        [SerializeField] ContentType m_ContentType = ContentType.Standard;
        [SerializeField] InputType m_InputType = InputType.Standard;
        [SerializeField] char m_AsteriskChar = '*';
        [SerializeField] TouchScreenKeyboardType m_KeyboardType;
        [SerializeField] LineType m_LineType = LineType.SingleLine;
        [SerializeField] bool m_HideMobileInput;
        [SerializeField] CharacterValidation m_CharacterValidation = CharacterValidation.None;
        [SerializeField] int m_CharacterLimit;
        [SerializeField] SubmitEvent m_OnSubmit = new SubmitEvent();
        [SerializeField] EndEditEvent m_OnDidEndEdit = new EndEditEvent();
        [SerializeField] OnChangeEvent m_OnValueChanged = new OnChangeEvent();
        [SerializeField] OnValidateInput m_OnValidateInput;
        [SerializeField] Color m_CaretColor = new Color(50f / 255f, 50f / 255f, 50f / 255f, 1f);
        [SerializeField] bool m_CustomCaretColor;
        [SerializeField] Color m_SelectionColor = new Color(168f / 255f, 206f / 255f, 255f / 255f, 192f / 255f);
        [SerializeField] protected string m_Text = "";
        [Range(0f, 4f)] [SerializeField] float m_CaretBlinkRate = 0.85f;
        [Range(1, 5)] [SerializeField] int m_CaretWidth = 1;
        [SerializeField] bool m_ReadOnly, m_ShouldActivateOnSelect = true;
        internal readonly TextEditCore m_Core = new TextEditCore();
        protected InputField() { }
        public string text { get => m_Text; set => SetText(value, true); }
        public void SetTextWithoutNotify(string input) => SetText(input, false);
        void SetText(string value, bool sendCallback)
        {
            value ??= "";
            if (m_CharacterLimit > 0 && value.Length > m_CharacterLimit) value = value.Substring(0, m_CharacterLimit);
            if (m_Text == value) return;
            m_Text = value; m_Core.text = value;
            UpdateLabel();
            if (sendCallback) m_OnValueChanged.Invoke(m_Text);
        }
        public bool isFocused => m_Core.focused;
        public float caretBlinkRate { get => m_CaretBlinkRate; set => m_CaretBlinkRate = value; }
        public int caretWidth { get => m_CaretWidth; set => m_CaretWidth = value; }
        public Text textComponent { get => m_TextComponent; set { m_TextComponent = value; UpdateLabel(); } }
        public Graphic placeholder { get => m_Placeholder; set { m_Placeholder = value; UpdateLabel(); } }
        public Color caretColor { get => m_CustomCaretColor ? m_CaretColor : (textComponent ? textComponent.color : Color.black); set => m_CaretColor = value; }
        public bool customCaretColor { get => m_CustomCaretColor; set => m_CustomCaretColor = value; }
        public Color selectionColor { get => m_SelectionColor; set => m_SelectionColor = value; }
        public EndEditEvent onEndEdit { get => m_OnDidEndEdit; set => m_OnDidEndEdit = value; }
        public SubmitEvent onSubmit { get => m_OnSubmit; set => m_OnSubmit = value; }
        [Obsolete("onValueChange has been renamed to onValueChanged")] public OnChangeEvent onValueChange { get => onValueChanged; set => onValueChanged = value; }
        public OnChangeEvent onValueChanged { get => m_OnValueChanged; set => m_OnValueChanged = value; }
        public OnValidateInput onValidateInput { get => m_OnValidateInput; set => m_OnValidateInput = value; }
        public int characterLimit { get => m_CharacterLimit; set => m_CharacterLimit = Mathf.Max(0, value); }
        public ContentType contentType { get => m_ContentType; set => m_ContentType = value; }
        public LineType lineType { get => m_LineType; set => m_LineType = value; }
        public InputType inputType { get => m_InputType; set => m_InputType = value; }
        public TouchScreenKeyboard touchScreenKeyboard => null;
        public TouchScreenKeyboardType keyboardType { get => m_KeyboardType; set => m_KeyboardType = value; }
        public CharacterValidation characterValidation { get => m_CharacterValidation; set => m_CharacterValidation = value; }
        public bool readOnly { get => m_ReadOnly; set => m_ReadOnly = value; }
        public bool multiLine => m_LineType != LineType.SingleLine;
        public char asteriskChar { get => m_AsteriskChar; set => m_AsteriskChar = value; }
        public bool wasCanceled { get; private set; }
        public bool shouldHideMobileInput { get => m_HideMobileInput; set => m_HideMobileInput = value; }
        public bool shouldActivateOnSelect { get => m_ShouldActivateOnSelect; set => m_ShouldActivateOnSelect = value; }
        public int caretPosition { get => m_Text.Length; set { } }
        public int anchorPosition { get => m_Text.Length; set { } }
        public int selectionAnchorPosition { get => m_Text.Length; set { } }
        public int selectionFocusPosition { get => m_Text.Length; set { } }
        public virtual void Rebuild(CanvasUpdate update) { }
        public virtual void LayoutComplete() { }
        public virtual void GraphicUpdateComplete() { }
        public virtual void CalculateLayoutInputHorizontal() { }
        public virtual void CalculateLayoutInputVertical() { }
        public virtual float minWidth => 0; public virtual float preferredWidth => m_TextComponent != null ? m_TextComponent.preferredWidth : 0; public virtual float flexibleWidth => -1;
        public virtual float minHeight => 0; public virtual float preferredHeight => m_TextComponent != null ? m_TextComponent.preferredHeight : 0; public virtual float flexibleHeight => -1;
        public virtual int layoutPriority => 1;
        protected override void OnEnable() { base.OnEnable(); m_Core.text = m_Text; UpdateLabel(); }
        protected override void OnDisable() { DeactivateInputField(); base.OnDisable(); }
        public override void UIRefresh() { base.UIRefresh(); m_Core.text = m_Text; UpdateLabel(); }
        public void ActivateInputField() { if (m_TextComponent == null || !IsActive() || !IsInteractable()) return; m_Core.focused = true; m_Core.originalText = m_Text; wasCanceled = false; }
        public void DeactivateInputField()
        {
            if (!m_Core.focused) return;
            m_Core.focused = false; UpdateLabel();
            m_OnDidEndEdit.Invoke(m_Text);
        }
        public void MoveTextEnd(bool shift) { }
        public void MoveTextStart(bool shift) { }
        public void ForceLabelUpdate() => UpdateLabel();
        public override void OnSelect(BaseEventData eventData) { base.OnSelect(eventData); if (shouldActivateOnSelect) ActivateInputField(); }
        public override void OnDeselect(BaseEventData eventData) { DeactivateInputField(); base.OnDeselect(eventData); }
        public virtual void OnPointerClick(PointerEventData eventData) { if (eventData.button == PointerEventData.InputButton.Left) ActivateInputField(); }
        public virtual void OnBeginDrag(PointerEventData eventData) { }
        public virtual void OnDrag(PointerEventData eventData) { }
        public virtual void OnEndDrag(PointerEventData eventData) { }
        public virtual void OnSubmit(BaseEventData eventData) { if (!IsActive() || !IsInteractable()) return; if (!m_Core.focused) ActivateInputField(); }
        public virtual void OnCancel(BaseEventData eventData) { }
        public virtual void OnUpdateSelected(BaseEventData eventData)
        {
            if (!m_Core.focused) return;
            m_Core.characterLimit = m_CharacterLimit; m_Core.contentType = (int)m_ContentType; m_Core.lineType = (int)m_LineType; m_Core.readOnly = m_ReadOnly;
            if (m_CharacterValidation == CharacterValidation.Integer) m_Core.contentType = 2; else if (m_CharacterValidation == CharacterValidation.Decimal) m_Core.contentType = 3;
            var validator = m_OnValidateInput != null ? new Func<string, int, char, char>((t, i, c) => m_OnValidateInput(t, i, c)) : null;
            int r = m_Core.Process(validator, out bool changed);
            if (changed) { m_Text = m_Core.text; m_OnValueChanged.Invoke(m_Text); }
            if (r == 2) { m_OnSubmit.Invoke(m_Text); DeactivateInputField(); EventSystem.current?.SetSelectedGameObject(null); }
            else if (r == 3) { wasCanceled = true; m_Text = m_Core.text = m_Core.originalText; DeactivateInputField(); EventSystem.current?.SetSelectedGameObject(null); }
            UpdateLabel();
            eventData.Use();
        }
        protected void UpdateLabel()
        {
            if (m_TextComponent != null) m_TextComponent.text = m_Core.focused ? m_Core.Display(false) : (m_ContentType == ContentType.Password || m_ContentType == ContentType.Pin ? new string(m_AsteriskChar, m_Text.Length) : m_Text);
            if (m_Placeholder != null) m_Placeholder.enabled = string.IsNullOrEmpty(m_Text);
        }
        protected char Validate(string text, int pos, char ch) => ch;
        public virtual void ProcessEvent(Event e) { }
    }

    [AddComponentMenu("UI/Legacy/Dropdown", 102)]
    [RequireComponent(typeof(RectTransform))]
    public class Dropdown : Selectable, IPointerClickHandler, ISubmitHandler, ICancelHandler, IDropdownPopup
    {
        [Serializable] public class OptionData { [SerializeField] string m_Text; [SerializeField] Sprite m_Image; public string text { get => m_Text; set => m_Text = value; } public Sprite image { get => m_Image; set => m_Image = value; } public OptionData() { } public OptionData(string text) { this.text = text; } public OptionData(Sprite image) { this.image = image; } public OptionData(string text, Sprite image) { this.text = text; this.image = image; } }
        [Serializable] public class OptionDataList { [SerializeField] List<OptionData> m_Options = new List<OptionData>(); public List<OptionData> options { get => m_Options; set => m_Options = value; } }
        [Serializable] public class DropdownEvent : UnityEvent<int> { }
        [SerializeField] RectTransform m_Template;
        [SerializeField] Text m_CaptionText; [SerializeField] Image m_CaptionImage;
        [SerializeField] Text m_ItemText; [SerializeField] Image m_ItemImage;
        [SerializeField] int m_Value;
        [SerializeField] OptionDataList m_Options = new OptionDataList();
        [SerializeField] DropdownEvent m_OnValueChanged = new DropdownEvent();
        [SerializeField] float m_AlphaFadeSpeed = 0.15f;
        protected Dropdown() { }
        public RectTransform template { get => m_Template; set => m_Template = value; }
        public Text captionText { get => m_CaptionText; set { m_CaptionText = value; RefreshShownValue(); } }
        public Image captionImage { get => m_CaptionImage; set { m_CaptionImage = value; RefreshShownValue(); } }
        public Text itemText { get => m_ItemText; set => m_ItemText = value; }
        public Image itemImage { get => m_ItemImage; set => m_ItemImage = value; }
        public List<OptionData> options { get => m_Options.options; set { m_Options.options = value; RefreshShownValue(); } }
        public DropdownEvent onValueChanged { get => m_OnValueChanged; set => m_OnValueChanged = value; }
        public float alphaFadeSpeed { get => m_AlphaFadeSpeed; set => m_AlphaFadeSpeed = value; }
        public int value { get => m_Value; set => Set(value); }
        public void SetValueWithoutNotify(int input) => Set(input, false);
        void Set(int value, bool sendCallback = true)
        {
            if (Application.isPlaying && (value == m_Value || options.Count == 0)) return;
            m_Value = Mathf.Clamp(value, 0, Mathf.Max(0, options.Count - 1));
            RefreshShownValue();
            if (sendCallback) m_OnValueChanged.Invoke(m_Value);
        }
        protected override void Awake() { base.Awake(); if (m_Template) m_Template.gameObject.SetActive(false); }
        protected override void Start() { base.Start(); RefreshShownValue(); }
        public override void UIRefresh() { base.UIRefresh(); if (m_Template) m_Template.gameObject.m_ActiveSelf = false; RefreshShownValue(); }
        public void RefreshShownValue()
        {
            var data = options.Count > 0 && m_Value >= 0 && m_Value < options.Count ? options[m_Value] : new OptionData("");
            if (m_CaptionText) m_CaptionText.text = data.text ?? "";
            if (m_CaptionImage) { m_CaptionImage.sprite = data.image; m_CaptionImage.enabled = m_CaptionImage.sprite != null; }
        }
        public void AddOptions(List<OptionData> options) { this.options.AddRange(options); RefreshShownValue(); }
        public void AddOptions(List<string> options) { foreach (var s in options) this.options.Add(new OptionData(s)); RefreshShownValue(); }
        public void AddOptions(List<Sprite> options) { foreach (var s in options) this.options.Add(new OptionData(s)); RefreshShownValue(); }
        public void ClearOptions() { options.Clear(); m_Value = 0; RefreshShownValue(); }
        public bool IsExpanded => UIRuntime.popupOwner == (IDropdownPopup)this;
        public void Show() { if (!IsActive() || !IsInteractable() || IsExpanded) return; UIRuntime.OpenPopup(this); }
        public void Hide() { if (IsExpanded) UIRuntime.ClosePopup(); }
        public virtual void OnPointerClick(PointerEventData eventData) => Show();
        public virtual void OnSubmit(BaseEventData eventData) => Show();
        public virtual void OnCancel(BaseEventData eventData) => Hide();
        protected virtual GameObject CreateBlocker(Canvas rootCanvas) => null;
        protected virtual void DestroyBlocker(GameObject blocker) { }
        protected virtual GameObject CreateDropdownList(GameObject template) => null;
        protected virtual void DestroyDropdownList(GameObject dropdownList) { }
        // popup support
        int IDropdownPopup.Count => options.Count;
        string IDropdownPopup.Label(int i) => options[i].text;
        int IDropdownPopup.Current => m_Value;
        void IDropdownPopup.Choose(int i) { value = i; }
        RectTransform IDropdownPopup.Rect => (RectTransform)transform;
        Graphic IDropdownPopup.Caption => m_CaptionText;
        RectTransform IDropdownPopup.Template => m_Template;
        Component IDropdownPopup.Owner => this;
    }
    internal interface IDropdownPopup { int Count { get; } string Label(int i); int Current { get; } void Choose(int i); RectTransform Rect { get; } Graphic Caption { get; } RectTransform Template { get; } Component Owner { get; } }
}

namespace UnityEngine
{
    public enum TouchScreenKeyboardType { Default = 0, ASCIICapable = 1, NumbersAndPunctuation = 2, URL = 3, NumberPad = 4, PhonePad = 5, NamePhonePad = 6, EmailAddress = 7, NintendoNetworkAccount = 8, Social = 9, Search = 10, DecimalPad = 11, OneTimeCode = 12 }
    public partial class TouchScreenKeyboard
    {
        public static bool isSupported => false;
        public static bool visible => false;
        public static bool hideInput { get; set; }
        public string text { get; set; } = "";
        public bool active { get; set; }
        public static TouchScreenKeyboard Open(string text, TouchScreenKeyboardType keyboardType = TouchScreenKeyboardType.Default, bool autocorrection = true, bool multiline = false, bool secure = false, bool alert = false, string textPlaceholder = "", int characterLimit = 0) => null;
    }
}
