// Anvil — rendering-side components: Renderer, MeshFilter, Material, Camera, Light, Gizmos, primitives, audio stubs.
using System;
using System.Collections.Generic;
using Anvil;
using UnityEngine.Rendering;

namespace UnityEngine
{
    public enum CameraClearFlags { Skybox = 1, Color = 2, SolidColor = 2, Depth = 3, Nothing = 4 }
    public enum LightType { Spot = 0, Directional = 1, Point = 2, Area = 3, Rectangle = 3, Disc = 4, Pyramid = 5, Box = 6, Tube = 7 }
    public enum LightShadows { None = 0, Hard = 1, Soft = 2 }


    public sealed class Camera : Behaviour
    {
        public float fieldOfView { get; set; } = 60f;
        public float nearClipPlane { get; set; } = 0.3f;
        public float farClipPlane { get; set; } = 1000f;
        public bool orthographic { get; set; }
        public float orthographicSize { get; set; } = 5f;
        public CameraClearFlags clearFlags { get; set; } = CameraClearFlags.Skybox;
        public Color backgroundColor { get; set; } = new Color(0.19215687f, 0.3019608f, 0.4745098f, 0f);
        public float depth { get; set; } = -1f;
        public int cullingMask { get; set; } = -1;
        public Rect rect { get; set; } = new Rect(0, 0, 1, 1);
        public float aspect { get => m_Aspect > 0 ? m_Aspect : (float)Screen.width / Math.Max(1, Screen.height); set => m_Aspect = value; }
        float m_Aspect;
        public void ResetAspect() { m_Aspect = 0; }
        public int pixelWidth => Screen.width;
        public int pixelHeight => Screen.height;
        public Rect pixelRect => new Rect(0, 0, Screen.width, Screen.height);
        public RenderTexture targetTexture { get; set; }
        public bool usePhysicalProperties { get; set; }
        public static Camera main
        {
            get
            {
                Camera best = null;
                foreach (var go in World.SceneObjects())
                {
                    if (!go.activeInHierarchy || go.m_Tag != "MainCamera") continue;
                    foreach (var c in go.m_Components) if (c is Camera cam && cam.m_Enabled && !cam.m_Destroyed) { if (best == null || cam.depth > best.depth) best = cam; }
                }
                return best;
            }
        }
        public static Camera current => main;
        public static Camera[] allCameras
        {
            get
            {
                var list = new List<Camera>();
                foreach (var go in World.SceneObjects()) if (go.activeInHierarchy) foreach (var c in go.m_Components) if (c is Camera cam && cam.m_Enabled) list.Add(cam);
                return list.ToArray();
            }
        }
        public static int allCamerasCount => allCameras.Length;
        internal static Camera Rendering
        {
            get
            {
                Camera best = null;
                foreach (var cam in allCameras) if (cam.targetTexture == null && (best == null || cam.depth >= best.depth)) best = cam;
                return best;
            }
        }
        public Matrix4x4 worldToCameraMatrix
        {
            get
            {
                // Unity's view matrix is right-handed (camera looks down -Z) like OpenGL.
                Matrix4x4 m = Matrix4x4.TRS(transform.position, transform.rotation, Vector3.one).inverse;
                Matrix4x4 flip = Matrix4x4.Scale(new Vector3(1, 1, -1));
                return flip * m;
            }
        }
        public Matrix4x4 cameraToWorldMatrix => worldToCameraMatrix.inverse;
        public Matrix4x4 projectionMatrix
        {
            get => orthographic
                ? Matrix4x4.Ortho(-orthographicSize * aspect, orthographicSize * aspect, -orthographicSize, orthographicSize, nearClipPlane, farClipPlane)
                : Matrix4x4.Perspective(fieldOfView, aspect, nearClipPlane, farClipPlane);
            set { }
        }
        public Vector3 WorldToViewportPoint(Vector3 position)
        {
            Vector3 local = transform.InverseTransformDirection(position - transform.position);
            if (orthographic)
                return new Vector3(local.x / (orthographicSize * aspect) * 0.5f + 0.5f, local.y / orthographicSize * 0.5f + 0.5f, local.z);
            float t = Mathf.Tan(fieldOfView * 0.5f * Mathf.Deg2Rad);
            float z = local.z;
            if (Math.Abs(z) < 1e-9f) z = 1e-9f;
            return new Vector3(local.x / (z * t * aspect) * 0.5f + 0.5f, local.y / (z * t) * 0.5f + 0.5f, local.z);
        }
        public Vector3 WorldToScreenPoint(Vector3 position)
        {
            var v = WorldToViewportPoint(position);
            return new Vector3(v.x * pixelWidth, v.y * pixelHeight, v.z);
        }
        public Vector3 ViewportToWorldPoint(Vector3 position)
        {
            float z = position.z;
            Vector3 local;
            if (orthographic) local = new Vector3((position.x - 0.5f) * 2f * orthographicSize * aspect, (position.y - 0.5f) * 2f * orthographicSize, z);
            else
            {
                float t = Mathf.Tan(fieldOfView * 0.5f * Mathf.Deg2Rad);
                local = new Vector3((position.x - 0.5f) * 2f * t * aspect * z, (position.y - 0.5f) * 2f * t * z, z);
            }
            return transform.position + transform.rotation * local;
        }
        public Vector3 ScreenToWorldPoint(Vector3 position) => ViewportToWorldPoint(new Vector3(position.x / pixelWidth, position.y / pixelHeight, position.z));
        public Vector3 ScreenToViewportPoint(Vector3 position) => new Vector3(position.x / pixelWidth, position.y / pixelHeight, position.z);
        public Vector3 ViewportToScreenPoint(Vector3 position) => new Vector3(position.x * pixelWidth, position.y * pixelHeight, position.z);
        public Ray ViewportPointToRay(Vector3 pos)
        {
            if (orthographic)
            {
                Vector3 o = ViewportToWorldPoint(new Vector3(pos.x, pos.y, nearClipPlane));
                return new Ray(o, transform.forward);
            }
            Vector3 near = ViewportToWorldPoint(new Vector3(pos.x, pos.y, nearClipPlane));
            Vector3 far = ViewportToWorldPoint(new Vector3(pos.x, pos.y, 1f + nearClipPlane));
            return new Ray(near, (far - near).normalized);
        }
        public Ray ScreenPointToRay(Vector3 pos) => ViewportPointToRay(ScreenToViewportPoint(pos));
        public Ray ScreenPointToRay(Vector2 pos) => ScreenPointToRay((Vector3)pos);
        public void Render() { }
    }

    public class RenderTexture : Texture { public RenderTexture(int width, int height, int depth) { this.width = width; this.height = height; } }

    public sealed class Light : Behaviour
    {
        public LightType type { get; set; } = LightType.Point;
        public Color color { get; set; } = Color.white;
        public float intensity { get; set; } = 1f;
        public float range { get; set; } = 10f;
        public float spotAngle { get; set; } = 30f;
        public float innerSpotAngle { get; set; } = 21.8f;
        public LightShadows shadows { get; set; } = LightShadows.None;
        public float shadowStrength { get; set; } = 1f;
        public float bounceIntensity { get; set; } = 1f;
        public float colorTemperature { get; set; } = 6570f;
        public bool useColorTemperature { get; set; }
        public int cullingMask { get; set; } = -1;
    }

    public static class Gizmos
    {
        internal struct Cmd { public int kind; public Matrix4x4 m; public Vector3 a, b; public float r; public Color c; } // 0 line, 1 wire sphere, 2 sphere, 3 wire cube, 4 cube
        internal static readonly List<Cmd> cmds = new List<Cmd>();
        public static Color color { get; set; } = Color.white;
        public static Matrix4x4 matrix { get; set; } = Matrix4x4.identity;
        internal static void BeginFrame() { cmds.Clear(); color = Color.white; matrix = Matrix4x4.identity; }
        static void Add(int k, Vector3 a, Vector3 b, float r) { if (cmds.Count < 20000) cmds.Add(new Cmd { kind = k, m = matrix, a = a, b = b, r = r, c = color }); }
        public static void DrawLine(Vector3 from, Vector3 to) => Add(0, from, to, 0);
        public static void DrawRay(Vector3 from, Vector3 direction) => Add(0, from, from + direction, 0);
        public static void DrawRay(Ray r) => Add(0, r.origin, r.origin + r.direction, 0);
        public static void DrawWireSphere(Vector3 center, float radius) => Add(1, center, Vector3.zero, radius);
        public static void DrawSphere(Vector3 center, float radius) => Add(2, center, Vector3.zero, radius);
        public static void DrawWireCube(Vector3 center, Vector3 size) => Add(3, center, size, 0);
        public static void DrawCube(Vector3 center, Vector3 size) => Add(4, center, size, 0);
        public static void DrawIcon(Vector3 center, string name) { }
        public static void DrawIcon(Vector3 center, string name, bool allowScaling) { }
        public static void DrawFrustum(Vector3 center, float fov, float maxRange, float minRange, float aspect) { }
        public static void DrawMesh(Mesh mesh, Vector3 position) { }
        public static void DrawWireMesh(Mesh mesh, Vector3 position) { }
    }

    internal static class Primitives
    {
        internal static GameObject Create(PrimitiveType type)
        {
            string n = type.ToString();
            var go = new GameObject(n);
            var mf = go.AddComponent<MeshFilter>();
            mf.sharedMesh = Mesh.Primitive(n);
            go.AddComponent<MeshRenderer>();
            switch (type)
            {
                case PrimitiveType.Cube: go.AddComponent<BoxCollider>(); break;
                case PrimitiveType.Sphere: go.AddComponent<SphereCollider>(); break;
                case PrimitiveType.Capsule: go.AddComponent<CapsuleCollider>(); break;
                case PrimitiveType.Cylinder: go.AddComponent<CapsuleCollider>(); break;
                case PrimitiveType.Plane: case PrimitiveType.Quad: go.AddComponent<MeshCollider>(); break;
            }
            return go;
        }
    }

    internal static class Geometry
    {
        internal static Bounds TransformBounds(Matrix4x4 m, Bounds b)
        {
            Vector3 c = m.MultiplyPoint3x4(b.center);
            Vector3 e = b.extents;
            Vector3 ax = m.MultiplyVector(new Vector3(e.x, 0, 0)), ay = m.MultiplyVector(new Vector3(0, e.y, 0)), az = m.MultiplyVector(new Vector3(0, 0, e.z));
            Vector3 ext = new Vector3(Math.Abs(ax.x) + Math.Abs(ay.x) + Math.Abs(az.x), Math.Abs(ax.y) + Math.Abs(ay.y) + Math.Abs(az.y), Math.Abs(ax.z) + Math.Abs(ay.z) + Math.Abs(az.z));
            return new Bounds(c, ext * 2f);
        }
    }
}
