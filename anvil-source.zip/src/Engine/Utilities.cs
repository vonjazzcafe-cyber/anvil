// Anvil — JsonUtility (Unity's serializer rules and JSON layout) and ColorUtility.
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Text;
using System.Text.Json;
using Anvil;

namespace UnityEngine
{
    public static class JsonUtility
    {
        // ---------------- writing ----------------
        public static string ToJson(object obj) => ToJson(obj, false);
        public static string ToJson(object obj, bool prettyPrint)
        {
            if (obj == null) return "";
            var t = obj.GetType();
            if (obj is Object uo && uo == null) return "";
            if (t.IsPrimitive || obj is string || t.IsEnum || t.IsArray || SerializationRules.IsList(t)) return "{}";
            var sb = new StringBuilder();
            new Writer(sb, prettyPrint).Obj(obj, 0, 0);
            return sb.ToString();
        }

        sealed class Writer
        {
            readonly StringBuilder sb; readonly bool pretty;
            internal Writer(StringBuilder sb, bool pretty) { this.sb = sb; this.pretty = pretty; }
            void Indent(int level) { if (pretty) { sb.Append('\n'); sb.Append(' ', level * 4); } }
            void Key(string k, bool first, int level) { if (!first) sb.Append(','); Indent(level); Str(k); sb.Append(pretty ? ": " : ":"); }
            internal void Obj(object o, int level, int depth)
            {
                sb.Append('{');
                bool first = true;
                if (depth < 10)
                    foreach (var f in SerializationRules.GetSerializableFields(o.GetType()))
                    {
                        if (f.FieldType.IsGenericType && f.FieldType.GetGenericTypeDefinition() == typeof(Dictionary<,>)) continue;
                        Key(f.Name, first, level + 1); first = false;
                        Value(f.GetValue(o), f.FieldType, level + 1, depth + 1);
                    }
                if (!first) Indent(level);
                sb.Append('}');
            }
            void Fields(int level, bool[] first, params (string k, Action w)[] items)
            {
                foreach (var (k, w) in items) { Key(k, first[0], level); first[0] = false; w(); }
            }
            void Struct(int level, params (string k, Action w)[] items)
            {
                sb.Append('{'); var first = new[] { true }; Fields(level + 1, first, items); if (!first[0]) Indent(level); sb.Append('}');
            }
            internal void Value(object v, Type t, int level, int depth)
            {
                if (t == typeof(float)) { Float((float)(v ?? 0f)); return; }
                if (t == typeof(double)) { Double((double)(v ?? 0d)); return; }
                if (t == typeof(bool)) { sb.Append((bool)(v ?? false) ? "true" : "false"); return; }
                if (t == typeof(string)) { Str((string)v ?? ""); return; }
                if (t == typeof(char)) { sb.Append((int)(char)(v ?? '\0')); return; }
                if (t.IsEnum) { sb.Append(Convert.ToInt64(v ?? 0, CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture)); return; }
                if (t.IsPrimitive) { sb.Append(Convert.ToString(v ?? 0, CultureInfo.InvariantCulture)); return; }
                if (typeof(Object).IsAssignableFrom(t)) { var uo = v as Object; Struct(level, ("instanceID", () => sb.Append(uo != null ? uo.GetInstanceID() : 0))); return; }
                switch (v)
                {
                    case Vector2 a: Struct(level, ("x", () => Float(a.x)), ("y", () => Float(a.y))); return;
                    case Vector3 a: Struct(level, ("x", () => Float(a.x)), ("y", () => Float(a.y)), ("z", () => Float(a.z))); return;
                    case Vector4 a: Struct(level, ("x", () => Float(a.x)), ("y", () => Float(a.y)), ("z", () => Float(a.z)), ("w", () => Float(a.w))); return;
                    case Quaternion a: Struct(level, ("x", () => Float(a.x)), ("y", () => Float(a.y)), ("z", () => Float(a.z)), ("w", () => Float(a.w))); return;
                    case Color a: Struct(level, ("r", () => Float(a.r)), ("g", () => Float(a.g)), ("b", () => Float(a.b)), ("a", () => Float(a.a))); return;
                    case Color32 a: Struct(level, ("r", () => sb.Append(a.r)), ("g", () => sb.Append(a.g)), ("b", () => sb.Append(a.b)), ("a", () => sb.Append(a.a))); return;
                    case Vector2Int a: Struct(level, ("x", () => sb.Append(a.x)), ("y", () => sb.Append(a.y))); return;
                    case Vector3Int a: Struct(level, ("x", () => sb.Append(a.x)), ("y", () => sb.Append(a.y)), ("z", () => sb.Append(a.z))); return;
                    case Rect a: Struct(level, ("serializedVersion", () => Str("2")), ("x", () => Float(a.x)), ("y", () => Float(a.y)), ("width", () => Float(a.width)), ("height", () => Float(a.height))); return;
                    case Bounds a: Struct(level, ("m_Center", () => Value(a.center, typeof(Vector3), level + 1, depth)), ("m_Extent", () => Value(a.extents, typeof(Vector3), level + 1, depth))); return;
                    case LayerMask a: Struct(level, ("serializedVersion", () => Str("2")), ("m_Bits", () => sb.Append((uint)a.value))); return;
                    case Matrix4x4 m:
                        {
                            var items = new List<(string, Action)>();
                            for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) { int rr = r, cc = c; items.Add(("e" + r + c, () => Float(m[rr, cc]))); }
                            Struct(level, items.ToArray()); return;
                        }
                    case AnimationCurve curve:
                        Struct(level, ("serializedVersion", () => Str("2")), ("m_Curve", (Action)(() =>
                        {
                            sb.Append('['); var keys = curve.keys;
                            for (int i = 0; i < keys.Length; i++)
                            {
                                if (i > 0) sb.Append(','); Indent(level + 2); var k = keys[i];
                                Struct(level + 2, ("serializedVersion", () => Str("3")), ("time", () => Float(k.time)), ("value", () => Float(k.value)), ("inSlope", () => Float(k.inTangent)), ("outSlope", () => Float(k.outTangent)),
                                    ("tangentMode", () => sb.Append(0)), ("weightedMode", () => sb.Append(0)), ("inWeight", () => Float(1f / 3f)), ("outWeight", () => Float(1f / 3f)));
                            }
                            if (keys.Length > 0) Indent(level + 1); sb.Append(']');
                        })), ("m_PreInfinity", () => sb.Append(2)), ("m_PostInfinity", () => sb.Append(2)), ("m_RotationOrder", () => sb.Append(4)));
                        return;
                    case Gradient g:
                        {
                            var items = new List<(string, Action)> { ("serializedVersion", () => Str("2")) };
                            var ck = g.colorKeys; var ak = g.alphaKeys;
                            for (int i = 0; i < 8; i++)
                            {
                                int ii = i; Color c = i < ck.Length ? ck[i].color : Color.black; c.a = i < ak.Length ? ak[i].alpha : 0;
                                items.Add(("key" + i, () => Value(c, typeof(Color), level + 1, depth)));
                            }
                            for (int i = 0; i < 8; i++) { int ii = i; items.Add(("ctime" + i, () => sb.Append(ii < ck.Length ? (int)Math.Round(ck[ii].time * 65535) : 0))); }
                            for (int i = 0; i < 8; i++) { int ii = i; items.Add(("atime" + i, () => sb.Append(ii < ak.Length ? (int)Math.Round(ak[ii].time * 65535) : 0))); }
                            items.Add(("m_Mode", () => sb.Append((int)g.mode))); items.Add(("m_ColorSpace", () => sb.Append(-1)));
                            items.Add(("m_NumColorKeys", () => sb.Append(ck.Length))); items.Add(("m_NumAlphaKeys", () => sb.Append(ak.Length)));
                            Struct(level, items.ToArray()); return;
                        }
                }
                if (t.IsArray || SerializationRules.IsList(t))
                {
                    var et = t.IsArray ? t.GetElementType() : t.GetGenericArguments()[0];
                    sb.Append('[');
                    int n = 0;
                    if (v is IList list && depth < 10) foreach (var item in list) { if (n++ > 0) sb.Append(','); Indent(level + 1); Value(item, et, level + 1, depth + 1); }
                    if (n > 0) Indent(level);
                    sb.Append(']');
                    return;
                }
                // a [Serializable] class or struct: never null in Unity's serialized data
                if (v == null) v = SerializationRules.DefaultFor(t) ?? (t.IsValueType ? Activator.CreateInstance(t) : null);
                if (v == null) { sb.Append("{}"); return; }
                Obj(v, level, depth);
            }
            void Float(float f)
            {
                if (float.IsNaN(f)) { sb.Append("NaN"); return; }
                if (float.IsInfinity(f)) { sb.Append(f > 0 ? "Infinity" : "-Infinity"); return; }
                Num(((double)f).ToString("R", CultureInfo.InvariantCulture));
            }
            void Double(double d)
            {
                if (double.IsNaN(d)) { sb.Append("NaN"); return; }
                if (double.IsInfinity(d)) { sb.Append(d > 0 ? "Infinity" : "-Infinity"); return; }
                Num(d.ToString("R", CultureInfo.InvariantCulture));
            }
            void Num(string s) { sb.Append(s); if (s.IndexOf('.') < 0 && s.IndexOf('E') < 0 && s.IndexOf('e') < 0) sb.Append(".0"); }
            void Str(string s)
            {
                sb.Append('"');
                foreach (char c in s)
                {
                    switch (c)
                    {
                        case '"': sb.Append("\\\""); break;
                        case '\\': sb.Append("\\\\"); break;
                        case '\n': sb.Append("\\n"); break;
                        case '\r': sb.Append("\\r"); break;
                        case '\t': sb.Append("\\t"); break;
                        case '\b': sb.Append("\\b"); break;
                        case '\f': sb.Append("\\f"); break;
                        default: if (c < 0x20) sb.Append("\\u").Append(((int)c).ToString("x4")); else sb.Append(c); break;
                    }
                }
                sb.Append('"');
            }
        }

        // ---------------- reading ----------------
        public static T FromJson<T>(string json) => (T)FromJson(json, typeof(T));
        public static object FromJson(string json, Type type)
        {
            if (type == null) throw new ArgumentNullException(nameof(type));
            if (string.IsNullOrEmpty(json)) return type.IsValueType ? Activator.CreateInstance(type) : null;
            if (typeof(MonoBehaviour).IsAssignableFrom(type) || typeof(ScriptableObject).IsAssignableFrom(type) || typeof(Component).IsAssignableFrom(type))
                throw new ArgumentException($"Cannot deserialize JSON to new instances of type '{type.Name}.'");
            if (type.IsPrimitive || type == typeof(string) || type.IsEnum || type.IsArray || SerializationRules.IsList(type) || type.IsAbstract)
                throw new ArgumentException("JSON must represent an object type.");
            using var doc = Parse(json);
            object o;
            try { o = Activator.CreateInstance(type, true); }
            catch (MissingMethodException) { throw new ArgumentException($"Cannot deserialize JSON to new instances of type '{type.Name}.'"); }
            if (doc.RootElement.ValueKind != JsonValueKind.Object) throw new ArgumentException("JSON must represent an object type.");
            Apply(o, doc.RootElement, 0);
            return o;
        }
        public static void FromJsonOverwrite(string json, object objectToOverwrite)
        {
            if (objectToOverwrite == null) throw new ArgumentNullException(nameof(objectToOverwrite));
            if (objectToOverwrite is Object uo && uo == null) throw new ArgumentNullException(nameof(objectToOverwrite));
            if (string.IsNullOrEmpty(json)) return;
            using var doc = Parse(json);
            if (doc.RootElement.ValueKind != JsonValueKind.Object) throw new ArgumentException("JSON must represent an object type.");
            Apply(objectToOverwrite, doc.RootElement, 0);
        }
        static JsonDocument Parse(string json)
        {
            try { return JsonDocument.Parse(json, new JsonDocumentOptions { AllowTrailingCommas = true, CommentHandling = JsonCommentHandling.Skip }); }
            catch (JsonException) { throw new ArgumentException("JSON parse error: Invalid value."); }
        }
        static void Apply(object o, JsonElement e, int depth)
        {
            if (depth > 10) return;
            foreach (var f in SerializationRules.GetSerializableFields(o.GetType()))
            {
                if (!e.TryGetProperty(f.Name, out var v)) continue;
                try { f.SetValue(o, Read(v, f.FieldType, f.GetValue(o), depth + 1)); } catch (Exception) { /* a value of the wrong kind is skipped, like Unity */ }
            }
            SerializationRules.FillNulls(o);
        }
        static Object FindInstance(int id)
        {
            foreach (var go in World.allObjects)
            {
                if (go.m_InstanceID == id) return go;
                foreach (var c in go.m_Components) if (c.m_InstanceID == id) return c;
            }
            return null;
        }
        static float F(JsonElement e) => e.ValueKind == JsonValueKind.Number ? (float)e.GetDouble() : e.ValueKind == JsonValueKind.String && float.TryParse(e.GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var f) ? f : 0f;
        static float P(JsonElement e, string name) => e.ValueKind == JsonValueKind.Object && e.TryGetProperty(name, out var v) ? F(v) : 0f;
        static object Read(JsonElement v, Type t, object current, int depth)
        {
            if (t == typeof(float)) return F(v);
            if (t == typeof(double)) return v.ValueKind == JsonValueKind.Number ? v.GetDouble() : (double)F(v);
            if (t == typeof(bool)) return v.ValueKind == JsonValueKind.True || (v.ValueKind == JsonValueKind.Number && v.GetDouble() != 0);
            if (t == typeof(string)) return v.ValueKind == JsonValueKind.String ? v.GetString() : v.ValueKind == JsonValueKind.Null ? "" : v.ToString();
            if (t == typeof(char)) return v.ValueKind == JsonValueKind.Number ? (char)v.GetInt32() : (v.GetString() is string cs && cs.Length > 0 ? cs[0] : '\0');
            if (t.IsEnum) return Enum.ToObject(t, v.ValueKind == JsonValueKind.Number ? (long)v.GetDouble() : 0L);
            if (t.IsPrimitive) return Convert.ChangeType(v.ValueKind == JsonValueKind.Number ? v.GetDouble() : 0.0, t, CultureInfo.InvariantCulture) is var n && t != typeof(double) && t != typeof(float) ? Convert.ChangeType(Math.Truncate(Convert.ToDouble(n)), t, CultureInfo.InvariantCulture) : n;
            if (typeof(Object).IsAssignableFrom(t))
            {
                int id = v.ValueKind == JsonValueKind.Object && v.TryGetProperty("instanceID", out var idv) && idv.ValueKind == JsonValueKind.Number ? idv.GetInt32() : 0;
                if (id == 0) return null;
                var found = FindInstance(id);
                return found != null && t.IsInstanceOfType(found) ? found : null;
            }
            if (t == typeof(Vector2)) return new Vector2(P(v, "x"), P(v, "y"));
            if (t == typeof(Vector3)) return new Vector3(P(v, "x"), P(v, "y"), P(v, "z"));
            if (t == typeof(Vector4)) return new Vector4(P(v, "x"), P(v, "y"), P(v, "z"), P(v, "w"));
            if (t == typeof(Quaternion)) return new Quaternion(P(v, "x"), P(v, "y"), P(v, "z"), P(v, "w"));
            if (t == typeof(Color)) return new Color(P(v, "r"), P(v, "g"), P(v, "b"), P(v, "a"));
            if (t == typeof(Color32)) return new Color32((byte)P(v, "r"), (byte)P(v, "g"), (byte)P(v, "b"), (byte)P(v, "a"));
            if (t == typeof(Vector2Int)) return new Vector2Int((int)P(v, "x"), (int)P(v, "y"));
            if (t == typeof(Vector3Int)) return new Vector3Int((int)P(v, "x"), (int)P(v, "y"), (int)P(v, "z"));
            if (t == typeof(Rect)) return new Rect(P(v, "x"), P(v, "y"), P(v, "width"), P(v, "height"));
            if (t == typeof(LayerMask)) return (LayerMask)(int)(uint)P(v, "m_Bits");
            if (t == typeof(Bounds)) { var c = v.TryGetProperty("m_Center", out var cv) ? (Vector3)Read(cv, typeof(Vector3), null, depth) : Vector3.zero; var x = v.TryGetProperty("m_Extent", out var xv) ? (Vector3)Read(xv, typeof(Vector3), null, depth) : Vector3.zero; return new Bounds(c, x * 2); }
            if (t == typeof(Matrix4x4)) { var m = new Matrix4x4(); for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) m[r, c] = P(v, "e" + r + c); return m; }
            if (t == typeof(AnimationCurve))
            {
                var curve = new AnimationCurve();
                if (v.ValueKind == JsonValueKind.Object && v.TryGetProperty("m_Curve", out var arr) && arr.ValueKind == JsonValueKind.Array)
                    foreach (var k in arr.EnumerateArray()) curve.AddKey(new Keyframe(P(k, "time"), P(k, "value"), P(k, "inSlope"), P(k, "outSlope")));
                return curve;
            }
            if (t == typeof(Gradient))
            {
                var g = new Gradient();
                int nc = (int)P(v, "m_NumColorKeys"), na = (int)P(v, "m_NumAlphaKeys");
                var ck = new GradientColorKey[Math.Clamp(nc, 0, 8)]; var ak = new GradientAlphaKey[Math.Clamp(na, 0, 8)];
                for (int i = 0; i < ck.Length; i++) { var c = v.TryGetProperty("key" + i, out var kv) ? (Color)Read(kv, typeof(Color), null, depth) : Color.white; ck[i] = new GradientColorKey(c, P(v, "ctime" + i) / 65535f); }
                for (int i = 0; i < ak.Length; i++) { float a = v.TryGetProperty("key" + i, out var kv) ? P(kv, "a") : 1f; ak[i] = new GradientAlphaKey(a, P(v, "atime" + i) / 65535f); }
                if (ck.Length > 0 && ak.Length > 0) g.SetKeys(ck, ak);
                g.mode = (GradientMode)(int)P(v, "m_Mode");
                return g;
            }
            if (t.IsArray || SerializationRules.IsList(t))
            {
                var et = t.IsArray ? t.GetElementType() : t.GetGenericArguments()[0];
                var items = new List<object>();
                if (v.ValueKind == JsonValueKind.Array) foreach (var item in v.EnumerateArray()) items.Add(Read(item, et, null, depth + 1) ?? SerializationRules.DefaultFor(et) ?? (et.IsValueType ? Activator.CreateInstance(et) : null));
                if (t.IsArray) { var a = Array.CreateInstance(et, items.Count); for (int i = 0; i < items.Count; i++) a.SetValue(items[i], i); return a; }
                var list = (IList)Activator.CreateInstance(t); foreach (var it in items) list.Add(it); return list;
            }
            if (v.ValueKind != JsonValueKind.Object) return current;
            // nested [Serializable] class/struct: Unity overwrites the existing object's fields
            object target = current;
            if (target == null || t.IsValueType) target = t.IsValueType ? (current ?? Activator.CreateInstance(t)) : Activator.CreateInstance(t, true);
            Apply(target, v, depth);
            return target;
        }
    }

    public static class ColorUtility
    {
        static readonly Dictionary<string, Color32> s_Named = new Dictionary<string, Color32>(StringComparer.OrdinalIgnoreCase)
        {
            ["red"] = new Color32(255, 0, 0, 255), ["cyan"] = new Color32(0, 255, 255, 255), ["blue"] = new Color32(0, 0, 255, 255), ["darkblue"] = new Color32(0, 0, 160, 255),
            ["lightblue"] = new Color32(173, 216, 230, 255), ["purple"] = new Color32(128, 0, 128, 255), ["yellow"] = new Color32(255, 255, 0, 255), ["lime"] = new Color32(0, 255, 0, 255),
            ["fuchsia"] = new Color32(255, 0, 255, 255), ["white"] = new Color32(255, 255, 255, 255), ["silver"] = new Color32(192, 192, 192, 255), ["grey"] = new Color32(128, 128, 128, 255),
            ["black"] = new Color32(0, 0, 0, 255), ["orange"] = new Color32(255, 165, 0, 255), ["brown"] = new Color32(165, 42, 42, 255), ["maroon"] = new Color32(128, 0, 0, 255),
            ["green"] = new Color32(0, 128, 0, 255), ["olive"] = new Color32(128, 128, 0, 255), ["navy"] = new Color32(0, 0, 128, 255), ["teal"] = new Color32(0, 128, 128, 255),
            ["aqua"] = new Color32(0, 255, 255, 255), ["magenta"] = new Color32(255, 0, 255, 255),
        };
        public static bool TryParseHtmlString(string htmlString, out Color color)
        {
            color = new Color(1, 1, 1, 1);
            if (string.IsNullOrEmpty(htmlString)) return false;
            if (htmlString[0] != '#') { if (s_Named.TryGetValue(htmlString, out var n)) { color = n; return true; } return false; }
            string h = htmlString.Substring(1);
            if (h.Length == 3 || h.Length == 4) { var sb = new StringBuilder(); foreach (char c in h) sb.Append(c).Append(c); h = sb.ToString(); }
            if (h.Length != 6 && h.Length != 8) return false;
            if (!uint.TryParse(h, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out uint v)) return false;
            if (h.Length == 6) v = (v << 8) | 0xff;
            color = new Color32((byte)(v >> 24), (byte)(v >> 16), (byte)(v >> 8), (byte)v);
            return true;
        }
        public static string ToHtmlStringRGB(Color color) { Color32 c = new Color32((byte)Mathf.Round(Mathf.Clamp01(color.r) * 255), (byte)Mathf.Round(Mathf.Clamp01(color.g) * 255), (byte)Mathf.Round(Mathf.Clamp01(color.b) * 255), 1); return $"{c.r:X2}{c.g:X2}{c.b:X2}"; }
        public static string ToHtmlStringRGBA(Color color) { Color32 c = new Color32((byte)Mathf.Round(Mathf.Clamp01(color.r) * 255), (byte)Mathf.Round(Mathf.Clamp01(color.g) * 255), (byte)Mathf.Round(Mathf.Clamp01(color.b) * 255), (byte)Mathf.Round(Mathf.Clamp01(color.a) * 255)); return $"{c.r:X2}{c.g:X2}{c.b:X2}{c.a:X2}"; }
    }
}
