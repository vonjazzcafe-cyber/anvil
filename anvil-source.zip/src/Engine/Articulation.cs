// Anvil — ArticulationBody: Unity's joint system for robots and ragdolls, on PhysX reduced-coordinate articulations.
// A chain of ArticulationBodies (each one's parent is the nearest ArticulationBody above it in the hierarchy) is
// solved as one body: joints never stretch, a heavy hand on a light arm stays stable, and every joint reports its
// angle, speed and the force it carries. Drives are springs: force = stiffness·(target − position) + damping·(targetVelocity − velocity),
// capped at forceLimit. Like Unity: drive targets and limits are in degrees (metres for prismatic), jointPosition is in radians.
using System;
using System.Collections.Generic;
using Anvil;

namespace UnityEngine
{
    public enum ArticulationJointType { FixedJoint = 0, PrismaticJoint = 1, RevoluteJoint = 2, SphericalJoint = 3 }
    public enum ArticulationDofLock { LockedMotion = 0, LimitedMotion = 1, FreeMotion = 2 }
    public enum ArticulationDriveType { Force = 0, Acceleration = 1, Target = 2, Velocity = 3 }
    public enum ArticulationDriveAxis { X = 0, Y = 1, Z = 2 }

    public struct ArticulationDrive
    {
        public float lowerLimit;
        public float upperLimit;
        public float stiffness;
        public float damping;
        public float forceLimit;
        public float target;
        public float targetVelocity;
        public ArticulationDriveType driveType;
    }

    public struct ArticulationReducedSpace
    {
        float m_X, m_Y, m_Z;
        public int dofCount;
        public ArticulationReducedSpace(float a) { m_X = a; m_Y = 0; m_Z = 0; dofCount = 1; }
        public ArticulationReducedSpace(float a, float b) { m_X = a; m_Y = b; m_Z = 0; dofCount = 2; }
        public ArticulationReducedSpace(float a, float b, float c) { m_X = a; m_Y = b; m_Z = c; dofCount = 3; }
        public float this[int i]
        {
            get
            {
                if (i < 0 || i >= dofCount) throw new IndexOutOfRangeException("ArticulationReducedSpace index " + i + " is out of range (dofCount " + dofCount + ").");
                return i == 0 ? m_X : i == 1 ? m_Y : m_Z;
            }
            set
            {
                if (i < 0 || i >= dofCount) throw new IndexOutOfRangeException("ArticulationReducedSpace index " + i + " is out of range (dofCount " + dofCount + ").");
                if (i == 0) m_X = value; else if (i == 1) m_Y = value; else m_Z = value;
            }
        }
        internal static ArticulationReducedSpace Of(float[] v, int n) => n == 0 ? new ArticulationReducedSpace { dofCount = 0 } : n == 1 ? new ArticulationReducedSpace(v[0]) : n == 2 ? new ArticulationReducedSpace(v[0], v[1]) : new ArticulationReducedSpace(v[0], v[1], v[2]);
    }

    [DisallowMultipleComponent]
    public class ArticulationBody : Behaviour
    {
        static ArticulationDrive DefaultDrive => new ArticulationDrive { forceLimit = float.MaxValue };

        internal ArticulationJointType m_JointType = ArticulationJointType.FixedJoint;
        internal Vector3 m_AnchorPos, m_ParentAnchorPos;
        internal Quaternion m_AnchorRot = Quaternion.identity, m_ParentAnchorRot = Quaternion.identity;
        internal bool m_MatchAnchors = true, m_Immovable, m_UseGravity = true, m_AutoCom = true, m_AutoInertia = true;
        internal ArticulationDofLock m_LinX = ArticulationDofLock.FreeMotion, m_LinY = ArticulationDofLock.LockedMotion, m_LinZ = ArticulationDofLock.LockedMotion;
        internal ArticulationDofLock m_Twist = ArticulationDofLock.FreeMotion, m_SwingY = ArticulationDofLock.FreeMotion, m_SwingZ = ArticulationDofLock.FreeMotion;
        internal ArticulationDrive m_XDrive = DefaultDrive, m_YDrive = DefaultDrive, m_ZDrive = DefaultDrive;
        internal float m_Mass = 1f, m_LinDamp = 0.05f, m_AngDamp = 0.05f, m_JointFriction = 0.05f, m_MaxAngVel = 50f, m_MaxLinVel = 1e16f, m_MaxJointVel = 1e16f, m_MaxDepen = 1e16f, m_Sleep = 0.005f;
        internal int m_SolverIterations = 6, m_SolverVelIterations = 1;
        internal CollisionDetectionMode m_CDM;
        internal Vector3 m_Com, m_Inertia = Vector3.one; internal Quaternion m_InertiaRot = Quaternion.identity;

        // physics-side state
        internal int handle = -1, linkIndex = -1, structVersion = 1;
        internal ArticulationBody builtParent, root;
        internal bool driveDirty = true, massDirty = true, pendingWake, pendingSleep, hasLast;
        internal Vector3 s_Pos, s_LinVel, s_AngVel, s_WorldCom, s_LocalCom, s_Inertia = Vector3.one; internal Quaternion s_Rot = Quaternion.identity, s_InertiaRot = Quaternion.identity;
        internal bool s_HasState, s_Sleeping; internal float s_Mass = 1;
        internal Vector3 lastPos; internal Quaternion lastRot = Quaternion.identity;
        internal Vector3 accImpulse, accTorqueImpulse, accAngVelChange;
        internal Vector3? pendingRootPos; internal Quaternion? pendingRootRot; internal Vector3? pendingRootVel, pendingRootAngVel;
        internal readonly float[] s_JointPos = new float[6], s_JointVel = new float[6], s_JointLoad = new float[6], s_PrevVel = new float[6], s_JointAcc = new float[6];
        internal float[] pendingJointPos;
        internal int ownerDepth;

        void Struct() { structVersion++; PhysicsWorld.MarkStructureDirty(); }
        void Drive() { driveDirty = true; pendingWake = true; }

        // ---- joint ----
        public ArticulationJointType jointType { get => m_JointType; set { if (m_JointType != value) { m_JointType = value; Struct(); } } }
        public Vector3 anchorPosition { get => m_AnchorPos; set { m_AnchorPos = value; Struct(); } }
        public Quaternion anchorRotation { get => m_AnchorRot; set { m_AnchorRot = value; Struct(); } }
        public Vector3 parentAnchorPosition { get => m_ParentAnchorPos; set { m_ParentAnchorPos = value; if (!m_MatchAnchors) Struct(); } }
        public Quaternion parentAnchorRotation { get => m_ParentAnchorRot; set { m_ParentAnchorRot = value; if (!m_MatchAnchors) Struct(); } }
        public bool matchAnchors { get => m_MatchAnchors; set { m_MatchAnchors = value; Struct(); } }
        public ArticulationDofLock linearLockX { get => m_LinX; set { m_LinX = value; Struct(); } }
        public ArticulationDofLock linearLockY { get => m_LinY; set { m_LinY = value; Struct(); } }
        public ArticulationDofLock linearLockZ { get => m_LinZ; set { m_LinZ = value; Struct(); } }
        public ArticulationDofLock twistLock { get => m_Twist; set { m_Twist = value; Struct(); } }
        public ArticulationDofLock swingYLock { get => m_SwingY; set { m_SwingY = value; Struct(); } }
        public ArticulationDofLock swingZLock { get => m_SwingZ; set { m_SwingZ = value; Struct(); } }
        public ArticulationDrive xDrive { get => m_XDrive; set { m_XDrive = value; Drive(); } }
        public ArticulationDrive yDrive { get => m_YDrive; set { m_YDrive = value; Drive(); } }
        public ArticulationDrive zDrive { get => m_ZDrive; set { m_ZDrive = value; Drive(); } }
        public float jointFriction { get => m_JointFriction; set { m_JointFriction = Math.Max(0, value); Drive(); } }
        public float maxJointVelocity { get => m_MaxJointVel; set { m_MaxJointVel = Math.Max(0, value); Drive(); } }
        public bool computeParentAnchor { get => m_MatchAnchors; set => matchAnchors = value; }

        // ---- body ----
        public bool immovable { get => m_Immovable; set { if (m_Immovable != value) { m_Immovable = value; Struct(); } } }
        public bool useGravity { get => m_UseGravity; set { m_UseGravity = value; Struct(); } }
        public float mass { get => m_Mass; set { m_Mass = Math.Max(1e-7f, value); massDirty = true; } }
        public bool automaticCenterOfMass { get => m_AutoCom; set { m_AutoCom = value; massDirty = true; } }
        public bool automaticInertiaTensor { get => m_AutoInertia; set { m_AutoInertia = value; massDirty = true; } }
        public Vector3 centerOfMass { get { PhysicsWorld.EnsureArtMass(this); return m_AutoCom ? s_LocalCom : m_Com; } set { m_Com = value; m_AutoCom = false; massDirty = true; } }
        public Vector3 inertiaTensor { get { PhysicsWorld.EnsureArtMass(this); return m_AutoInertia ? s_Inertia : m_Inertia; } set { m_Inertia = value; m_AutoInertia = false; massDirty = true; } }
        public Quaternion inertiaTensorRotation { get { PhysicsWorld.EnsureArtMass(this); return m_AutoInertia ? s_InertiaRot : m_InertiaRot; } set { m_InertiaRot = value; m_AutoInertia = false; massDirty = true; } }
        public Vector3 worldCenterOfMass { get { PhysicsWorld.EnsureArtMass(this); return (handle >= 0 && s_HasState ? s_Pos : transform.position) + (handle >= 0 && s_HasState ? s_Rot : transform.rotation) * centerOfMass; } }
        public void ResetCenterOfMass() { m_AutoCom = true; massDirty = true; }
        public void ResetInertiaTensor() { m_AutoInertia = true; massDirty = true; }
        public float linearDamping { get => m_LinDamp; set { m_LinDamp = Math.Max(0, value); Struct(); } }
        public float angularDamping { get => m_AngDamp; set { m_AngDamp = Math.Max(0, value); Struct(); } }
        public float maxAngularVelocity { get => m_MaxAngVel; set { m_MaxAngVel = Math.Max(0, value); Struct(); } }
        public float maxLinearVelocity { get => m_MaxLinVel; set { m_MaxLinVel = Math.Max(0, value); Struct(); } }
        public float maxDepenetrationVelocity { get => m_MaxDepen; set { m_MaxDepen = value; Struct(); } }
        public float sleepThreshold { get => m_Sleep; set { m_Sleep = Math.Max(0, value); Struct(); } }
        public int solverIterations { get => m_SolverIterations; set { m_SolverIterations = Math.Max(1, value); Struct(); } }
        public int solverVelocityIterations { get => m_SolverVelIterations; set { m_SolverVelIterations = Math.Max(0, value); Struct(); } }
        public CollisionDetectionMode collisionDetectionMode { get => m_CDM; set { m_CDM = value; Struct(); } }
        public LayerMask excludeLayers { get; set; }
        public LayerMask includeLayers { get; set; }
        [Obsolete("linearDamping")] public float drag { get => linearDamping; set => linearDamping = value; }
        [Obsolete("angularDamping")] public float angularDrag { get => angularDamping; set => angularDamping = value; }

        // ---- structure info ----
        public bool isRoot => PhysicsWorld.ArtParent(this) == null;
        public int index { get { PhysicsWorld.SyncArtForQuery(); return linkIndex < 0 ? 0 : linkIndex; } }
        public int dofCount => DofAxes().Count;
        internal List<int> DofAxes()
        {
            // axis indices into the 6 joint values: 0 twist(X), 1 swing1(Y), 2 swing2(Z), 3 linear X, 4 Y, 5 Z
            var l = new List<int>(3);
            if (isRoot) return l;
            switch (m_JointType)
            {
                case ArticulationJointType.RevoluteJoint: if (m_Twist != ArticulationDofLock.LockedMotion) l.Add(0); break;
                case ArticulationJointType.SphericalJoint:
                    if (m_Twist != ArticulationDofLock.LockedMotion) l.Add(0);
                    if (m_SwingY != ArticulationDofLock.LockedMotion) l.Add(1);
                    if (m_SwingZ != ArticulationDofLock.LockedMotion) l.Add(2);
                    break;
                case ArticulationJointType.PrismaticJoint:
                    if (m_LinX != ArticulationDofLock.LockedMotion) l.Add(3);
                    else if (m_LinY != ArticulationDofLock.LockedMotion) l.Add(4);
                    else if (m_LinZ != ArticulationDofLock.LockedMotion) l.Add(5);
                    break;
            }
            return l;
        }
        ArticulationReducedSpace Reduced(float[] src)
        {
            var ax = DofAxes(); var v = new float[3];
            for (int i = 0; i < ax.Count; i++) v[i] = src[ax[i]];
            return ArticulationReducedSpace.Of(v, ax.Count);
        }

        // ---- readouts ----
        /// joint angle(s) in radians (metres for prismatic), measured from where the joint was built
        public ArticulationReducedSpace jointPosition
        {
            get => Reduced(s_JointPos);
            set
            {
                var ax = DofAxes(); var p = (float[])s_JointPos.Clone();
                for (int i = 0; i < ax.Count && i < value.dofCount; i++) p[ax[i]] = value[i];
                pendingJointPos = p; Array.Copy(p, s_JointPos, 6); pendingWake = true;
            }
        }
        public ArticulationReducedSpace jointVelocity { get => Reduced(s_JointVel); set { } }
        public ArticulationReducedSpace jointAcceleration { get => Reduced(s_JointAcc); set { } }
        /// the torque (N·m) or force (N) the joint's drive applies along each moving axis: what holds this link and everything beyond it
        public ArticulationReducedSpace jointForce { get => driveForce; set { } }
        /// the force the drive itself is pushing with this step: stiffness·(target − position) + damping·(targetVelocity − velocity), capped at forceLimit
        public ArticulationReducedSpace driveForce
        {
            get
            {
                var ax = DofAxes(); var v = new float[3];
                for (int i = 0; i < ax.Count; i++) v[i] = DriveForceOn(ax[i]);
                return ArticulationReducedSpace.Of(v, ax.Count);
            }
        }
        internal ArticulationDrive DriveFor(int axis) => axis == 0 || axis == 3 ? m_XDrive : axis == 1 || axis == 4 ? m_YDrive : m_ZDrive;
        internal float DriveForceOn(int axis)
        {
            var d = DriveFor(axis);
            bool ang = axis < 3;
            float tgt = ang ? d.target * Mathf.Deg2Rad : d.target, tv = ang ? d.targetVelocity * Mathf.Deg2Rad : d.targetVelocity;
            float f = d.stiffness * (tgt - s_JointPos[axis]) + d.damping * (tv - s_JointVel[axis]);
            if (d.driveType == ArticulationDriveType.Force || d.driveType == ArticulationDriveType.Acceleration)
            {
                float lim = d.forceLimit <= 0 ? 0 : d.forceLimit;
                return Mathf.Clamp(f, -lim, lim);
            }
            return 0f;
        }

        public Vector3 linearVelocity { get => s_LinVel; set { if (isRoot) { s_LinVel = value; pendingRootVel = value; } } }
        public Vector3 velocity { get => linearVelocity; set => linearVelocity = value; }
        public Vector3 angularVelocity { get => s_AngVel; set { if (isRoot) { s_AngVel = value; pendingRootAngVel = value; } } }
        public Vector3 GetPointVelocity(Vector3 worldPoint) => s_LinVel + Vector3.Cross(s_AngVel, worldPoint - worldCenterOfMass);
        public Vector3 GetRelativePointVelocity(Vector3 localPoint) => GetPointVelocity(transform.TransformPoint(localPoint));

        // ---- drives ----
        ArticulationDrive Get(ArticulationDriveAxis a) => a == ArticulationDriveAxis.X ? m_XDrive : a == ArticulationDriveAxis.Y ? m_YDrive : m_ZDrive;
        void Set(ArticulationDriveAxis a, ArticulationDrive d) { if (a == ArticulationDriveAxis.X) m_XDrive = d; else if (a == ArticulationDriveAxis.Y) m_YDrive = d; else m_ZDrive = d; Drive(); }
        public void SetDriveTarget(ArticulationDriveAxis axis, float value) { var d = Get(axis); d.target = value; Set(axis, d); }
        public void SetDriveTargetVelocity(ArticulationDriveAxis axis, float value) { var d = Get(axis); d.targetVelocity = value; Set(axis, d); }
        public void SetDriveLimits(ArticulationDriveAxis axis, float lower, float upper) { var d = Get(axis); d.lowerLimit = lower; d.upperLimit = upper; Set(axis, d); }
        public void SetDriveStiffness(ArticulationDriveAxis axis, float value) { var d = Get(axis); d.stiffness = value; Set(axis, d); }
        public void SetDriveDamping(ArticulationDriveAxis axis, float value) { var d = Get(axis); d.damping = value; Set(axis, d); }
        public void SetDriveForceLimit(ArticulationDriveAxis axis, float value) { var d = Get(axis); d.forceLimit = value; Set(axis, d); }

        // ---- forces ----
        public void AddForce(Vector3 force) => AddForce(force, ForceMode.Force);
        public void AddForce(Vector3 force, ForceMode mode)
        {
            float dt = Time.fixedDeltaTime;
            switch (mode)
            {
                case ForceMode.Force: accImpulse += force * dt; break;
                case ForceMode.Impulse: accImpulse += force; break;
                case ForceMode.Acceleration: accImpulse += force * dt * m_Mass; break;
                case ForceMode.VelocityChange: accImpulse += force * m_Mass; break;
            }
            pendingWake = true;
        }
        public void AddRelativeForce(Vector3 force) => AddForce(transform.TransformDirection(force), ForceMode.Force);
        public void AddRelativeForce(Vector3 force, ForceMode mode) => AddForce(transform.TransformDirection(force), mode);
        public void AddTorque(Vector3 torque) => AddTorque(torque, ForceMode.Force);
        public void AddTorque(Vector3 torque, ForceMode mode)
        {
            float dt = Time.fixedDeltaTime;
            switch (mode)
            {
                case ForceMode.Force: accTorqueImpulse += torque * dt; break;
                case ForceMode.Impulse: accTorqueImpulse += torque; break;
                case ForceMode.Acceleration: accAngVelChange += torque * dt; break;
                case ForceMode.VelocityChange: accAngVelChange += torque; break;
            }
            pendingWake = true;
        }
        public void AddRelativeTorque(Vector3 torque) => AddTorque(transform.TransformDirection(torque), ForceMode.Force);
        public void AddRelativeTorque(Vector3 torque, ForceMode mode) => AddTorque(transform.TransformDirection(torque), mode);
        public void AddForceAtPosition(Vector3 force, Vector3 position) => AddForceAtPosition(force, position, ForceMode.Force);
        public void AddForceAtPosition(Vector3 force, Vector3 position, ForceMode mode)
        {
            AddForce(force, mode);
            Vector3 t = Vector3.Cross(position - worldCenterOfMass, force);
            if (mode == ForceMode.Force || mode == ForceMode.Impulse) AddTorque(t, mode);
            else accTorqueImpulse += t * (mode == ForceMode.Acceleration ? Time.fixedDeltaTime * m_Mass : m_Mass);
        }
        public void TeleportRoot(Vector3 position, Quaternion rotation)
        {
            if (!isRoot) { Debug.LogWarning("TeleportRoot can only be called on the root ArticulationBody."); return; }
            pendingRootPos = position; pendingRootRot = rotation; transform.SetPositionAndRotation(position, rotation);
            lastPos = transform.position; lastRot = transform.rotation;
        }
        public void WakeUp() { pendingWake = true; s_Sleeping = false; }
        public void Sleep() { pendingSleep = true; s_Sleeping = true; }
        public bool IsSleeping() => s_Sleeping;

        // ---- whole-articulation helpers (call on any body; they read the whole chain, like Unity) ----
        public int GetDofStartIndices(List<int> dofStartIndices)
        {
            var links = PhysicsWorld.ArtLinks(this); dofStartIndices.Clear(); int total = 0;
            foreach (var l in links) { dofStartIndices.Add(total); total += l.dofCount; }
            return total;
        }
        int Gather(List<float> list, Func<ArticulationBody, ArticulationReducedSpace> f)
        {
            list.Clear();
            foreach (var l in PhysicsWorld.ArtLinks(this)) { var r = f(l); for (int i = 0; i < r.dofCount; i++) list.Add(r[i]); }
            return list.Count;
        }
        public int GetJointPositions(List<float> positions) => Gather(positions, l => l.jointPosition);
        public int GetJointVelocities(List<float> velocities) => Gather(velocities, l => l.jointVelocity);
        public int GetJointAccelerations(List<float> accelerations) => Gather(accelerations, l => l.jointAcceleration);
        public int GetJointForces(List<float> forces) => Gather(forces, l => l.jointForce);
        public int GetDriveForces(List<float> forces) => Gather(forces, l => l.driveForce);
        public int GetDriveTargets(List<float> targets)
        {
            targets.Clear();
            foreach (var l in PhysicsWorld.ArtLinks(this)) foreach (var a in l.DofAxes()) { var d = l.DriveFor(a); targets.Add(a < 3 ? d.target * Mathf.Deg2Rad : d.target); }
            return targets.Count;
        }
        public void SetDriveTargets(List<float> targets)
        {
            int k = 0;
            foreach (var l in PhysicsWorld.ArtLinks(this))
                foreach (var a in l.DofAxes())
                {
                    if (k >= targets.Count) return;
                    var axis = (ArticulationDriveAxis)(a % 3);
                    l.SetDriveTarget(axis, a < 3 ? targets[k] * Mathf.Rad2Deg : targets[k]); k++;
                }
        }
        public void SetJointPositions(List<float> positions)
        {
            int k = 0;
            foreach (var l in PhysicsWorld.ArtLinks(this))
            {
                int n = l.dofCount; if (n == 0) continue;
                var v = new float[3]; for (int i = 0; i < n && k < positions.Count; i++) v[i] = positions[k++];
                l.jointPosition = ArticulationReducedSpace.Of(v, n);
            }
        }

        internal override void OnAddedInternal() => PhysicsWorld.MarkStructureDirty();
        internal override void OnRemovedInternal() => PhysicsWorld.MarkStructureDirty();
        internal override void OnActiveChangedInternal(bool active) => PhysicsWorld.MarkStructureDirty();
    }
}
