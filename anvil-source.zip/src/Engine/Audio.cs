// Audio: AudioClip (imported files and AudioClip.Create), AudioSource and AudioListener, played by the page with Web Audio.
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using Anvil;

namespace UnityEngine
{
    public enum AudioDataLoadState { Unloaded = 0, Loading = 1, Loaded = 2, Failed = 3 }
    public enum AudioClipLoadType { DecompressOnLoad = 0, CompressedInMemory = 1, Streaming = 2 }

    public sealed class AudioClip : Object
    {
        public delegate void PCMReaderCallback(float[] data);
        public delegate void PCMSetPositionCallback(int position);
        internal readonly int m_Uid = ++s_NextUid; static int s_NextUid;
        internal string m_AssetPath;
        internal float m_Length; internal int m_Channels = 1, m_Frequency = 44100, m_Samples;
        internal float[] m_Data; internal int m_Version; internal int m_SentVersion = -1;
        AudioClip() { }
        internal static AudioClip FromAsset(string path, float length, int channels, int frequency)
            => new AudioClip { m_AssetPath = path, m_Length = length, m_Channels = Math.Max(1, channels), m_Frequency = Math.Max(1, frequency), m_Samples = (int)(length * frequency), m_IsAsset = true, m_Name = System.IO.Path.GetFileNameWithoutExtension(path) };
        public float length => m_Length;
        public int samples => m_Samples;
        public int channels => m_Channels;
        public int frequency => m_Frequency;
        public bool isReadyToPlay => true;
        public AudioClipLoadType loadType => AudioClipLoadType.DecompressOnLoad;
        public bool preloadAudioData => true;
        public bool ambisonic => false;
        public bool loadInBackground => false;
        public AudioDataLoadState loadState => AudioDataLoadState.Loaded;
        public bool LoadAudioData() => true;
        public bool UnloadAudioData() => true;
        public static AudioClip Create(string name, int lengthSamples, int channels, int frequency, bool stream) => Create(name, lengthSamples, channels, frequency, stream, null, null);
        public static AudioClip Create(string name, int lengthSamples, int channels, int frequency, bool stream, PCMReaderCallback pcmreadercallback) => Create(name, lengthSamples, channels, frequency, stream, pcmreadercallback, null);
        public static AudioClip Create(string name, int lengthSamples, int channels, int frequency, bool stream, PCMReaderCallback pcmreadercallback, PCMSetPositionCallback pcmsetpositioncallback)
        {
            if (name == null) throw new NullReferenceException();
            if (lengthSamples <= 0) throw new ArgumentException("Length of created clip must be larger than 0");
            if (channels <= 0) throw new ArgumentException("Number of channels in created clip must be greater than 0");
            if (frequency <= 0) throw new ArgumentException("Frequency in created clip must be greater than 0");
            var c = new AudioClip { m_Name = name, m_Channels = channels, m_Frequency = frequency, m_Samples = lengthSamples, m_Length = lengthSamples / (float)frequency };
            c.m_Data = new float[lengthSamples * channels];
            if (pcmreadercallback != null) { pcmsetpositioncallback?.Invoke(0); try { pcmreadercallback(c.m_Data); } catch (Exception e) { Debug.LogException(e); } }
            return c;
        }
        public bool SetData(float[] data, int offsetSamples)
        {
            if (m_Data == null) { Debug.LogError("Cannot set data on an imported AudioClip in Anvil (its samples stay in the browser)."); return false; }
            if (data == null) throw new NullReferenceException();
            int start = offsetSamples * m_Channels;
            for (int i = 0; i < data.Length && start + i < m_Data.Length; i++) m_Data[start + i] = data[i];
            m_Version++;
            return true;
        }
        public bool GetData(float[] data, int offsetSamples)
        {
            if (m_Data == null) { Debug.LogError("AudioClip.GetData: the samples of an imported clip aren't available to scripts in Anvil."); return false; }
            int start = offsetSamples * m_Channels;
            for (int i = 0; i < data.Length; i++) data[i] = start + i < m_Data.Length ? m_Data[start + i] : 0f;
            return true;
        }
        internal string Ref() => m_AssetPath ?? ("#" + m_Uid);
    }

    [RequireComponent(typeof(Transform))]
    [DisallowMultipleComponent]
    public sealed class AudioListener : Behaviour
    {
        public static float volume { get => AudioSync.s_MasterVolume; set { AudioSync.s_MasterVolume = Mathf.Clamp01(value); } }
        public static bool pause { get => AudioSync.s_Paused; set { AudioSync.s_Paused = value; } }
        public AudioVelocityUpdateMode velocityUpdateMode { get; set; }
        public static void GetOutputData(float[] samples, int channel) { Array.Clear(samples, 0, samples.Length); }
        public static void GetSpectrumData(float[] samples, int channel, FFTWindow window) { Array.Clear(samples, 0, samples.Length); }
    }
    public enum FFTWindow { Rectangular = 0, Triangle = 1, Hamming = 2, Hanning = 3, Blackman = 4, BlackmanHarris = 5 }

    public sealed class AudioSource : Behaviour
    {
        internal readonly int m_Id = ++AudioSync.s_NextId;
        AudioClip m_Clip;
        float m_Volume = 1f, m_Pitch = 1f;
        internal bool m_Playing, m_Paused, m_Started;
        internal double m_StartReal; internal float m_StartOffset;
        public AudioClip clip { get => m_Clip; set { if (m_Clip == value) return; if (m_Playing) Stop(); m_Clip = value; } }
        public float volume { get => m_Volume; set => m_Volume = Mathf.Clamp01(value); }
        public float pitch { get => m_Pitch; set => m_Pitch = Mathf.Clamp(value, -3f, 3f); }
        public bool loop { get; set; }
        public bool playOnAwake { get; set; } = true;
        public bool mute { get; set; }
        public float spatialBlend { get; set; }
        public float panStereo { get; set; }
        public float minDistance { get; set; } = 1f;
        public float maxDistance { get; set; } = 500f;
        public AudioRolloffMode rolloffMode { get; set; } = AudioRolloffMode.Logarithmic;
        public float dopplerLevel { get; set; } = 1f;
        public float spread { get; set; }
        public int priority { get; set; } = 128;
        public float reverbZoneMix { get; set; } = 1f;
        public bool bypassEffects { get; set; }
        public bool bypassListenerEffects { get; set; }
        public bool bypassReverbZones { get; set; }
        public bool ignoreListenerVolume { get; set; }
        public bool ignoreListenerPause { get; set; }
        public bool spatialize { get; set; }
        public bool spatializePostEffects { get; set; }
        public Audio.AudioMixerGroup outputAudioMixerGroup { get; set; }
        public AudioVelocityUpdateMode velocityUpdateMode { get; set; }
        public bool isVirtual => false;
        public bool isPlaying
        {
            get
            {
                if (!m_Playing || m_Paused) return false;
                if (loop || m_Clip == null) return m_Playing;
                return Elapsed() < m_Clip.length - 0.0001f;
            }
        }
        float Elapsed() => m_StartOffset + (float)(Time.realtimeSinceStartupAsDouble - m_StartReal) * Mathf.Abs(m_Pitch);
        public float time
        {
            get { if (!m_Playing || m_Clip == null) return m_StartOffset; float e = m_Paused ? m_StartOffset : Elapsed(); return loop && m_Clip.length > 0 ? e % m_Clip.length : Mathf.Min(e, m_Clip.length); }
            set { m_StartOffset = Mathf.Max(0, value); m_StartReal = Time.realtimeSinceStartupAsDouble; if (m_Playing && !m_Paused) AudioSync.Op("seek", this, null, 0); }
        }
        public int timeSamples { get => m_Clip != null ? (int)(time * m_Clip.frequency) : 0; set { if (m_Clip != null) time = value / (float)m_Clip.frequency; } }
        public void Play()
        {
            if (m_Clip == null) return;
            if (!isActiveAndEnabled) { Debug.LogWarning("Can not play a disabled audio source"); return; }
            if (!m_Playing || !m_Paused) m_StartOffset = m_Playing ? 0 : m_StartOffset;
            m_Playing = true; m_Paused = false; m_StartReal = Time.realtimeSinceStartupAsDouble;
            AudioSync.Register(this);
            AudioSync.Op("play", this, m_Clip, 0);
            m_StartOffset = 0;
        }
        public void Play(ulong delay) => PlayDelayed(delay / 44100f);
        public void PlayDelayed(float delay) { if (m_Clip == null) return; m_Playing = true; m_Paused = false; m_StartOffset = -Mathf.Max(0, delay); m_StartReal = Time.realtimeSinceStartupAsDouble; AudioSync.Register(this); AudioSync.Op("play", this, m_Clip, Mathf.Max(0, delay)); m_StartOffset = -Mathf.Max(0, delay); }
        public void PlayScheduled(double time) => PlayDelayed((float)Math.Max(0, time - AudioSettings.dspTime));
        public void PlayOneShot(AudioClip clip) => PlayOneShot(clip, 1f);
        public void PlayOneShot(AudioClip clip, float volumeScale)
        {
            if (clip == null) { Debug.LogWarning("PlayOneShot was called with a null AudioClip."); return; }
            if (!isActiveAndEnabled) { Debug.LogWarning("Can not play a disabled audio source"); return; }
            AudioSync.OneShot(clip, volumeScale, this, transform.position);
        }
        public void Stop() { if (!m_Playing) return; m_Playing = false; m_Paused = false; m_StartOffset = 0; AudioSync.Op("stop", this, null, 0); }
        public void Stop(bool stopOneShots) => Stop();
        public void Pause() { if (!m_Playing || m_Paused) return; m_StartOffset = Elapsed(); m_Paused = true; AudioSync.Op("pause", this, null, 0); }
        public void UnPause() { if (!m_Playing || !m_Paused) return; m_Paused = false; m_StartReal = Time.realtimeSinceStartupAsDouble; AudioSync.Op("play", this, m_Clip, 0); }
        public static void PlayClipAtPoint(AudioClip clip, Vector3 position) => PlayClipAtPoint(clip, position, 1f);
        public static void PlayClipAtPoint(AudioClip clip, Vector3 position, float volume)
        {
            if (clip == null) return;
            AudioSync.OneShot(clip, volume, null, position);
        }
        public void SetScheduledStartTime(double time) { }
        public void SetScheduledEndTime(double time) { }
        public void GetOutputData(float[] samples, int channel) { Array.Clear(samples, 0, samples.Length); }
        public void GetSpectrumData(float[] samples, int channel, FFTWindow window) { Array.Clear(samples, 0, samples.Length); }
        public AnimationCurve GetCustomCurve(AudioSourceCurveType type) => AnimationCurve.Linear(0, 1, 1, 0);
        public void SetCustomCurve(AudioSourceCurveType type, AnimationCurve curve) { }
        internal override void OnActiveChangedInternal(bool active)
        {
            if (active && playOnAwake && m_Clip != null && World.isPlaying && !m_Playing) Play();
            if (!active && m_Playing) { m_Playing = false; AudioSync.Op("stop", this, null, 0); }
        }
        internal override void OnRemovedInternal() { if (m_Playing) { m_Playing = false; AudioSync.Op("stop", this, null, 0); } }
        // effective gain and pan for this source as heard by the listener (Unity's logarithmic/linear rolloff)
        internal void Mix(Vector3 pos, out float gain, out float pan) => AudioSync.Mix(this, pos, m_Volume, out gain, out pan);
    }
    public enum AudioSourceCurveType { CustomRolloff = 0, SpatialBlend = 1, ReverbZoneMix = 2, Spread = 3 }

    public sealed class AudioSettings
    {
        AudioSettings() { }
        public static double dspTime => Time.realtimeSinceStartupAsDouble;
        public static int outputSampleRate => 48000;
        public static AudioSpeakerMode driverCapabilities => AudioSpeakerMode.Stereo;
        public static AudioSpeakerMode speakerMode { get => AudioSpeakerMode.Stereo; set { } }
        public static void GetDSPBufferSize(out int bufferLength, out int numBuffers) { bufferLength = 1024; numBuffers = 4; }
    }
    public enum AudioSpeakerMode { Mono = 1, Stereo = 2, Quad = 3, Surround = 4, Mode5point1 = 5, Mode7point1 = 6, Prologic = 7 }
}

namespace UnityEngine.Audio
{
    public class AudioMixer : Object
    {
        public bool SetFloat(string name, float value) => false;
        public bool GetFloat(string name, out float value) { value = 0; return false; }
        public AudioMixerGroup[] FindMatchingGroups(string subPath) => new AudioMixerGroup[0];
        public AudioMixerSnapshot FindSnapshot(string name) => null;
        public bool ClearFloat(string name) => false;
        public AudioMixerGroup outputAudioMixerGroup { get; set; }
    }
    public class AudioMixerGroup : Object { public AudioMixer audioMixer => null; }
    public class AudioMixerSnapshot : Object { public AudioMixer audioMixer => null; public void TransitionTo(float timeToReach) { } }
}

namespace Anvil
{
    // collects audio commands each frame for the page (frame events "audio")
    internal static class AudioSync
    {
        internal static int s_NextId;
        internal static float s_MasterVolume = 1f;
        internal static bool s_Paused, s_SentPaused;
        static readonly List<UnityEngine.AudioSource> s_Playing = new List<UnityEngine.AudioSource>();
        static readonly Dictionary<int, (float g, float p, float pitch)> s_Last = new Dictionary<int, (float, float, float)>();
        static readonly StringBuilder s_Ops = new StringBuilder();
        static int s_OpCount;
        internal static readonly List<(int uid, int ch, int freq, float[] data)> clipUploads = new List<(int, int, int, float[])>();
        internal static void Reset() { s_Playing.Clear(); s_Last.Clear(); s_Ops.Clear(); s_OpCount = 0; clipUploads.Clear(); s_MasterVolume = 1f; s_Paused = false; s_SentPaused = false; }
        internal static void Register(UnityEngine.AudioSource s) { if (!s_Playing.Contains(s)) s_Playing.Add(s); }
        static void Begin() { if (s_Ops.Length == 0) s_Ops.Append('['); else s_Ops.Append(','); s_OpCount++; }
        static void ClipRef(UnityEngine.AudioClip clip)
        {
            if (clip.m_Data != null && clip.m_SentVersion != clip.m_Version) { clipUploads.Add((clip.m_Uid, clip.m_Channels, clip.m_Frequency, (float[])clip.m_Data.Clone())); clip.m_SentVersion = clip.m_Version; }
            s_Ops.Append(",\"clip\":").Append(JsonSerializer.Serialize(clip.Ref())).Append(",\"len\":").Append(F(clip.length));
        }
        static string F(float v) => float.IsFinite(v) ? v.ToString("0.####", System.Globalization.CultureInfo.InvariantCulture) : "0";
        internal static void Op(string op, UnityEngine.AudioSource s, UnityEngine.AudioClip clip, float delay)
        {
            if (s_OpCount > 500) return;
            Begin();
            s_Ops.Append("{\"op\":\"").Append(op).Append("\",\"id\":").Append(s.m_Id);
            if (clip != null)
            {
                ClipRef(clip);
                s.Mix(s.transform.position, out var g, out var p);
                s_Last[s.m_Id] = (g, p, s.pitch);
                s_Ops.Append(",\"loop\":").Append(s.loop ? "true" : "false").Append(",\"t\":").Append(F(Math.Max(0, s.m_StartOffset))).Append(",\"delay\":").Append(F(delay)).Append(",\"gain\":").Append(F(g)).Append(",\"pan\":").Append(F(p)).Append(",\"pitch\":").Append(F(s.pitch));
            }
            if (op == "seek") s_Ops.Append(",\"t\":").Append(F(s.time));
            s_Ops.Append('}');
        }
        internal static void OneShot(UnityEngine.AudioClip clip, float scale, UnityEngine.AudioSource s, UnityEngine.Vector3 pos)
        {
            if (s_OpCount > 500) return;
            float g, p, pitch = 1f;
            if (s != null) { Mix(s, pos, s.volume * scale, out g, out p); pitch = s.pitch; }
            else Mix(null, pos, scale, out g, out p);
            Begin();
            s_Ops.Append("{\"op\":\"oneshot\",\"id\":").Append(++s_NextId);
            ClipRef(clip);
            s_Ops.Append(",\"gain\":").Append(F(g)).Append(",\"pan\":").Append(F(p)).Append(",\"pitch\":").Append(F(pitch)).Append('}');
        }
        static UnityEngine.Transform Listener()
        {
            foreach (var l in World.FindObjectsOfType<UnityEngine.AudioListener>(false)) if (l.isActiveAndEnabled) return l.transform;
            var cam = UnityEngine.Camera.main; return cam != null ? cam.transform : null;
        }
        internal static void Mix(UnityEngine.AudioSource s, UnityEngine.Vector3 pos, float volume, out float gain, out float pan)
        {
            float blend = s != null ? s.spatialBlend : 1f;
            bool mute = s != null && s.mute;
            float g = mute ? 0 : volume;
            if (s == null || !s.ignoreListenerVolume) g *= s_MasterVolume;
            float p = s != null ? s.panStereo : 0;
            if (blend > 0)
            {
                var l = Listener();
                float att = 1f, sp = 0f;
                if (l != null)
                {
                    var d = pos - l.position; float dist = d.magnitude;
                    float min = s != null ? Math.Max(0.0001f, s.minDistance) : 1f, max = s != null ? s.maxDistance : 500f;
                    var mode = s != null ? s.rolloffMode : UnityEngine.AudioRolloffMode.Logarithmic;
                    if (mode == UnityEngine.AudioRolloffMode.Linear) att = UnityEngine.Mathf.Clamp01(1f - (dist - min) / Math.Max(0.0001f, max - min));
                    else att = dist <= min ? 1f : (dist >= max ? min / max : min / dist);
                    if (dist > 0.0001f) sp = UnityEngine.Vector3.Dot(d / dist, l.right);
                }
                g *= 1f - blend + blend * att;
                p = p * (1 - blend) + sp * blend;
            }
            gain = g; pan = UnityEngine.Mathf.Clamp(p, -1f, 1f);
        }
        // each frame: volume/pan of playing sources follow movement and property changes; ended clips stop
        internal static void Update()
        {
            for (int i = s_Playing.Count - 1; i >= 0; i--)
            {
                var s = s_Playing[i];
                if (s == null || s.m_Destroyed || !s.m_Playing) { s_Playing.RemoveAt(i); if (s != null) s_Last.Remove(s.m_Id); continue; }
                if (!s.loop && !s.m_Paused && s.clip != null && s.time >= s.clip.length - 0.0001f && s.isPlaying == false) { s.m_Playing = false; s_Playing.RemoveAt(i); s_Last.Remove(s.m_Id); continue; }
                if (s.m_Paused) continue;
                s.Mix(s.transform.position, out var g, out var p);
                if (!s_Last.TryGetValue(s.m_Id, out var last) || Math.Abs(last.g - g) > 0.003f || Math.Abs(last.p - p) > 0.01f || Math.Abs(last.pitch - s.pitch) > 0.001f)
                {
                    s_Last[s.m_Id] = (g, p, s.pitch);
                    if (s_OpCount > 500) continue;
                    Begin();
                    s_Ops.Append("{\"op\":\"set\",\"id\":").Append(s.m_Id).Append(",\"gain\":").Append(F(g)).Append(",\"pan\":").Append(F(p)).Append(",\"pitch\":").Append(F(s.pitch)).Append(",\"loop\":").Append(s.loop ? "true" : "false").Append('}');
                }
            }
            if (s_Paused != s_SentPaused) { s_SentPaused = s_Paused; Begin(); s_Ops.Append("{\"op\":\"pauseAll\",\"on\":").Append(s_Paused ? "true" : "false").Append('}'); }
        }
        internal static void Write(Utf8JsonWriter w)
        {
            if (s_Ops.Length == 0) return;
            s_Ops.Append(']');
            w.WritePropertyName("audio"); w.WriteRawValue(s_Ops.ToString(), true);
            s_Ops.Clear(); s_OpCount = 0;
        }
    }
}
