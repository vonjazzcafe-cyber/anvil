// Anvil — keeps the 2D physics world (editor/js/runtime/physics2d.js, Box2D) in sync with the scene:
// creates/removes bodies, colliders, joints and effectors, pushes transform moves, velocities and forces,
// steps the simulation, writes poses back to transforms and sends the OnCollision*2D / OnTrigger*2D /
// OnJointBreak2D messages. Every exchange is one exec(commands) call.
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Anvil
{
    internal static class Physics2DWorld
    {
        internal static Func<double[], double[]> s_Exec;
        internal static bool settingsDirty = true, layersDirty = true;
        static bool s_Started;
        static int s_NextId = 1;
        static readonly HashSet<Rigidbody2D> s_Bodies = new HashSet<Rigidbody2D>();
        static readonly HashSet<Collider2D> s_Colliders = new HashSet<Collider2D>();
        static readonly HashSet<Joint2D> s_Joints = new HashSet<Joint2D>();
        static readonly Dictionary<int, Rigidbody2D> s_BodyByHandle = new Dictionary<int, Rigidbody2D>();
        static readonly Dictionary<int, Collider2D> s_ColByHandle = new Dictionary<int, Collider2D>();
        static readonly Dictionary<int, Joint2D> s_JointByHandle = new Dictionary<int, Joint2D>();
        static readonly Dictionary<Collider2D, double[]> s_Sig = new Dictionary<Collider2D, double[]>();
        static readonly HashSet<(int, int)> s_Ignore = new HashSet<(int, int)>();
        static readonly HashSet<(Collider2D, Collider2D)> s_IgnorePending = new HashSet<(Collider2D, Collider2D)>();
        static readonly List<double> s_Cmd = new List<double>();

        sealed class Pair
        {
            public Collider2D a, b; public bool trigger;
            public Vector2 n, rv;
            public readonly List<(Vector2 p, float sep, float ni, float ti)> pts = new List<(Vector2, float, float, float)>();
        }
        static readonly Dictionary<(int, int), Pair> s_Touching = new Dictionary<(int, int), Pair>();

        internal static bool Any => s_Bodies.Count > 0 || s_Colliders.Count > 0;
        internal static void MarkDirty() { }
        internal static void Track(Component c)
        {
            if (c is Rigidbody2D rb) s_Bodies.Add(rb);
            else if (c is Collider2D col) s_Colliders.Add(col);
            else if (c is Joint2D j) s_Joints.Add(j);
        }
        internal static void Reset()
        {
            s_Bodies.Clear(); s_Colliders.Clear(); s_Joints.Clear(); s_BodyByHandle.Clear(); s_ColByHandle.Clear(); s_JointByHandle.Clear();
            s_Sig.Clear(); s_Ignore.Clear(); s_IgnorePending.Clear(); s_Touching.Clear(); s_Cmd.Clear();
            s_Started = false; settingsDirty = true; layersDirty = true;
        }
        internal static IEnumerable<Collider2D> AllColliders() => s_Colliders.Where(c => !c.m_Destroyed);

        static double[] Flush()
        {
            if (s_Exec == null) { s_Cmd.Clear(); return Array.Empty<double>(); }
            var r = s_Exec(s_Cmd.ToArray());
            s_Cmd.Clear();
            return r ?? Array.Empty<double>();
        }
        static void C(params double[] v) => s_Cmd.AddRange(v);

        // ---------- ownership ----------
        static bool Alive(Component c) => c != null && !c.m_Destroyed && c.m_GameObject != null && !c.m_GameObject.m_Destroyed && c.m_GameObject.activeInHierarchy;
        internal static Rigidbody2D FindOwner(Collider2D col)
        {
            for (var t = col.transform; t != null; t = t.parent)
            {
                var rb = t.gameObject.GetComponent<Rigidbody2D>();
                if (rb != null && !rb.m_Destroyed) return rb;
            }
            return null;
        }
        internal static List<Collider2D> CollidersOf(Rigidbody2D rb) => s_Colliders.Where(c => Alive(c) && c.m_Enabled && FindOwner(c) == rb).ToList();
        static float Angle(Transform t) => t.eulerAngles.z;
        static int Depth(Transform t) { int d = 0; for (var p = t.parent; p != null; p = p.parent) d++; return d; }

        // ---------- structure + per-step inputs ----------
        static readonly double[] s_EffBuf = new double[10];
        static void Sync()
        {
            if (!s_Started)
            {
                s_Started = true;
                C(1, Physics2D.gravity.x, Physics2D.gravity.y, Physics2D.velocityIterations, Physics2D.positionIterations, Physics2D.bounceThreshold);
                settingsDirty = false; layersDirty = true;
            }
            if (settingsDirty) { settingsDirty = false; C(2, Physics2D.gravity.x, Physics2D.gravity.y, Physics2D.velocityIterations, Physics2D.positionIterations, Physics2D.bounceThreshold); }
            if (layersDirty) { layersDirty = false; s_Cmd.Add(50); foreach (var m in Physics2D.s_LayerMasks) s_Cmd.Add(m); }

            s_Bodies.RemoveWhere(rb => rb.m_Destroyed && rb.handle < 0);
            // bodies
            foreach (var rb in s_Bodies.ToArray())
            {
                bool want = Alive(rb);
                if (!want)
                {
                    if (rb.handle >= 0) RemoveBody(rb.handle);
                    rb.handle = -1;
                    if (rb.m_Destroyed) s_Bodies.Remove(rb);
                    continue;
                }
                var t = rb.transform;
                if (rb.handle < 0)
                {
                    rb.handle = s_NextId++; s_BodyByHandle[rb.handle] = rb;
                    rb.depth = Depth(t);
                    Vector2 p = rb.pendingPos ?? (Vector2)t.position; float a = rb.pendingAngle ?? Angle(t);
                    C(10, rb.handle, (int)rb.m_BodyType, p.x, p.y, a * Mathf.Deg2Rad, (int)rb.m_SleepMode, 1);
                    BodyProps(rb);
                    rb.propsDirty = false; rb.pendingPos = null; rb.pendingAngle = null; rb.pendingTeleport = false;
                    rb.s_Pos = p; rb.s_Angle = a; rb.lastPos = t.position; rb.lastRot = t.rotation; rb.hasLast = true;
                    rb.pendingVel = true; rb.pendingAngVel = true;
                }
                else if (rb.propsDirty) { rb.propsDirty = false; C(12, rb.handle); BodyProps(rb); }
            }
            // colliders
            s_Colliders.RemoveWhere(c => c.m_Destroyed && c.handle < 0 && c.staticBody < 0);
            foreach (var col in s_Colliders.ToArray())
            {
                bool active = Alive(col) && col.m_Enabled;
                var owner = active ? FindOwner(col) : null;
                if (owner != null && owner.handle < 0) owner = null;    // its body is inactive: so is the collider
                if (active && owner == null && col.transform.GetComponentInParent<Rigidbody2D>() is Rigidbody2D inactiveRb && !inactiveRb.m_Destroyed && inactiveRb.handle < 0) active = false;
                if (!active)
                {
                    if (col.handle >= 0) { C(31, col.handle); col.handle = -1; }
                    if (col.staticBody >= 0) { RemoveBody(col.staticBody); col.staticBody = -1; }
                    if (col.m_Destroyed) { s_Colliders.Remove(col); s_Sig.Remove(col); }
                    continue;
                }
                var ct = col.transform;
                int body; Vector2 bp; float ba;
                if (owner != null)
                {
                    if (col.staticBody >= 0) { RemoveBody(col.staticBody); col.staticBody = -1; }
                    body = owner.handle; bp = owner.transform.position; ba = Angle(owner.transform);
                }
                else
                {
                    Vector2 tp = ct.position; float ta = Angle(ct);
                    if (col.staticBody < 0)
                    {
                        col.staticBody = s_NextId++;
                        C(10, col.staticBody, 2, tp.x, tp.y, ta * Mathf.Deg2Rad, 1, 0);
                        StaticProps();
                        col.lastPos = ct.position; col.lastRot = ct.rotation;
                    }
                    else if (ct.position != col.lastPos || ct.rotation != col.lastRot)
                    {
                        C(13, col.staticBody, tp.x, tp.y, ta * Mathf.Deg2Rad);
                        col.lastPos = ct.position; col.lastRot = ct.rotation;
                    }
                    body = col.staticBody; bp = tp; ba = ta;
                }
                float cs = Mathf.Cos(ba * Mathf.Deg2Rad), sn = Mathf.Sin(ba * Mathf.Deg2Rad);
                Vector2 toBody(Vector2 p) { var w = ct.TransformPoint(new Vector3(p.x, p.y, 0)); float dx = w.x - bp.x, dy = w.y - bp.y; return new Vector2(cs * dx + sn * dy, -sn * dx + cs * dy); }
                var mat = col.m_Material ?? owner?.m_Material;
                // rebuild when anything about the shape or its placement on the body changed
                if (!s_Sig.TryGetValue(col, out var sig)) { sig = new double[16]; s_Sig[col] = sig; sig[0] = double.NaN; }
                var o = toBody(Vector2.zero); var ex = toBody(Vector2.right); var ey = toBody(Vector2.up);
                var ls = ct.lossyScale;
                double[] now = { body, col.shapeVersion, col.gameObject.layer, col.m_IsTrigger ? 1 : 0, mat?.friction ?? 0.4f, mat?.bounciness ?? 0, col.m_Density, R(o.x), R(o.y), R(ex.x), R(ex.y), R(ey.x), R(ey.y), R(ls.x), R(ls.y), mat?.m_Version ?? 0 };
                bool changed = false; for (int k = 0; k < 16; k++) if (sig[k] != now[k]) { changed = true; break; }
                if (changed && col.handle >= 0) { C(31, col.handle); col.handle = -1; }
                if (col.handle < 0)
                {
                    Array.Copy(now, sig, 16);
                    var data = new List<double>();
                    col.BuildShape(toBody, ls, data, out int kind);
                    col.handle = s_NextId++; col.bodyHandle = body; s_ColByHandle[col.handle] = col;
                    C(30, col.handle, body, kind, col.gameObject.layer, col.m_IsTrigger ? 1 : 0, mat?.friction ?? 0.4f, mat?.bounciness ?? 0f, col.m_Density, data.Count);
                    s_Cmd.AddRange(data);
                    col.effectorSig = 0;
                    if (owner != null) owner.propsDirty = true;   // mass follows the colliders
                }
                // effector on the same GameObject
                var eff = col.m_UsedByEffector ? col.GetComponent<Effector2D>() : null;
                int esig = eff != null && eff.m_Enabled ? eff.version * 31 + eff.Type + 7 : 1;
                if (esig != col.effectorSig)
                {
                    col.effectorSig = esig;
                    Array.Clear(s_EffBuf, 0, 10);
                    if (eff != null && eff.m_Enabled) eff.ParamsInto(s_EffBuf);
                    C(32, col.handle, eff != null && eff.m_Enabled ? eff.Type : 0, eff != null && eff.useColliderMask ? 1 : 0, eff?.colliderMask ?? -1);
                    s_Cmd.AddRange(s_EffBuf);
                }
            }
            foreach (var (a, b) in s_IgnorePending.ToArray())
                if (a.handle >= 0 && b.handle >= 0) { C(51, a.handle, b.handle, 1); s_Ignore.Add(Key(a.handle, b.handle)); s_IgnorePending.Remove((a, b)); }
            // body inputs: teleports, moves, velocities, forces, sleep (after colliders so mass is right)
            foreach (var rb in s_Bodies)
            {
                if (rb.handle < 0) continue;
                if (rb.propsDirty) { rb.propsDirty = false; C(12, rb.handle); BodyProps(rb); }
                var t = rb.transform;
                if (rb.pendingPos.HasValue || rb.pendingAngle.HasValue)
                {
                    Vector2 p = rb.pendingPos ?? rb.s_Pos; float a = rb.pendingAngle ?? rb.s_Angle;
                    C(13, rb.handle, p.x, p.y, a * Mathf.Deg2Rad);
                    rb.pendingPos = null; rb.pendingAngle = null; rb.pendingTeleport = false;
                    rb.s_Pos = p; rb.s_Angle = a;
                }
                else if (!rb.hasLast || t.position != rb.lastPos || t.rotation != rb.lastRot)
                {
                    Vector2 p = t.position; float a = Angle(t);
                    C(13, rb.handle, p.x, p.y, a * Mathf.Deg2Rad);
                    rb.s_Pos = p; rb.s_Angle = a; rb.lastPos = t.position; rb.lastRot = t.rotation; rb.hasLast = true;
                }
                if (rb.movePos.HasValue || rb.moveAngle.HasValue)
                {
                    Vector2 p = rb.movePos ?? rb.s_Pos; float a = rb.moveAngle ?? rb.s_Angle;
                    C(21, rb.handle, p.x, p.y, a * Mathf.Deg2Rad);
                    rb.movePos = null; rb.moveAngle = null;
                }
                if (rb.pendingVel) { C(14, rb.handle, rb.s_Vel.x, rb.s_Vel.y); rb.pendingVel = false; }
                if (rb.pendingAngVel) { C(15, rb.handle, rb.s_AngVel * Mathf.Deg2Rad); rb.pendingAngVel = false; }
                var f = rb.pendingForces;
                for (int i = 0; i < f.Count;)
                {
                    int op = (int)f[i]; int len = op <= 17 ? 6 : 3;
                    s_Cmd.Add(op); s_Cmd.Add(rb.handle); for (int k = 2; k < len; k++) s_Cmd.Add(f[i + k]);
                    i += len;
                }
                f.Clear();
                if (rb.pendingWake) { C(22, rb.handle); rb.pendingWake = false; }
                if (rb.pendingSleep) { C(23, rb.handle); rb.pendingSleep = false; }
            }
            // joints
            s_Joints.RemoveWhere(j => j.m_Destroyed && j.handle < 0);
            foreach (var j in s_Joints.ToArray())
            {
                var self = j.m_Destroyed ? null : j.GetComponent<Rigidbody2D>();
                var other = j.m_ConnectedBody;
                bool active = Alive(j) && j.m_Enabled && self != null && self.handle >= 0 && (other == null || (Alive(other) && other.handle >= 0)) && j.Kind >= 0;
                int A = j.AnchorsOnGround ? -1 : self?.handle ?? -1, B = j.AnchorsOnGround ? self?.handle ?? -1 : other != null ? other.handle : -1;
                if (j.handle >= 0 && (!active || j.builtVersion != j.structVersion || j.builtA != A || j.builtB != B)) { C(41, j.handle); j.handle = -1; }
                if (j.m_Destroyed) { s_Joints.Remove(j); continue; }
                if (!active) continue;
                var p = new List<double>();
                if (j.handle < 0)
                {
                    Vector2 wa = self.transform.TransformPoint(j.LocalAnchor);
                    Vector2 wb = j.WorldAnchorB(self);
                    j.Configure(self, wa, wb);
                    j.ParamsInto(p);
                    j.handle = s_NextId++; s_JointByHandle[j.handle] = j;
                    j.builtVersion = j.structVersion; j.sentParams = j.paramVersion; j.builtA = A; j.builtB = B; j.broken = false;
                    C(40, j.handle, j.Kind, A, B, j.m_EnableCollision ? 1 : 0, wa.x, wa.y, wb.x, wb.y, p.Count);
                    s_Cmd.AddRange(p);
                }
                else if (j.sentParams != j.paramVersion)
                {
                    j.sentParams = j.paramVersion; j.ParamsInto(p);
                    C(42, j.handle, p.Count); s_Cmd.AddRange(p);
                }
            }
        }
        static double R(float v) => Math.Round(v * 10000.0) / 10000.0;
        static void BodyProps(Rigidbody2D rb)
        {
            C((int)rb.m_BodyType, rb.m_LinDamp, rb.m_AngDamp, rb.m_GravityScale, (int)rb.m_Constraints, rb.m_CDM == CollisionDetectionMode2D.Continuous ? 1 : 0,
              rb.m_SleepMode == RigidbodySleepMode2D.NeverSleep ? 0 : 1, rb.m_Simulated ? 1 : 0, rb.m_FullKinematic ? 1 : 0, rb.m_AutoMass ? 1 : 0, rb.m_Mass,
              rb.m_HasCom ? 1 : 0, rb.m_Com.x, rb.m_Com.y, rb.m_HasInertia ? 1 : 0, rb.m_Inertia);
        }
        static void StaticProps() => C(2, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1);
        static void RemoveBody(int handle)
        {
            C(11, handle);
            // the JS side drops the body's colliders and joints with it
            foreach (var c in s_Colliders) if (c.handle >= 0 && c.bodyHandle == handle) c.handle = -1;
            foreach (var j in s_Joints) if (j.handle >= 0 && (j.builtA == handle || j.builtB == handle)) j.handle = -1;
            s_BodyByHandle.Remove(handle);
        }

        internal static void SyncForQuery()
        {
            if (!World.isPlaying || s_Exec == null || !Any) return;
            Sync();
            if (s_Cmd.Count > 0) Flush();
        }

        // ---------- step ----------
        internal static void Step(float dt)
        {
            if (!World.isPlaying || s_Exec == null || !Any) return;
            Sync();
            s_Cmd.Add(60); s_Cmd.Add(dt);
            var st = Flush();
            ApplyState(st);
            foreach (var rb in s_Bodies) { rb.m_TotalForce = Vector2.zero; rb.m_TotalTorque = 0; }
        }

        static (int, int) Key(int a, int b) => a < b ? (a, b) : (b, a);
        static readonly List<(Rigidbody2D rb, Vector3 p, Quaternion q)> s_Writes = new List<(Rigidbody2D, Vector3, Quaternion)>();
        static void ApplyState(double[] st)
        {
            if (st.Length == 0) return;
            int i = 0;
            int nb = (int)st[i++];
            s_Writes.Clear();
            for (int k = 0; k < nb; k++, i += 14)
            {
                if (!s_BodyByHandle.TryGetValue((int)st[i], out var rb) || rb.m_Destroyed) continue;
                rb.s_Pos = new Vector2((float)st[i + 1], (float)st[i + 2]);
                rb.s_Angle = (float)(st[i + 3] * Mathf.Rad2Deg);
                rb.s_Vel = new Vector2((float)st[i + 4], (float)st[i + 5]);
                rb.s_AngVel = (float)(st[i + 6] * Mathf.Rad2Deg);
                rb.s_Awake = st[i + 7] != 0;
                rb.s_WorldCom = new Vector2((float)st[i + 8], (float)st[i + 9]);
                rb.s_Mass = (float)st[i + 10]; rb.s_Inertia = (float)st[i + 11];
                rb.s_LocalCom = new Vector2((float)st[i + 12], (float)st[i + 13]);
                rb.s_HasState = true;
                if (rb.m_BodyType == RigidbodyType2D.Static) continue;
                var t = rb.transform;
                var e = t.eulerAngles;
                var q = Mathf.Abs(Mathf.DeltaAngle(e.x, 0)) < 1e-3f && Mathf.Abs(Mathf.DeltaAngle(e.y, 0)) < 1e-3f ? Quaternion.Euler(0, 0, rb.s_Angle) : Quaternion.Euler(e.x, e.y, rb.s_Angle);
                s_Writes.Add((rb, new Vector3(rb.s_Pos.x, rb.s_Pos.y, t.position.z), q));
            }
            s_Writes.Sort((a, b) => a.rb.depth.CompareTo(b.rb.depth));
            foreach (var (rb, p, q) in s_Writes)
            {
                var t = rb.transform;
                t.SetWorldPoseFromPhysics(p, q);
                rb.lastPos = t.position; rb.lastRot = t.rotation; rb.hasLast = true;
            }
            // contacts
            var colEvents = new List<(Pair pair, int kind)>();
            int nc = (int)st[i++];
            for (int k = 0; k < nc; k++)
            {
                int ha = (int)st[i], hb = (int)st[i + 1], kind = (int)st[i + 2], np = (int)st[i + 3];
                var n = new Vector2((float)st[i + 4], (float)st[i + 5]); var rv = new Vector2((float)st[i + 6], (float)st[i + 7]);
                i += 8;
                var key = Key(ha, hb);
                s_ColByHandle.TryGetValue(ha, out var ca); s_ColByHandle.TryGetValue(hb, out var cb);
                if (!s_Touching.TryGetValue(key, out var pair)) { pair = new Pair { a = ca, b = cb }; }
                pair.n = n; pair.rv = rv;
                if (kind != 2) pair.pts.Clear();
                for (int m = 0; m < np; m++, i += 5) pair.pts.Add((new Vector2((float)st[i], (float)st[i + 1]), (float)st[i + 2], (float)st[i + 3], (float)st[i + 4]));
                if (kind == 2) s_Touching.Remove(key); else s_Touching[key] = pair;
                if (ca != null && cb != null) colEvents.Add((pair, kind));
            }
            var trigEvents = new List<(Collider2D a, Collider2D b, int kind)>();
            int nt = (int)st[i++];
            for (int k = 0; k < nt; k++, i += 3)
            {
                int ha = (int)st[i], hb = (int)st[i + 1], kind = (int)st[i + 2];
                s_ColByHandle.TryGetValue(ha, out var ca); s_ColByHandle.TryGetValue(hb, out var cb);
                var key = Key(ha, hb);
                if (kind == 2) s_Touching.Remove(key); else if (!s_Touching.ContainsKey(key)) s_Touching[key] = new Pair { a = ca, b = cb, trigger = true };
                if (ca != null && cb != null) trigEvents.Add((ca, cb, kind));
            }
            // joints
            var breaks = new List<Joint2D>();
            int nj = i < st.Length ? (int)st[i++] : 0;
            for (int k = 0; k < nj; k++, i += 8)
            {
                if (!s_JointByHandle.TryGetValue((int)st[i], out var j) || j.m_Destroyed) continue;
                j.s_Force = new Vector2((float)st[i + 1], (float)st[i + 2]); j.s_Torque = (float)st[i + 3];
                j.s_Angle = (float)st[i + 4]; j.s_AngSpeed = (float)st[i + 5]; j.s_Trans = (float)st[i + 6]; j.s_TransSpeed = (float)st[i + 7];
                bool over = j.s_Force.magnitude > j.m_BreakForce || Math.Abs(j.s_Torque) > j.m_BreakTorque;
                if (over && !j.broken && j.m_BreakAction != JointBreakAction2D.Ignore) { j.broken = true; breaks.Add(j); }
                else if (!over) j.broken = false;
            }
            // messages (after all state is in, like Unity)
            foreach (var (pair, kind) in colEvents) DeliverCollision(pair, kind);
            foreach (var (a, b, kind) in trigEvents)
            {
                string m = kind == 0 ? "OnTriggerEnter2D" : kind == 1 ? "OnTriggerStay2D" : "OnTriggerExit2D";
                Deliver(a, m, b); Deliver(b, m, a);
            }
            foreach (var j in breaks)
            {
                if (j.m_Destroyed) continue;
                Messaging.Send(j.m_GameObject, "OnJointBreak2D", j);
                if (j.m_BreakAction == JointBreakAction2D.Disable) j.enabled = false;
                else if (j.m_BreakAction == JointBreakAction2D.Destroy && !j.m_Destroyed) UnityEngine.Object.Destroy(j);
            }
        }
        static void Deliver(Collider2D self, string message, object arg)
        {
            if (self == null || self.m_Destroyed) return;
            var go = self.m_GameObject;
            if (go != null && !go.m_Destroyed) Messaging.Send(go, message, arg);
            var rb = FindOwner(self);
            if (rb != null && rb.m_GameObject != go && !rb.m_GameObject.m_Destroyed) Messaging.Send(rb.m_GameObject, message, arg);
        }
        static Collision2D MakeCollision(Pair pair, bool forA, bool exit)
        {
            var self = forA ? pair.a : pair.b; var other = forA ? pair.b : pair.a;
            // the contact normal points from the other collider into this one
            var normal = forA ? -pair.n : pair.n;
            var rv = forA ? pair.rv : -pair.rv;
            var col = new Collision2D { m_Collider = other, m_OtherCollider = self, m_RelVel = rv };
            if (!exit)
            {
                col.m_Contacts = new ContactPoint2D[pair.pts.Count];
                for (int k = 0; k < pair.pts.Count; k++)
                {
                    var (p, sep, ni, ti) = pair.pts[k];
                    col.m_Contacts[k] = new ContactPoint2D { m_Point = p, m_Normal = normal, m_Separation = sep, m_NormalImpulse = ni, m_TangentImpulse = ti, m_RelVel = rv, m_Collider = other, m_OtherCollider = self };
                }
            }
            return col;
        }
        static void DeliverCollision(Pair pair, int kind)
        {
            string m = kind == 0 ? "OnCollisionEnter2D" : kind == 1 ? "OnCollisionStay2D" : "OnCollisionExit2D";
            Deliver(pair.a, m, MakeCollision(pair, true, kind == 2));
            Deliver(pair.b, m, MakeCollision(pair, false, kind == 2));
        }

        // ---------- touching / contacts ----------
        static IEnumerable<(Pair p, Collider2D self, Collider2D other)> PairsOf(Collider2D c)
        {
            if (c == null || c.handle < 0) yield break;
            foreach (var p in s_Touching.Values)
            {
                if (p.a == c && p.b != null && !p.b.m_Destroyed) yield return (p, c, p.b);
                else if (p.b == c && p.a != null && !p.a.m_Destroyed) yield return (p, c, p.a);
            }
        }
        internal static bool Touching(Collider2D a, Collider2D b) => a != null && b != null && a.handle >= 0 && b.handle >= 0 && s_Touching.ContainsKey(Key(a.handle, b.handle));
        internal static bool Touching(Collider2D a, Collider2D b, ContactFilter2D f) => Touching(a, b) && f.Passes(b);
        internal static bool TouchingAny(Collider2D c, ContactFilter2D f) => PairsOf(c).Any(x => f.Passes(x.other));
        internal static bool TouchingLayers(Collider2D c, int mask) => PairsOf(c).Any(x => (mask & (1 << x.other.gameObject.layer)) != 0);
        internal static int GetContacts(List<Collider2D> cols, ContactPoint2D[] arr, List<ContactPoint2D> list, ContactFilter2D f)
        {
            var res = new List<ContactPoint2D>();
            foreach (var c in cols)
                foreach (var (p, self, other) in PairsOf(c))
                {
                    if (p.trigger) continue;
                    var col = MakeCollision(p, p.a == self, false);
                    foreach (var cp in col.m_Contacts) if (f.Passes(other, cp.normal)) res.Add(cp);
                }
            if (list != null) { list.Clear(); list.AddRange(res); return res.Count; }
            int n = Math.Min(res.Count, arr.Length); for (int i = 0; i < n; i++) arr[i] = res[i]; return n;
        }
        internal static int GetContactColliders(List<Collider2D> cols, Collider2D[] arr, List<Collider2D> list, ContactFilter2D f)
        {
            var res = new List<Collider2D>();
            foreach (var c in cols) foreach (var (p, self, other) in PairsOf(c)) if (f.Passes(other) && !res.Contains(other)) res.Add(other);
            if (list != null) { list.Clear(); list.AddRange(res); return res.Count; }
            int n = Math.Min(res.Count, arr.Length); for (int i = 0; i < n; i++) arr[i] = res[i]; return n;
        }

        // ---------- ignore pairs ----------
        internal static void SetIgnore(Collider2D a, Collider2D b, bool ignore)
        {
            if (ignore) s_IgnorePending.Add((a, b)); else s_IgnorePending.Remove((a, b));
            if (!ignore && a.handle >= 0 && b.handle >= 0) { C(51, a.handle, b.handle, 0); s_Ignore.Remove(Key(a.handle, b.handle)); }
            SyncForQuery();
        }
        internal static bool IsIgnored(Collider2D a, Collider2D b) => s_IgnorePending.Contains((a, b)) || s_IgnorePending.Contains((b, a)) || (a.handle >= 0 && b.handle >= 0 && s_Ignore.Contains(Key(a.handle, b.handle)));

        // ---------- queries ----------
        static Collider2D Col(double h) => s_ColByHandle.TryGetValue((int)h, out var c) && !c.m_Destroyed ? c : null;
        static double[] Query(params double[] cmd)
        {
            SyncForQuery();
            if (s_Exec == null || !Any) return new double[] { 0 };
            s_Cmd.AddRange(cmd);
            return Flush();
        }
        internal static RaycastHit2D[] Ray(Vector2 origin, Vector2 dir, float distance, ContactFilter2D f, bool firstOnly)
        {
            if (dir.sqrMagnitude < 1e-12f) return Array.Empty<RaycastHit2D>();
            var r = Query(70, origin.x, origin.y, dir.x, dir.y, float.IsInfinity(distance) ? 1e7 : distance, f.Mask, f.useTriggers ? 1 : 0, Physics2D.queriesStartInColliders ? 1 : 0);
            return Hits(r, origin, dir, distance, f, firstOnly, false);
        }
        internal static RaycastHit2D[] Cast(int kind, double[] shape, Vector2 origin, Vector2 dir, float distance, ContactFilter2D f)
        {
            if (dir.sqrMagnitude < 1e-12f) dir = Vector2.right;
            var cmd = new List<double> { 71, kind }; cmd.AddRange(shape);
            cmd.AddRange(new double[] { dir.x, dir.y, float.IsInfinity(distance) ? 1e6 : distance, f.Mask, f.useTriggers ? 1 : 0, Physics2D.queriesStartInColliders ? 1 : 0 });
            var r = Query(cmd.ToArray());
            return Hits(r, origin, dir, distance, f, false, true);
        }
        static RaycastHit2D[] Hits(double[] r, Vector2 origin, Vector2 dir, float distance, ContactFilter2D f, bool firstOnly, bool centroid)
        {
            if (r.Length == 0) return Array.Empty<RaycastHit2D>();
            int n = (int)r[0]; var res = new List<RaycastHit2D>(n);
            var nd = dir.normalized;
            for (int k = 0, i = 1; k < n; k++, i += 6)
            {
                var c = Col(r[i]); if (c == null) continue;
                var normal = new Vector2((float)r[i + 3], (float)r[i + 4]);
                if (!f.Passes(c, normal)) continue;
                float d = (float)r[i + 5];
                var p = new Vector2((float)r[i + 1], (float)r[i + 2]);
                res.Add(new RaycastHit2D { m_Collider = c, m_Point = p, m_Normal = normal, m_Distance = d, m_Fraction = float.IsInfinity(distance) || distance <= 0 ? d : d / distance, m_Centroid = centroid ? origin + nd * d : p });
                if (firstOnly) break;
            }
            return res.ToArray();
        }
        internal static Collider2D[] Overlap(int kind, double[] shape, ContactFilter2D f)
        {
            var cmd = new List<double> { 72, kind }; cmd.AddRange(shape); cmd.Add(f.Mask); cmd.Add(f.useTriggers ? 1 : 0);
            return Ids(Query(cmd.ToArray()), f);
        }
        internal static Collider2D[] OverlapPoint(Vector2 p, ContactFilter2D f) => Ids(Query(73, p.x, p.y, f.Mask, f.useTriggers ? 1 : 0), f);
        static Collider2D[] Ids(double[] r, ContactFilter2D f)
        {
            if (r.Length == 0) return Array.Empty<Collider2D>();
            int n = (int)r[0]; var res = new List<Collider2D>(n);
            for (int k = 0; k < n; k++) { var c = Col(r[1 + k]); if (c != null && f.Passes(c)) res.Add(c); }
            return res.ToArray();
        }
        internal static Collider2D[] OverlapCollider(Collider2D c, ContactFilter2D f)
        {
            var b = BoundsOf(c);
            var cands = Overlap(3, new double[] { b.min.x, b.min.y, b.max.x, b.max.y, 0, 0 }, f);
            return cands.Where(o => o != c && Distance(c, o) is var d && d.isValid && d.distance <= 1e-4f).ToArray();
        }
        internal static bool OverlapPointSelf(Collider2D c, Vector2 p)
        {
            var r = Query(73, p.x, p.y, -1, 1);
            if (c.handle < 0 || r.Length == 0) return false;
            for (int k = 0; k < (int)r[0]; k++) if ((int)r[1 + k] == c.handle) return true;
            return false;
        }
        internal static Vector2 ClosestPoint(Collider2D c, Vector2 p)
        {
            var r = Query(75, c.handle, p.x, p.y);
            return r.Length >= 2 && c.handle >= 0 ? new Vector2((float)r[0], (float)r[1]) : p;
        }
        internal static ColliderDistance2D Distance(Collider2D a, Collider2D b)
        {
            if (a == null || b == null) return default;
            var r = Query(74, a.handle, b.handle);
            if (r.Length < 8 || r[0] == 0 || a.handle < 0 || b.handle < 0) return default;
            return new ColliderDistance2D { m_Valid = true, m_PointA = new Vector2((float)r[1], (float)r[2]), m_PointB = new Vector2((float)r[3], (float)r[4]), m_Normal = new Vector2((float)r[5], (float)r[6]), m_Distance = (float)r[7] };
        }
        internal static Bounds BoundsOf(Collider2D c)
        {
            float z = c.transform.position.z;
            if (World.isPlaying && s_Exec != null)
            {
                var r = Query(76, c.handle);
                if (c.handle >= 0 && r.Length >= 5 && r[0] != 0)
                {
                    var min = new Vector3((float)r[1], (float)r[2], z); var max = new Vector3((float)r[3], (float)r[4], z);
                    var bb = new Bounds(); bb.SetMinMax(min, max); return bb;
                }
            }
            var s = c.transform.lossyScale; var size = Vector2.one;
            if (c is BoxCollider2D bx) size = bx.size; else if (c is CircleCollider2D cc) size = Vector2.one * cc.radius * 2; else if (c is CapsuleCollider2D cp) size = cp.size;
            return new Bounds(c.transform.TransformPoint(c.offset), new Vector3(Math.Abs(size.x * s.x), Math.Abs(size.y * s.y), 0));
        }
    }
}
