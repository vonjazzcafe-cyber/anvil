// Anvil — the ArticulationBody side of the physics world: builds each chain as one PhysX articulation,
// sends drive changes, and reads back link poses and per-joint position, velocity and load.
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Anvil
{
    internal static partial class PhysicsWorld
    {
        static readonly HashSet<ArticulationBody> s_Arts = new HashSet<ArticulationBody>();
        static readonly Dictionary<int, ArticulationBody> s_ArtByHandle = new Dictionary<int, ArticulationBody>();
        // root -> what its articulation was built from (link instance ids, parents and struct versions)
        static readonly Dictionary<ArticulationBody, string> s_ArtBuilt = new Dictionary<ArticulationBody, string>();
        static readonly Dictionary<ArticulationBody, List<ArticulationBody>> s_ArtLinks = new Dictionary<ArticulationBody, List<ArticulationBody>>();
        static bool s_WarnedNoArt;

        static void ResetArticulations() { s_Arts.Clear(); s_ArtByHandle.Clear(); s_ArtBuilt.Clear(); s_ArtLinks.Clear(); }
        static bool ArtActive(ArticulationBody ab) => Active(ab) && ab.m_Enabled;

        /// the nearest active ArticulationBody above this one in the hierarchy (its parent link), or null for a root
        internal static ArticulationBody ArtParent(ArticulationBody ab)
        {
            var t = ab.m_GameObject?.m_Transform?.m_Parent;
            while (t != null)
            {
                foreach (var c in t.m_GameObject.m_Components) if (c is ArticulationBody p && !p.m_Destroyed && (ArtActive(p) || !World.isPlaying)) return p;
                t = t.m_Parent;
            }
            return null;
        }
        static ArticulationBody ArtRoot(ArticulationBody ab) { var r = ab; for (var p = ArtParent(ab); p != null; p = ArtParent(p)) r = p; return r; }

        /// all links of the articulation this body belongs to, parents before children (the order Unity's index uses)
        internal static List<ArticulationBody> ArtLinks(ArticulationBody ab)
        {
            var root = ArtRoot(ab);
            if (s_ArtLinks.TryGetValue(root, out var l) && l.Count > 0) return l;
            return Collect(root);
        }
        static List<ArticulationBody> Collect(ArticulationBody root)
        {
            var list = new List<ArticulationBody> { root };
            for (int i = 0; i < list.Count; i++)
            {
                // children: ArticulationBodies below this one with no other ArticulationBody in between
                void walk(Transform t)
                {
                    foreach (var ch in t.m_Children)
                    {
                        var a = ch.m_GameObject.GetComponent<ArticulationBody>();
                        if (a != null && !a.m_Destroyed && (ArtActive(a) || !World.isPlaying)) list.Add(a);
                        else walk(ch);
                    }
                }
                walk(list[i].m_GameObject.m_Transform);
            }
            return list;
        }

        internal static void SyncArtForQuery() { if (World.isPlaying) SyncStructure(); }
        internal static void EnsureArtMass(ArticulationBody ab)
        {
            if (World.isPlaying && ab.handle < 0 && ArtActive(ab)) SyncStructure();
            if (ab.handle >= 0 && ab.massDirty) ComputeArtMass(ab);
            else if (ab.handle < 0) { ab.s_LocalCom = Vector3.zero; ab.s_Inertia = Vector3.one * ab.m_Mass * 0.1666f; ab.s_InertiaRot = Quaternion.identity; }
        }
        static void ComputeArtMass(ArticulationBody ab)
        {
            ab.massDirty = false;
            backend.SetMassProps(ab.handle, ab.m_Mass, !ab.m_AutoCom, ab.m_Com, !ab.m_AutoInertia, ab.m_Inertia, ab.m_InertiaRot, s_Mass);
            ab.s_Mass = (float)s_Mass[0];
            ab.s_LocalCom = new Vector3((float)s_Mass[1], (float)s_Mass[2], (float)s_Mass[3]);
            ab.s_Inertia = new Vector3((float)s_Mass[4], (float)s_Mass[5], (float)s_Mass[6]);
            ab.s_InertiaRot = Quaternion.Normalize(new Quaternion((float)s_Mass[7], (float)s_Mass[8], (float)s_Mass[9], (float)s_Mass[10]));
        }

        // ---------- structure ----------
        static void SyncArticulations()
        {
            foreach (var ab in s_Arts.ToArray()) if (ab.m_Destroyed) s_Arts.Remove(ab);
            // roots that should exist now
            var roots = new HashSet<ArticulationBody>();
            foreach (var ab in s_Arts) if (ArtActive(ab) && ArtParent(ab) == null) roots.Add(ab);
            // remove articulations whose root went away or whose shape changed
            foreach (var root in s_ArtBuilt.Keys.ToArray())
            {
                string sig = roots.Contains(root) ? Signature(Collect(root)) : null;
                if (sig == null || sig != s_ArtBuilt[root]) RemoveArticulation(root);
            }
            foreach (var root in roots) if (!s_ArtBuilt.ContainsKey(root)) BuildArticulation(root);
        }
        static string Signature(List<ArticulationBody> links)
        {
            var sb = new System.Text.StringBuilder();
            foreach (var l in links) { var p = ArtParent(l); sb.Append(l.m_InstanceID).Append(':').Append(p != null ? p.m_InstanceID : 0).Append(':').Append(l.structVersion).Append(';'); }
            return sb.ToString();
        }
        static void RemoveArticulation(ArticulationBody root)
        {
            if (s_ArtLinks.TryGetValue(root, out var links))
            {
                if (root.handle >= 0) backend.RemoveArticulation(root.handle);
                foreach (var l in links)
                {
                    if (l.handle >= 0) s_ArtByHandle.Remove(l.handle);
                    foreach (var c in s_Colliders) if (c.artOwner == l) { if (c.handle >= 0) s_ColliderByHandle.Remove(c.handle); c.handle = -1; c.bodyHandle = -1; c.artOwner = null; }
                    foreach (var j in s_Joints) if (j.handle >= 0 && (j.m_ConnectedArt == l)) { backend.RemoveJoint(j.handle); j.handle = -1; }
                    l.handle = -1; l.linkIndex = -1; l.root = null; l.builtParent = null;
                }
            }
            s_ArtBuilt.Remove(root); s_ArtLinks.Remove(root);
        }

        const int ART_LINK = 38;
        static void BuildArticulation(ArticulationBody root)
        {
            var links = Collect(root);
            var idx = new Dictionary<ArticulationBody, int>();
            for (int i = 0; i < links.Count; i++) idx[links[i]] = i;
            var spec = new double[5 + links.Count * ART_LINK];
            spec[0] = root.m_Immovable ? 1 : 0; spec[1] = root.m_SolverIterations; spec[2] = root.m_SolverVelIterations; spec[3] = root.m_Sleep; spec[4] = links.Count;
            for (int i = 0; i < links.Count; i++)
            {
                var l = links[i]; var t = l.m_GameObject.m_Transform;
                var parent = i == 0 ? null : ArtParent(l);
                int o = 5 + i * ART_LINK;
                Vector3 pc = t.position; Quaternion qc = t.rotation;
                spec[o] = parent != null ? idx[parent] : -1;
                spec[o + 1] = pc.x; spec[o + 2] = pc.y; spec[o + 3] = pc.z; spec[o + 4] = qc.x; spec[o + 5] = qc.y; spec[o + 6] = qc.z; spec[o + 7] = qc.w;
                spec[o + 8] = parent != null ? (int)l.m_JointType : 0;
                Vector3 a1 = Vector3.zero, a2 = Vector3.zero; Quaternion f1 = Quaternion.identity, f2 = Quaternion.identity;
                if (parent != null)
                {
                    var pt = parent.m_GameObject.m_Transform; Vector3 pp = pt.position; Quaternion qp = pt.rotation;
                    Vector3 worldAnchor = t.TransformPoint(l.m_AnchorPos);
                    Quaternion worldRot = qc * l.m_AnchorRot;
                    a2 = Quaternion.Inverse(qc) * (worldAnchor - pc); f2 = Quaternion.Normalize(l.m_AnchorRot);
                    if (l.m_MatchAnchors)
                    {
                        a1 = Quaternion.Inverse(qp) * (worldAnchor - pp); f1 = Quaternion.Normalize(Quaternion.Inverse(qp) * worldRot);
                        l.m_ParentAnchorPos = pt.InverseTransformPoint(worldAnchor); l.m_ParentAnchorRot = f1;
                    }
                    else
                    {
                        a1 = Quaternion.Inverse(qp) * (pt.TransformPoint(l.m_ParentAnchorPos) - pp); f1 = Quaternion.Normalize(l.m_ParentAnchorRot);
                    }
                }
                spec[o + 9] = a1.x; spec[o + 10] = a1.y; spec[o + 11] = a1.z; spec[o + 12] = f1.x; spec[o + 13] = f1.y; spec[o + 14] = f1.z; spec[o + 15] = f1.w;
                spec[o + 16] = a2.x; spec[o + 17] = a2.y; spec[o + 18] = a2.z; spec[o + 19] = f2.x; spec[o + 20] = f2.y; spec[o + 21] = f2.z; spec[o + 22] = f2.w;
                spec[o + 23] = l.m_LinDamp; spec[o + 24] = l.m_AngDamp; spec[o + 25] = l.m_MaxAngVel; spec[o + 26] = l.m_MaxLinVel;
                spec[o + 27] = l.m_UseGravity ? 1 : 0; spec[o + 28] = l.m_CDM != CollisionDetectionMode.Discrete ? 1 : 0;
                spec[o + 29] = l.m_MaxJointVel; spec[o + 30] = l.m_JointFriction; spec[o + 31] = l.m_MaxDepen;
                // which axes move (fixed when the articulation is built, like PhysX requires): twist, swing1, swing2, x, y, z
                var jt = parent != null ? l.m_JointType : ArticulationJointType.FixedJoint;
                bool rev = jt == ArticulationJointType.RevoluteJoint, sph = jt == ArticulationJointType.SphericalJoint, pri = jt == ArticulationJointType.PrismaticJoint;
                spec[o + 32] = rev || sph ? (int)l.m_Twist : 0; spec[o + 33] = sph ? (int)l.m_SwingY : 0; spec[o + 34] = sph ? (int)l.m_SwingZ : 0;
                int pa = l.m_LinX != ArticulationDofLock.LockedMotion ? 0 : l.m_LinY != ArticulationDofLock.LockedMotion ? 1 : 2;
                spec[o + 35] = pri && pa == 0 ? (int)l.m_LinX : 0; spec[o + 36] = pri && pa == 1 ? (int)l.m_LinY : 0; spec[o + 37] = pri && pa == 2 ? (int)l.m_LinZ : 0;
            }
            var ids = backend.CreateArticulation(spec);
            if (ids == null || ids.Length != links.Count)
            {
                if (!s_WarnedNoArt) { s_WarnedNoArt = true; Debug.LogWarning("ArticulationBody needs the PhysX physics engine (Project Settings › Physics Engine › PhysX). These bodies won't move."); }
                s_ArtBuilt[root] = Signature(links); s_ArtLinks[root] = links;
                return;
            }
            for (int i = 0; i < links.Count; i++)
            {
                var l = links[i]; var t = l.m_GameObject.m_Transform;
                l.handle = ids[i]; l.linkIndex = i; l.root = root; l.builtParent = i == 0 ? null : ArtParent(l);
                s_ArtByHandle[l.handle] = l;
                l.driveDirty = true; l.massDirty = true;
                l.lastPos = t.position; l.lastRot = t.rotation; l.hasLast = true;
                l.s_Pos = l.lastPos; l.s_Rot = l.lastRot; l.s_HasState = true;
                l.ownerDepth = Depth(t);
                Array.Clear(l.s_JointPos, 0, 6); Array.Clear(l.s_JointVel, 0, 6); Array.Clear(l.s_JointLoad, 0, 6); Array.Clear(l.s_PrevVel, 0, 6); Array.Clear(l.s_JointAcc, 0, 6);
            }
            s_ArtBuilt[root] = Signature(links); s_ArtLinks[root] = links;
            // colliders on these links are (re)built against the new link bodies
            foreach (var c in s_Colliders) if (c.handle >= 0 && c.artOwner == null && FindArtOwner(c) != null && links.Contains(FindArtOwner(c))) RemoveCollider(c);
            s_StructureDirty = true;
        }

        /// the ArticulationBody a collider belongs to, if an ArticulationBody is nearer above it than any Rigidbody
        internal static ArticulationBody FindArtOwner(Collider col)
        {
            var t = col.m_GameObject?.m_Transform;
            while (t != null)
            {
                foreach (var c in t.m_GameObject.m_Components)
                {
                    if (c is Rigidbody rb && !rb.m_Destroyed) return null;
                    if (c is ArticulationBody ab && !ab.m_Destroyed) return ArtActive(ab) || !World.isPlaying ? ab : null;
                }
                t = t.m_Parent;
            }
            return null;
        }

        // ---------- per step ----------
        static void Axis(double[] c, ref int k, ArticulationDofLock lk, ArticulationDrive d, bool angular, bool used)
        {
            float sc = angular ? Mathf.Deg2Rad : 1f;
            c[k++] = used ? (int)lk : 0;
            c[k++] = d.lowerLimit * sc; c[k++] = d.upperLimit * sc;
            float stiff = d.stiffness, damp = d.damping; int type = d.driveType == ArticulationDriveType.Force ? 0 : 1;
            float dt = Math.Max(1e-4f, Time.fixedDeltaTime);
            if (d.driveType == ArticulationDriveType.Target) { stiff = 1f / (dt * dt); damp = 0; }
            else if (d.driveType == ArticulationDriveType.Velocity) { stiff = 0; damp = 1f / dt; }
            c[k++] = used ? stiff : 0; c[k++] = used ? damp : 0; c[k++] = d.forceLimit <= 0 ? 0 : Math.Min(d.forceLimit, 3.4e38f);
            c[k++] = d.target * sc; c[k++] = d.targetVelocity * sc; c[k++] = type;
        }
        static void SyncArtPoses()
        {
            foreach (var ab in s_ArtByHandle.Values)
            {
                if (ab.m_Destroyed) continue;
                if (ab.massDirty) ComputeArtMass(ab);
                bool isRoot = ab.linkIndex == 0;
                if (ab.driveDirty && !isRoot)
                {
                    ab.driveDirty = false;
                    Need(2 + 54);
                    s_Cmd[s_CmdLen++] = 13; s_Cmd[s_CmdLen++] = ab.handle;
                    var jt = ab.m_JointType; int k = s_CmdLen; var c = s_Cmd;
                    bool rev = jt == ArticulationJointType.RevoluteJoint, sph = jt == ArticulationJointType.SphericalJoint, pri = jt == ArticulationJointType.PrismaticJoint;
                    Axis(c, ref k, ab.m_Twist, ab.m_XDrive, true, rev || sph);
                    Axis(c, ref k, ab.m_SwingY, ab.m_YDrive, true, sph);
                    Axis(c, ref k, ab.m_SwingZ, ab.m_ZDrive, true, sph);
                    Axis(c, ref k, ab.m_LinX, ab.m_XDrive, false, pri);
                    Axis(c, ref k, ab.m_LinY, ab.m_YDrive, false, pri);
                    Axis(c, ref k, ab.m_LinZ, ab.m_ZDrive, false, pri);
                    s_CmdLen = k;
                }
                else if (ab.driveDirty) ab.driveDirty = false;
                if (ab.pendingJointPos != null && !isRoot)
                {
                    Need(8); s_Cmd[s_CmdLen++] = 14; s_Cmd[s_CmdLen++] = ab.handle;
                    for (int a = 0; a < 6; a++) s_Cmd[s_CmdLen++] = ab.pendingJointPos[a];
                    ab.pendingJointPos = null;
                }
                bool wake = ab.pendingWake;
                if (isRoot)
                {
                    var t = ab.m_GameObject.m_Transform;
                    if (ab.pendingRootPos.HasValue || ab.pendingRootRot.HasValue)
                    {
                        CmdPose(1, ab.handle, ab.pendingRootPos ?? t.position, ab.pendingRootRot ?? t.rotation);
                        ab.pendingRootPos = null; ab.pendingRootRot = null; wake = true;
                    }
                    else if (ab.hasLast && (t.position != ab.lastPos || t.rotation != ab.lastRot))
                    {
                        // the root was moved from a script or the Inspector: move the whole articulation
                        CmdPose(1, ab.handle, t.position, t.rotation);
                        ab.lastPos = t.position; ab.lastRot = t.rotation; wake = true;
                    }
                    if (ab.pendingRootVel.HasValue) { Cmd(2, ab.handle, ab.pendingRootVel.Value); ab.pendingRootVel = null; wake = true; }
                    if (ab.pendingRootAngVel.HasValue) { Cmd(3, ab.handle, ab.pendingRootAngVel.Value); ab.pendingRootAngVel = null; wake = true; }
                }
                if (ab.accImpulse != Vector3.zero) { Cmd(4, ab.handle, ab.accImpulse); ab.accImpulse = Vector3.zero; }
                if (ab.accTorqueImpulse != Vector3.zero) { Cmd(5, ab.handle, ab.accTorqueImpulse); ab.accTorqueImpulse = Vector3.zero; }
                if (ab.accAngVelChange != Vector3.zero) { Cmd(6, ab.handle, ab.accAngVelChange); ab.accAngVelChange = Vector3.zero; }
                if (wake) { Cmd1(7, ab.handle); ab.pendingWake = false; }
                if (ab.pendingSleep) { Cmd1(8, ab.handle); ab.pendingSleep = false; }
            }
        }

        static bool ApplyArtBody(int h, double[] st, int i)
        {
            if (!s_ArtByHandle.TryGetValue(h, out var ab) || ab.m_Destroyed) return false;
            ab.s_Pos = new Vector3((float)st[i + 1], (float)st[i + 2], (float)st[i + 3]);
            ab.s_Rot = Quaternion.Normalize(new Quaternion((float)st[i + 4], (float)st[i + 5], (float)st[i + 6], (float)st[i + 7]));
            ab.s_LinVel = new Vector3((float)st[i + 8], (float)st[i + 9], (float)st[i + 10]);
            ab.s_AngVel = new Vector3((float)st[i + 11], (float)st[i + 12], (float)st[i + 13]);
            ab.s_WorldCom = new Vector3((float)st[i + 14], (float)st[i + 15], (float)st[i + 16]);
            ab.s_Sleeping = st[i + 17] != 0; ab.s_HasState = true;
            s_ArtWrites.Add((ab, ab.s_Pos, ab.s_Rot));
            return true;
        }
        static readonly List<(ArticulationBody ab, Vector3 p, Quaternion q)> s_ArtWrites = new List<(ArticulationBody, Vector3, Quaternion)>();
        static void WriteArtPoses()
        {
            s_ArtWrites.Sort((a, b) => a.ab.ownerDepth.CompareTo(b.ab.ownerDepth));
            foreach (var (ab, p, q) in s_ArtWrites)
            {
                var t = ab.m_GameObject.m_Transform;
                t.SetWorldPoseFromPhysics(p, q);
                ab.lastPos = t.position; ab.lastRot = t.rotation; ab.hasLast = true;
            }
            s_ArtWrites.Clear();
        }
        // per link: id, 6 joint positions, 6 joint velocities, 6 loads (force xyz, torque xyz in the joint frame)
        static int ReadArtJoints(double[] st, int i, float dt)
        {
            if (i >= st.Length) return i;
            int n = (int)st[i++];
            for (int k = 0; k < n && i + 19 <= st.Length; k++)
            {
                int h = (int)st[i];
                if (s_ArtByHandle.TryGetValue(h, out var ab))
                {
                    for (int a = 0; a < 6; a++)
                    {
                        ab.s_JointPos[a] = (float)st[i + 1 + a];
                        float v = (float)st[i + 7 + a];
                        ab.s_JointAcc[a] = dt > 0 ? (v - ab.s_PrevVel[a]) / dt : 0; ab.s_PrevVel[a] = v;
                        ab.s_JointVel[a] = v;
                    }
                    // load along each axis: torque about twist/swing1/swing2, force along x/y/z
                    ab.s_JointLoad[0] = (float)st[i + 16]; ab.s_JointLoad[1] = (float)st[i + 17]; ab.s_JointLoad[2] = (float)st[i + 18];
                    ab.s_JointLoad[3] = (float)st[i + 13]; ab.s_JointLoad[4] = (float)st[i + 14]; ab.s_JointLoad[5] = (float)st[i + 15];
                }
                i += 19;
            }
            return i;
        }
    }
}
