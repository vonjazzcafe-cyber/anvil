// TextMesh Pro: TMP_Text, TextMeshProUGUI, TextMeshPro (3D), TMP_InputField, TMP_Dropdown and the common helper types.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Anvil;

namespace TMPro
{
    [Flags] public enum FontStyles { Normal = 0, Bold = 1, Italic = 2, Underline = 4, LowerCase = 8, UpperCase = 16, SmallCaps = 32, Strikethrough = 64, Superscript = 128, Subscript = 256, Highlight = 512 }
    public enum FontWeight { Thin = 100, ExtraLight = 200, Light = 300, Regular = 400, Medium = 500, SemiBold = 600, Bold = 700, Heavy = 800, Black = 900 }
    public enum HorizontalAlignmentOptions { Left = 1, Center = 2, Right = 4, Justified = 8, Flush = 16, Geometry = 32 }
    public enum VerticalAlignmentOptions { Top = 256, Middle = 512, Bottom = 1024, Baseline = 2048, Geometry = 4096, Capline = 8192 }
    public enum TextAlignmentOptions { TopLeft = 257, Top = 258, TopRight = 260, TopJustified = 264, TopFlush = 272, TopGeoAligned = 288, Left = 513, Center = 514, Right = 516, Justified = 520, Flush = 528, CenterGeoAligned = 544, BottomLeft = 1025, Bottom = 1026, BottomRight = 1028, BottomJustified = 1032, BottomFlush = 1040, BottomGeoAligned = 1056, BaselineLeft = 2049, Baseline = 2050, BaselineRight = 2052, BaselineJustified = 2056, BaselineFlush = 2064, BaselineGeoAligned = 2080, MidlineLeft = 4097, Midline = 4098, MidlineRight = 4100, MidlineJustified = 4104, MidlineFlush = 4112, MidlineGeoAligned = 4128, CaplineLeft = 8193, Capline = 8194, CaplineRight = 8196, CaplineJustified = 8200, CaplineFlush = 8208, CaplineGeoAligned = 8224, Converted = 65535 }
    public enum TextOverflowModes { Overflow = 0, Ellipsis = 1, Masking = 2, Truncate = 3, ScrollRect = 4, Page = 5, Linked = 6 }
    public enum TextWrappingModes { NoWrap = 0, Normal = 1, PreserveWhitespace = 2, PreserveWhitespaceNoWrap = 3 }
    public enum TextureMappingOptions { Character = 0, Line = 1, Paragraph = 2, MatchAspect = 3 }
    public enum MaskingTypes { MaskOff = 0, MaskHard = 1, MaskSoft = 2 }
    public enum ColorMode { Single = 0, HorizontalGradient = 1, VerticalGradient = 2, FourCornersGradient = 3 }
    public enum TextRenderFlags { DontRender = 0, Render = 255 }
    public enum TMP_TextElementType { Character = 0, Sprite = 1 }
    public enum VertexSortingOrder { Normal = 0, Reverse = 1 }
    [Flags] public enum TMP_VertexDataUpdateFlags { None = 0, Vertices = 1, Uv0 = 2, Uv2 = 4, Uv4 = 8, Colors32 = 16, All = 255 }

    [Serializable]
    public struct VertexGradient
    {
        public Color topLeft, topRight, bottomLeft, bottomRight;
        public VertexGradient(Color color) { topLeft = topRight = bottomLeft = bottomRight = color; }
        public VertexGradient(Color color0, Color color1, Color color2, Color color3) { topLeft = color0; topRight = color1; bottomLeft = color2; bottomRight = color3; }
    }
    public class TMP_ColorGradient : ScriptableObject { public ColorMode colorMode = ColorMode.FourCornersGradient; public Color topLeft = Color.white, topRight = Color.white, bottomLeft = Color.white, bottomRight = Color.white; }
    public abstract class TMP_Asset : ScriptableObject { public int hashCode; public Material material; public int materialHashCode; }
    [Serializable] public struct FaceInfo_Legacy { public string Name; public float PointSize, Scale, LineHeight, Ascender, CapHeight, Baseline, Descender; }
    public class TMP_FontAsset : TMP_Asset
    {
        internal Font m_SourceFont;
        public UnityEngine.TextCore.FaceInfo faceInfo { get; set; }
        public Font sourceFontFile => m_SourceFont;
        public List<TMP_FontAsset> fallbackFontAssetTable { get; set; } = new List<TMP_FontAsset>();
        public static TMP_FontAsset CreateFontAsset(Font font) { var a = CreateInstance<TMP_FontAsset>(); a.m_SourceFont = font; a.name = font != null ? font.name + " SDF" : "Font SDF"; return a; }
        public bool HasCharacter(char character) => true;
        public bool HasCharacter(int character) => true;
        public bool HasCharacters(string text) => true;
        public bool HasCharacters(string text, out List<char> missingCharacters) { missingCharacters = new List<char>(); return true; }
        public bool TryAddCharacters(string characters) => true;
        internal string Family => m_SourceFont == null ? null : (m_SourceFont.fontNames != null && m_SourceFont.fontNames.Length > 0 ? string.Join(",", m_SourceFont.fontNames) : m_SourceFont.name);
    }
    public class TMP_SpriteAsset : TMP_Asset { }
    public class TMP_StyleSheet : ScriptableObject { }
    public class TMP_Settings : ScriptableObject
    {
        static TMP_FontAsset s_Default;
        public static TMP_Settings instance => null;
        public static TMP_FontAsset defaultFontAsset => s_Default ??= TMP_FontAsset.CreateFontAsset(null);
        public static bool enableWordWrapping => true;
        public static bool enableKerning => true;
        public static bool enableExtraPadding => false;
        public static float defaultFontSize => 36;
        public static bool autoSizeTextContainer => false;
        public static bool isTextObjectScaleStatic { get; set; }
        public static List<TMP_FontAsset> fallbackFontAssets => new List<TMP_FontAsset>();
    }

    public struct TMP_CharacterInfo
    {
        public char character; public int index, stringLength, lineNumber, pageNumber, vertexIndex, materialReferenceIndex;
        public TMP_TextElementType elementType; public bool isVisible; public float pointSize, scale, xAdvance, aspectRatio;
        public Vector3 topLeft, bottomLeft, topRight, bottomRight, vertex_TL_position;
        public float origin, ascender, baseLine, descender; public Color32 color; public FontStyles style;
    }
    public struct TMP_LineInfo { public int characterCount, visibleCharacterCount, spaceCount, wordCount, firstCharacterIndex, firstVisibleCharacterIndex, lastCharacterIndex, lastVisibleCharacterIndex; public float length, lineHeight, ascender, baseline, descender, maxAdvance, width; public TextAlignmentOptions alignment; }
    public struct TMP_WordInfo { public TMP_Text textComponent; public int firstCharacterIndex, lastCharacterIndex, characterCount; public string GetWord() { var t = textComponent != null ? UIText.StripTags(textComponent.text, textComponent.richText) : ""; return firstCharacterIndex >= 0 && lastCharacterIndex < t.Length && lastCharacterIndex >= firstCharacterIndex ? t.Substring(firstCharacterIndex, lastCharacterIndex - firstCharacterIndex + 1) : ""; } }
    public struct TMP_LinkInfo { public TMP_Text textComponent; public int hashCode, linkIdFirstCharacterIndex, linkIdLength, linkTextfirstCharacterIndex, linkTextLength; public string GetLinkID() => ""; public string GetLinkText() => ""; }
    public struct TMP_MeshInfo { public Mesh mesh; public int vertexCount; public Vector3[] vertices; public Vector2[] uvs0; public Color32[] colors32; public int[] triangles; }
    public class TMP_TextInfo
    {
        public TMP_Text textComponent;
        public int characterCount, spriteCount, spaceCount, wordCount, linkCount, lineCount, pageCount, materialCount;
        public TMP_CharacterInfo[] characterInfo = new TMP_CharacterInfo[8];
        public TMP_WordInfo[] wordInfo = new TMP_WordInfo[4];
        public TMP_LinkInfo[] linkInfo = new TMP_LinkInfo[0];
        public TMP_LineInfo[] lineInfo = new TMP_LineInfo[2];
        public TMP_MeshInfo[] meshInfo = new TMP_MeshInfo[1];
        public TMP_TextInfo() { }
        public TMP_TextInfo(TMP_Text textComponent) { this.textComponent = textComponent; }
        public void Clear() { characterCount = spriteCount = spaceCount = wordCount = linkCount = lineCount = pageCount = 0; }
        public void ClearMeshInfo(bool updateMesh) { }
        public void ClearAllMeshInfo() { }
        public void ResetVertexLayout(bool isVolumetric) { }
        public TMP_MeshInfo[] CopyMeshInfoVertexData() => meshInfo;
    }

    public abstract class TMP_Text : MaskableGraphic
    {
        [SerializeField] [TextArea(5, 10)] protected string m_text = "";
        [SerializeField] protected TMP_FontAsset m_fontAsset;
        [SerializeField] protected Material m_sharedMaterial;
        [SerializeField] protected float m_fontSize = 36, m_fontSizeMin = 18, m_fontSizeMax = 72;
        [SerializeField] protected bool m_enableAutoSizing;
        [SerializeField] protected FontStyles m_fontStyle = FontStyles.Normal;
        [SerializeField] protected FontWeight m_fontWeight = FontWeight.Regular;
        [SerializeField] protected TextAlignmentOptions m_textAlignment = TextAlignmentOptions.TopLeft;
        [SerializeField] protected float m_characterSpacing, m_wordSpacing, m_lineSpacing, m_paragraphSpacing;
        [SerializeField] protected TextWrappingModes m_TextWrappingMode = TextWrappingModes.Normal;
        [SerializeField] protected TextOverflowModes m_overflowMode = TextOverflowModes.Overflow;
        [SerializeField] protected Vector4 m_margin;
        [SerializeField] protected bool m_isRichText = true;
        [SerializeField] protected bool m_enableVertexGradient;
        [SerializeField] protected VertexGradient m_fontColorGradient = new VertexGradient(Color.white);
        [SerializeField] protected Color32 m_outlineColor = new Color32(0, 0, 0, 255);
        [SerializeField] protected float m_outlineWidth;
        [SerializeField] protected int m_maxVisibleCharacters = 99999, m_maxVisibleWords = 99999, m_maxVisibleLines = 99999, m_firstVisibleCharacter, m_pageToDisplay = 1;
        [SerializeField] protected bool m_isRightToLeft, m_enableKerning = true, m_parseCtrlCharacters = true, m_isOrthographic = true, m_autoSizeTextContainer;
        [NonSerialized] TMP_TextInfo m_textInfo;
        public virtual string text { get => m_text; set { if (m_text == value) return; m_text = value ?? ""; SetLayoutDirty(); } }
        public TMP_FontAsset font { get => m_fontAsset; set => m_fontAsset = value; }
        public virtual Material fontSharedMaterial { get => m_sharedMaterial; set => m_sharedMaterial = value; }
        public virtual Material[] fontSharedMaterials { get => new[] { m_sharedMaterial }; set { } }
        public Material fontMaterial { get => m_sharedMaterial; set => m_sharedMaterial = value; }
        public virtual Material[] fontMaterials { get => new[] { m_sharedMaterial }; set { } }
        public override Color color { get => base.color; set => base.color = value; }
        public float alpha { get => color.a; set { var c = color; c.a = value; color = c; } }
        public bool enableVertexGradient { get => m_enableVertexGradient; set => m_enableVertexGradient = value; }
        public VertexGradient colorGradient { get => m_fontColorGradient; set => m_fontColorGradient = value; }
        public TMP_ColorGradient colorGradientPreset { get; set; }
        public TMP_SpriteAsset spriteAsset { get; set; }
        public bool tintAllSprites { get; set; }
        public TMP_StyleSheet styleSheet { get; set; }
        public bool overrideColorTags { get; set; }
        public Color32 faceColor { get => color; set => color = value; }
        public Color32 outlineColor { get => m_outlineColor; set => m_outlineColor = value; }
        public float outlineWidth { get => m_outlineWidth; set => m_outlineWidth = value; }
        public float fontSize { get => m_fontSize; set { m_fontSize = value; SetLayoutDirty(); } }
        public float fontScale => 1f;
        public FontWeight fontWeight { get => m_fontWeight; set => m_fontWeight = value; }
        public float pixelsPerUnit => 1f;
        public bool enableAutoSizing { get => m_enableAutoSizing; set => m_enableAutoSizing = value; }
        public float fontSizeMin { get => m_fontSizeMin; set => m_fontSizeMin = value; }
        public float fontSizeMax { get => m_fontSizeMax; set => m_fontSizeMax = value; }
        public FontStyles fontStyle { get => m_fontStyle; set => m_fontStyle = value; }
        public bool isUsingBold => (m_fontStyle & FontStyles.Bold) != 0;
        public HorizontalAlignmentOptions horizontalAlignment { get => (HorizontalAlignmentOptions)((int)m_textAlignment & 0xFF); set => m_textAlignment = (TextAlignmentOptions)(((int)m_textAlignment & 0xFF00) | (int)value); }
        public VerticalAlignmentOptions verticalAlignment { get => (VerticalAlignmentOptions)((int)m_textAlignment & 0xFF00); set => m_textAlignment = (TextAlignmentOptions)(((int)m_textAlignment & 0xFF) | (int)value); }
        public TextAlignmentOptions alignment { get => m_textAlignment; set => m_textAlignment = value; }
        public float characterSpacing { get => m_characterSpacing; set => m_characterSpacing = value; }
        public float wordSpacing { get => m_wordSpacing; set => m_wordSpacing = value; }
        public float lineSpacing { get => m_lineSpacing; set => m_lineSpacing = value; }
        public float lineSpacingAdjustment { get; set; }
        public float paragraphSpacing { get => m_paragraphSpacing; set => m_paragraphSpacing = value; }
        public float characterWidthAdjustment { get; set; }
        public TextWrappingModes textWrappingMode { get => m_TextWrappingMode; set => m_TextWrappingMode = value; }
        [Obsolete("The enabledWordWrapping property is now obsolete. Please use the textWrappingMode property instead.")]
        public bool enableWordWrapping { get => m_TextWrappingMode == TextWrappingModes.Normal || m_TextWrappingMode == TextWrappingModes.PreserveWhitespace; set => m_TextWrappingMode = value ? TextWrappingModes.Normal : TextWrappingModes.NoWrap; }
        public float wordWrappingRatios { get; set; } = 0.4f;
        public TextOverflowModes overflowMode { get => m_overflowMode; set => m_overflowMode = value; }
        public bool isTextOverflowing { get { var r = MarginRect(); var m = UIText.Measure(DisplayText(), m_fontSize, isUsingBold, Wraps ? r.width : -1, LineMul, m_characterSpacing / 100f, m_isRichText); return m.y > r.height + 0.5f || (!Wraps && m.x > r.width + 0.5f); } }
        public int firstOverflowCharacterIndex => -1;
        public TMP_Text linkedTextComponent { get; set; }
        public bool isTextTruncated => false;
        public bool enableKerning { get => m_enableKerning; set => m_enableKerning = value; }
        public bool fontFeatures => true;
        public bool extraPadding { get; set; }
        public bool richText { get => m_isRichText; set => m_isRichText = value; }
        public bool emojiFallbackSupport { get; set; } = true;
        public bool parseCtrlCharacters { get => m_parseCtrlCharacters; set => m_parseCtrlCharacters = value; }
        public bool isOverlay { get; set; }
        public bool isOrthographic { get => m_isOrthographic; set => m_isOrthographic = value; }
        public bool enableCulling { get; set; }
        public bool ignoreVisibility { get; set; }
        public TextureMappingOptions horizontalMapping { get; set; }
        public TextureMappingOptions verticalMapping { get; set; }
        public float mappingUvLineOffset { get; set; }
        public TextRenderFlags renderMode { get; set; } = TextRenderFlags.Render;
        public VertexSortingOrder geometrySortingOrder { get; set; }
        public bool isTextObjectScaleStatic { get; set; }
        public bool vertexBufferAutoSizeReduction { get; set; }
        public int firstVisibleCharacter { get => m_firstVisibleCharacter; set => m_firstVisibleCharacter = value; }
        public int maxVisibleCharacters { get => m_maxVisibleCharacters; set => m_maxVisibleCharacters = value; }
        public int maxVisibleWords { get => m_maxVisibleWords; set => m_maxVisibleWords = value; }
        public int maxVisibleLines { get => m_maxVisibleLines; set => m_maxVisibleLines = value; }
        public bool useMaxVisibleDescender { get; set; } = true;
        public int pageToDisplay { get => m_pageToDisplay; set => m_pageToDisplay = value; }
        public virtual Vector4 margin { get => m_margin; set => m_margin = value; }
        public TMP_TextInfo textInfo { get { if (m_textInfo == null) m_textInfo = new TMP_TextInfo(this); FillTextInfo(m_textInfo); return m_textInfo; } }
        public bool havePropertiesChanged { get; set; }
        public bool isUsingLegacyAnimationComponent { get; set; }
        public new Transform transform => base.transform;
        public new RectTransform rectTransform => base.rectTransform;
        public virtual bool autoSizeTextContainer { get => m_autoSizeTextContainer; set => m_autoSizeTextContainer = value; }
        public virtual Mesh mesh => null;
        public bool isVolumetricText { get; set; }
        public Bounds bounds { get { var r = rectTransform.rect; var m = GetPreferredValues(); return new Bounds(new Vector3(r.center.x, r.center.y), new Vector3(Mathf.Min(m.x, r.width), Mathf.Min(m.y, r.height))); } }
        public Bounds textBounds => bounds;
        public float flexibleHeight => -1;
        public float flexibleWidth => -1;
        public float minWidth => 0;
        public float minHeight => 0;
        public float maxWidth => 10000;
        public float maxHeight => 10000;
        public float preferredWidth => GetPreferredValues().x;
        public float preferredHeight => GetPreferredValues(rectTransform.rect.width, 0).y;
        public float renderedWidth => Mathf.Min(preferredWidth, rectTransform.rect.width);
        public float renderedHeight => Mathf.Min(preferredHeight, rectTransform.rect.height);
        public int layoutPriority => 0;
        public bool isRightToLeftText { get => m_isRightToLeft; set => m_isRightToLeft = value; }
        public virtual void CalculateLayoutInputHorizontal() { }
        public virtual void CalculateLayoutInputVertical() { }
        public Vector2 GetPreferredValues() => GetPreferredValues(-1, -1);
        public Vector2 GetPreferredValues(float width, float height)
        {
            var m = UIText.Measure(DisplayText(), m_fontSize, isUsingBold, Wraps && width > 0 ? width - m_margin.x - m_margin.z : -1, LineMul, m_characterSpacing / 100f, m_isRichText);
            return new Vector2(m.x + m_margin.x + m_margin.z, m.y + m_margin.y + m_margin.w);
        }
        public Vector2 GetPreferredValues(string text) { var m = UIText.Measure(text, m_fontSize, isUsingBold, -1, LineMul, m_characterSpacing / 100f, m_isRichText); return m; }
        public Vector2 GetPreferredValues(string text, float width, float height) { var m = UIText.Measure(text, m_fontSize, isUsingBold, Wraps ? width : -1, LineMul, m_characterSpacing / 100f, m_isRichText); return m; }
        public Vector2 GetRenderedValues() => new Vector2(renderedWidth, renderedHeight);
        public Vector2 GetRenderedValues(bool onlyVisibleCharacters) => GetRenderedValues();
        public TMP_TextInfo GetTextInfo(string text) { var ti = new TMP_TextInfo(this); FillTextInfo(ti, text); return ti; }
        public virtual void ForceMeshUpdate(bool ignoreActiveState = false, bool forceTextReparsing = false) { }
        public virtual void UpdateGeometry(Mesh mesh, int index) { }
        public virtual void UpdateVertexData(TMP_VertexDataUpdateFlags flags) { }
        public virtual void UpdateVertexData() { }
        public virtual void SetVertices(Vector3[] vertices) { }
        public virtual void UpdateMeshPadding() { }
        public virtual void ClearMesh() { }
        public virtual void ClearMesh(bool uploadGeometry) { }
        public virtual string GetParsedText() => UIText.StripTags(m_text, m_isRichText);
        public void SetText(string sourceText) => text = sourceText;
        public void SetText(string sourceText, bool syncTextInputBox) => text = sourceText;
        public void SetText(string sourceText, float arg0) => text = Format(sourceText, arg0, 0, 0, 0, 0, 0, 0, 0);
        public void SetText(string sourceText, float arg0, float arg1) => text = Format(sourceText, arg0, arg1, 0, 0, 0, 0, 0, 0);
        public void SetText(string sourceText, float arg0, float arg1, float arg2) => text = Format(sourceText, arg0, arg1, arg2, 0, 0, 0, 0, 0);
        public void SetText(string sourceText, float arg0, float arg1, float arg2, float arg3) => text = Format(sourceText, arg0, arg1, arg2, arg3, 0, 0, 0, 0);
        public void SetText(string sourceText, float arg0, float arg1, float arg2, float arg3, float arg4) => text = Format(sourceText, arg0, arg1, arg2, arg3, arg4, 0, 0, 0);
        public void SetText(string sourceText, float arg0, float arg1, float arg2, float arg3, float arg4, float arg5) => text = Format(sourceText, arg0, arg1, arg2, arg3, arg4, arg5, 0, 0);
        public void SetText(string sourceText, float arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6) => text = Format(sourceText, arg0, arg1, arg2, arg3, arg4, arg5, arg6, 0);
        public void SetText(string sourceText, float arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6, float arg7) => text = Format(sourceText, arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
        public void SetText(StringBuilder sourceText) => text = sourceText?.ToString() ?? "";
        public void SetText(char[] sourceText) => text = sourceText != null ? new string(sourceText) : "";
        public void SetText(char[] sourceText, int start, int length) => text = sourceText != null ? new string(sourceText, start, length) : "";
        public void SetCharArray(char[] sourceText) => SetText(sourceText);
        public void SetCharArray(char[] sourceText, int start, int length) => SetText(sourceText, start, length);
        // TMP's format: {0} {1:2} (2 decimals) {0:00.0} (pattern)
        static string Format(string src, params float[] args)
        {
            if (src == null) return "";
            var sb = new StringBuilder();
            for (int i = 0; i < src.Length; i++)
            {
                char c = src[i];
                if (c == '{' && i + 2 < src.Length && char.IsDigit(src[i + 1]))
                {
                    int close = src.IndexOf('}', i);
                    if (close > 0)
                    {
                        string inner = src.Substring(i + 1, close - i - 1);
                        string idxS = inner, fmt = null;
                        int colon = inner.IndexOf(':'); if (colon >= 0) { idxS = inner.Substring(0, colon); fmt = inner.Substring(colon + 1); }
                        if (int.TryParse(idxS, out int idx) && idx >= 0 && idx < args.Length)
                        {
                            float v = args[idx];
                            if (fmt == null) sb.Append(v.ToString(CultureInfo.InvariantCulture));
                            else if (int.TryParse(fmt, out int dec)) sb.Append(v.ToString("F" + dec, CultureInfo.InvariantCulture));
                            else sb.Append(v.ToString(fmt, CultureInfo.InvariantCulture));
                            i = close; continue;
                        }
                    }
                }
                sb.Append(c);
            }
            return sb.ToString();
        }
        void FillTextInfo(TMP_TextInfo ti, string source = null)
        {
            string t = UIText.StripTags(source ?? m_text, m_isRichText);
            ti.characterCount = t.Length;
            if (ti.characterInfo.Length < t.Length) ti.characterInfo = new TMP_CharacterInfo[Mathf.NextPowerOfTwo(t.Length + 1)];
            int line = 0, words = 0; bool inWord = false; ti.spaceCount = 0;
            for (int i = 0; i < t.Length; i++)
            {
                char ch = t[i];
                ti.characterInfo[i] = new TMP_CharacterInfo { character = ch, index = i, lineNumber = line, isVisible = !char.IsWhiteSpace(ch), pointSize = m_fontSize, color = color, style = m_fontStyle };
                if (ch == '\n') line++;
                if (char.IsWhiteSpace(ch)) { inWord = false; if (ch == ' ') ti.spaceCount++; }
                else if (!inWord) { inWord = true; words++; }
            }
            ti.wordCount = words;
            var r = MarginRect();
            var m = UIText.Measure(t, m_fontSize, isUsingBold, Wraps ? r.width : -1, LineMul, m_characterSpacing / 100f, false);
            ti.lineCount = t.Length == 0 ? 0 : Mathf.Max(line + 1, Mathf.RoundToInt(m.y / Mathf.Max(0.01f, m_fontSize * 1.15f * LineMul)));
            ti.pageCount = 1;
        }
        internal bool Wraps => m_TextWrappingMode == TextWrappingModes.Normal || m_TextWrappingMode == TextWrappingModes.PreserveWhitespace;
        internal float LineMul => 1f + m_lineSpacing / 100f;
        internal Rect MarginRect() { var r = rectTransform.rect; return new Rect(r.x + m_margin.x, r.y + m_margin.w, r.width - m_margin.x - m_margin.z, r.height - m_margin.y - m_margin.w); }
        internal string DisplayText()
        {
            string t = m_text ?? "";
            if ((m_fontStyle & FontStyles.UpperCase) != 0) t = t.ToUpperInvariant();
            else if ((m_fontStyle & FontStyles.LowerCase) != 0) t = t.ToLowerInvariant();
            if (m_maxVisibleCharacters < 99999 || m_firstVisibleCharacter > 0)
            {
                // count visible characters, skipping rich text tags
                var sb = new StringBuilder(); int visible = 0;
                for (int i = 0; i < t.Length; i++)
                {
                    if (m_isRichText && t[i] == '<') { int close = t.IndexOf('>', i); if (close > i && close - i < 40) { sb.Append(t, i, close - i + 1); i = close; continue; } }
                    if (visible >= m_firstVisibleCharacter && visible - m_firstVisibleCharacter < m_maxVisibleCharacters) sb.Append(t[i]);
                    visible++;
                }
                t = sb.ToString();
            }
            return t;
        }
        internal float WorldScale => this is TextMeshPro ? 0.1f : 1f;
        internal override void Draw(UIDraw d)
        {
            var r = MarginRect();
            string t = DisplayText();
            float size = m_fontSize;
            if (m_enableAutoSizing) size = UIText.BestFit(t, m_fontSizeMin, m_fontSizeMax, r.size / WorldScale, LineMul, m_characterSpacing / 100f, m_isRichText, Wraps);
            int h = (int)m_textAlignment & 0xFF, v = (int)m_textAlignment & 0xFF00;
            int col = (h & 4) != 0 ? 2 : (h & 2) != 0 || (h & 32) != 0 ? 1 : 0;
            int row = v == 256 || v == 8192 ? 0 : v == 512 || v == 4096 ? 1 : 2;
            int style = (isUsingBold || m_fontWeight >= FontWeight.Bold ? 1 : 0) | ((m_fontStyle & FontStyles.Italic) != 0 ? 2 : 0);
            var sb = new StringBuilder("tmp=1;");
            if (m_lineSpacing != 0) sb.Append("ls=").Append(UIDraw.F(LineMul)).Append(';');
            if (m_characterSpacing != 0) sb.Append("cs=").Append(UIDraw.F(m_characterSpacing / 100f)).Append(';');
            if (m_wordSpacing != 0) sb.Append("ws=").Append(UIDraw.F(m_wordSpacing / 100f)).Append(';');
            if ((h & 8) != 0 || (h & 16) != 0) sb.Append("j=1;");
            if ((m_fontStyle & FontStyles.Underline) != 0) sb.Append("u=1;");
            if ((m_fontStyle & FontStyles.Strikethrough) != 0) sb.Append("st=1;");
            if ((m_fontStyle & FontStyles.SmallCaps) != 0) sb.Append("sc=1;");
            if (m_fontWeight != FontWeight.Regular) sb.Append("fw=").Append((int)m_fontWeight).Append(';');
            if (m_overflowMode == TextOverflowModes.Ellipsis) sb.Append("el=1;clip=1;");
            else if (m_overflowMode == TextOverflowModes.Masking || m_overflowMode == TextOverflowModes.Truncate || m_overflowMode == TextOverflowModes.Page || m_overflowMode == TextOverflowModes.ScrollRect) sb.Append("clip=1;");
            if (m_TextWrappingMode == TextWrappingModes.PreserveWhitespace || m_TextWrappingMode == TextWrappingModes.PreserveWhitespaceNoWrap) sb.Append("pw=1;");
            if (m_outlineWidth > 0) sb.Append("ow=").Append(UIDraw.Hex(m_outlineColor)).Append(',').Append(UIDraw.F(m_outlineWidth)).Append(';');
            if (m_enableVertexGradient) sb.Append("gr=").Append(UIDraw.Hex(m_fontColorGradient.topLeft)).Append(',').Append(UIDraw.Hex(m_fontColorGradient.bottomLeft)).Append(';');
            if (m_isRightToLeft) sb.Append("rtl=1;");
            UIEffects.Append(this, sb);
            var c = RenderColor(1f);
            d.HitOnly(this);
            d.TextBox(this, r, t, size * WorldScale, style, row * 3 + col, Wraps, m_isRichText, m_fontAsset?.Family, sb.ToString(), c);
        }
        public override string ToString() => m_text;
    }

    [AddComponentMenu("UI/TextMeshPro - Text (UI)", 11)]
    [ExecuteAlways]
    [RequireComponent(typeof(RectTransform))]
    [RequireComponent(typeof(CanvasRenderer))]
    [DisallowMultipleComponent]
    public class TextMeshProUGUI : TMP_Text, ILayoutElement
    {
        public override Material materialForRendering => fontSharedMaterial;
        public new float preferredWidth => base.preferredWidth;
        public new float preferredHeight => base.preferredHeight;
        public new float minWidth => 0;
        public new float minHeight => 0;
        public new float flexibleWidth => -1;
        public new float flexibleHeight => -1;
        public new int layoutPriority => 0;
        float ILayoutElement.minWidth => 0;
        float ILayoutElement.preferredWidth => base.preferredWidth;
        float ILayoutElement.flexibleWidth => -1;
        float ILayoutElement.minHeight => 0;
        float ILayoutElement.preferredHeight => base.preferredHeight;
        float ILayoutElement.flexibleHeight => -1;
        int ILayoutElement.layoutPriority => 0;
        public CanvasRenderer[] subMeshes => new CanvasRenderer[0];
        public override void SetAllDirty() { }
        public override void SetVerticesDirty() { }
        public override void SetLayoutDirty() => UIRuntime.MarkLayoutDirty();
        public override void SetMaterialDirty() { }
        public override void Rebuild(CanvasUpdate update) { }
        public override void UpdateMeshPadding() { }
        public void ComputeMarginSize() { }
        public override void ForceMeshUpdate(bool ignoreActiveState = false, bool forceTextReparsing = false) { }
    }

    [AddComponentMenu("Mesh/TextMeshPro - Text", 11)]
    [ExecuteAlways]
    [RequireComponent(typeof(RectTransform))]
    [DisallowMultipleComponent]
    public class TextMeshPro : TMP_Text, ILayoutElement
    {
        public int sortingLayerID { get; set; }
        public int sortingOrder { get; set; }
        public Renderer renderer => GetComponent<Renderer>();
        public override Material materialForRendering => fontSharedMaterial;
        float ILayoutElement.minWidth => 0;
        float ILayoutElement.preferredWidth => base.preferredWidth;
        float ILayoutElement.flexibleWidth => -1;
        float ILayoutElement.minHeight => 0;
        float ILayoutElement.preferredHeight => base.preferredHeight;
        float ILayoutElement.flexibleHeight => -1;
        int ILayoutElement.layoutPriority => 0;
        public new Transform transform => base.transform;
        public override void SetAllDirty() { }
        public override void SetVerticesDirty() { }
        public override void SetLayoutDirty() { }
        public override void SetMaterialDirty() { }
        public override void ForceMeshUpdate(bool ignoreActiveState = false, bool forceTextReparsing = false) { }
        public void SetMask(MaskingTypes type, Vector4 maskCoords) { }
        public void SetMask(MaskingTypes type, Vector4 maskCoords, float softnessX, float softnessY) { }
        internal override void OnAddedInternal()
        {
            base.OnAddedInternal();
            if (transform is RectTransform rt && rt.m_SizeDelta == new Vector2(100, 100)) rt.m_SizeDelta = new Vector2(20, 5);
        }
    }

    [AddComponentMenu("UI/TextMeshPro - Input Field", 11)]
    public class TMP_InputField : Selectable, IUpdateSelectedHandler, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerClickHandler, ISubmitHandler, ICancelHandler, ICanvasElement, ILayoutElement, IScrollHandler
    {
        public enum ContentType { Standard = 0, Autocorrected = 1, IntegerNumber = 2, DecimalNumber = 3, Alphanumeric = 4, Name = 5, EmailAddress = 6, Password = 7, Pin = 8, Custom = 9 }
        public enum InputType { Standard = 0, AutoCorrect = 1, Password = 2 }
        public enum CharacterValidation { None = 0, Digit = 1, Integer = 2, Decimal = 3, Alphanumeric = 4, Name = 5, Regex = 6, EmailAddress = 7, CustomValidator = 8 }
        public enum LineType { SingleLine = 0, MultiLineSubmit = 1, MultiLineNewline = 2 }
        public delegate char OnValidateInput(string text, int charIndex, char addedChar);
        [Serializable] public class SubmitEvent : UnityEvent<string> { }
        [Serializable] public class OnChangeEvent : UnityEvent<string> { }
        [Serializable] public class SelectionEvent : UnityEvent<string> { }
        [Serializable] public class TextSelectionEvent : UnityEvent<string, int, int> { }
        [Serializable] public class TouchScreenKeyboardEvent : UnityEvent<TouchScreenKeyboard.Status> { }
        [SerializeField] protected RectTransform m_TextViewport;
        [SerializeField] protected TMP_Text m_TextComponent;
        [SerializeField] protected Graphic m_Placeholder;
        [SerializeField] protected Scrollbar m_VerticalScrollbar;
        [SerializeField] ContentType m_ContentType = ContentType.Standard;
        [SerializeField] InputType m_InputType = InputType.Standard;
        [SerializeField] char m_AsteriskChar = '*';
        [SerializeField] TouchScreenKeyboardType m_KeyboardType;
        [SerializeField] LineType m_LineType = LineType.SingleLine;
        [SerializeField] bool m_HideMobileInput, m_HideSoftKeyboard;
        [SerializeField] CharacterValidation m_CharacterValidation = CharacterValidation.None;
        [SerializeField] string m_RegexValue = "";
        [SerializeField] float m_GlobalPointSize = 14;
        [SerializeField] int m_CharacterLimit;
        [SerializeField] SubmitEvent m_OnEndEdit = new SubmitEvent(), m_OnSubmit = new SubmitEvent();
        [SerializeField] SelectionEvent m_OnSelect = new SelectionEvent(), m_OnDeselect = new SelectionEvent();
        [SerializeField] TextSelectionEvent m_OnTextSelection = new TextSelectionEvent(), m_OnEndTextSelection = new TextSelectionEvent();
        [SerializeField] OnChangeEvent m_OnValueChanged = new OnChangeEvent();
        [SerializeField] TouchScreenKeyboardEvent m_OnTouchScreenKeyboardStatusChanged = new TouchScreenKeyboardEvent();
        [SerializeField] Color m_CaretColor = new Color(50f / 255f, 50f / 255f, 50f / 255f, 1f);
        [SerializeField] bool m_CustomCaretColor;
        [SerializeField] Color m_SelectionColor = new Color(168f / 255f, 206f / 255f, 255f / 255f, 192f / 255f);
        [SerializeField] [TextArea(5, 10)] protected string m_Text = "";
        [SerializeField] float m_CaretBlinkRate = 0.85f;
        [SerializeField] int m_CaretWidth = 1;
        [SerializeField] bool m_ReadOnly, m_RichText = true, m_ResetOnDeActivation = true, m_RestoreOriginalTextOnEscape = true, m_OnFocusSelectAll = true, m_isRichTextEditingAllowed, m_ShouldActivateOnSelect = true;
        [SerializeField] TMP_FontAsset m_GlobalFontAsset;
        [SerializeField] int m_LineLimit;
        [SerializeField] protected TMP_InputValidator m_InputValidator;
        internal readonly TextEditCore m_Core = new TextEditCore();
        protected TMP_InputField() { }
        public string text { get => m_Text; set => SetText(value, true); }
        public void SetTextWithoutNotify(string input) => SetText(input, false);
        void SetText(string value, bool sendCallback)
        {
            value ??= "";
            if (m_CharacterLimit > 0 && value.Length > m_CharacterLimit) value = value.Substring(0, m_CharacterLimit);
            if (m_Text == value) return;
            m_Text = value; m_Core.text = value;
            UpdateLabel();
            if (sendCallback) m_OnValueChanged.Invoke(m_Text);
        }
        public bool isFocused => m_Core.focused;
        public float caretBlinkRate { get => m_CaretBlinkRate; set => m_CaretBlinkRate = value; }
        public int caretWidth { get => m_CaretWidth; set => m_CaretWidth = value; }
        public RectTransform textViewport { get => m_TextViewport; set => m_TextViewport = value; }
        public TMP_Text textComponent { get => m_TextComponent; set { m_TextComponent = value; UpdateLabel(); } }
        public Graphic placeholder { get => m_Placeholder; set { m_Placeholder = value; UpdateLabel(); } }
        public Scrollbar verticalScrollbar { get => m_VerticalScrollbar; set => m_VerticalScrollbar = value; }
        public float scrollSensitivity { get; set; } = 1.0f;
        public Color caretColor { get => m_CustomCaretColor ? m_CaretColor : (textComponent ? textComponent.color : Color.black); set => m_CaretColor = value; }
        public bool customCaretColor { get => m_CustomCaretColor; set => m_CustomCaretColor = value; }
        public Color selectionColor { get => m_SelectionColor; set => m_SelectionColor = value; }
        public SubmitEvent onEndEdit { get => m_OnEndEdit; set => m_OnEndEdit = value; }
        public SubmitEvent onSubmit { get => m_OnSubmit; set => m_OnSubmit = value; }
        public SelectionEvent onSelect { get => m_OnSelect; set => m_OnSelect = value; }
        public SelectionEvent onDeselect { get => m_OnDeselect; set => m_OnDeselect = value; }
        public TextSelectionEvent onTextSelection { get => m_OnTextSelection; set => m_OnTextSelection = value; }
        public TextSelectionEvent onEndTextSelection { get => m_OnEndTextSelection; set => m_OnEndTextSelection = value; }
        public OnChangeEvent onValueChanged { get => m_OnValueChanged; set => m_OnValueChanged = value; }
        public TouchScreenKeyboardEvent onTouchScreenKeyboardStatusChanged { get => m_OnTouchScreenKeyboardStatusChanged; set => m_OnTouchScreenKeyboardStatusChanged = value; }
        public OnValidateInput onValidateInput { get; set; }
        public int characterLimit { get => m_CharacterLimit; set => m_CharacterLimit = Mathf.Max(0, value); }
        public float pointSize { get => m_GlobalPointSize; set { m_GlobalPointSize = value; if (m_TextComponent) m_TextComponent.fontSize = value; } }
        public TMP_FontAsset fontAsset { get => m_GlobalFontAsset; set { m_GlobalFontAsset = value; if (m_TextComponent) m_TextComponent.font = value; } }
        public bool onFocusSelectAll { get => m_OnFocusSelectAll; set => m_OnFocusSelectAll = value; }
        public bool resetOnDeActivation { get => m_ResetOnDeActivation; set => m_ResetOnDeActivation = value; }
        public bool restoreOriginalTextOnEscape { get => m_RestoreOriginalTextOnEscape; set => m_RestoreOriginalTextOnEscape = value; }
        public bool isRichTextEditingAllowed { get => m_isRichTextEditingAllowed; set => m_isRichTextEditingAllowed = value; }
        public ContentType contentType { get => m_ContentType; set => m_ContentType = value; }
        public LineType lineType { get => m_LineType; set => m_LineType = value; }
        public int lineLimit { get => m_LineLimit; set => m_LineLimit = value; }
        public InputType inputType { get => m_InputType; set => m_InputType = value; }
        public TouchScreenKeyboardType keyboardType { get => m_KeyboardType; set => m_KeyboardType = value; }
        public CharacterValidation characterValidation { get => m_CharacterValidation; set => m_CharacterValidation = value; }
        public TMP_InputValidator inputValidator { get => m_InputValidator; set => m_InputValidator = value; }
        public bool readOnly { get => m_ReadOnly; set => m_ReadOnly = value; }
        public bool richText { get => m_RichText; set => m_RichText = value; }
        public bool multiLine => m_LineType != LineType.SingleLine;
        public char asteriskChar { get => m_AsteriskChar; set => m_AsteriskChar = value; }
        public bool wasCanceled { get; private set; }
        public bool shouldHideMobileInput { get => m_HideMobileInput; set => m_HideMobileInput = value; }
        public bool shouldHideSoftKeyboard { get => m_HideSoftKeyboard; set => m_HideSoftKeyboard = value; }
        public bool shouldActivateOnSelect { get => m_ShouldActivateOnSelect; set => m_ShouldActivateOnSelect = value; }
        public TouchScreenKeyboard touchScreenKeyboard => null;
        public int caretPosition { get => m_Text.Length; set { } }
        public int stringPosition { get => m_Text.Length; set { } }
        public int selectionAnchorPosition { get => m_Text.Length; set { } }
        public int selectionFocusPosition { get => m_Text.Length; set { } }
        public int selectionStringAnchorPosition { get => m_Text.Length; set { } }
        public int selectionStringFocusPosition { get => m_Text.Length; set { } }
        public string regexValue { get => m_RegexValue; set => m_RegexValue = value; }
        public virtual void Rebuild(CanvasUpdate update) { }
        public virtual void LayoutComplete() { }
        public virtual void GraphicUpdateComplete() { }
        public virtual void CalculateLayoutInputHorizontal() { }
        public virtual void CalculateLayoutInputVertical() { }
        public virtual float minWidth => 0; public virtual float preferredWidth => m_TextComponent != null ? m_TextComponent.preferredWidth : 0; public virtual float flexibleWidth => -1;
        public virtual float minHeight => 0; public virtual float preferredHeight => m_TextComponent != null ? m_TextComponent.preferredHeight : 0; public virtual float flexibleHeight => -1;
        public virtual int layoutPriority => 1;
        protected override void OnEnable() { base.OnEnable(); m_Core.text = m_Text; UpdateLabel(); }
        protected override void OnDisable() { DeactivateInputField(); base.OnDisable(); }
        public override void UIRefresh() { base.UIRefresh(); m_Core.text = m_Text; UpdateLabel(); }
        public void ActivateInputField() { if (m_TextComponent == null || !IsActive() || !IsInteractable()) return; m_Core.focused = true; m_Core.originalText = m_Text; wasCanceled = false; }
        public void DeactivateInputField(bool clearSelection = false)
        {
            if (!m_Core.focused) return;
            m_Core.focused = false; UpdateLabel();
            m_OnEndEdit.Invoke(m_Text);
        }
        public void MoveTextEnd(bool shift) { }
        public void MoveTextStart(bool shift) { }
        public void MoveToEndOfLine(bool shift, bool ctrl) { }
        public void MoveToStartOfLine(bool shift, bool ctrl) { }
        public void ForceLabelUpdate() => UpdateLabel();
        public void SetGlobalPointSize(float pointSize) => this.pointSize = pointSize;
        public void SetGlobalFontAsset(TMP_FontAsset fontAsset) => this.fontAsset = fontAsset;
        public override void OnSelect(BaseEventData eventData) { base.OnSelect(eventData); m_OnSelect.Invoke(m_Text); if (shouldActivateOnSelect) ActivateInputField(); }
        public override void OnDeselect(BaseEventData eventData) { DeactivateInputField(); m_OnDeselect.Invoke(m_Text); base.OnDeselect(eventData); }
        public virtual void OnPointerClick(PointerEventData eventData) { if (eventData.button == PointerEventData.InputButton.Left) ActivateInputField(); }
        public virtual void OnBeginDrag(PointerEventData eventData) { }
        public virtual void OnDrag(PointerEventData eventData) { }
        public virtual void OnEndDrag(PointerEventData eventData) { }
        public virtual void OnScroll(PointerEventData eventData) { }
        public virtual void OnSubmit(BaseEventData eventData) { if (!IsActive() || !IsInteractable()) return; if (!m_Core.focused) ActivateInputField(); }
        public virtual void OnCancel(BaseEventData eventData) { }
        public virtual void OnUpdateSelected(BaseEventData eventData)
        {
            if (!m_Core.focused) return;
            m_Core.characterLimit = m_CharacterLimit; m_Core.lineType = (int)m_LineType; m_Core.readOnly = m_ReadOnly;
            m_Core.contentType = m_CharacterValidation switch { CharacterValidation.Integer => 2, CharacterValidation.Decimal => 3, CharacterValidation.Digit => 8, CharacterValidation.Alphanumeric => 4, CharacterValidation.Name => 5, CharacterValidation.EmailAddress => 6, _ => (int)m_ContentType };
            Func<string, int, char, char> validator = null;
            if (onValidateInput != null) validator = (t, i, c) => onValidateInput(t, i, c);
            else if (m_CharacterValidation == CharacterValidation.CustomValidator && m_InputValidator != null) validator = (t, i, c) => { string s = t; int p = i; return m_InputValidator.Validate(ref s, ref p, c); };
            else if (m_CharacterValidation == CharacterValidation.Regex && !string.IsNullOrEmpty(m_RegexValue)) validator = (t, i, c) => System.Text.RegularExpressions.Regex.IsMatch(c.ToString(), m_RegexValue) ? c : '\0';
            int r = m_Core.Process(validator, out bool changed);
            if (changed) { m_Text = m_Core.text; m_OnValueChanged.Invoke(m_Text); }
            if (r == 2) { m_OnSubmit.Invoke(m_Text); DeactivateInputField(); EventSystem.current?.SetSelectedGameObject(null); }
            else if (r == 3) { wasCanceled = true; if (m_RestoreOriginalTextOnEscape) m_Text = m_Core.text = m_Core.originalText; DeactivateInputField(); EventSystem.current?.SetSelectedGameObject(null); }
            UpdateLabel();
            eventData.Use();
        }
        protected void UpdateLabel()
        {
            if (m_TextComponent != null) m_TextComponent.text = m_Core.focused ? m_Core.Display(false) : (m_ContentType == ContentType.Password || m_ContentType == ContentType.Pin ? new string(m_AsteriskChar, m_Text.Length) : m_Text);
            if (m_Placeholder != null) m_Placeholder.enabled = string.IsNullOrEmpty(m_Text);
        }
        public virtual void ProcessEvent(Event e) { }
    }
    [Serializable]
    public abstract class TMP_InputValidator : ScriptableObject { public abstract char Validate(ref string text, ref int pos, char ch); }

    [AddComponentMenu("UI/Dropdown - TextMeshPro", 35)]
    [RequireComponent(typeof(RectTransform))]
    public class TMP_Dropdown : Selectable, IPointerClickHandler, ISubmitHandler, ICancelHandler, IDropdownPopup
    {
        [Serializable] public class OptionData { [SerializeField] string m_Text; [SerializeField] Sprite m_Image; [SerializeField] Color m_Color = Color.white; public string text { get => m_Text; set => m_Text = value; } public Sprite image { get => m_Image; set => m_Image = value; } public Color color { get => m_Color; set => m_Color = value; } public OptionData() { } public OptionData(string text) { this.text = text; } public OptionData(Sprite image) { this.image = image; } public OptionData(string text, Sprite image, Color color) { this.text = text; this.image = image; this.color = color; } }
        [Serializable] public class OptionDataList { [SerializeField] List<OptionData> m_Options = new List<OptionData>(); public List<OptionData> options { get => m_Options; set => m_Options = value; } }
        [Serializable] public class DropdownEvent : UnityEvent<int> { }
        [SerializeField] RectTransform m_Template;
        [SerializeField] TMP_Text m_CaptionText; [SerializeField] Image m_CaptionImage; [SerializeField] Graphic m_Placeholder;
        [SerializeField] TMP_Text m_ItemText; [SerializeField] Image m_ItemImage;
        [SerializeField] int m_Value;
        [SerializeField] OptionDataList m_Options = new OptionDataList();
        [SerializeField] DropdownEvent m_OnValueChanged = new DropdownEvent();
        [SerializeField] float m_AlphaFadeSpeed = 0.15f;
        [SerializeField] bool m_MultiSelect;
        protected TMP_Dropdown() { }
        public RectTransform template { get => m_Template; set => m_Template = value; }
        public TMP_Text captionText { get => m_CaptionText; set { m_CaptionText = value; RefreshShownValue(); } }
        public Image captionImage { get => m_CaptionImage; set { m_CaptionImage = value; RefreshShownValue(); } }
        public Graphic placeholder { get => m_Placeholder; set { m_Placeholder = value; RefreshShownValue(); } }
        public TMP_Text itemText { get => m_ItemText; set => m_ItemText = value; }
        public Image itemImage { get => m_ItemImage; set => m_ItemImage = value; }
        public List<OptionData> options { get => m_Options.options; set { m_Options.options = value; RefreshShownValue(); } }
        public DropdownEvent onValueChanged { get => m_OnValueChanged; set => m_OnValueChanged = value; }
        public float alphaFadeSpeed { get => m_AlphaFadeSpeed; set => m_AlphaFadeSpeed = value; }
        public bool MultiSelect { get => m_MultiSelect; set => m_MultiSelect = value; }
        public int value { get => m_Value; set => SetValue(value); }
        public void SetValueWithoutNotify(int input) => SetValue(input, false);
        void SetValue(int value, bool sendCallback = true)
        {
            if (Application.isPlaying && (value == m_Value || options.Count == 0)) return;
            m_Value = Mathf.Clamp(value, m_Placeholder ? -1 : 0, Mathf.Max(0, options.Count - 1));
            RefreshShownValue();
            if (sendCallback) m_OnValueChanged.Invoke(m_Value);
        }
        public bool IsExpanded => UIRuntime.popupOwner == (IDropdownPopup)this;
        protected override void Awake() { base.Awake(); if (m_Template) m_Template.gameObject.SetActive(false); }
        protected override void Start() { base.Start(); RefreshShownValue(); }
        public override void UIRefresh() { base.UIRefresh(); if (m_Template) m_Template.gameObject.m_ActiveSelf = false; RefreshShownValue(); }
        public void RefreshShownValue()
        {
            var data = options.Count > 0 && m_Value >= 0 && m_Value < options.Count ? options[m_Value] : new OptionData("");
            if (m_CaptionText) m_CaptionText.text = data.text ?? "";
            if (m_CaptionImage) { m_CaptionImage.sprite = data.image; m_CaptionImage.enabled = m_CaptionImage.sprite != null; }
            if (m_Placeholder) m_Placeholder.enabled = options.Count == 0 || m_Value == -1;
        }
        public void AddOptions(List<OptionData> options) { this.options.AddRange(options); RefreshShownValue(); }
        public void AddOptions(List<string> options) { foreach (var s in options) this.options.Add(new OptionData(s)); RefreshShownValue(); }
        public void AddOptions(List<Sprite> options) { foreach (var s in options) this.options.Add(new OptionData(s)); RefreshShownValue(); }
        public void ClearOptions() { options.Clear(); m_Value = 0; RefreshShownValue(); }
        public void Show() { if (!IsActive() || !IsInteractable() || IsExpanded) return; UIRuntime.OpenPopup(this); }
        public void Hide() { if (IsExpanded) UIRuntime.ClosePopup(); }
        public virtual void OnPointerClick(PointerEventData eventData) => Show();
        public virtual void OnSubmit(BaseEventData eventData) => Show();
        public virtual void OnCancel(BaseEventData eventData) => Hide();
        int IDropdownPopup.Count => options.Count;
        string IDropdownPopup.Label(int i) => options[i].text;
        int IDropdownPopup.Current => m_Value;
        void IDropdownPopup.Choose(int i) { value = i; }
        RectTransform IDropdownPopup.Rect => (RectTransform)transform;
        Graphic IDropdownPopup.Caption => m_CaptionText;
        RectTransform IDropdownPopup.Template => m_Template;
        Component IDropdownPopup.Owner => this;
    }
}

namespace UnityEngine.TextCore
{
    [Serializable]
    public struct FaceInfo
    {
        public string familyName { get; set; } public string styleName { get; set; } public int pointSize { get; set; } public float scale { get; set; }
        public float lineHeight { get; set; } public float ascentLine { get; set; } public float capLine { get; set; } public float meanLine { get; set; } public float baseline { get; set; } public float descentLine { get; set; }
        public float superscriptOffset { get; set; } public float superscriptSize { get; set; } public float subscriptOffset { get; set; } public float subscriptSize { get; set; }
        public float underlineOffset { get; set; } public float underlineThickness { get; set; } public float strikethroughOffset { get; set; } public float strikethroughThickness { get; set; } public float tabWidth { get; set; }
    }
}

namespace UnityEngine
{
    public partial class TouchScreenKeyboard { public enum Status { Visible = 0, Done = 1, Canceled = 2, LostFocus = 3 } }
}
