// Anvil — LineRenderer and TrailRenderer. The renderer builds a camera-facing ribbon from the points each frame.
using System;
using System.Collections.Generic;
using Anvil;

namespace UnityEngine
{

    // shared width/colour settings of lines and trails
    public abstract class LineLikeRenderer : Renderer
    {
        internal AnimationCurve m_WidthCurve = new AnimationCurve(new Keyframe(0, 1));
        internal Gradient m_Gradient = new Gradient();
        internal override bool UsesDefaultMaterial => false; // like Unity: no material until you assign one (drawn magenta)
        public float widthMultiplier { get; set; } = 1f;
        public AnimationCurve widthCurve { get => m_WidthCurve; set => m_WidthCurve = value ?? new AnimationCurve(new Keyframe(0, 1)); }
        public float startWidth
        {
            get => m_WidthCurve.length > 0 ? m_WidthCurve[0].value * widthMultiplier : widthMultiplier;
            set { SetWidthEnds(value, endWidth); }
        }
        public float endWidth
        {
            get => m_WidthCurve.length > 0 ? m_WidthCurve[m_WidthCurve.length - 1].value * widthMultiplier : widthMultiplier;
            set { SetWidthEnds(startWidth, value); }
        }
        void SetWidthEnds(float a, float b)
        {
            float m = widthMultiplier == 0 ? 1 : widthMultiplier;
            if (Math.Abs(a - b) < 1e-7f) m_WidthCurve = new AnimationCurve(new Keyframe(0, a / m));
            else m_WidthCurve = new AnimationCurve(new Keyframe(0, a / m), new Keyframe(1, b / m));
        }
        public Gradient colorGradient { get => m_Gradient; set => m_Gradient = value ?? new Gradient(); }
        public Color startColor
        {
            get => m_Gradient.Evaluate(0);
            set { SetColorEnds(value, endColor); }
        }
        public Color endColor
        {
            get => m_Gradient.Evaluate(1);
            set { SetColorEnds(startColor, value); }
        }
        void SetColorEnds(Color a, Color b)
        {
            var g = new Gradient();
            g.SetKeys(new[] { new GradientColorKey(a, 0), new GradientColorKey(b, 1) }, new[] { new GradientAlphaKey(a.a, 0), new GradientAlphaKey(b.a, 1) });
            m_Gradient = g;
        }
        public int numCornerVertices { get; set; }
        public int numCapVertices { get; set; }
        public LineAlignment alignment { get; set; } = LineAlignment.View;
        public LineTextureMode textureMode { get; set; } = LineTextureMode.Stretch;
        public Vector2 textureScale { get; set; } = Vector2.one;
        public float shadowBias { get; set; } = 0.5f;
        public bool generateLightingData { get; set; }
        public SpriteMaskInteraction maskInteraction { get; set; }
        internal float WidthAt(float t) => Math.Max(0, m_WidthCurve.Evaluate(t) * widthMultiplier);
        internal Color ColorAt(float t) => m_Gradient.Evaluate(t);
        // world-space points for the renderer
        internal abstract int WorldPoints(List<Vector3> pts, List<float> ts);
        internal override Bounds LocalBoundsOverride()
        {
            var p = new List<Vector3>(); var t = new List<float>(); WorldPoints(p, t);
            if (p.Count == 0) return default;
            var inv = transform.worldToLocalMatrix; Vector3 mn = inv.MultiplyPoint3x4(p[0]), mx = mn;
            foreach (var q in p) { var l = inv.MultiplyPoint3x4(q); mn = Vector3.Min(mn, l); mx = Vector3.Max(mx, l); }
            return new Bounds((mn + mx) * 0.5f, mx - mn);
        }
        internal override void CopyFromInternal(Component src)
        {
            base.CopyFromInternal(src);
            var l = (LineLikeRenderer)src;
            m_WidthCurve = new AnimationCurve(l.m_WidthCurve.keys);
            var g = new Gradient(); g.SetKeys(l.m_Gradient.colorKeys, l.m_Gradient.alphaKeys); g.mode = l.m_Gradient.mode; m_Gradient = g;
        }
        public void BakeMesh(Mesh mesh, bool useTransform = false) => BakeMesh(mesh, Camera.main, useTransform);
        public void BakeMesh(Mesh mesh, Camera camera, bool useTransform = false)
        {
            if (mesh == null) return;
            var pts = new List<Vector3>(); var ts = new List<float>(); WorldPoints(pts, ts);
            var v = new List<Vector3>(); var tri = new List<int>(); var col = new List<Color>(); var uv = new List<Vector2>();
            Vector3 view = camera != null ? camera.transform.forward : Vector3.forward;
            var inv = transform.worldToLocalMatrix;
            for (int i = 0; i < pts.Count; i++)
            {
                Vector3 dir = i + 1 < pts.Count ? pts[i + 1] - pts[i] : (i > 0 ? pts[i] - pts[i - 1] : Vector3.right);
                Vector3 side = Vector3.Cross(dir, view).normalized * (WidthAt(ts[i]) * 0.5f);
                Vector3 a = pts[i] - side, b = pts[i] + side;
                if (useTransform) { a = inv.MultiplyPoint3x4(a); b = inv.MultiplyPoint3x4(b); }
                v.Add(a); v.Add(b); var c = ColorAt(ts[i]); col.Add(c); col.Add(c); uv.Add(new Vector2(ts[i], 0)); uv.Add(new Vector2(ts[i], 1));
                if (i > 0) { int k = v.Count - 4; tri.AddRange(new[] { k, k + 2, k + 1, k + 1, k + 2, k + 3 }); }
            }
            mesh.Clear(); mesh.SetVertices(v); mesh.SetColors(col); mesh.SetUVs(0, uv); mesh.SetTriangles(tri, 0); mesh.RecalculateNormals();
        }
    }

    public sealed class LineRenderer : LineLikeRenderer
    {
        internal Vector3[] m_Positions = { Vector3.zero, new Vector3(0, 0, 1) };
        internal int m_Count = 2;
        public int positionCount
        {
            get => m_Count;
            set { value = Math.Max(0, value); if (value > m_Positions.Length) Array.Resize(ref m_Positions, Math.Max(value, m_Positions.Length * 2)); m_Count = value; }
        }
        public bool useWorldSpace { get; set; } = true;
        public bool loop { get; set; }
        public void SetPosition(int index, Vector3 position)
        {
            if (index < 0 || index >= m_Count) { Debug.LogError($"LineRenderer.SetPosition index out of bounds! Index: {index}, positionCount: {m_Count}"); return; }
            m_Positions[index] = position;
        }
        public Vector3 GetPosition(int index)
        {
            if (index < 0 || index >= m_Count) throw new IndexOutOfRangeException($"LineRenderer.GetPosition index out of bounds! Index: {index}, positionCount: {m_Count}");
            return m_Positions[index];
        }
        public void SetPositions(Vector3[] positions)
        {
            if (positions == null) return;
            int n = Math.Min(positions.Length, m_Count);
            Array.Copy(positions, m_Positions, n);
        }
        public int GetPositions(Vector3[] positions)
        {
            if (positions == null) return 0;
            int n = Math.Min(positions.Length, m_Count); Array.Copy(m_Positions, positions, n); return n;
        }
        public void Simplify(float tolerance)
        {
            if (m_Count < 3) return;
            var pts = new List<Vector3>(); for (int i = 0; i < m_Count; i++) pts.Add(m_Positions[i]);
            var keep = new bool[pts.Count]; keep[0] = keep[pts.Count - 1] = true;
            void Rdp(int a, int b)
            {
                float best = -1; int idx = -1;
                for (int i = a + 1; i < b; i++) { float d = HandleDist(pts[i], pts[a], pts[b]); if (d > best) { best = d; idx = i; } }
                if (best > tolerance && idx >= 0) { keep[idx] = true; Rdp(a, idx); Rdp(idx, b); }
            }
            Rdp(0, pts.Count - 1);
            var res = new List<Vector3>(); for (int i = 0; i < pts.Count; i++) if (keep[i]) res.Add(pts[i]);
            m_Positions = res.ToArray(); m_Count = res.Count;
        }
        static float HandleDist(Vector3 p, Vector3 a, Vector3 b) { var ab = b - a; float l = ab.sqrMagnitude; if (l < 1e-12f) return (p - a).magnitude; float t = Mathf.Clamp01(Vector3.Dot(p - a, ab) / l); return (a + ab * t - p).magnitude; }
        internal override int WorldPoints(List<Vector3> pts, List<float> ts)
        {
            pts.Clear(); ts.Clear();
            if (m_Count == 0) return 0;
            var m = transform.localToWorldMatrix;
            int n = m_Count + (loop && m_Count > 2 ? 1 : 0);
            float total = 0; var tmp = new Vector3[n];
            for (int i = 0; i < n; i++) { var p = m_Positions[i % m_Count]; tmp[i] = useWorldSpace ? p : m.MultiplyPoint3x4(p); if (i > 0) total += (tmp[i] - tmp[i - 1]).magnitude; }
            float acc = 0;
            for (int i = 0; i < n; i++)
            {
                if (i > 0) acc += (tmp[i] - tmp[i - 1]).magnitude;
                pts.Add(tmp[i]); ts.Add(total > 0 ? acc / total : (n > 1 ? (float)i / (n - 1) : 0));
            }
            return n;
        }
        internal override void CopyFromInternal(Component src)
        {
            base.CopyFromInternal(src);
            var l = (LineRenderer)src;
            m_Positions = (Vector3[])l.m_Positions.Clone(); m_Count = l.m_Count;
        }
    }

    public sealed class TrailRenderer : LineLikeRenderer
    {
        internal struct Pt { public Vector3 p; public float t; }
        internal readonly List<Pt> m_Points = new List<Pt>();
        public float time { get; set; } = 5f;
        public float minVertexDistance { get; set; } = 0.1f;
        public bool emitting { get; set; } = true;
        public bool autodestruct { get; set; }
        public int positionCount => m_Points.Count;
        public TrailRenderer() { SetDefaultWidth(); }
        void SetDefaultWidth() { m_WidthCurve = new AnimationCurve(new Keyframe(0, 1)); }
        public Vector3 GetPosition(int index) => m_Points[index].p;
        public int GetPositions(Vector3[] positions) { int n = Math.Min(positions.Length, m_Points.Count); for (int i = 0; i < n; i++) positions[i] = m_Points[i].p; return n; }
        public void SetPosition(int index, Vector3 position) { if (index >= 0 && index < m_Points.Count) m_Points[index] = new Pt { p = position, t = m_Points[index].t }; }
        public void SetPositions(Vector3[] positions) { for (int i = 0; i < positions.Length && i < m_Points.Count; i++) SetPosition(i, positions[i]); }
        public void AddPosition(Vector3 position) => m_Points.Add(new Pt { p = position, t = Time.time });
        public void AddPositions(Vector3[] positions) { foreach (var p in positions) AddPosition(p); }
        public void Clear() => m_Points.Clear();
        internal override void OnAddedInternal() { base.OnAddedInternal(); Effects.trails.Add(this); }
        internal override void OnRemovedInternal() { Effects.trails.Remove(this); }
        internal void Step()
        {
            if (m_Destroyed) return;
            float now = Time.time;
            // drop points older than 'time'
            int drop = 0; while (drop < m_Points.Count && now - m_Points[drop].t > time) drop++;
            if (drop > 0) m_Points.RemoveRange(0, drop);
            if (emitting && m_GameObject.activeInHierarchy && m_Enabled)
            {
                var p = transform.position;
                if (m_Points.Count == 0 || (m_Points[m_Points.Count - 1].p - p).magnitude >= minVertexDistance) m_Points.Add(new Pt { p = p, t = now });
            }
            if (autodestruct && m_Points.Count == 0 && !emitting) Object.Destroy(m_GameObject);
        }
        internal override int WorldPoints(List<Vector3> pts, List<float> ts)
        {
            pts.Clear(); ts.Clear();
            float now = Time.time;
            // newest first: t = 0 at the object, 1 at the oldest point
            var head = transform.position;
            bool addHead = emitting && m_Points.Count > 0 && (m_Points[m_Points.Count - 1].p - head).sqrMagnitude > 1e-10f;
            if (addHead) { pts.Add(head); ts.Add(0); }
            for (int i = m_Points.Count - 1; i >= 0; i--) { pts.Add(m_Points[i].p); ts.Add(time > 0 ? Mathf.Clamp01((now - m_Points[i].t) / time) : 0); }
            return pts.Count;
        }
    }

    // particle systems and trails advance after LateUpdate, like Unity
    internal static class Effects
    {
        internal static readonly HashSet<TrailRenderer> trails = new HashSet<TrailRenderer>();
        internal static readonly HashSet<ParticleSystem> systems = new HashSet<ParticleSystem>();
        internal static void Reset() { trails.Clear(); systems.Clear(); }
        internal static void Update()
        {
            if (systems.Count > 0) foreach (var ps in new List<ParticleSystem>(systems)) { try { ps.FrameUpdate(); } catch (Exception e) { Debug.LogException(e); } }
            if (trails.Count > 0) foreach (var t in new List<TrailRenderer>(trails)) t.Step();
        }
    }
}
