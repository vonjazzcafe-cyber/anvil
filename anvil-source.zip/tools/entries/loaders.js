// 3D model loaders (bundled into vendor/loaders.js; loaded only when a model is imported or opened)
export { GLTFLoader } from '../node_modules/three/examples/jsm/loaders/GLTFLoader.js';
export { FBXLoader } from '../node_modules/three/examples/jsm/loaders/FBXLoader.js';
export { OBJLoader } from '../node_modules/three/examples/jsm/loaders/OBJLoader.js';
export { STLLoader } from '../node_modules/three/examples/jsm/loaders/STLLoader.js';
