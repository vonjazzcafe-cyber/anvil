#!/usr/bin/env bash
# Packs the static site (plus the C# sources, so the repository can rebuild itself) into anvil-site.zip.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$ROOT/../dist}"
mkdir -p "$OUT"
STAGE="$(mktemp -d)"
cd "$ROOT"
cp -r index.html sw.js README.md editor vendor engine "$STAGE/"
# the C# sources and build tools go in one zip, so the site stays under GitHub's 100-files-per-upload limit
SRC="$(mktemp -d)"
mkdir -p "$SRC/src" "$SRC/tools"
for d in Engine Host; do
  mkdir -p "$SRC/src/$d"
  cp src/$d/*.cs src/$d/*.csproj "$SRC/src/$d/"
done
cp tools/build.sh tools/package.sh tools/sw-manifest.py tools/package.json "$SRC/tools/"
cp -r tools/entries "$SRC/tools/"
cp nuget.config "$SRC/"
(cd "$SRC" && zip -qr -9 "$STAGE/anvil-source.zip" .)
rm -rf "$SRC"
python3 "$ROOT/tools/sw-manifest.py" "$STAGE"
rm -f "$OUT/anvil-site.zip"
(cd "$STAGE" && zip -qr -9 "$OUT/anvil-site.zip" .)
echo "files: $(cd "$STAGE" && find . -type f | wc -l)"
rm -rf "$STAGE"
ls -la "$OUT/anvil-site.zip"
